-- READ ONLY: checks how the live server is set up. Changes nothing (only SELECT). Safe on the live project.
-- Supabase: SQL Editor > New query > paste all > Run. Send a screenshot of the table it shows.
-- Each row: what was checked, OK or PROBLEM, and details.
select check_name, status, details from (
  -- 1. Old prototype rules (open to anyone, "proto ...") must be gone.
  select 1 as n, 'old prototype rules removed' as check_name,
    case when count(*) = 0 then 'OK' else 'PROBLEM' end as status,
    coalesce(string_agg(tablename || ': ' || policyname, ', '), 'none left') as details
  from pg_policies where policyname ilike 'proto%'
  union all
  -- 2. No rule on the family tables or storage that lets anon (not signed in) in.
  select 2, 'no family rule open to anon',
    case when count(*) = 0 then 'OK' else 'PROBLEM' end,
    coalesce(string_agg(schemaname || '.' || tablename || ': ' || policyname, ', '), 'none')
  from pg_policies
  where (tablename in ('circles','posts','reactions','comments','family_memberships','family_invites','family_messages')
         or (schemaname = 'storage' and tablename = 'objects'))
    and ('anon' = any(roles) or 'public' = any(roles))
    and permissive = 'PERMISSIVE'  -- restrictive rules only block, they never open access
  union all
  -- 3. anon has no table rights on the family tables.
  select 3, 'anon has no table rights',
    case when count(*) = 0 then 'OK' else 'PROBLEM' end,
    coalesce(string_agg(table_name || ':' || privilege_type, ', '), 'none')
  from information_schema.role_table_grants
  where grantee = 'anon' and table_schema = 'public'
    and table_name in ('circles','posts','reactions','comments','family_memberships','family_invites','family_messages')
  union all
  -- 4. Row security is on for every family table.
  select 4, 'row security on',
    case when bool_and(c.relrowsecurity) then 'OK' else 'PROBLEM' end,
    string_agg(c.relname || '=' || c.relrowsecurity::text, ', ')
  from pg_class c join pg_namespace s on s.oid = c.relnamespace
  where s.nspname = 'public' and c.relname in ('circles','posts','reactions','comments','family_memberships','family_invites','family_messages')
  union all
  -- 5. The secure version (v3) and the leave/remove functions (v4) are installed.
  select 5, 'v3 + v4 functions installed',
    case when count(*) = 4 then 'OK' else 'PROBLEM' end,
    coalesce(string_agg(p.proname, ', '), 'none')
  from pg_proc p join pg_namespace s on s.oid = p.pronamespace
  where s.nspname = 'public' and p.proname in ('family_circle_version','leave_family','remove_family_member','family_is_owner')
  union all
  -- 6. Private buckets (family, community, print) are not public.
  select 6, 'media buckets private',
    case when bool_or(public) then 'PROBLEM' else 'OK' end,
    coalesce(string_agg(id || '=' || public::text, ', '), 'none')
  from storage.buckets where id in ('moments','community','print')
  union all
  -- 7. The family chat outbox column (family-chat-outbox.sql), for information.
  select 7, 'chat outbox column (optional)',
    case when count(*) = 1 then 'OK' else 'not run yet' end,
    case when count(*) = 1 then 'client_id present' else 'family-chat-outbox.sql not run' end
  from information_schema.columns
  where table_schema = 'public' and table_name = 'family_messages' and column_name = 'client_id'
) r order by n;
