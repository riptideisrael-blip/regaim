// Supabase Edge Function: ai
// One gate for all of Moments' AI. The app never holds an AI key: this function checks the account, keeps a
// monthly budget per family (table ai_usage, see ai-gate.sql), and forwards the request to Claude or Gemini.
// Nothing sent here is stored: no pictures, no questions, no answers. Only a call counter per family per month.
//
// Secrets (Supabase → Edge Functions → Secrets):
//   ANTHROPIC_API_KEY  – required (descriptions, questions, stories)
//   GEMINI_API_KEY     – optional (comic drawings)
//   AI_MONTHLY_LIMIT   – optional, requests per family per month (default 300)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ANTHROPIC = Deno.env.get("ANTHROPIC_API_KEY") ?? "";
const GEMINI = Deno.env.get("GEMINI_API_KEY") ?? "";
const LIMIT = Number(Deno.env.get("AI_MONTHLY_LIMIT") ?? "300") || 300;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const CLAUDE_MODELS = new Set(["claude-sonnet-5-5", "claude-haiku-4-5-20251001"]);
const GEMINI_MODELS = new Set(["gemini-3.1-flash-image"]);
const MAX_TOKENS = 4000;
const MAX_IMAGES = 8; // 3 for a description, 8 for "find the exact moment"
const MAX_BYTES = 8 * 1024 * 1024;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

// deno-lint-ignore no-explicit-any
function countClaudeImages(messages: any[]): number {
  let n = 0;
  for (const m of messages ?? []) {
    if (Array.isArray(m?.content)) for (const b of m.content) if (b?.type === "image") n++;
  }
  return n;
}

// deno-lint-ignore no-explicit-any
function countGeminiImages(body: any): number {
  let n = 0;
  for (const c of body?.contents ?? []) for (const p of c?.parts ?? []) if (p?.inline_data || p?.inlineData) n++;
  return n;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const raw = await req.text();
    if (raw.length > MAX_BYTES) return json({ error: "too large" }, 413);
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
    const { data: u } = await userClient.auth.getUser();
    const uid = u?.user?.id;
    if (!uid) return json({ error: "sign in" }, 401);
    // Guest sign-ins can't spend the family AI budget (otherwise anyone could script free AI on our key).
    if ((u?.user as { is_anonymous?: boolean })?.is_anonymous) return json({ error: "email or Google account needed" }, 403);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const body = JSON.parse(raw || "{}");
    const action = String(body.action ?? "");

    if (action === "usage") {
      const { data } = await admin.rpc("ai_left", { p_user: uid, p_limit: LIMIT });
      return json({ left: Math.max(0, Number(data ?? LIMIT)), limit: LIMIT, drawing: GEMINI.length > 0 });
    }

    if (action === "claude") {
      if (!ANTHROPIC) return json({ error: "not configured" }, 503);
      const b = body.body ?? {};
      const model = String(b.model ?? "");
      if (!CLAUDE_MODELS.has(model)) return json({ error: "model not allowed" }, 400);
      const messages = Array.isArray(b.messages) ? b.messages : [];
      const images = countClaudeImages(messages);
      if (images > MAX_IMAGES) return json({ error: "too many pictures" }, 400);
      const { data: used } = await admin.rpc("ai_use", { p_user: uid, p_images: images, p_limit: LIMIT });
      if (Number(used ?? -1) < 0) return json({ error: "budget" }, 429);
      const request: Record<string, unknown> = {
        model,
        max_tokens: Math.min(Number(b.max_tokens ?? 500) || 500, MAX_TOKENS),
        messages,
      };
      if (typeof b.system === "string") request.system = b.system;
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": ANTHROPIC, "anthropic-version": "2023-06-01" },
        body: JSON.stringify(request),
      });
      return new Response(await r.text(), { status: r.status, headers: { ...cors, "Content-Type": "application/json" } });
    }

    if (action === "gemini") {
      if (!GEMINI) return json({ error: "not configured" }, 503);
      const model = String(body.model ?? "");
      const version = body.version === "v1" ? "v1" : "v1beta";
      if (!GEMINI_MODELS.has(model)) return json({ error: "model not allowed" }, 400);
      const images = countGeminiImages(body.body);
      if (images > 4) return json({ error: "too many pictures" }, 400);
      const { data: used } = await admin.rpc("ai_use", { p_user: uid, p_images: images, p_limit: LIMIT });
      if (Number(used ?? -1) < 0) return json({ error: "budget" }, 429);
      const r = await fetch(`https://generativelanguage.googleapis.com/${version}/models/${model}:generateContent`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": GEMINI },
        body: JSON.stringify(body.body ?? {}),
      });
      return new Response(await r.text(), { status: r.status, headers: { ...cors, "Content-Type": "application/json" } });
    }

    return json({ error: "unknown action" }, 400);
  } catch (e) {
    return json({ error: String((e as Error)?.message ?? e).slice(0, 200) }, 500);
  }
});
