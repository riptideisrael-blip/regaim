// Supabase Edge Function: cartoon-film
// The app never sees the fal key. It asks this function to (1) reserve a credit, (2) draw a frame in a cartoon style,
// (3) draw the other frames like that first "anchor" character, (4) animate a drawn frame, (5) poll, (6) refund.
// Models and prompts can be changed from the film_settings table (SQL), without touching this code.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FAL_KEY = Deno.env.get("FAL_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// ---------- defaults (film_settings rows override them) ----------
const DEFAULTS: Record<string, string> = {
  style_model: "fal-ai/flux-pro/kontext",
  ref_model: "fal-ai/nano-banana/edit",
  // Used only when the app sends profile photos for the faces. Must accept prompt + image_urls.
  face_model: "fal-ai/nano-banana/edit",
  anim_model: "fal-ai/kling-video/v2.5-turbo/pro/image-to-video",
  // A second pass that makes an "edited" picture fully 3D-animated (the face/character models keep too much photo).
  // Set to "off" in film_settings to skip it.
  polish_model: "fal-ai/flux-pro/kontext",
  anim_cfg: "0.6",
  // Fully cartoon, never "half real": realistic faces with cartoon eyes look creepy (the uncanny valley).
  style_prompt:
    "Redraw this photo as a frame from a warm, family-friendly 3D animated movie (Pixar / Disney animation style). " +
    "Turn every person into a fully stylized cartoon character: simplified cute features, soft rounded face, small nose, " +
    "friendly natural-size eyes with a happy expression, smooth matte skin with no skin texture or pores, soft toy-like look. " +
    "Children look adorable and sweet and keep their real young age: a toddler stays a toddler, with chubby cheeks, " +
    "small baby-like features and thin light eyebrows, never adult-looking features or wrinkles. " +
    "The photo may be taken with a wide-angle lens very close to the face: fix that distortion, give natural proportions, " +
    "and frame the character a little wider so the face is not huge or stretched. " +
    "Keep what makes each person recognizable: hair color and hairstyle, clothing and its colors, pose. " +
    "Redraw the background and every object in the same 3D animated style, with bright soft colors and gentle warm lighting. " +
    "Nothing may look photographic or realistic. No distorted faces, no extra fingers, no creepy or eerie expressions.",
  // Image 1 = the real photo of this scene. Image 2 = the approved cartoon character (the anchor).
  ref_prompt:
    "Edit the FIRST image. Take everything from the first image: the composition, framing, camera angle, pose, action, " +
    "background, objects and clothes. The second image is ONLY a character reference: it shows the same people already drawn " +
    "as 3D animated movie characters. Redraw the first image as a frame of that same 3D animated movie (Pixar / Disney style), " +
    "and draw every person with exactly the same cartoon face, age, hair and art style as in the second image. " +
    "Do NOT copy the pose, framing or background of the second image. A toddler stays a toddler. " +
    "Fix wide-angle lens distortion so faces are not huge or stretched. Nothing may look photographic. " +
    "No distorted faces, no extra fingers, no creepy expressions.",
  // Image 1 = the scene. Images 2+ = the family's profile photos of the people in it (for their faces only).
  face_prompt:
    "Edit the FIRST image. Take everything from the first image: the composition, framing, camera angle, pose, action, " +
    "background, objects and clothes. The other images are ONLY close-up face photos of the people in the first image: " +
    "use them for the faces and nothing else. Redraw the first image as a frame from a warm, family-friendly 3D animated movie " +
    "(Pixar / Disney animation style), and make each person clearly recognizable from the face photos: same face shape, " +
    "eye shape and color, eyebrows, nose, smile, skin tone, hair color, texture and hairstyle, as a cute 3D cartoon character " +
    "of the same age. Do NOT use the pose, framing, background or clothes of the face photos. A toddler stays a toddler. " +
    "Smooth stylized skin, soft warm lighting, nothing photographic. Fix wide-angle lens distortion so the face is not huge " +
    "or stretched. No distorted faces, no extra fingers, no creepy expressions.",
  polish_prompt:
    "Turn this picture into a frame of a high-quality, warm 3D animated family movie (Pixar / Disney animation style). " +
    "Keep the same people, faces, hair, clothes, pose, composition and background, but render EVERYTHING as stylized 3D " +
    "animation: smooth stylized skin with no photographic texture, soft rounded features, friendly natural-size eyes, " +
    "soft cinematic lighting, rich gentle colors. A toddler stays a toddler. Nothing may look like a photo. " +
    "No distorted faces, no oversized eyes, no extra fingers, no creepy expressions.",
  // {action} = what the moment is about (from the app). Kling sees the picture; it continues what is in it.
  motion_prompt:
    "A scene from a warm 3D animated family movie. {action} Gentle, natural, slow motion that continues what is happening " +
    "in the picture. The characters' faces stay stable, cute and consistent. Soft, slow camera movement.",
  negative_prompt:
    "realistic, photographic, uncanny, creepy, scary, distorted face, deformed face, morphing face, melting, " +
    "extra fingers, extra limbs, bad anatomy, big sudden movements, flicker, blur, low quality",
  // ---------- personal children's books ----------
  // Must accept prompt + image_urls (several references).
  // GPT Image draws the pages too: it keeps every character the same from page to page (the cheaper
  // "fal-ai/nano-banana/edit" can be set here or in film_settings, at a cost in likeness and style).
  book_model: "openai/gpt-image-2/edit",
  // Images = 1–3 real photos of the child (face crops). {age} and {outfit} come from the app.
  book_character_prompt:
    "Create the main character of a children's picture book from the child in these photos. " +
    "A {age}. Full body, standing, friendly relaxed pose, facing the viewer, on a plain soft cream background. " +
    "Art style: warm, gentle hand-painted picture-book illustration (soft gouache and watercolor textures, " +
    "rounded friendly shapes, soft light, muted warm colors). Keep exactly what makes the child recognizable: " +
    "face shape, eye shape and color, eyebrows, nose, hair color, texture and hairstyle, skin tone. " +
    "Keep the child's real age and proportions. Outfit: {outfit}. Only this one child. " +
    "No text, no letters, no logos, no frame.",
  // The character the parent approves (the face every page copies) is drawn by a model that keeps likeness best.
  // openai/* models (GPT Image on fal) get their own input; any other model gets the book_model input.
  book_character_model: "openai/gpt-image-2/edit",
  // The look of the whole book (the pages copy the character's style). Change it here or in film_settings.
  book_style:
    "a still from a Pixar / Disney 3D animated feature film: clearly stylized animated characters - a slightly larger head, " +
    "big expressive eyes, soft rounded cartoon shapes - while every person keeps their own recognizable face, hair and smile; " +
    "finely detailed, textured hair, skin " +
    "and clothing; a rich, detailed, believable real-world setting; vibrant saturated colors; warm golden-hour sunlight with " +
    "soft shadows (or warm lamp light at night); cinematic depth of field; crisp, sharp, highly detailed 4K film-still " +
    "quality - clearly an animated movie, never a photo",
  // Picture sizes for the GPT drawings ("WIDTHxHEIGHT"): tall pages fill a phone screen sharply, like a real film still.
  book_page_size: "1152x2048",
  // Enlarges finished pages for print (cheap: charged per second of computing).
  print_upscale_model: "fal-ai/esrgan",
  book_character_size: "1024x1536",
  // Pages: "openai/..." models get the GPT input (better at keeping references); others the book_model input.
  book_page_quality: "high",
  book_character_quality: "high",
  book_character_prompt_gpt:
    "Create the main character of a children's picture book: an animated movie character based on the child in these " +
    "photos. Style: {style}. It must NOT look like a photograph or a realistic child. Even as a cartoon, the parents must " +
    "recognize THIS child at once: keep their face shape, eye shape and color, eyebrows, nose, smile, hair color, curls " +
    "and hairstyle, and skin tone. Do not make them older or younger. A {age}. Full body, standing, relaxed friendly " +
    "pose, facing the viewer, on a plain soft cream background, portrait orientation. Outfit: {outfit}. Only this one " +
    "child. No text, no letters, no logos, no frame.",
  // Image 1 = the approved character. Image 2 = a real photo of the child (face only). {scene} {outfit} from the app.
  book_page_prompt:
    "Create a new illustration for the same children's picture book, rendered in this style: {style}. " +
    "The FIRST image is the book's approved main character: draw the SAME child - the same face, hair, age, proportions " +
    "and outfit ({outfit}) - and match the first image's style. The second image is a real photo of the child: use it " +
    "only to keep the face recognizable. Do not copy the pose or background of any reference image.{parent} Scene: {scene} " +
    "Gentle, warm, reassuring mood. The child is clearly visible. No text, no letters, no speech bubbles, no frame.",
  // Pages with labelled references (every person in the picture has a character sheet).
  book_page_cast_prompt:
    "Create one full-page illustration for a children's picture book, rendered in this style: {style}. " +
    "Reference images (character sheets of this book): {refs}. Draw every person exactly like their character sheet - " +
    "the same face, hair, skin tone, body proportions, age and outfit - so they are instantly recognizable as the same " +
    "characters on every page. Do not copy the sheets' poses or plain backgrounds; place them in a full, detailed, " +
    "cinematic scene.{people} Scene (people are named by their [id]): {scene} {layout} Warm, emotional, beautifully lit, " +
    "like a still from an animated feature film: vivid colors, crisp detail, a real, lived-in place full of small details. " +
    "If a real photo of a person is given, use it for that person's true face (the character sheet for the style and outfit). " +
    "No text, no letters, no signs, no speech bubbles, no frame, no border.",
  book_page_layout: "Tall portrait composition (like a phone screen); keep the lower third of the picture calm and simple (soft floor, sky or wall) because the story text is printed there.",
  book_cover_layout: "Portrait book-cover composition; the hero large and central, and keep the upper fifth calm and simple because the title is printed there.",
  // Another person in the story (from their photo when the parent gave one), always in the hero's style.
  book_cast_prompt_photo:
    "Create a character for the same children's picture book. Image 1 is a real photo of the person: turn them into an " +
    "animated movie character that their family recognizes at once (keep their face shape, eyes, eyebrows, nose, hair, " +
    "beard or no beard, skin tone, build and approximate age). Image 2 is the book's main character ({hero}): use exactly " +
    "the same art style, rendering and proportions. This person is: {who}. Full body, standing, relaxed and friendly, " +
    "facing the viewer, on a plain soft cream background, everyday clothes that fit them. Only this one person. " +
    "No text, no letters, no logos, no frame.",
  book_cast_prompt_nophoto:
    "Create a character for the same children's picture book. The image is the book's main character ({hero}): use " +
    "exactly the same art style, rendering and proportions. Draw a new character: {who}. Warm, kind and believable. " +
    "Full body, standing, relaxed and friendly, facing the viewer, on a plain soft cream background, everyday clothes. " +
    "Only this one person. No text, no letters, no logos, no frame.",
  book_page_parent:
    " The third image is a real photo of the child's {role}: whenever the {role} appears in the scene, draw them as this " +
    "real person - their face shape, hair, beard or no beard, skin tone and build - in the same animated style, so the " +
    "family recognizes them.",
};
const ASPECTS = ["9:16", "16:9", "3:4", "4:3", "1:1"];

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

// deno-lint-ignore no-explicit-any
async function settings(admin: any): Promise<Record<string, string>> {
  const out = { ...DEFAULTS };
  try {
    const { data } = await admin.from("film_settings").select("key,value");
    for (const row of data ?? []) {
      const v = String(row.value ?? "").trim();
      if (v) out[String(row.key)] = v;
    }
  } catch (_) { /* no table yet: defaults */ }
  return out;
}

/** "1152x2048" -> { width, height } for GPT drawings (multiples of 16, within the model's limits), else undefined = auto. */
function size(v: string | undefined): { width: number; height: number } | undefined {
  const m = /^(\d{3,4})x(\d{3,4})$/.exec(String(v ?? "").trim());
  if (!m) return undefined;
  const fit = (n: number) => Math.max(512, Math.min(3840, Math.round(n / 16) * 16));
  return { width: fit(Number(m[1])), height: fit(Number(m[2])) };
}

const clean = (s: unknown, max: number) => String(s ?? "").replace(/[\r\n\t]+/g, " ").replace(/[{}]/g, "").trim().slice(0, max);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    if (!FAL_KEY) return json({ error: "השרת עוד לא הוגדר (חסר מפתח fal)." }, 500);
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
    const { data: u } = await userClient.auth.getUser();
    const uid = u?.user?.id;
    if (!uid) return json({ error: "צריך להתחבר לחשבון." }, 401);
    // Guest (anonymous) sign-ins can't spend film credits: otherwise anyone could script free films on our fal key.
    if ((u?.user as { is_anonymous?: boolean })?.is_anonymous) return json({ error: "כדי ליצור סרט צריך להתחבר עם מייל או Google." }, 403);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "credits") {
      const { data } = await admin.rpc("film_balance", { p_user: uid });
      return json({ credits: data ?? 0 });
    }
    // A book sends its own reference ("ref"): asking again for the same book never takes a second credit
    // (a phone on a weak signal may resend a request whose answer was lost). Needs book-credits.sql; without it, the old way.
    const ref = clean(body.ref, 80);
    if (action === "reserve" && ref) {
      const { data, error } = await admin.rpc("film_reserve_once", { p_user: uid, p_ref: ref, p_again: body.again === true });
      if (!error) {
        if (data === "active" || data === "charged") return json({ ok: true, charged: data === "charged" });
        if (data === "expired") return json({ error: "expired", expired: true }, 409);
        return json({ error: "אין לך קרדיטים לסרטים. אפשר להוסיף קרדיטים בקרוב." }, 402);
      }
    }
    if (action === "refund" && ref) {
      const { data, error } = await admin.rpc("film_refund_once", { p_user: uid, p_ref: ref });
      if (!error) return json({ ok: true, refunded: data === true });
    }
    if (action === "reserve") {
      const { data } = await admin.rpc("film_reserve", { p_user: uid });
      if (!data) return json({ error: "אין לך קרדיטים לסרטים. אפשר להוסיף קרדיטים בקרוב." }, 402);
      return json({ ok: true });
    }
    if (action === "refund") {
      await admin.rpc("film_refund", { p_user: uid });
      return json({ ok: true });
    }
    if (action === "submit") {
      const kind = String(body.kind ?? "");
      // Preparing a finished book for print (a cheap enlargement of pages already paid for) doesn't use the credit's calls.
      if (kind !== "book_upscale") {
        const { data: allowed } = await admin.rpc("film_use_call", { p_user: uid });
        if (!allowed) return json({ error: "אין הרשאה להמשיך. התחילו סרט מחדש." }, 402);
      }
      const s = await settings(admin);
      const image = String(body.image ?? "");
      const aspect = ASPECTS.includes(String(body.aspect ?? "")) ? String(body.aspect) : undefined;
      if (!image || image.length > 4_000_000) return json({ error: "תמונה לא תקינה." }, 400);
      let model: string;
      let input: Record<string, unknown>;
      // Up to two face photos from the family's profile (data: URIs from the app, kept small).
      const refs = (Array.isArray(body.refs) ? body.refs : [])
        .map((r: unknown) => String(r ?? ""))
        .filter((r: string) => (r.startsWith("data:image/") || r.startsWith("https://")) && r.length <= 1_500_000)
        .slice(0, 9);
      if (kind === "style" && refs.length > 0) {
        model = s.face_model;
        input = { prompt: s.face_prompt, image_urls: [image, ...refs.slice(0, 2)], output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "style") {
        model = s.style_model;
        input = { prompt: s.style_prompt, image_url: image, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "style_ref") {
        const ref = String(body.ref ?? "");
        if (!ref.startsWith("https://")) return json({ error: "חסרה דמות העוגן." }, 400);
        model = s.ref_model;
        input = { prompt: s.ref_prompt, image_urls: [image, ref], output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "book_character") {
        // Up to three real photos of the child: the first is `image`, the rest come in refs (data: URIs only).
        model = s.book_character_model || s.book_model;
        const photos = [image, ...refs].filter((r: string) => r.startsWith("data:image/")).slice(0, 3);
        if (photos.length === 0) return json({ error: "חסרה תמונה של הילד." }, 400);
        const age = clean(body.age, 80) || "young child";
        const outfit = clean(body.outfit, 200) || "simple comfortable everyday clothes";
        if (model.startsWith("openai/")) {
          const prompt = s.book_character_prompt_gpt.replace("{style}", s.book_style).replace("{age}", age).replace("{outfit}", outfit);
          const quality = ["low", "medium", "high"].includes(s.book_character_quality) ? s.book_character_quality : "high";
          input = { prompt, image_urls: photos, quality, num_images: 1, output_format: "jpeg", ...(size(s.book_character_size) ? { image_size: size(s.book_character_size) } : {}) };
        } else {
          const prompt = s.book_character_prompt.replace("{age}", age).replace("{outfit}", outfit);
          input = { prompt, image_urls: photos, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
        }
      } else if (kind === "book_cast") {
        model = s.book_character_model || s.book_model;
        const pics = [image, ...refs].filter((r: string) => r.startsWith("data:image/")).slice(0, 2);
        const withPhoto = body.photo === true && pics.length >= 2;
        const prompt = (withPhoto ? s.book_cast_prompt_photo : s.book_cast_prompt_nophoto)
          .replace("{hero}", clean(body.hero, 40) || "the hero").replace("{who}", clean(body.who, 200) || "a kind adult");
        const quality = ["low", "medium", "high"].includes(s.book_character_quality) ? s.book_character_quality : "high";
        input = model.startsWith("openai/")
          ? { prompt, image_urls: withPhoto ? pics : pics.slice(0, 1), quality, num_images: 1, output_format: "jpeg", ...(size(s.book_character_size) ? { image_size: size(s.book_character_size) } : {}) }
          : { prompt, image_urls: withPhoto ? pics : pics.slice(0, 1), output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "book_page" && Array.isArray(body.labels) && body.labels.length > 0) {
        // Every person in the picture comes with their labelled character sheet (image 1 = the hero).
        model = s.book_model;
        const scene = clean(body.scene, 900);
        if (!scene) return json({ error: "חסר תיאור העמוד." }, 400);
        const pics = [image, ...refs].filter((r: string) => r.startsWith("data:image/")).slice(0, 10);
        const labels = (body.labels as unknown[]).slice(0, pics.length).map((l, k) => `Image ${k + 1} = ${clean(l, 220)}`);
        const people = clean(body.people, 500);
        const prompt = s.book_page_cast_prompt.replace("{style}", s.book_style).replace("{refs}", labels.join("; "))
          .replace("{people}", people ? ` Also in the scene, without a reference image (draw them simply and keep them consistent): ${people}.` : "")
          .replace("{scene}", scene).replace("{layout}", body.cover === true ? s.book_cover_layout : s.book_page_layout);
        if (model.startsWith("openai/")) {
          const quality = ["low", "medium", "high"].includes(s.book_page_quality) ? s.book_page_quality : "high";
          input = { prompt, image_urls: pics, quality, num_images: 1, output_format: "jpeg", ...(size(s.book_page_size) ? { image_size: size(s.book_page_size) } : {}) };
        } else {
          input = { prompt, image_urls: pics, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
        }
      } else if (kind === "book_page") {
        // `image` = the approved character (sent from the phone each time, so it never depends on an expired link).
        model = s.book_model;
        const scene = clean(body.scene, 700);
        if (!scene) return json({ error: "חסר תיאור העמוד." }, 400);
        // Image 3 (optional) = the parent's face, from their profile photo, so the parent in the story looks like them.
        const role = clean(body.parent, 30).replace(/[^a-z ]/gi, "");
        const pics = [image, ...refs.slice(0, role ? 2 : 1)];
        const parentLine = role && pics.length >= 3 ? s.book_page_parent.replaceAll("{role}", role) : "";
        const prompt = s.book_page_prompt.replace("{style}", s.book_style).replace("{parent}", parentLine)
          .replace("{scene}", scene).replace("{outfit}", clean(body.outfit, 200) || "the same outfit");
        if (model.startsWith("openai/")) {
          const quality = ["low", "medium", "high"].includes(s.book_page_quality) ? s.book_page_quality : "medium";
          input = { prompt, image_urls: pics, quality, num_images: 1, output_format: "jpeg", ...(size(s.book_page_size) ? { image_size: size(s.book_page_size) } : {}) };
        } else {
          input = { prompt, image_urls: pics, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
        }
      } else if (kind === "book_upscale") {
        // Print quality: the finished page, enlarged twice (sharp at print size). Only the page picture is sent.
        if (!image.startsWith("data:image/")) return json({ error: "תמונה לא תקינה." }, 400);
        model = s.print_upscale_model;
        input = { image_url: image, scale: 2, model: "RealESRGAN_x4plus", output_format: "jpeg" };
      } else if (kind === "polish") {
        if (!image.startsWith("https://")) return json({ error: "כתובת תמונה לא תקינה." }, 400);
        if (s.polish_model === "off") return json({ skip: true });
        model = s.polish_model;
        input = { prompt: s.polish_prompt, image_url: image, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "anim") {
        if (!image.startsWith("https://")) return json({ error: "כתובת תמונה לא תקינה." }, 400);
        model = s.anim_model;
        const act = clean(body.motion, 200);
        const prompt = s.motion_prompt.includes("{action}") ? s.motion_prompt.replace("{action}", act) : `${s.motion_prompt} ${act}`;
        const cfg = Number(s.anim_cfg);
        // The approved main scene is animated for 10 seconds, the others for 5 (Kling accepts "5" or "10").
        const duration = String(body.duration ?? "5") === "10" ? "10" : "5";
        input = {
          prompt: prompt.trim(), image_url: image, duration, negative_prompt: s.negative_prompt,
          ...(Number.isFinite(cfg) ? { cfg_scale: cfg } : {}),
        };
      } else return json({ error: "בקשה לא מוכרת." }, 400);
      const r = await fetch("https://queue.fal.run/" + model, {
        method: "POST",
        headers: {
          Authorization: "Key " + FAL_KEY, "Content-Type": "application/json",
          // Results are public links on fal's CDN until they expire: keep them for one hour only (the app downloads
          // them right away, and asks fal to delete the request with "forget").
          "X-Fal-Object-Lifecycle-Preference": JSON.stringify({ expiration_duration_seconds: 3600 }),
        },
        body: JSON.stringify(input),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        // Say why (the model's own message), so the parent's screenshot tells us what to fix.
        const why = String((j as any)?.detail?.[0]?.msg ?? (j as any)?.detail ?? (j as any)?.error ?? (j as any)?.message ?? "").slice(0, 160);
        console.log(JSON.stringify({ ev: "fal_submit_failed", model, status: r.status, body: JSON.stringify(j).slice(0, 500) }));
        return json({ error: `שירות הציור לא זמין כרגע (${model}, ${r.status}${why ? ": " + why : ""}).`, detail: JSON.stringify(j).slice(0, 300) }, 502);
      }
      return json({ status_url: j.status_url, response_url: j.response_url, request_id: j.request_id ?? "" });
    }
    // After the phone saved a result: delete the request's inputs, outputs and output files at fal.
    // (Needs a fal key with the models:requests:write and assets:write permissions; the answer says if it worked.)
    if (action === "forget") {
      const id = String(body.request_id ?? "");
      if (!/^[0-9a-f-]{36}$/i.test(id)) return json({ error: "מזהה לא תקין." }, 400);
      const r = await fetch(`https://api.fal.ai/v1/models/requests/${id}/payloads`, {
        method: "DELETE", headers: { Authorization: "Key " + FAL_KEY, "Idempotency-Key": id },
      });
      const j = await r.json().catch(() => ({}));
      const failed = (j.cdn_delete_results ?? []).filter((x: { exception: unknown }) => x.exception).length;
      return json({ ok: r.ok && failed === 0, status: r.status, detail: r.ok ? "" : JSON.stringify(j).slice(0, 200) });
    }

    if (action === "poll") {
      const su = String(body.status_url ?? "");
      const ru = String(body.response_url ?? "");
      if (!su.startsWith("https://queue.fal.run/") || !ru.startsWith("https://queue.fal.run/")) return json({ error: "כתובת לא תקינה." }, 400);
      const H = { Authorization: "Key " + FAL_KEY };
      const st = await (await fetch(su, { headers: H })).json().catch(() => ({}));
      if (st.status === "COMPLETED") {
        const rr = await fetch(ru, { headers: H });
        const j = await rr.json().catch(() => ({}));
        if (!rr.ok) return json({ status: "FAILED", detail: JSON.stringify(j).slice(0, 300) });
        const url = j.video?.url ?? j.images?.[0]?.url ?? j.image?.url ?? "";
        return json({ status: url ? "DONE" : "FAILED", url, ...(url ? {} : { detail: JSON.stringify(j).slice(0, 300) }) });
      }
      if (st.status === "FAILED" || st.error) return json({ status: "FAILED", detail: JSON.stringify(st.error ?? st).slice(0, 300) });
      return json({ status: "PENDING" });
    }
    return json({ error: "בקשה לא מוכרת." }, 400);
  } catch (e) {
    return json({ error: "שגיאה בשרת.", detail: String(e).slice(0, 200) }, 500);
  }
});
