// Supabase Edge Function: cartoon-film
// The app never sees the fal key. It asks this function to (1) reserve a credit, (2) draw a frame in a cartoon style,
// (3) draw the other frames like that first "anchor" character, (4) animate a drawn frame, (5) poll, (6) refund.
// Models and prompts can be changed from the film_settings table (SQL), without touching this code.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FAL_KEY = Deno.env.get("FAL_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// ---------- defaults (film_settings rows override them) ----------
const DEFAULTS: Record<string, string> = {
  style_model: "fal-ai/flux-pro/kontext",
  ref_model: "fal-ai/flux-pro/kontext/multi",
  anim_model: "fal-ai/kling-video/v2.5-turbo/pro/image-to-video",
  anim_cfg: "0.6",
  // Fully cartoon, never "half real": realistic faces with cartoon eyes look creepy (the uncanny valley).
  style_prompt:
    "Redraw this photo as a frame from a warm, family-friendly 3D animated movie (Pixar / Disney animation style). " +
    "Turn every person into a fully stylized cartoon character: simplified cute features, soft rounded face, small nose, " +
    "friendly natural-size eyes with a happy expression, smooth matte skin with no skin texture or pores, soft toy-like look. " +
    "Children look adorable and sweet and keep their real young age: a toddler stays a toddler, with chubby cheeks, " +
    "small baby-like features and thin light eyebrows, never adult-looking features or wrinkles. " +
    "The photo may be taken with a wide-angle lens very close to the face: fix that distortion, give natural proportions, " +
    "and frame the character a little wider so the face is not huge or stretched. " +
    "Keep what makes each person recognizable: hair color and hairstyle, clothing and its colors, pose. " +
    "Redraw the background and every object in the same 3D animated style, with bright soft colors and gentle warm lighting. " +
    "Nothing may look photographic or realistic. No distorted faces, no extra fingers, no creepy or eerie expressions.",
  // Image 1 = the real photo of this scene. Image 2 = the approved cartoon character (the anchor).
  ref_prompt:
    "The first image is a real photo. The second image shows the same people already drawn as 3D animated movie characters. " +
    "Redraw the first photo as a frame of that same 3D animated movie: keep the pose, the action, the camera angle and the place " +
    "of the first photo, and draw every person exactly like their cartoon character in the second image: same face, same age, " +
    "same hair, same clothes, same colors and the same art style. A toddler stays a toddler. " +
    "Fix wide-angle lens distortion so faces are not huge or stretched. Redraw the background in the same 3D animated style. " +
    "Nothing may look photographic. No distorted faces, no extra fingers, no creepy expressions.",
  // {action} = what the moment is about (from the app). Kling sees the picture; it continues what is in it.
  motion_prompt:
    "A scene from a warm 3D animated family movie. {action} Gentle, natural, slow motion that continues what is happening " +
    "in the picture. The characters' faces stay stable, cute and consistent. Soft, slow camera movement.",
  negative_prompt:
    "realistic, photographic, uncanny, creepy, scary, distorted face, deformed face, morphing face, melting, " +
    "extra fingers, extra limbs, bad anatomy, big sudden movements, flicker, blur, low quality",
};
const ASPECTS = ["9:16", "16:9", "3:4", "4:3", "1:1"];

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

// deno-lint-ignore no-explicit-any
async function settings(admin: any): Promise<Record<string, string>> {
  const out = { ...DEFAULTS };
  try {
    const { data } = await admin.from("film_settings").select("key,value");
    for (const row of data ?? []) {
      const v = String(row.value ?? "").trim();
      if (v) out[String(row.key)] = v;
    }
  } catch (_) { /* no table yet: defaults */ }
  return out;
}

const clean = (s: unknown, max: number) => String(s ?? "").replace(/[\r\n\t]+/g, " ").replace(/[{}]/g, "").trim().slice(0, max);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    if (!FAL_KEY) return json({ error: "השרת עוד לא הוגדר (חסר מפתח fal)." }, 500);
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
    const { data: u } = await userClient.auth.getUser();
    const uid = u?.user?.id;
    if (!uid) return json({ error: "צריך להתחבר לחשבון." }, 401);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "credits") {
      const { data } = await admin.rpc("film_balance", { p_user: uid });
      return json({ credits: data ?? 0 });
    }
    if (action === "reserve") {
      const { data } = await admin.rpc("film_reserve", { p_user: uid });
      if (!data) return json({ error: "אין לך קרדיטים לסרטים. אפשר להוסיף קרדיטים בקרוב." }, 402);
      return json({ ok: true });
    }
    if (action === "refund") {
      await admin.rpc("film_refund", { p_user: uid });
      return json({ ok: true });
    }
    if (action === "submit") {
      const { data: allowed } = await admin.rpc("film_use_call", { p_user: uid });
      if (!allowed) return json({ error: "אין הרשאה להמשיך. התחילו סרט מחדש." }, 402);
      const s = await settings(admin);
      const kind = String(body.kind ?? "");
      const image = String(body.image ?? "");
      const aspect = ASPECTS.includes(String(body.aspect ?? "")) ? String(body.aspect) : undefined;
      if (!image || image.length > 4_000_000) return json({ error: "תמונה לא תקינה." }, 400);
      let model: string;
      let input: Record<string, unknown>;
      if (kind === "style") {
        model = s.style_model;
        input = { prompt: s.style_prompt, image_url: image, output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "style_ref") {
        const ref = String(body.ref ?? "");
        if (!ref.startsWith("https://")) return json({ error: "חסרה דמות העוגן." }, 400);
        model = s.ref_model;
        input = { prompt: s.ref_prompt, image_urls: [image, ref], output_format: "jpeg", ...(aspect ? { aspect_ratio: aspect } : {}) };
      } else if (kind === "anim") {
        if (!image.startsWith("https://")) return json({ error: "כתובת תמונה לא תקינה." }, 400);
        model = s.anim_model;
        const act = clean(body.motion, 200);
        const prompt = s.motion_prompt.includes("{action}") ? s.motion_prompt.replace("{action}", act) : `${s.motion_prompt} ${act}`;
        const cfg = Number(s.anim_cfg);
        input = {
          prompt: prompt.trim(), image_url: image, duration: "5", negative_prompt: s.negative_prompt,
          ...(Number.isFinite(cfg) ? { cfg_scale: cfg } : {}),
        };
      } else return json({ error: "בקשה לא מוכרת." }, 400);
      const r = await fetch("https://queue.fal.run/" + model, {
        method: "POST",
        headers: { Authorization: "Key " + FAL_KEY, "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return json({ error: "שירות הציור לא זמין כרגע.", detail: JSON.stringify(j).slice(0, 300) }, 502);
      return json({ status_url: j.status_url, response_url: j.response_url });
    }
    if (action === "poll") {
      const su = String(body.status_url ?? "");
      const ru = String(body.response_url ?? "");
      if (!su.startsWith("https://queue.fal.run/") || !ru.startsWith("https://queue.fal.run/")) return json({ error: "כתובת לא תקינה." }, 400);
      const H = { Authorization: "Key " + FAL_KEY };
      const st = await (await fetch(su, { headers: H })).json().catch(() => ({}));
      if (st.status === "COMPLETED") {
        const rr = await fetch(ru, { headers: H });
        const j = await rr.json().catch(() => ({}));
        if (!rr.ok) return json({ status: "FAILED", detail: JSON.stringify(j).slice(0, 300) });
        const url = j.video?.url ?? j.images?.[0]?.url ?? "";
        return json({ status: url ? "DONE" : "FAILED", url });
      }
      if (st.status === "FAILED" || st.error) return json({ status: "FAILED" });
      return json({ status: "PENDING" });
    }
    return json({ error: "בקשה לא מוכרת." }, 400);
  } catch (e) {
    return json({ error: "שגיאה בשרת.", detail: String(e).slice(0, 200) }, 500);
  }
});
