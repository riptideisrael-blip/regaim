// Supabase Edge Function: cartoon-film
// The app never sees the fal key. It asks this function to (1) reserve a credit, (2) draw a frame in a cartoon style,
// (3) animate the drawn frame, (4) poll for results, (5) refund when a film fails.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FAL_KEY = Deno.env.get("FAL_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const STYLE_MODEL = "fal-ai/flux-pro/kontext";
const ANIM_MODEL = "fal-ai/kling-video/v2.1/pro/image-to-video";

// Edit these two to change the look of every film. No app update is needed.
const STYLE_PROMPT =
  "Transform this photograph into a stylized 3D animated feature-film character render in the style of Pixar movies: " +
  "smooth stylized skin, large expressive but proportional eyes, soft rounded features, vibrant colors, soft cinematic lighting. " +
  "Redraw EVERYTHING in the image as a stylized 3D animated scene: the people, the background and every object. " +
  "Nothing may look photographic. Keep each person's identity: same hair color and hairstyle, same clothing and colors, same pose and expression.";
const MOTIONS = [
  "Gentle natural movement, the child looks around and smiles, soft cinematic lighting, smooth 3D animation, stable character design.",
  "The child moves playfully with small natural gestures, warm cinematic lighting, smooth 3D animated film look, consistent face and clothing.",
  "A calm tender moment, subtle natural motion, slight camera push-in, smooth 3D animation, consistent character.",
  "The child reacts with joy, natural gentle movement, warm light, smooth animated film look, consistent character design.",
];

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    if (!FAL_KEY) return json({ error: "השרת עוד לא הוגדר (חסר מפתח fal)." }, 500);
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
    const { data: u } = await userClient.auth.getUser();
    const uid = u?.user?.id;
    if (!uid) return json({ error: "צריך להתחבר לחשבון." }, 401);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "credits") {
      const { data } = await admin.rpc("film_balance", { p_user: uid });
      return json({ credits: data ?? 0 });
    }
    if (action === "reserve") {
      const { data } = await admin.rpc("film_reserve", { p_user: uid });
      if (!data) return json({ error: "אין לך קרדיטים לסרטים. אפשר להוסיף קרדיטים בקרוב." }, 402);
      return json({ ok: true });
    }
    if (action === "refund") {
      await admin.rpc("film_refund", { p_user: uid });
      return json({ ok: true });
    }
    if (action === "submit") {
      const { data: allowed } = await admin.rpc("film_use_call", { p_user: uid });
      if (!allowed) return json({ error: "אין הרשאה להמשיך. התחילו סרט מחדש." }, 402);
      const kind = String(body.kind ?? "");
      const image = String(body.image ?? "");
      if (!image || image.length > 4_000_000) return json({ error: "תמונה לא תקינה." }, 400);
      let model: string;
      let input: Record<string, unknown>;
      if (kind === "style") {
        model = STYLE_MODEL;
        input = { prompt: STYLE_PROMPT, image_url: image, output_format: "jpeg" };
      } else if (kind === "anim") {
        if (!image.startsWith("https://")) return json({ error: "כתובת תמונה לא תקינה." }, 400);
        model = ANIM_MODEL;
        const i = Math.abs(Number(body.scene ?? 0)) % MOTIONS.length;
        input = { prompt: MOTIONS[i], image_url: image, duration: "5" };
      } else return json({ error: "בקשה לא מוכרת." }, 400);
      const r = await fetch("https://queue.fal.run/" + model, {
        method: "POST",
        headers: { Authorization: "Key " + FAL_KEY, "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return json({ error: "שירות הציור לא זמין כרגע.", detail: JSON.stringify(j).slice(0, 300) }, 502);
      return json({ status_url: j.status_url, response_url: j.response_url });
    }
    if (action === "poll") {
      const su = String(body.status_url ?? "");
      const ru = String(body.response_url ?? "");
      if (!su.startsWith("https://queue.fal.run/") || !ru.startsWith("https://queue.fal.run/")) return json({ error: "כתובת לא תקינה." }, 400);
      const H = { Authorization: "Key " + FAL_KEY };
      const s = await (await fetch(su, { headers: H })).json().catch(() => ({}));
      if (s.status === "COMPLETED") {
        const rr = await fetch(ru, { headers: H });
        const j = await rr.json().catch(() => ({}));
        if (!rr.ok) return json({ status: "FAILED", detail: JSON.stringify(j).slice(0, 300) });
        const url = j.video?.url ?? j.images?.[0]?.url ?? "";
        return json({ status: url ? "DONE" : "FAILED", url });
      }
      if (s.status === "FAILED" || s.error) return json({ status: "FAILED" });
      return json({ status: "PENDING" });
    }
    return json({ error: "בקשה לא מוכרת." }, 400);
  } catch (e) {
    return json({ error: "שגיאה בשרת.", detail: String(e).slice(0, 200) }, 500);
  }
});
