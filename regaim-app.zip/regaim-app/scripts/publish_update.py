#!/usr/bin/env python3
"""
Puts the new APK in the app's private updates folder (Supabase storage 'app-updates'), so "Check for a new version"
in the app's settings finds it. Runs in the GitHub build after the APK is built.

The server key: the SUPABASE_SERVICE_ROLE_KEY secret if set, otherwise it's fetched with the SUPABASE_ACCESS_TOKEN
secret (the one the server-deploy workflow already uses). Neither one set: nothing is published (the build still
succeeds). Only the newest version is kept on the server (the free plan has 1 GB).

usage: publish_update.py APK VERSION_CODE VERSION_NAME
"""
import hashlib, json, os, sys, urllib.request, urllib.error

REF = "acqgmcmvxijyijhgivnt"
BASE = f"https://{REF}.supabase.co/storage/v1"
BUCKET = "app-updates"
PART = 45 * 1024 * 1024  # one file on the free plan: at most 50 MB
UA = {"User-Agent": "moments-build/1.0"}


def server_key():
    key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "").strip()
    tok = os.environ.get("SUPABASE_ACCESS_TOKEN", "").strip()
    if not key and tok:
        req = urllib.request.Request(f"https://api.supabase.com/v1/projects/{REF}/api-keys?reveal=true",
                                     headers={"Authorization": "Bearer " + tok, **UA})
        keys = json.load(urllib.request.urlopen(req, timeout=60))
        for k in keys:
            if k.get("name") == "service_role" and k.get("api_key"):
                key = k["api_key"]
                break
        else:
            for k in keys:
                if k.get("type") == "secret" and k.get("api_key"):
                    key = k["api_key"]
                    break
    return key


def call(key, method, path, data=None, ctype="application/json", extra=None):
    headers = {"apikey": key, **UA, **(extra or {})}
    if not key.startswith("sb_secret_"):
        headers["Authorization"] = "Bearer " + key
    if data is not None:
        headers["Content-Type"] = ctype
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            body = r.read()
            return json.loads(body) if body[:1] in (b"[", b"{") else body
    except urllib.error.HTTPError as e:
        raise SystemExit(f"{method} {path}: {e.code} {e.read()[:300]!r}")


def main():
    apk, code, name = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    # The number the build really gave the app (it grows with time; the one passed in is the old way).
    kept = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "build", "version-code.txt")
    if os.path.exists(kept):
        code = int(open(kept).read().strip())
    kept_name = os.path.join(os.path.dirname(kept), "version-name.txt")
    if os.path.exists(kept_name):
        name = open(kept_name, encoding="utf-8").read().strip()
    key = server_key()
    if not key:
        print("::warning::No SUPABASE_ACCESS_TOKEN / SUPABASE_SERVICE_ROLE_KEY secret: the update wasn't published to the app.")
        return 0
    # First the APKs get Moments' own signing key (sign_release.py). If that fails, nothing is published: an update
    # signed the old way could no longer install over a phone that already has the new key.
    import sign_release
    sign_release.main_for([apk, os.path.join(os.path.dirname(os.path.abspath(apk)), "regaim-protected.apk")])
    print(f"::add-mask::{key}")
    blob = open(apk, "rb").read()
    folder = f"v{code}"
    parts = []
    for i in range(0, len(blob), PART):
        p = f"{folder}/moments.apk.{i // PART:03d}"
        call(key, "POST", f"/object/{BUCKET}/{p}", blob[i:i + PART], "application/octet-stream", {"x-upsert": "true"})
        parts.append(p)
        print("uploaded", p)
    note = {"code": code, "name": name, "parts": parts, "size": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
    # The note last: the app only sees a version once all its parts are there.
    call(key, "POST", f"/object/{BUCKET}/latest.json", json.dumps(note).encode(), "application/json",
         {"x-upsert": "true", "cache-control": "no-cache"})
    print("published", note["name"], len(blob), "bytes")
    # Older versions are removed (only the newest is kept).
    for entry in call(key, "POST", f"/object/list/{BUCKET}", json.dumps({"prefix": "", "limit": 1000}).encode()):
        old = entry.get("name", "")
        if entry.get("id") is None and old.startswith("v") and old != folder:
            files = call(key, "POST", f"/object/list/{BUCKET}", json.dumps({"prefix": old, "limit": 1000}).encode())
            names = [f"{old}/{f['name']}" for f in files if f.get("name")]
            if names:
                call(key, "DELETE", f"/object/{BUCKET}", json.dumps({"prefixes": names}).encode())
                print("removed", old)
    return 0


if __name__ == "__main__":
    sys.exit(main())
