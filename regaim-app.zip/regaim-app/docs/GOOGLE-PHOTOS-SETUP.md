Package: com.regaim.app
SHA-1: 92:AA:EA:39:2A:FD:9F:57:22:3C:FC:17:10:27:B8:BA:2D:64:21:33
Scope: https://www.googleapis.com/auth/photospicker.mediaitems.readonly
Google Cloud: enable "Photos Picker API"; OAuth consent screen (add scope, add test users); create OAuth client type Android with the package and SHA-1.
