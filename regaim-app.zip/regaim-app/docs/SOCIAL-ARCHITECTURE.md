# Social layer architecture (plan, not built)

Rule: every feature asks `Privacy.canSee(level, viewer)`. Levels: Private < Family < Friends < Public.

Exists (0.19): Privacy enum, Memory.privacy (default private), publish to Family/Public, public feed, likes, comments, report, block, admin hide/delete.
Missing: Friends level (needs follow/friend graph), Profiles (public name/avatar/bio table), Follow, Search, Shares, per-post audience column on server, server-side moderation queue, private bucket for community media.

Next server steps: profiles(user_id, handle, name, avatar, bio); follows(follower, followee, status); community_posts.audience in ('public','friends'); RLS: friends posts visible only to accepted followers.
