package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppleSpotsTest {
    private val green = (0xFF shl 24) or (60 shl 16) or (140 shl 8) or 50
    private val red = (0xFF shl 24) or (210 shl 16) or (40 shl 8) or 35

    private fun picture(w: Int, h: Int, apples: List<Triple<Int, Int, Int>>, extra: (IntArray) -> Unit = {}): IntArray {
        val px = IntArray(w * h) { green }
        for ((cx, cy, r) in apples) for (y in cy - r..cy + r) for (x in cx - r..cx + r)
            if (x in 0 until w && y in 0 until h && (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) px[y * w + x] = red
        extra(px)
        return px
    }

    @Test fun findsTheApplesOnTheTree() {
        val apples = listOf(Triple(150, 30, 7), Triple(180, 50, 8), Triple(200, 25, 6), Triple(130, 60, 7), Triple(210, 70, 6))
        val px = picture(240, 135, apples) { p ->
            // A red stripe (a ribbon, not an apple) and a fallen apple at the very bottom: not counted.
            for (x in 10..90) for (y in 100..102) p[y * 240 + x] = red
            for (y in 124..132) for (x in 40..48) p[y * 240 + x] = red
        }
        val found = AppleSpots.find(px, 240, 135, 5)
        assertEquals(5, found.size)
        for ((cx, cy, _) in apples) assertTrue("$cx,$cy", found.any { kotlin.math.abs(it.x - cx) < 2 && kotlin.math.abs(it.y - cy) < 2 })
        // Asked for more than there are: only the real ones.
        assertEquals(5, AppleSpots.find(px, 240, 135, 8).size)
        // The biggest first.
        assertEquals(180f, AppleSpots.find(px, 240, 135, 1)[0].x, 2f)
    }
}
