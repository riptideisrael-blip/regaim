package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt
import kotlin.random.Random

class FacePrintsTest {
    private fun unit(v: FloatArray): FloatArray {
        val n = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        return FloatArray(v.size) { v[it] / n }
    }

    private fun near(base: FloatArray, r: Random, noise: Float) =
        unit(FloatArray(base.size) { base[it] + (r.nextFloat() - 0.5f) * noise })

    @Test
    fun damagedPrintsNeverMatch() {
        val a = unit(FloatArray(192) { 1f })
        assertEquals(FacePrints.FAR, FacePrints.dist(FloatArray(0), FloatArray(0)))
        assertEquals(FacePrints.FAR, FacePrints.dist(a, FloatArray(0)))
        assertEquals(FacePrints.FAR, FacePrints.dist(a, a.copyOf(128)))
        val nan = a.copyOf().also { it[3] = Float.NaN }
        assertEquals(FacePrints.FAR, FacePrints.dist(a, nan))
        assertEquals(0f, FacePrints.dist(a, a), 1e-6f)
        assertTrue(FacePrints.dist(a, FloatArray(192) { if (it == 0) 1f else 0f }) < 2.0001f)
    }

    @Test
    fun normalizeRejectsGarbage() {
        assertNull(FacePrints.normalize(FloatArray(0)))
        assertNull(FacePrints.normalize(FloatArray(192)))
        assertNull(FacePrints.normalize(FloatArray(192) { if (it == 5) Float.POSITIVE_INFINITY else 1f }))
        val n = FacePrints.normalize(FloatArray(4) { 2f })!!
        assertEquals(1f, sqrt(n.sumOf { (it * it).toDouble() }).toFloat(), 1e-5f)
    }

    @Test
    fun typicalLeavesOutTheOddFace() {
        val r = Random(7)
        val child = unit(FloatArray(192) { r.nextFloat() - 0.5f })
        val sibling = unit(FloatArray(192) { r.nextFloat() - 0.5f })
        val group = List(8) { near(child, r, 0.08f) } + near(sibling, r, 0.08f)
        val odd = group.last()
        val picked = FacePrints.typical(group, 6)
        assertEquals(6, picked.size)
        assertTrue(picked.none { it === odd })
        // Even with room for all, the odd one stays out.
        assertTrue(FacePrints.typical(group, 20).none { it === odd })
    }

    @Test
    fun typicalKeepsSmallGroups() {
        val r = Random(3)
        val a = unit(FloatArray(192) { r.nextFloat() - 0.5f })
        assertEquals(2, FacePrints.typical(listOf(a, near(a, r, 0.1f)), 6).size)
        assertEquals(1, FacePrints.typical(listOf(a, FloatArray(0)), 6).size)
    }

    @Test
    fun scanTriesRetryThenGiveUp() {
        val ids = listOf("a" to 100L, "b" to 300L, "c" to 200L, "d" to 50L)
        val tries = mapOf("a" to 1, "d" to ScanTries.MAX)
        // Fewest failures first, newest first among equals; given-up and already-failed-this-run are skipped.
        assertEquals(listOf("b", "a"), ScanTries.order(ids, tries, setOf("c")))
        assertEquals(listOf("b", "c", "a"), ScanTries.order(ids, tries, emptySet()))
        assertTrue(!ScanTries.giveUp(ScanTries.MAX - 1))
        assertTrue(ScanTries.giveUp(ScanTries.MAX))
    }

    @Test
    fun hexIsLowercase() {
        assertEquals("00ff10", FacePrints.hex(byteArrayOf(0, -1, 16)))
    }
}
