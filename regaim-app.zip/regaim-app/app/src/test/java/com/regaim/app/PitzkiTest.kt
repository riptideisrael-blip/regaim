package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PitzkiTest {
    private val boy = PitzkiKid("אורי", girl = false)
    private val girl = PitzkiKid("מיכל", girl = true)
    private val nobody = PitzkiKid("", girl = false)

    private fun allText(kid: PitzkiKid) = PitzkiScript.lesson(kid).flatMap { it.beats }.joinToString("\n") {
        when (it) { is Beat.Say -> it.text; is Beat.Family -> it.text; else -> "" }
    }

    @Test fun eightScenesInOrder() {
        val s = PitzkiScript.lesson(boy)
        assertEquals(PitzkiScript.SCENES, s.size)
        assertEquals((1..8).toList(), s.map { it.n })
    }

    @Test fun everyColorIsTaughtOnceAndAskedTwice() {
        val beats = PitzkiScript.lesson(boy).flatMap { it.beats }
        for (c in PColor.values()) {
            assertEquals("scene for $c", 1, PitzkiScript.lesson(boy).count { it.color == c })
            assertEquals("asks for $c", 2, beats.count { it is Beat.Ask && it.color == c })
            assertTrue("word for $c", beats.count { it is Beat.Word && it.color == c } >= 3)
        }
    }

    @Test fun talksToTheChildInTheRightForm() {
        val b = allText(boy)
        val g = allText(girl)
        val n = allText(nobody)
        assertTrue(b.contains("שלום אורי!"))
        assertTrue(b.contains("מוכן?"))
        assertTrue(g.contains("מוכנה?"))
        assertTrue(g.contains("תגידי איתי"))
        assertTrue(n.contains("שלום חברים!"))
        assertTrue(n.contains("תגידו איתי"))
        assertFalse(n.contains(", תגידו")) // no dangling comma without a name
        assertTrue(b.contains("תלחץ על האבן האפורה.")) // a stone is feminine in Hebrew
        assertTrue(b.contains("תלחץ על העלה הירוק."))
    }

    @Test fun personalLinesAreMarkedSoRecordingsDontReplaceThem() {
        val says = PitzkiScript.lesson(boy).flatMap { it.beats }.filterIsInstance<Beat.Say>()
        for (s in says) if (s.text.contains("אורי")) assertTrue(s.id, s.personal)
        // Without a name, nothing is personal: every line can be a recording.
        assertTrue(PitzkiScript.lesson(nobody).flatMap { it.beats }.filterIsInstance<Beat.Say>().none { it.personal })
    }

    @Test fun lineIdsAreUnique() {
        val ids = PitzkiScript.lesson(boy).flatMap { it.beats }.filterIsInstance<Beat.Say>().map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun praiseAndHelpTexts() {
        assertEquals("כל הכבוד!", PitzkiScript.praise(boy, 0))
        assertEquals(PitzkiScript.praise(boy, 1), PitzkiScript.praise(boy, 5))
        assertTrue(PitzkiScript.praise(girl, 1).contains("אלופה"))
        assertTrue(PitzkiScript.praise(boy, -1).isNotEmpty())
        assertEquals("כמעט! זה אדום. נסי שוב: איפה הירוק?", PitzkiScript.tryAgain(girl, PColor.RED, PColor.GREEN))
    }

    // ---------- colors in the family's photos ----------

    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    @Test fun pixelColors() {
        assertEquals(PColor.RED, PitzkiColors.of(rgb(220, 30, 30)))
        assertEquals(PColor.GREEN, PitzkiColors.of(rgb(40, 160, 60)))
        assertEquals(PColor.YELLOW, PitzkiColors.of(rgb(240, 210, 30)))
        assertEquals(PColor.BROWN, PitzkiColors.of(rgb(110, 70, 30)))
        assertEquals(PColor.GRAY, PitzkiColors.of(rgb(128, 128, 128)))
        assertNull(PitzkiColors.of(rgb(255, 255, 255))) // white
        assertNull(PitzkiColors.of(rgb(10, 10, 10))) // black
        assertNull(PitzkiColors.of(rgb(40, 80, 220))) // blue
        assertNull(PitzkiColors.of(rgb(232, 190, 160))) // light skin is not brown
        assertNull(PitzkiColors.of(rgb(200, 150, 110))) // tan skin is not brown
    }

    @Test fun sharesCountPixels() {
        val px = IntArray(10) { if (it < 3) rgb(220, 30, 30) else rgb(255, 255, 255) }
        val s = PitzkiColors.shares(px)
        assertEquals(0.3f, s[PColor.RED]!!, 0.001f)
        assertEquals(0f, s[PColor.GREEN]!!, 0.001f)
        assertTrue(PitzkiColors.shares(IntArray(0)).isEmpty())
    }

    @Test fun onePicturePerColorAndRareColorsFirst() {
        val pics = listOf(
            "a" to mapOf(PColor.GRAY to 0.6f, PColor.RED to 0.25f),
            "b" to mapOf(PColor.GRAY to 0.5f),
            "c" to mapOf(PColor.GREEN to 0.1f), // too little green
        )
        val p = PitzkiColors.pick(pics)
        assertEquals("a", p[PColor.RED]) // the only red picture isn't taken by gray
        assertEquals("b", p[PColor.GRAY])
        assertNull(p[PColor.GREEN])
        assertEquals(p.values.size, p.values.toSet().size)
    }
}
