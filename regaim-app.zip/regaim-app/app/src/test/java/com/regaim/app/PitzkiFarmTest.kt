package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PitzkiFarmTest {
    private val boy = PitzkiKid("אורי", false)
    private val girl = PitzkiKid("נועה", true)

    @Test fun farmIsWellFormed() {
        PitzkiScript.worldId = FarmWorld.ID
        try {
            val s = PitzkiScript.lesson(boy)
            assertEquals(FarmWorld.KEYS, s.map { it.key })
            assertEquals(FarmWorld.KID_INTRO, PitzkiScript.INTRO_KEY)
            assertTrue(PitzkiScript.KEYS.containsAll(PitzkiScript.CHILD_KEYS))
            assertEquals(7, FarmWorld.ANIMALS.size)
            // Each animal: its sound first, then Pitzki asks (his video), then the pictures: the right one is that animal.
            for (a in FarmWorld.ANIMALS) {
                val ask = s.first { it.key == a.key }.beats
                assertTrue(a.id, ask[0] is Beat.Sound && ask[1] is Beat.Talk)
                val pick = ask.filterIsInstance<Beat.Pick>().single()
                assertEquals(a.he, pick.choices[pick.right].label)
                assertEquals(3, pick.choices.map { it.label }.toSet().size)
                assertTrue(s.indexOfFirst { it.key == a.open } == s.indexOfFirst { it.key == a.key } + 1)
            }
            // The game at the end: three sounds, each with its pictures.
            val game = s.first { it.key == "farm_review" }.beats
            assertEquals(3, game.filterIsInstance<Beat.Sound>().size)
            for (pk in game.filterIsInstance<Beat.Pick>()) assertTrue(pk.right in pk.choices.indices)
            // Pitzki's videos are the same for every child: no name, no boy/girl words.
            for (t in FarmWorld.TALKS) {
                assertTrue(t.key in FarmWorld.KEYS && t.key !in FarmWorld.CHILD_KEYS)
                assertFalse(t.key, t.text.contains("אורי") || t.text.contains("אתה ") || t.text.contains("תנסה"))
            }
            val says = s.flatMap { it.beats }.filterIsInstance<Beat.Say>()
            assertEquals(says.size, says.map { it.id }.toSet().size)
            for (x in says) if (x.text.contains("אורי")) assertTrue(x.id, x.personal)
            assertTrue(PitzkiScript.lesson(girl).flatMap { it.beats }.filterIsInstance<Beat.Say>().any { it.text.contains("מוכנה?") })
            assertTrue(PitzkiTalks.KEYS.containsAll(FarmWorld.TALKS.map { it.key }))
        } finally { PitzkiScript.worldId = "forest" }
    }

    /** Before the farm's pictures are made, every scene that isn't the child's has a picture that comes with the app. */
    @Test fun bundledPicturesCoverTheFarm() {
        val files = java.io.File("src/main/assets/pitzki/farm").takeIf { it.isDirectory } ?: java.io.File("app/src/main/assets/pitzki/farm")
        for (key in FarmWorld.KEYS) {
            val name = FarmWorld.bundled(key)
            if (key in FarmWorld.CHILD_KEYS || key == "song") { assertEquals(key, null, name); continue }
            assertTrue(key, name != null && java.io.File(files, "$name.jpg").exists())
        }
        // The questions never show the animal (only the gate).
        for (a in FarmWorld.ANIMALS) assertEquals("farm_gate", FarmWorld.bundled(a.key))
    }

    /** The spoiled starts are cut only in the animals' coming-out clips, and the donkey's question shows the gate. */
    @Test fun spoiledClipsAreCut() {
        for (a in FarmWorld.ANIMALS) {
            val f = FarmWorld.clipFrom(a.open)
            assertTrue(a.id, f in 0f..0.8f)
            assertEquals(0f, FarmWorld.clipFrom(a.key), 0f) // never the question scene
        }
        assertEquals(0f, FarmWorld.clipFrom("farm_dog_open"), 0f) // the dog's clip was clean
        assertTrue(FarmWorld.clipFrom("farm_cow_open") > 0f)
        assertEquals(0f, FarmWorld.clipFrom("farm_dog_kid"), 0f)
        assertTrue(FarmWorld.gateInstead("farm_donkey"))
        assertFalse(FarmWorld.gateInstead("farm_donkey_open"))
    }
}
