package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PitzkiFarmTest {
    private val boy = PitzkiKid("אורי", false)
    private val girl = PitzkiKid("נועה", true)

    @Test fun farmIsWellFormed() {
        PitzkiScript.worldId = FarmWorld.ID
        try {
            val s = PitzkiScript.lesson(boy)
            assertEquals(FarmWorld.KEYS, s.map { it.key })
            assertEquals(FarmWorld.KID_INTRO, PitzkiScript.INTRO_KEY)
            assertTrue(PitzkiScript.KEYS.containsAll(PitzkiScript.CHILD_KEYS))
            assertEquals(7, FarmWorld.ANIMALS.size)
            // Each animal: its sound first, then Pitzki asks (his video), then the pictures: the right one is that animal.
            for (a in FarmWorld.ANIMALS) {
                val ask = s.first { it.key == a.key }.beats
                assertTrue(a.id, ask[0] is Beat.Sound && ask[1] is Beat.Talk)
                val pick = ask.filterIsInstance<Beat.Pick>().single()
                assertEquals(a.he, pick.choices[pick.right].label)
                assertEquals(3, pick.choices.map { it.label }.toSet().size)
                assertTrue(s.indexOfFirst { it.key == a.open } == s.indexOfFirst { it.key == a.key } + 1)
            }
            // The game at the end: three sounds, each with its pictures.
            val game = s.first { it.key == "farm_review" }.beats
            assertEquals(3, game.filterIsInstance<Beat.Sound>().size)
            for (pk in game.filterIsInstance<Beat.Pick>()) assertTrue(pk.right in pk.choices.indices)
            // Pitzki's videos are the same for every child: no name, no boy/girl words.
            for (t in FarmWorld.TALKS) {
                assertTrue(t.key in FarmWorld.KEYS && t.key !in FarmWorld.CHILD_KEYS)
                assertFalse(t.key, t.text.contains("אורי") || t.text.contains("אתה ") || t.text.contains("תנסה"))
            }
            val says = s.flatMap { it.beats }.filterIsInstance<Beat.Say>()
            assertEquals(says.size, says.map { it.id }.toSet().size)
            for (x in says) if (x.text.contains("אורי")) assertTrue(x.id, x.personal)
            assertTrue(PitzkiScript.lesson(girl).flatMap { it.beats }.filterIsInstance<Beat.Say>().any { it.text.contains("מוכנה?") })
            assertTrue(PitzkiTalks.KEYS.containsAll(FarmWorld.TALKS.map { it.key }))
        } finally { PitzkiScript.worldId = "forest" }
    }

    /** Before the farm's pictures are made, every scene that isn't the child's has a picture that comes with the app. */
    @Test fun bundledPicturesCoverTheFarm() {
        val files = java.io.File("src/main/assets/pitzki/farm").takeIf { it.isDirectory } ?: java.io.File("app/src/main/assets/pitzki/farm")
        for (key in FarmWorld.KEYS) {
            val name = FarmWorld.bundled(key)
            if (key in FarmWorld.CHILD_KEYS || key == "song") { assertEquals(key, null, name); continue }
            assertTrue(key, name != null && java.io.File(files, "$name.jpg").exists())
        }
        // The questions never show the animal (only the gate).
        for (a in FarmWorld.ANIMALS) assertEquals("farm_gate", FarmWorld.bundled(a.key))
    }

    /** The spoiled starts are cut only in the animals' coming-out clips, and the donkey's question shows the gate. */
    @Test fun spoiledClipsAreCut() {
        for (a in FarmWorld.ANIMALS) {
            val f = FarmWorld.clipFrom(a.open)
            assertTrue(a.id, f in 0f..0.8f)
            assertEquals(0f, FarmWorld.clipFrom(a.key), 0f) // never the question scene
        }
        assertTrue(FarmWorld.clipFrom("farm_cow_open") > 0f)
        assertEquals(0f, FarmWorld.clipFrom("farm_dog_kid"), 0f)
        assertTrue(FarmWorld.gateInstead("farm_donkey"))
        assertFalse(FarmWorld.gateInstead("farm_donkey_open"))
        assertTrue(FarmWorld.gateInstead(FarmWorld.INTRO) && !FarmWorld.voiceOnly(FarmWorld.INTRO))
        assertFalse(FarmWorld.voiceOnly("farm_cow"))
        assertTrue(FarmWorld.voiceOnly("farm_cat") && FarmWorld.gateInstead("farm_cat"))
    }

    /** After the easy animals come out, the child makes their sound too (any sound counts); the owl's thanks is the child's. */
    @Test fun childMakesTheSound() {
        PitzkiScript.worldId = FarmWorld.ID
        try {
            val s = PitzkiScript.lesson(boy)
            for (a in FarmWorld.ANIMALS) {
                val hears = s.first { it.key == a.open }.beats.filterIsInstance<Beat.Hear>()
                if (a.id in FarmWorld.COPY) {
                    assertEquals(a.id, 1, hears.size)
                    assertTrue(Beat.ANY in hears[0].words && hears[0].hint.endsWith(a.sound))
                } else assertTrue(a.id, hears.isEmpty())
            }
        } finally { PitzkiScript.worldId = "forest" }
        assertFalse(TrainWorld.cutText("train_owl", TrainWorld.talk("train_owl")!!.text).contains("תּוֹדָה"))
        assertTrue(TrainWorld.TALK_END_MS.getValue("train_owl") in 4300L..5500L) // inside the pause before his "thank you"
    }

    /** Pitzki remembers: the missed animal comes back in the game; all known -> new questions and a welcome back. */
    @Test fun pitzkiRemembers() {
        var m = PitzkiMemory.parse("")
        m = PitzkiMemory.record(m, "f_horse_pick", false)
        m = PitzkiMemory.record(m, "f_cow_pick", true)
        assertEquals(m, PitzkiMemory.parse(PitzkiMemory.write(m)))
        val horse = FarmWorld.ANIMALS.indexOfFirst { it.id == "horse" }
        assertEquals(horse, FarmWorld.reviewOrder(m).first())
        assertEquals(3, FarmWorld.reviewOrder(m).distinct().size)
        assertEquals(listOf(1, 3, 0), FarmWorld.reviewOrder(emptyMap()))
        assertFalse(FarmWorld.allKnown(m))
        val all = FarmWorld.ANIMALS.associate { "f_${it.id}_pick" to 1 }
        assertTrue(FarmWorld.allKnown(all))
        PitzkiScript.worldId = FarmWorld.ID
        PitzkiScript.memory = all; PitzkiScript.walksDone = 2
        try {
            val s = PitzkiScript.lesson(boy)
            assertTrue(s.first { it.key == "farm_review" }.beats.any { it is Beat.Pick && it.id == "f_bonus_0" })
            assertTrue(s.first { it.key == FarmWorld.KID_INTRO }.beats.any { it is Beat.Say && it.id == "f_back" })
            assertTrue(s.first { it.key == "farm_end_kid" }.beats.any { it is Beat.Open })
        } finally { PitzkiScript.worldId = "forest"; PitzkiScript.memory = emptyMap(); PitzkiScript.walksDone = 0 }
        PitzkiScript.worldId = FarmWorld.ID
        try { assertTrue(PitzkiScript.lesson(boy).first { it.key == FarmWorld.KID_INTRO }.beats.none { it is Beat.Say && it.id == "f_back" }) }
        finally { PitzkiScript.worldId = "forest" }
    }

    /** The night world: its scenes in order, the child in three, Pitzki's own drawn once (a prompt for each). */
    @Test fun nightIsWellFormed() {
        PitzkiScript.worldId = NightWorld.ID
        try {
            for (k in listOf(boy, girl, PitzkiKid("", false))) {
                val s = PitzkiScript.lesson(k)
                assertEquals(NightWorld.KEYS, s.map { it.key })
                assertEquals(NightWorld.INTRO, PitzkiScript.INTRO_KEY)
                assertTrue(PitzkiScript.KEYS.containsAll(PitzkiScript.CHILD_KEYS))
                for (sc in s) for (b in sc.beats) if (b is Beat.Pick) assertTrue(b.id, b.right in b.choices.indices)
            }
            for (key in NightWorld.KEYS - NightWorld.CHILD_KEYS.toSet() - "song")
                assertTrue(key, NightWorld.sharedPrompt(key).contains("Exactly one Pitzki") && !NightWorld.sharedPrompt(key).contains("Pitzki in a calm forest in the evening"))
            assertTrue(PitzkiScript.voiceLines(boy).any { it.contains("דובי זה חבר נהדר") })
        } finally { PitzkiScript.worldId = "forest" }
    }
}
