package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PitzkiFarmTest {
    private val boy = PitzkiKid("אורי", false)
    private val girl = PitzkiKid("נועה", true)

    @Test fun farmIsWellFormed() {
        PitzkiScript.worldId = FarmWorld.ID
        try {
            val s = PitzkiScript.lesson(boy)
            assertEquals(FarmWorld.KEYS, s.map { it.key })
            assertEquals(FarmWorld.KID_INTRO, PitzkiScript.INTRO_KEY)
            assertTrue(PitzkiScript.KEYS.containsAll(PitzkiScript.CHILD_KEYS))
            assertEquals(7, FarmWorld.ANIMALS.size)
            // Each animal: its sound first, then Pitzki asks (his video), then the pictures: the right one is that animal.
            for (a in FarmWorld.ANIMALS) {
                val ask = s.first { it.key == a.key }.beats
                assertTrue(a.id, ask[0] is Beat.Sound && ask[1] is Beat.Talk)
                val pick = ask.filterIsInstance<Beat.Pick>().single()
                assertEquals(a.he, pick.choices[pick.right].label)
                assertEquals(3, pick.choices.map { it.label }.toSet().size)
                assertTrue(s.indexOfFirst { it.key == a.open } == s.indexOfFirst { it.key == a.key } + 1)
            }
            // The game at the end: three sounds, each with its pictures.
            val game = s.first { it.key == "farm_review" }.beats
            assertEquals(3, game.filterIsInstance<Beat.Sound>().size)
            for (pk in game.filterIsInstance<Beat.Pick>()) assertTrue(pk.right in pk.choices.indices)
            // Pitzki's videos are the same for every child: no name, no boy/girl words.
            for (t in FarmWorld.TALKS) {
                assertTrue(t.key in FarmWorld.KEYS && t.key !in FarmWorld.CHILD_KEYS)
                assertFalse(t.key, t.text.contains("אורי") || t.text.contains("אתה ") || t.text.contains("תנסה"))
            }
            val says = s.flatMap { it.beats }.filterIsInstance<Beat.Say>()
            assertEquals(says.size, says.map { it.id }.toSet().size)
            for (x in says) if (x.text.contains("אורי")) assertTrue(x.id, x.personal)
            assertTrue(PitzkiScript.lesson(girl).flatMap { it.beats }.filterIsInstance<Beat.Say>().any { it.text.contains("מוכנה?") })
            assertTrue(PitzkiTalks.KEYS.containsAll(FarmWorld.TALKS.map { it.key }))
        } finally { PitzkiScript.worldId = "forest" }
    }
}
