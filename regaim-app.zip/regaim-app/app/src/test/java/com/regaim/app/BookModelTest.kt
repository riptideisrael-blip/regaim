package com.regaim.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BookModelTest {
    private fun face(key: String, group: String = key, side: Int = 320, sharp: Float = 0.8f, yaw: Float = 5f, ageDays: Long = 20, eyes: Float = 0.9f, dist: Float = 0.5f, crowded: Boolean = false) =
        FaceQuality.Stats(key, group, side, sharp, 140f, 0.02f, yaw, 2f, eyes, dist, ageDays, crowded)

    @Test fun aClearRecentFrontalFaceScoresHigh() {
        assertTrue(FaceQuality.score(face("a")) > 0.75f)
    }

    @Test fun blurTinyTurnedOldOrUnsureFacesScoreLower() {
        val base = FaceQuality.score(face("a"))
        assertTrue(FaceQuality.score(face("b", sharp = 0.1f)) < base)
        assertTrue(FaceQuality.score(face("c", side = 90)) < base)
        assertTrue(FaceQuality.score(face("d", yaw = 45f)) < base)
        assertTrue(FaceQuality.score(face("e", ageDays = 500)) < base * 0.5f)
        assertTrue(FaceQuality.score(face("f", dist = 0.8f)) < base)
        assertTrue(FaceQuality.score(face("g", eyes = 0.05f)) < base)
        assertTrue(FaceQuality.score(face("h", crowded = true)) < base)
    }

    @Test fun picksVarietyAndAFrontalFace() {
        val all = listOf(
            face("a1", group = "day1", yaw = 25f), face("a2", group = "day1", yaw = 24f), face("a3", group = "day1", yaw = 26f),
            face("b", group = "day2", yaw = 22f, sharp = 0.75f), face("c", group = "day3", yaw = 3f, sharp = 0.55f),
            face("bad", group = "day4", sharp = 0.05f, side = 80),
        )
        val p = FaceQuality.pick(all, 3)
        assertEquals(3, p.size)
        assertEquals(3, p.map { it.group }.distinct().size)
        assertTrue(p.any { kotlin.math.abs(it.yaw) < 15f })
        assertTrue(p.none { it.key == "bad" })
    }

    @Test fun nothingGoodMeansNothingPicked() {
        assertTrue(FaceQuality.pick(listOf(face("x", sharp = 0.05f, side = 70, ageDays = 900)), 3).isEmpty())
    }

    @Test fun storyIsParsedAndChecked() {
        val ok = """Here: {"title":"אורי והלילה","outfit":"blue pajamas with stars","cover_scene":"A boy in bed with a lamp",
            "pages":[{"text":"א","scene":"s1"},{"text":"ב","scene":"s2"},{"text":"ג","scene":"s3"},{"text":"ד","scene":"s4"},{"text":"ה","scene":"s5"},{"text":"ו","scene":"s6"}]}"""
        val s = BookJson.story(ok)
        assertNotNull(s)
        assertEquals(6, s!!.pages.size)
        assertEquals("blue pajamas with stars", s.outfit)
        assertNull(BookJson.story("""{"title":"x","pages":[{"text":"a","scene":"b"}]}"""))
        assertNull(BookJson.story("no json at all"))
        assertNull(BookJson.story("""{"title":"","pages":[]}"""))
    }

    @Test fun ageLines() {
        assertEquals("3-year-old boy", BookJson.ageDesc(40, false))
        assertEquals("toddler girl of about 18 months", BookJson.ageDesc(18, true))
        assertEquals("young child", BookJson.ageDesc(null, null))
        assertTrue(BookJson.wordsPerPage(20) < BookJson.wordsPerPage(60))
    }

    @Test fun bookRoundTrip() {
        val b = Book("id1", "נועה", "3-year-old girl", "dark", "he", "נועה והלילה", "pink pajamas",
            BookPage("כריכה", "cover scene", "cover.jpg", "done"),
            listOf(BookPage("טקסט", "scene", "p1.jpg", "done", 1), BookPage("עוד", "scene 2")),
            character = "character.jpg", characterTries = 2, state = "pages", photoSources = listOf("m1", "m2"),
            forgotten = mapOf("req-1" to true, "req-2" to false), charged = true)
        val back = BookJson.fromJson(BookJson.toJson(b))
        assertEquals(b, back)
    }

    @Test fun everyThemeHasGuidance() {
        assertEquals(6, BookThemes.ALL.size)
        assertTrue(BookThemes.ALL.all { it.guidance.length > 80 })
        assertEquals("dark", BookThemes.of("dark").key)
    }
}
