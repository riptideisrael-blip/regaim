package com.regaim.app

/**
 * Finds the red apples in a scene's picture (the counting game: the child touches the real apples on the tree, not
 * pictures pasted over it). Red, round, apple-sized spots, apart from each other, the biggest first. Works on plain
 * pixels (ARGB ints), no Android here (unit-tested).
 */
object AppleSpots {
    /** An apple: its center and radius, in the picture's pixels. */
    data class Spot(val x: Float, val y: Float, val r: Float)

    private fun red(p: Int): Boolean {
        val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
        if (r < 105) return false
        val min = minOf(g, b)
        val sat = (r - min).toFloat() / r
        return sat >= 0.45f && r > g * 1.5f && r > b * 1.5f
    }

    /** Up to [n] apples in a [w]×[h] picture, biggest first (fewer when the picture has fewer). */
    fun find(px: IntArray, w: Int, h: Int, n: Int): List<Spot> {
        if (w <= 0 || h <= 0 || px.size < w * h || n <= 0) return emptyList()
        val seen = BooleanArray(w * h)
        val total = w * h
        val minArea = maxOf(6, (total * 0.0003f).toInt())
        val maxArea = (total * 0.03f).toInt()
        val found = ArrayList<Pair<Spot, Int>>()
        val queue = IntArray(total)
        for (start in 0 until total) {
            if (seen[start] || !red(px[start])) continue
            // One red patch (4-connected).
            var head = 0; var tail = 0
            queue[tail++] = start; seen[start] = true
            var sx = 0L; var sy = 0L; var minX = w; var maxX = 0; var minY = h; var maxY = 0
            while (head < tail) {
                val i = queue[head++]
                val x = i % w; val y = i / w
                sx += x; sy += y
                if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
                if (x > 0) { val j = i - 1; if (!seen[j] && red(px[j])) { seen[j] = true; queue[tail++] = j } }
                if (x < w - 1) { val j = i + 1; if (!seen[j] && red(px[j])) { seen[j] = true; queue[tail++] = j } }
                if (y > 0) { val j = i - w; if (!seen[j] && red(px[j])) { seen[j] = true; queue[tail++] = j } }
                if (y < h - 1) { val j = i + w; if (!seen[j] && red(px[j])) { seen[j] = true; queue[tail++] = j } }
            }
            val area = tail
            if (area < minArea || area > maxArea) continue
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val aspect = bw.toFloat() / bh
            // Round-ish and filled (an apple, not a red stripe or a scatter of red dots).
            if (aspect < 0.55f || aspect > 1.8f) continue
            if (area.toFloat() / (bw * bh) < 0.45f) continue
            val cy = sy.toFloat() / area
            // Not at the very edges (the ground's fallen apples at the bottom, cut-off ones at the top).
            if (cy > h * 0.86f || cy < h * 0.03f) continue
            found.add(Spot(sx.toFloat() / area, cy, maxOf(bw, bh) / 2f) to area)
        }
        val out = ArrayList<Spot>()
        for ((s, _) in found.sortedByDescending { it.second }) {
            if (out.any { o -> kotlin.math.hypot((o.x - s.x).toDouble(), (o.y - s.y).toDouble()) < (o.r + s.r) * 1.25 }) continue
            out.add(s)
            if (out.size == n) break
        }
        return out
    }
}
