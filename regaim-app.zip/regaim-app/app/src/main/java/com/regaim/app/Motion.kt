package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.TransitionDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.util.WeakHashMap
import java.util.concurrent.Executors

/**
 * "Living" thumbnails: ~3 seconds around the heart of each moment (the laugh, the word, the hug),
 * shown as a soft looping flipbook. Frames are taken once, cached on disk, and only animate while on screen.
 */
object Motion {
    private const val FRAMES = 8
    private const val SPAN_MS = 3000L
    private const val STEP_MS = 400L
    private val pool = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val running = WeakHashMap<ImageView, Runnable>()
    private val mem = object : android.util.LruCache<String, List<Bitmap>>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: List<Bitmap>) = value.sumOf { it.byteCount }
    }

    fun enabled(ctx: Context) = Settings.prefs(ctx).getBoolean("motion_on", true)

    private fun key(m: Memory) = "${m.id}_${m.durationMs}_${m.highlight}"
    private fun dir(ctx: Context) = File(ctx.filesDir, "motion").apply { mkdirs() }

    /** Background thread only. */
    private fun frames(ctx: Context, m: Memory, width: Int): List<Bitmap> {
        val k = key(m)
        mem.get(k)?.let { return it }
        val files = (0 until FRAMES).map { File(dir(ctx), "${k}_$it.jpg") }
        val list = if (files.all { it.exists() }) {
            files.mapNotNull { BitmapFactory.decodeFile(it.absolutePath) }
        } else {
            val mmr = MediaMetadataRetriever()
            try {
                if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
                val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: m.durationMs
                val start = (m.highlight - SPAN_MS / 2).coerceIn(0, (dur - SPAN_MS).coerceAtLeast(0))
                (0 until FRAMES).mapNotNull { i ->
                    val t = (start + SPAN_MS * i / (FRAMES - 1)) * 1000
                    val raw = if (Build.VERSION.SDK_INT >= 27) {
                        mmr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST, width, width * 2)
                    } else mmr.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST)
                    raw?.let { b ->
                        val s = if (b.width > width) Bitmap.createScaledBitmap(b, width, (b.height * width.toFloat() / b.width).toInt(), true) else b
                        try { FileOutputStream(files[i]).use { o -> s.compress(Bitmap.CompressFormat.JPEG, 80, o) } } catch (_: Exception) {}
                        s
                    }
                }
            } catch (_: Throwable) {
                emptyList()
            } finally {
                try { mmr.release() } catch (_: Exception) {}
            }
        }
        if (list.size >= 3) mem.put(k, list)
        return list
    }

    /**
     * Starts the living preview in [iv] once its frames are ready (the static cover stays until then).
     * [round] clips it to a circle (for the round bubbles).
     */
    fun attach(iv: ImageView, m: Memory, round: Boolean = false, width: Int = 360) {
        stop(iv)
        if (!enabled(iv.context)) return
        val k = key(m)
        iv.setTag(R.id.motionTag, k)
        val ctx = iv.context.applicationContext
        val begin = Runnable {
            pool.execute {
                if (iv.getTag(R.id.motionTag) != k || !iv.isAttachedToWindow) return@execute
                val list = try { frames(ctx, m, width) } catch (_: Throwable) { emptyList() }
                if (list.size < 3) return@execute
                main.post { if (iv.getTag(R.id.motionTag) == k && iv.isAttachedToWindow) play(iv, list, round) }
            }
        }
        if (iv.isAttachedToWindow) begin.run()
        iv.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                if (iv.getTag(R.id.motionTag) == k && running[iv] == null) begin.run()
            }
            override fun onViewDetachedFromWindow(v: View) {
                stop(iv)
                if (iv.getTag(R.id.motionTag) != k) iv.removeOnAttachStateChangeListener(this)
            }
        })
    }

    private fun play(iv: ImageView, list: List<Bitmap>, round: Boolean) {
        stop(iv)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (round) {
            iv.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            iv.clipToOutline = true
        }
        var i = 0
        var prev: BitmapDrawable = BitmapDrawable(iv.resources, list[0])
        iv.setImageDrawable(prev)
        val tick = object : Runnable {
            override fun run() {
                if (!iv.isAttachedToWindow) return
                // Forward, then gently back: a smooth "boomerang" loop.
                val n = list.size
                val pos = i % (2 * n - 2)
                val idx = if (pos < n) pos else 2 * n - 2 - pos
                i++
                val next = BitmapDrawable(iv.resources, list[idx])
                val t = TransitionDrawable(arrayOf(prev, next)).apply { isCrossFadeEnabled = true }
                iv.setImageDrawable(t)
                t.startTransition((STEP_MS * 0.8).toInt())
                prev = next
                main.postDelayed(this, STEP_MS)
            }
        }
        running[iv] = tick
        main.postDelayed(tick, STEP_MS)
    }

    fun stop(iv: ImageView) {
        running.remove(iv)?.let { main.removeCallbacks(it) }
    }
}
