package com.regaim.app

import android.app.Application

class RegaimApp : Application() {
    override fun onCreate() {
        super.onCreate()
        L.init(this)
        Fonts.install(this)
        Reminders.schedule(this)
    }
}
