package com.regaim.app

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/** "Ask Regaim": a chat that searches your memories ("where was I yesterday?", "the baby's first steps"). */
class ChatActivity : AppCompatActivity() {

    private lateinit var scroll: ScrollView
    private lateinit var thread: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendBtn: TextView
    private lateinit var analyzeStatus: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val history = mutableListOf<Pair<String, String>>() // role, text
    private var busy = false

    private val suggestions = listOf(
        "איפה הייתי אתמול?",
        "תראי לי את הצעד הראשון של התינוק",
        "מה היה הרגע הכי מצחיק השבוע?",
        "תראי לי רגעים מהגן שעשועים",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        scroll = findViewById(R.id.chatScroll)
        thread = findViewById(R.id.chatThread)
        input = findViewById(R.id.chatInput)
        sendBtn = findViewById(R.id.btnSend)
        analyzeStatus = findViewById(R.id.analyzeStatus)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnKey).setOnClickListener { askForKey() }
        sendBtn.setOnClickListener { send(input.text.toString()) }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send(input.text.toString())
                true
            } else false
        }

        val chips = findViewById<LinearLayout>(R.id.suggestions)
        for (q in suggestions) {
            val chip = layoutInflater.inflate(R.layout.item_chip, chips, false) as TextView
            chip.text = q
            chip.setOnClickListener { send(q) }
            chips.addView(chip)
        }

        addAssistant("היי! אני רגעים. שאל אותי על הזיכרונות שלך, ואני אמצא לך אותם.", emptyList())
        if (!ClaudeClient.hasKey(this)) askForKey()
    }

    override fun onResume() {
        super.onResume()
        analyzeInBackground()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------- AI ----------

    private fun analyzeInBackground() {
        if (!ClaudeClient.hasKey(this)) return
        val pending = MemoryStore.all(this).count { !it.analyzed }
        if (pending == 0) {
            analyzeStatus.visibility = View.GONE
            return
        }
        analyzeStatus.visibility = View.VISIBLE
        analyzeStatus.text = "ה-AI מסתכל על $pending רגעים חדשים..."
        worker.execute {
            MemoryStore.analyzePending(applicationContext)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                val left = MemoryStore.all(this).count { !it.analyzed }
                if (left == 0) {
                    analyzeStatus.visibility = View.GONE
                } else {
                    analyzeStatus.text = "$left רגעים עדיין לא נותחו. ${Status.error ?: ""}"
                }
            }
        }
    }

    private fun send(raw: String) {
        val q = raw.trim()
        if (q.isEmpty() || busy) return
        if (!ClaudeClient.hasKey(this)) {
            askForKey()
            return
        }
        input.setText("")
        addUser(q)
        val thinking = addAssistant("חושבת...", emptyList())
        busy = true
        sendBtn.isEnabled = false
        val past = history.toList()
        worker.execute {
            val result = try {
                val memories = MemoryStore.all(applicationContext)
                if (memories.isEmpty()) {
                    ClaudeClient.Answer("עוד אין רגעים שמורים. הפעל את ההקלטה, וכל צחוק יישמר כבועה שאפשר לשאול עליה.", emptyList())
                } else {
                    ClaudeClient.ask(applicationContext, q, memories, past)
                }
            } catch (e: Exception) {
                ClaudeClient.Answer("משהו השתבש: ${e.message}", emptyList())
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                thread.removeView(thinking)
                val byId = MemoryStore.all(this).associateBy { it.id }
                addAssistant(result.text, result.ids.mapNotNull { byId[it] })
                history.add("user" to q)
                history.add("assistant" to result.text)
                busy = false
                sendBtn.isEnabled = true
            }
        }
    }

    // ---------- chat views ----------

    private fun addUser(text: String) {
        val tv = bubbleText(text, R.drawable.chat_user_bg, ContextCompat.getColor(this, R.color.white))
        val row = LinearLayout(this).apply {
            gravity = Gravity.START // RTL: user on the right
            addView(tv)
        }
        thread.addView(row)
        scrollDown()
    }

    private fun addAssistant(text: String, memories: List<Memory>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(LinearLayout(this).apply {
            gravity = Gravity.END
            addView(bubbleText(text, R.drawable.chat_ai_bg, ContextCompat.getColor(this@ChatActivity, R.color.ink)))
        })
        if (memories.isNotEmpty()) {
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in memories.take(12)) strip.addView(memoryBubble(m))
            box.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(strip)
            })
        }
        thread.addView(box)
        scrollDown()
        return box
    }

    private fun bubbleText(text: String, bg: Int, color: Int): TextView {
        val pad = dp(14)
        return TextView(this).apply {
            this.text = text
            setTextColor(color)
            textSize = 16f
            setLineSpacing(dp(3).toFloat(), 1f)
            setBackgroundResource(bg)
            setPadding(pad, dp(10), pad, dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { setMargins(0, dp(6), 0, dp(6)) }
        }
    }

    private fun memoryBubble(m: Memory): View {
        val v = LayoutInflater.from(this).inflate(R.layout.item_bubble, null, false)
        v.layoutParams = LinearLayout.LayoutParams(dp(120), LinearLayout.LayoutParams.WRAP_CONTENT)
        val img = v.findViewById<ImageView>(R.id.bubbleImage)
        val bmp = if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb) else null
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.drawable.bubble_placeholder)
        v.findViewById<TextView>(R.id.bubbleTitle).text = java.text.SimpleDateFormat("d.M HH:mm", java.util.Locale.US).format(java.util.Date(m.time))
        v.findViewById<TextView>(R.id.bubbleSub).text = m.place.ifEmpty { Labels.he(m.label) }
        v.setOnClickListener { play(m) }
        return v
    }

    private fun play(m: Memory) {
        try {
            val uri = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.parse("file://" + m.uri)
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "הקליפ נמצא בגלריה, תיקייה Regaim", Toast.LENGTH_LONG).show()
        }
    }

    private fun askForKey() {
        val field = EditText(this).apply {
            hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(ClaudeClient.apiKey(this@ChatActivity))
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("מפתח API של Claude")
            .setMessage("כדי שה-AI יבין את הרגעים, הדבק מפתח מ-console.anthropic.com. המפתח נשמר רק בטלפון הזה.")
            .setView(field)
            .setPositiveButton("שמור") { _, _ ->
                ClaudeClient.setApiKey(this, field.text.toString())
                if (ClaudeClient.hasKey(this)) analyzeInBackground()
                else Toast.makeText(this, "המפתח צריך להתחיל ב-sk-", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("איפה משיגים?") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.anthropic.com/settings/keys")))
                } catch (_: Exception) {
                }
            }
            .setNegativeButton("אחר כך", null)
            .show()
    }

    private fun scrollDown() = scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
