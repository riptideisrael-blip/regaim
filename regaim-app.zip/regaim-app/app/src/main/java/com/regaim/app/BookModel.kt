package com.regaim.app

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A theme for a personal book, with the guidance the story writer follows (gentle, never shaming or scary). */
data class BookTheme(val key: String, val he: String, val en: String, val guidance: String) {
    val title: String get() = L.t(he, en)
}

object BookThemes {
    val ALL = listOf(
        BookTheme("pacifier", "נפרדים מהמוצץ", "Saying goodbye to the pacifier",
            "The child gently and gradually says goodbye to the pacifier (for example giving it to someone who needs it, or a special goodbye ritual). " +
                "Validate that it is hard and that it's okay to miss it. A loving parent helps with comfort alternatives (a hug, a song, a soft toy). " +
                "The child feels proud and grown-up at the end. Never shame the child or call the pacifier bad."),
        BookTheme("diaper", "להתחיל להשתמש בסיר", "Starting to use the potty",
            "The child learns to use the potty/toilet step by step. Accidents are normal and nobody is angry. Celebrate small successes. " +
                "The body is natural; no shame, no pressure, no rewards that feel like bribes. Proud, happy ending."),
        BookTheme("dark", "לא מפחדים מהחושך", "Not afraid of the dark",
            "The child feels afraid in the dark at bedtime. Validate the feeling. Together with a parent the child discovers the room is the same " +
                "room in the dark (a night light, a brave cuddly toy, naming the familiar shapes). No monsters described in detail, nothing scary. " +
                "Calm, safe, sleepy ending."),
        BookTheme("sibling", "אח או אחות חדשים", "A new baby in the family",
            "A new baby joins the family. The child has mixed feelings (excited, a little jealous, missing special time) and that's okay. " +
                "The parents' love is not divided; the child has a special role as a big sibling and still gets one-on-one time. Warm ending."),
        BookTheme("confidence", "אני יכול/ה!", "I can do it!",
            "The child tries something new that feels hard (climbing, a new place, trying again after failing). Effort matters more than winning. " +
                "Small brave steps, a supportive parent, pride in trying. Encouraging ending."),
        BookTheme("sleep", "נרדמים לבד", "Falling asleep on my own",
            "The child learns to fall asleep in their own bed. A calming bedtime routine (bath, story, cuddle, a favorite toy), the parent is near, " +
                "the child learns to calm their body. Very soothing rhythm, sleepy and safe ending."),
    )

    fun of(key: String): BookTheme = ALL.firstOrNull { it.key == key } ?: ALL.first()
}

data class BookPage(
    val text: String,
    /** English description of the picture (sent to the illustrator). */
    val scene: String,
    /** File name inside the book's folder, empty until drawn. */
    val image: String = "",
    /** "todo", "done" or "failed". */
    val status: String = "todo",
    val tries: Int = 0,
)

data class Book(
    val id: String,
    val child: String,
    /** English age description for the illustrator ("3-year-old boy"). */
    val ageDesc: String,
    val theme: String,
    val lang: String,
    val title: String,
    val outfit: String,
    val cover: BookPage,
    val pages: List<BookPage>,
    /** The approved character drawing (file name), empty until drawn. */
    val character: String = "",
    val characterTries: Int = 0,
    /** "photos", "writing", "character", "approve", "pages", "done", "failed". */
    val state: String = "writing",
    val created: Long = System.currentTimeMillis(),
    /** Memories the face photos came from (never uploaded except as the face crops themselves). */
    val photoSources: List<String> = emptyList(),
    /** Every fal request id, and whether fal confirmed deleting it. */
    val forgotten: Map<String, Boolean> = emptyMap(),
    val error: String = "",
    /** One credit was taken for this book (its server reference is the book id). */
    val charged: Boolean = false,
) {
    val allPages: List<BookPage> get() = listOf(cover) + pages
    val done: Boolean get() = state == "done"
}

/** Pure helpers: story JSON, book JSON, the age line. Unit tested. */
object BookJson {
    class Story(val title: String, val outfit: String, val coverScene: String, val pages: List<Pair<String, String>>)

    /** Parses and checks the story writer's answer. Null when it isn't usable (then we ask once more). */
    fun story(text: String, minPages: Int = 5, maxPages: Int = 8): Story? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val o = try { JSONObject(text.substring(start, end + 1)) } catch (_: Exception) { return null }
        val title = o.optString("title").trim()
        val outfit = o.optString("outfit").trim()
        val cover = o.optString("cover_scene").trim()
        val arr = o.optJSONArray("pages") ?: return null
        val pages = (0 until arr.length()).mapNotNull { i ->
            val p = arr.optJSONObject(i) ?: return@mapNotNull null
            val t = p.optString("text").trim()
            val s = p.optString("scene").trim()
            if (t.isEmpty() || s.isEmpty()) null else t.take(400) to s.take(700)
        }
        if (title.isEmpty() || pages.size < minPages) return null
        return Story(title.take(80), outfit.ifEmpty { "a simple comfortable everyday outfit" }.take(200), cover.ifEmpty { pages.first().second }.take(700), pages.take(maxPages))
    }

    /** "3-year-old boy", "toddler girl of about 18 months", "young child" (no birth date). */
    fun ageDesc(months: Int?, girl: Boolean?): String {
        val who = when (girl) { true -> "girl"; false -> "boy"; null -> "child" }
        return when {
            months == null || months < 0 -> "young $who"
            months < 12 -> "baby $who of about $months months"
            months < 24 -> "toddler $who of about $months months"
            else -> "${months / 12}-year-old $who"
        }
    }

    /** How long each page's text may be, by age (shorter for little ones). */
    fun wordsPerPage(months: Int?): Int = when {
        months == null -> 30
        months < 30 -> 18
        months < 48 -> 28
        else -> 40
    }

    fun toJson(b: Book): JSONObject {
        fun page(p: BookPage) = JSONObject().put("text", p.text).put("scene", p.scene).put("image", p.image).put("status", p.status).put("tries", p.tries)
        return JSONObject()
            .put("id", b.id).put("child", b.child).put("age", b.ageDesc).put("theme", b.theme).put("lang", b.lang)
            .put("title", b.title).put("outfit", b.outfit).put("cover", page(b.cover))
            .put("pages", JSONArray().also { a -> b.pages.forEach { a.put(page(it)) } })
            .put("character", b.character).put("characterTries", b.characterTries).put("state", b.state).put("created", b.created)
            .put("photoSources", JSONArray(b.photoSources))
            .put("forgotten", JSONObject().also { o -> b.forgotten.forEach { (k, v) -> o.put(k, v) } })
            .put("error", b.error)
            .put("charged", b.charged)
    }

    fun fromJson(o: JSONObject): Book {
        fun page(p: JSONObject?) = BookPage(p?.optString("text").orEmpty(), p?.optString("scene").orEmpty(), p?.optString("image").orEmpty(),
            p?.optString("status", "todo") ?: "todo", p?.optInt("tries") ?: 0)
        val pages = o.optJSONArray("pages") ?: JSONArray()
        val srcs = o.optJSONArray("photoSources") ?: JSONArray()
        val forgot = o.optJSONObject("forgotten") ?: JSONObject()
        return Book(
            o.optString("id"), o.optString("child"), o.optString("age"), o.optString("theme"), o.optString("lang", "he"),
            o.optString("title"), o.optString("outfit"), page(o.optJSONObject("cover")),
            (0 until pages.length()).map { page(pages.optJSONObject(it)) },
            o.optString("character"), o.optInt("characterTries"), o.optString("state", "writing"), o.optLong("created"),
            (0 until srcs.length()).map { srcs.optString(it) },
            forgot.keys().asSequence().associateWith { forgot.optBoolean(it) },
            o.optString("error"),
            o.optBoolean("charged"),
        )
    }
}

/** Choosing the best face photos of the child automatically. Pure scoring, unit tested; the Android part is in BookPhotos. */
object FaceQuality {
    /** What we measured about one face of the child. */
    data class Stats(
        val key: String,
        /** Same day / same memory = the same "moment" (for variety). */
        val group: String,
        /** Face size in pixels (shorter side of the box). */
        val side: Int,
        /** 0 = blur, 1 = sharp (of the face area). */
        val sharp: Float,
        /** Mean brightness of the face 0..255, and how much is burnt or black (0..1). */
        val mean: Float,
        val clipped: Float,
        /** Head angles in degrees (ML Kit). */
        val yaw: Float,
        val roll: Float,
        /** Both eyes open probability, -1 unknown. */
        val eyes: Float,
        /** Face-print distance to the child (lower = surer). */
        val dist: Float,
        val ageDays: Long,
        /** Another face overlapping this one (a hug, a sibling): confusing for the illustrator. */
        val crowded: Boolean = false,
    )

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }

    fun score(s: Stats): Float {
        val size = smooth(110f, 380f, s.side.toFloat())
        val sharp = s.sharp.coerceIn(0f, 1f)
        val exposure = (1f - abs(s.mean - 140f) / 140f).coerceIn(0f, 1f) * (1f - s.clipped.coerceIn(0f, 1f))
        val pose = (1f - smooth(12f, 40f, abs(s.yaw))) * (1f - smooth(10f, 30f, abs(s.roll)))
        val eyes = if (s.eyes < 0f) 0.7f else smooth(0.3f, 0.8f, s.eyes)
        // Children change fast: the last three months count fully, a year-old photo about half.
        val recency = when {
            s.ageDays <= 90 -> 1f
            s.ageDays <= 365 -> 1f - 0.5f * (s.ageDays - 90) / 275f
            else -> 0.35f
        }
        val sure = 1f - smooth(0.55f, 0.82f, s.dist)
        var q = 0.25f * size + 0.25f * sharp + 0.15f * exposure + 0.2f * pose + 0.15f * eyes
        if (s.crowded) q *= 0.7f
        return (q * recency * (0.5f + 0.5f * sure)).coerceIn(0f, 1f)
    }

    /** Good enough to draw from. */
    const val GOOD = 0.42f

    /**
     * Up to [n] faces: the best first, then from other days, and at least one looking at the camera when possible.
     * Returns the chosen stats (best first).
     */
    fun pick(all: List<Stats>, n: Int = 3, min: Float = GOOD): List<Stats> {
        val good = all.filter { score(it) >= min }.sortedByDescending { score(it) }
        val out = ArrayList<Stats>()
        for (s in good) {
            if (out.size >= n) break
            if (out.any { it.group == s.group }) continue
            out.add(s)
        }
        // Fill from the same days if there weren't enough different ones.
        for (s in good) { if (out.size >= n) break; if (s !in out) out.add(s) }
        // One frontal face in the set (the illustrator needs it).
        if (out.none { abs(it.yaw) < 15f }) good.firstOrNull { abs(it.yaw) < 15f }?.let { f -> if (out.size >= n) out[out.size - 1] = f else out.add(f) }
        return out.sortedByDescending { score(it) }
    }
}

/**
 * Making sure the book's photos are all the same child. Face recognition passes faces that are close enough to the
 * child, but siblings can pass too. Two checks, pure and unit tested:
 *  - faces that look more like a face the parent already said "this isn't him/her" are dropped;
 *  - when the faces split clearly into two groups (two children), only the group closer to the child's own
 *    reference photos (the profile photo and the faces named as the child) is kept.
 */
object FaceGroups {
    /** [anchorDist]: distance to the child's reference prints (lower = more like the child). */
    class Cand(val key: String, val print: FloatArray, val anchorDist: Float)

    fun dist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) { val d = a[i] - b[i]; s += d * d }
        return kotlin.math.sqrt(s)
    }

    fun notRejected(c: List<Cand>, rejected: List<FloatArray>): List<Cand> =
        c.filter { x -> rejected.none { r -> r.size == x.print.size && dist(x.print, r) < LOOKALIKE * x.anchorDist } }

    /** A face is dropped with a rejected one only if it's clearly nearer to it than to the child (siblings are close). */
    const val LOOKALIKE = 0.8f

    /** How clearly the faces form two groups (silhouette, -1..1; above ~0.15 = two different faces). */
    fun silhouette(g1: List<Cand>, g2: List<Cand>): Float {
        val all = g1 + g2
        if (g1.isEmpty() || g2.isEmpty()) return 0f
        var sum = 0f
        for (x in all) {
            val own = if (x in g1) g1 else g2
            val other = if (x in g1) g2 else g1
            if (own.size < 2) continue // a single face: no information (counts as 0)
            val a = own.filter { it !== x }.map { dist(x.print, it.print) }.average().toFloat()
            val b = other.map { dist(x.print, it.print) }.average().toFloat()
            sum += (b - a) / max(a, b).coerceAtLeast(1e-6f)
        }
        return sum / all.size
    }

    private fun medoid(g: List<Cand>): Cand = g.minByOrNull { x -> g.sumOf { dist(x.print, it.print).toDouble() } }!!

    fun sameChild(c: List<Cand>, split: Float = 0.15f): List<Cand> {
        if (c.size < 3) return c
        var m1 = c.minByOrNull { it.anchorDist }!!
        var m2 = c.maxByOrNull { dist(it.print, m1.print) }!!
        var g1 = c; var g2 = emptyList<Cand>()
        repeat(6) {
            g1 = c.filter { dist(it.print, m1.print) <= dist(it.print, m2.print) }
            g2 = c.filter { it !in g1 }
            if (g2.isEmpty()) return c
            m1 = medoid(g1); m2 = medoid(g2)
        }
        if (silhouette(g1, g2) < split) return c // one child
        val a1 = g1.map { it.anchorDist }.average()
        val a2 = g2.map { it.anchorDist }.average()
        return if (a1 <= a2) g1 else g2
    }
}
