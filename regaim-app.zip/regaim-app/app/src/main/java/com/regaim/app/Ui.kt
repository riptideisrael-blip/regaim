package com.regaim.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

/** Small helpers to build the settings-style screens in code, in the Moments look. */
class Ui(private val a: Activity) {
    /** Called whenever the user changes a switch, chip or text field built by this helper (e.g. to show "save"). */
    var onChange: (() -> Unit)? = null

    private val d = a.resources.displayMetrics.density
    fun dp(v: Int) = (v * d).toInt()
    fun color(id: Int) = ContextCompat.getColor(a, id)

    private fun wrapLp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    fun text(s: CharSequence, size: Float = 15f, colorRes: Int = R.color.ink, bold: Boolean = false, top: Int = 0) =
        TextView(a).apply {
            text = s
            textSize = size
            setTextColor(color(colorRes))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(dp(2).toFloat(), 1f)
            layoutParams = wrapLp(top)
        }

    /** Section title above a card. */
    fun section(s: String) = text(s, 18f, R.color.ink, bold = true, top = 22)

    fun hint(s: String, top: Int = 4) = text(s, 13f, R.color.ink_soft, top = top)

    fun card(top: Int = 8) = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundResource(R.drawable.card_white)
        elevation = dp(2).toFloat()
        outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = wrapLp(top)
    }

    fun divider() = View(a).apply {
        setBackgroundColor(0x14000000)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(12); bottomMargin = dp(4)
        }
    }

    fun switch(label: String, checked: Boolean, top: Int = 8, onChange: (Boolean) -> Unit) = SwitchCompat(a).apply {
        text = label
        textSize = 15f
        setTextColor(color(R.color.ink))
        isChecked = checked
        thumbTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(color(R.color.accent), 0xFFBDBACB.toInt()),
        )
        trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(0x665B4FE0, 0x33000000),
        )
        layoutParams = wrapLp(top)
        setOnCheckedChangeListener { _, on ->
            onChange(on)
            this@Ui.onChange?.invoke()
        }
    }

    /** Soft purple button (primary = solid accent). */
    fun button(label: String, primary: Boolean = false, top: Int = 10, onClick: () -> Unit) = MaterialButton(a).apply {
        text = label
        textSize = 15f
        setAllCaps(false)
        cornerRadius = dp(24)
        backgroundTintList = ColorStateList.valueOf(if (primary) color(R.color.accent) else 0xFFE9E7FB.toInt())
        setTextColor(if (primary) color(R.color.white) else color(R.color.accent_dark))
        layoutParams = wrapLp(top)
        setOnClickListener { onClick() }
    }

    /** A text link-like row: label on the right, value / arrow on the left. */
    fun row(label: String, value: String = "", top: Int = 4, onClick: (() -> Unit)? = null) = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(10), 0, dp(10))
        layoutParams = wrapLp(top)
        addView(TextView(a).apply {
            text = label
            textSize = 15f
            setTextColor(color(R.color.ink))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        addView(TextView(a).apply {
            text = if (onClick != null) "$value ›".trim() else value
            textSize = 14f
            setTextColor(color(if (onClick != null) R.color.accent else R.color.ink_soft))
        })
        if (onClick != null) {
            setBackgroundResource(android.R.drawable.list_selector_background)
            setOnClickListener { onClick() }
        }
    }

    fun field(hint: String, value: String, multiline: Boolean = false, top: Int = 8, password: Boolean = false) = EditText(a).apply {
        this.hint = hint
        setText(value)
        textSize = 15f
        setTextColor(color(R.color.ink))
        setBackgroundResource(R.drawable.chat_input_bg)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        gravity = Gravity.TOP or Gravity.START
        inputType = when {
            password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        if (multiline) minLines = 2
        layoutParams = wrapLp(top)
        addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a2: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { onChange?.invoke() }
        })
    }

    /** A row of pill chips; tapping one selects it. */
    fun chips(options: List<String>, selected: Int, top: Int = 8, onPick: (Int) -> Unit): View {
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        fun paint(sel: Int) {
            row.removeAllViews()
            options.forEachIndexed { i, o ->
                row.addView(TextView(a).apply {
                    text = o
                    textSize = 14f
                    gravity = Gravity.CENTER
                    minWidth = dp(56)
                    setPadding(dp(16), dp(9), dp(16), dp(9))
                    val on = i == sel
                    setTypeface(typeface, if (on) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (on) color(R.color.white) else color(R.color.ink))
                    // Outlined white pill; the chosen one filled with the accent color.
                    background = GradientDrawable().apply {
                        cornerRadius = dp(22).toFloat()
                        setColor(if (on) color(R.color.accent) else 0xFFFFFFFF.toInt())
                        if (!on) setStroke(dp(1), 0xFFE4E0D8.toInt())
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { marginEnd = dp(8) }
                    setOnClickListener {
                        paint(i)
                        onPick(i)
                        onChange?.invoke()
                    }
                })
            }
        }
        paint(selected)
        return HorizontalScrollView(a).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = wrapLp(top)
            addView(row)
        }
    }

    /** A round thumbnail of a moment. */
    fun bubble(path: String, sizeDp: Int = 48) = ImageView(a).apply {
        val bmp = if (path.isNotEmpty()) BitmapFactory.decodeFile(path) else null
        if (bmp != null) setImageBitmap(bmp) else setImageResource(R.drawable.bubble_placeholder)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { marginEnd = dp(6) }
    }

    fun horizontal(top: Int = 8) = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = wrapLp(top)
    }

    fun scrollRow(inner: LinearLayout, top: Int = 8) = HorizontalScrollView(a).apply {
        isHorizontalScrollBarEnabled = false
        layoutParams = wrapLp(top)
        addView(inner.apply { layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
    }

    /** Small inline action like "תקן" / "מחק". */
    fun action(label: String, colorRes: Int = R.color.accent, onClick: () -> Unit) = TextView(a).apply {
        text = label
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color(colorRes))
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setBackgroundResource(android.R.drawable.list_selector_background)
        setOnClickListener { onClick() }
    }

    fun padded(v: View): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), 0)
        addView(v)
    }
}
