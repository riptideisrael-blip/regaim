package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * The approval queue: automatic captures, one card at a time, a few seconds around the moment (the existing
 * preview, not the whole clip). 👍 keeps it in the archive; 👎 sends it to the trash and teaches the recorder.
 * Nothing about a queued moment leaves the phone (faces and pets are recognized locally, so a name can show).
 */
class ReviewActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, ReviewActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private var preview: ImageView? = null
    private var kept = 0
    private var dropped = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("רגעים שמחכים", "Moments waiting")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        render()
        // Local only: recognize faces and pets in the queue so the card can show a name.
        worker.execute {
            try { if (PeopleStore.peopleEnabled(applicationContext)) PeopleStore.scanPending(applicationContext) } catch (_: Exception) { }
            try { Pets.scanPending(applicationContext) } catch (_: Throwable) { }
            runOnUiThread { if (!isFinishing && !isDestroyed) render() }
        }
    }

    override fun onDestroy() {
        preview?.let { Motion.stop(it) }
        worker.shutdown()
        super.onDestroy()
    }

    private fun render() {
        preview?.let { Motion.stop(it) }
        preview = null
        content.removeAllViews()
        try { MemoryStore.expirePending(this) } catch (_: Exception) { }
        val queue = MemoryStore.pending(this)
        if (queue.isEmpty()) { done(); return }
        val m = queue.first()

        content.addView(ui.hint(
            if (queue.size == 1) L.t("רגע אחרון", "Last one") else L.t("עוד ${queue.size} רגעים", "${queue.size} moments to go"),
            top = 12,
        ))

        // A few seconds around the moment, with the preview that already exists (not the whole clip).
        val width = resources.displayMetrics.widthPixels - ui.dp(40)
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = ui.dp(20).toFloat(); setColor(0xFFEFEFEF.toInt()) }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (width * 1.2f).toInt()).apply { topMargin = ui.dp(10) }
            if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb)?.let { setImageBitmap(it) }
        }
        content.addView(iv)
        preview = iv
        Motion.attach(iv, m, width = 480)

        val names = Fmt.names(m)
        val what = listOf(
            Labels.he(m.label),
            DateUtils.getRelativeTimeSpanString(m.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
        ).joinToString(" · ")
        content.addView(ui.text(if (names.isNotEmpty()) names.joinToString(", ") else what, 18f, bold = true, top = 14))
        if (names.isNotEmpty()) content.addView(ui.hint(what, top = 2))
        if (m.place.isNotEmpty()) content.addView(ui.hint(m.place, top = 2))

        // 👍 on top, 👎 below.
        content.addView(bigButton("👍  " + L.t("לשמור", "Keep it"), primary = true, top = 18) { keep(m) })
        content.addView(bigButton("👎  " + L.t("לא צריך", "Not needed"), primary = false, top = 10) { drop(m) })
        content.addView(ui.hint(L.t(
            "רגע שלא תגעו בו יעבור לפח אחרי 36 שעות, בלי שנלמד ממנו.",
            "A moment you don't touch moves to the trash after 36 hours, and nothing is learned from it.",
        ), top = 14).apply { gravity = Gravity.CENTER })
    }

    private fun bigButton(label: String, primary: Boolean, top: Int, onClick: () -> Unit): View = TextView(this).apply {
        text = label
        textSize = 17f
        gravity = Gravity.CENTER
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (primary) 0xFFFFFFFF.toInt() else ui.color(R.color.ink))
        background = GradientDrawable().apply {
            cornerRadius = ui.dp(28).toFloat()
            if (primary) setColor(0xFF2B3A35.toInt()) else { setColor(0xFFEFEFEF.toInt()) }
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(56)).apply { topMargin = ui.dp(top) }
        setOnClickListener { onClick() }
    }

    /** 👍: into the archive as approved (not a favorite, not "chosen"), a vote for its label, then the usual description. */
    private fun keep(m: Memory) {
        MemoryStore.approve(this, m.id)
        CaptureVotes.up(this, m.label, score(m))
        kept++
        worker.execute { try { MemoryStore.analyzePending(applicationContext) } catch (_: Exception) { } }
        render()
    }

    /** 👎: to the trash with learning (the recorder remembers the look); a vote against its label. Nothing goes to the cloud. */
    private fun drop(m: Memory) {
        MemoryStore.moveToTrash(this, setOf(m.id), learn = true)
        CaptureVotes.down(this, m.label, score(m))
        dropped++
        render()
    }

    /** The detector's score when it saved this moment (-1 when there is none, e.g. a smile). */
    private fun score(m: Memory): Float = Facts.get(this, m.id)?.optDouble("trigger_score", -1.0)?.toFloat() ?: -1f

    private fun done() {
        content.addView(ui.heading(L.t("הכל עבר", "All done"), 24f, top = 24))
        if (kept + dropped > 0) content.addView(ui.hint(L.t("נשמרו $kept · נזרקו $dropped. תודה, Moments לומד מזה.", "Kept $kept · dropped $dropped. Thanks, Moments learns from this."), top = 6))
        else content.addView(ui.hint(L.t("אין רגעים שמחכים לאישור.", "No moments are waiting."), top = 6))
        content.addView(ui.button(L.t("לזיכרונות", "Open memories"), primary = true, top = 18) {
            startActivity(Intent(this, MemoriesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)); finish()
        })
    }
}
