package com.regaim.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** The visual building blocks for memories: big cards, the hero, small covers, avatars, the heart. */
class MemoryViews(private val a: Activity) {
    private val ui = Ui(a)
    fun dp(v: Int) = ui.dp(v)
    private fun color(id: Int) = ContextCompat.getColor(a, id)

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    /** Rounded media frame with a cover image filling it. */
    private fun media(m: Memory, heightDp: Int): Pair<FrameLayout, ImageView> {
        val frame = FrameLayout(a).apply {
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
        }
        val img = ImageView(a).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        frame.addView(img)
        Covers.load(img, m)
        return frame to img
    }

    /** Small "▶ 0:30" pill: this memory is a video. */
    private fun videoPill(m: Memory) = TextView(a).apply {
        text = "▶ ${Fmt.shortDuration(m.durationMs)}"
        textSize = 12f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color(R.color.white))
        setBackgroundResource(R.drawable.pill_dark)
        setPadding(dp(10), dp(4), dp(10), dp(4))
    }

    /** Heart toggle; updates the memory and pops softly. */
    fun heart(m: Memory, sizeDp: Int = 38, onDark: Boolean = true, onChange: ((Memory) -> Unit)? = null): ImageView {
        var fav = m.favorite
        return ImageView(a).apply {
            val p = dp(8)
            setPadding(p, p, p, p)
            if (onDark) setBackgroundResource(R.drawable.pill_dark)
            fun paint() {
                setImageResource(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline)
                setColorFilter(if (fav) color(R.color.heart) else if (onDark) color(R.color.white) else color(R.color.ink_soft))
            }
            paint()
            contentDescription = "מועדף"
            setOnClickListener {
                val fresh = MemoryStore.get(a, m.id) ?: m
                fav = !fresh.favorite
                val updated = fresh.copy(favorite = fav)
                MemoryStore.update(a, updated)
                paint()
                scaleX = 0.6f; scaleY = 0.6f
                animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(3f)).start()
                onChange?.invoke(updated)
            }
            layoutParams = FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }
    }

    /** Soft pulse for "we're understanding the moment...". */
    fun pulse(v: View) {
        stopPulse(v)
        pulses[v] = ObjectAnimator.ofFloat(v, "alpha", 1f, 0.4f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    fun stopPulse(v: View) {
        pulses.remove(v)?.cancel()
        v.alpha = 1f
    }

    companion object {
        private val pulses = java.util.WeakHashMap<View, ObjectAnimator>()
    }

    /** The big "היום לפני שנה" card: photo with the story written on it. */
    fun hero(label: String, m: Memory, onOpen: () -> Unit): View {
        val (frame, _) = media(m, 300)
        frame.layoutParams = matchWrap(16).apply { height = dp(300) }
        frame.addView(View(a).apply {
            setBackgroundResource(R.drawable.cover_scrim)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190), Gravity.BOTTOM)
        })
        val texts = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(18))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            addView(TextView(a).apply {
                text = label
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFFFE3E3.toInt())
            })
            addView(TextView(a).apply {
                text = Fmt.title(m)
                textSize = 24f
                setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
                setTextColor(color(R.color.white))
                setPadding(0, dp(2), 0, 0)
            })
            addView(TextView(a).apply {
                text = (Fmt.names(m) + listOf(Fmt.fullDate(m.time))).joinToString(" · ")
                textSize = 13f
                setTextColor(0xE6FFFFFF.toInt())
                setPadding(0, dp(2), 0, 0)
            })
        }
        frame.addView(texts)
        frame.addView(videoPill(m).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                setMargins(dp(14), dp(14), dp(14), dp(14))
            }
        })
        frame.setOnClickListener { onOpen() }
        return frame
    }

    /** A memory in the feed: big cover, then title, when, who and where. */
    fun card(m: Memory, onOpen: () -> Unit): View {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = matchWrap(22)
        }
        val (frame, _) = media(m, 220)
        frame.addView(videoPill(m).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(dp(12), dp(12), dp(12), dp(12))
            }
        })
        frame.addView(heart(m).apply {
            layoutParams = FrameLayout.LayoutParams(dp(38), dp(38), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(12), dp(12), dp(12), dp(12))
            }
        })
        if (m.milestone.isNotEmpty()) frame.addView(TextView(a).apply {
            text = "★ ${m.milestone}"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color(R.color.white))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Categories.color("אבן דרך")) }
            setPadding(dp(10), dp(4), dp(10), dp(4))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                setMargins(dp(12), dp(16), dp(12), dp(12))
            }
        })
        frame.setOnClickListener { onOpen() }
        box.addView(frame)

        box.addView(TextView(a).apply {
            text = Fmt.title(m)
            textSize = 18f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(color(R.color.ink))
            setPadding(dp(4), dp(10), dp(4), 0)
            setOnClickListener { onOpen() }
        })
        val meta = TextView(a).apply {
            textSize = 13f
            setPadding(dp(4), dp(2), dp(4), 0)
        }
        if (Fmt.processing(a, m)) {
            meta.text = "${Fmt.dayTime(m.time)} · אנחנו מבינים את הרגע... ✨"
            meta.setTextColor(color(R.color.accent))
            pulse(meta)
        } else {
            meta.text = (listOf(Fmt.dayTime(m.time)) + listOf(Fmt.peopleLine(m)).filter { it.isNotEmpty() }).joinToString(" · ")
            meta.setTextColor(color(R.color.ink_soft))
        }
        box.addView(meta)
        return box
    }

    /** Small portrait cover, for strips. */
    fun mini(m: Memory, wDp: Int = 72, hDp: Int = 96, onOpen: () -> Unit): View {
        val frame = FrameLayout(a).apply {
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(wDp), dp(hDp)).apply { marginEnd = dp(8) }
            setOnClickListener { onOpen() }
        }
        val img = ImageView(a).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        frame.addView(img)
        Covers.load(img, m)
        return frame
    }

    /** Round face (from face recognition) or the first letter on a soft circle. */
    fun avatar(name: String, sizeDp: Int = 56): View {
        val photo = PeopleStore.people(a).firstOrNull { it.name == name }?.photo.orEmpty()
        val bmp = if (photo.isNotEmpty()) BitmapFactory.decodeFile(photo) else null
        val circle = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE9E7FB.toInt()) }
        return if (bmp != null) ImageView(a).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = circle
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        } else TextView(a).apply {
            text = name.take(1)
            textSize = (sizeDp / 2.4f)
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color(R.color.accent_dark))
            background = circle
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }
    }

    /** Avatar with the name under it. */
    fun person(name: String, sub: String = "", onClick: (() -> Unit)? = null): View = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, 0, 0, 0)
        layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) }
        addView(avatar(name))
        addView(TextView(a).apply {
            text = name
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(color(R.color.ink))
            setPadding(0, dp(6), 0, 0)
        })
        if (sub.isNotEmpty()) addView(TextView(a).apply {
            text = sub
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(color(R.color.ink_soft))
        })
        if (onClick != null) setOnClickListener { onClick() }
    }

    /** A soft chip like "😂 צחוק". */
    fun tag(text: String) = TextView(a).apply {
        this.text = text
        textSize = 14f
        setTextColor(color(R.color.ink))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xFFF1ECE6.toInt()) }
        setPadding(dp(14), dp(7), dp(14), dp(7))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8) }
    }

    fun sectionTitle(text: String, top: Int = 30) = TextView(a).apply {
        this.text = text
        textSize = 19f
        setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        setTextColor(color(R.color.ink))
        layoutParams = matchWrap(top)
    }

    /** Fade + rise, for things that appear (AI text, filtered lists). */
    fun reveal(v: View, delay: Long = 0) {
        v.alpha = 0f
        v.translationY = dp(10).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(260).start()
    }
}
