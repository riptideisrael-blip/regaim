package com.regaim.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.RangeSlider
import java.util.Locale
import java.util.concurrent.Executors

/** Shorten a moment: pick the part worth keeping, and only that stays in the gallery. */
class TrimActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, TrimActivity::class.java).putExtra(EXTRA_ID, id))
    }

    private lateinit var memory: Memory
    private lateinit var video: VideoView
    private lateinit var range: RangeSlider
    private lateinit var label: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private val loop = object : Runnable {
        override fun run() {
            // Play only the chosen part, over and over.
            val end = (range.values[1] * 1000).toInt()
            if (video.isPlaying && video.currentPosition >= end) video.seekTo((range.values[0] * 1000).toInt())
            ui.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trim)
        memory = MemoryStore.get(this, intent.getStringExtra(EXTRA_ID) ?: "") ?: run { finish(); return }
        video = findViewById(R.id.trimVideo)
        range = findViewById(R.id.trimRange)
        label = findViewById(R.id.trimLabel)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSaveTrim).setOnClickListener { save() }

        val uri = if (memory.uri.startsWith("content://")) Uri.parse(memory.uri) else Uri.parse("file://" + memory.uri)
        video.setVideoURI(uri)
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            val dur = (mp.duration / 1000f).coerceAtLeast(1f)
            range.valueFrom = 0f
            range.valueTo = dur
            range.stepSize = 0f
            // Suggest the middle around the moment itself (the clip is 15s before + 15s after).
            val mid = dur / 2f
            range.values = listOf((mid - 6f).coerceAtLeast(0f), (mid + 6f).coerceAtMost(dur))
            updateLabel()
            video.seekTo((range.values[0] * 1000).toInt())
            video.start()
        }
        range.addOnChangeListener { slider, _, fromUser ->
            updateLabel()
            if (fromUser) video.seekTo((slider.values[0] * 1000).toInt())
        }
        ui.post(loop)
    }

    override fun onDestroy() {
        ui.removeCallbacks(loop)
        worker.shutdown()
        super.onDestroy()
    }

    private fun fmt(s: Float) = String.format(Locale.US, "%d:%02d", (s / 60).toInt(), (s % 60).toInt())

    private fun updateLabel() {
        val a = range.values[0]
        val b = range.values[1]
        label.text = "שומרים ${fmt(a)} עד ${fmt(b)} · ${(b - a).toInt()} שניות"
    }

    private fun save() {
        val a = (range.values[0] * 1000).toLong()
        val b = (range.values[1] * 1000).toLong()
        if (b - a < 2000) {
            Toast.makeText(this, "צריך לפחות 2 שניות", Toast.LENGTH_SHORT).show()
            return
        }
        video.pause()
        findViewById<View>(R.id.btnSaveTrim).isEnabled = false
        label.text = "מקצר..."
        worker.execute {
            val result = try {
                Result.success(ClipTrimmer.trim(applicationContext, memory, a, b))
            } catch (e: Exception) {
                Result.failure(e)
            }
            runOnUiThread {
                result.onSuccess { m ->
                    MemoryStore.update(this, m)
                    Toast.makeText(this, "הרגע קוצר ל-${(b - a) / 1000} שניות", Toast.LENGTH_SHORT).show()
                    finish()
                }.onFailure { e ->
                    findViewById<View>(R.id.btnSaveTrim).isEnabled = true
                    label.text = "הקיצור נכשל: ${e.message}"
                }
            }
        }
    }
}
