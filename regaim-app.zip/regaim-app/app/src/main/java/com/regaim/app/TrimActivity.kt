package com.regaim.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.RangeSlider
import java.util.Locale
import java.util.concurrent.Executors

/** Shorten a moment: pick the part worth keeping, and only that stays in the gallery. */
class TrimActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, TrimActivity::class.java).putExtra(EXTRA_ID, id))
    }

    private lateinit var memory: Memory
    private lateinit var video: VideoView
    private lateinit var range: RangeSlider
    private lateinit var label: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var prepared = false

    private val loop = object : Runnable {
        override fun run() {
            // Play only the chosen part, over and over. (Before the video is ready the slider has no range yet.)
            try {
                val v = range.values
                if (prepared && v.size >= 2 && video.isPlaying && video.currentPosition >= (v[1] * 1000).toInt()) {
                    video.seekTo((v[0] * 1000).toInt())
                }
            } catch (_: Exception) {
            }
            ui.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trim)
        memory = MemoryStore.get(this, intent.getStringExtra(EXTRA_ID) ?: "") ?: run {
            Toast.makeText(this, "לא מצאתי את הרגע לעריכה", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        video = findViewById(R.id.trimVideo)
        range = findViewById(R.id.trimRange)
        label = findViewById(R.id.trimLabel)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSaveTrim).setOnClickListener { save() }

        // Give the slider two handles right away, so nothing reads a missing handle before the video loads.
        range.valueFrom = 0f
        range.valueTo = 30f
        range.values = listOf(9f, 21f)
        updateLabel()
        video.setOnErrorListener { _, _, _ ->
            label.text = "לא הצלחתי לפתוח את הקליפ לעריכה"
            true
        }

        val uri = if (memory.uri.startsWith("content://")) Uri.parse(memory.uri) else Uri.parse("file://" + memory.uri)
        video.setVideoURI(uri)
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            if (!prepared) {
                try {
                    val dur = (mp.duration / 1000f).coerceAtLeast(3f)
                    // Suggest the middle around the moment itself (the clip is "before + after" the trigger).
                    val mid = dur / 2f
                    val a = (mid - 6f).coerceAtLeast(0f)
                    val b = (mid + 6f).coerceAtMost(dur)
                    range.values = listOf(0f, 1f)
                    range.valueTo = dur
                    range.values = listOf(a, b)
                    prepared = true
                    updateLabel()
                } catch (e: Exception) {
                    label.text = "שגיאה בהכנת העריכה: ${e.message}"
                }
            }
            val v = range.values
            if (v.isNotEmpty()) video.seekTo((v[0] * 1000).toInt())
            video.start()
        }
        range.addOnChangeListener { slider, _, fromUser ->
            updateLabel()
            if (fromUser && slider.values.isNotEmpty()) video.seekTo((slider.values[0] * 1000).toInt())
        }
        ui.post(loop)
    }

    override fun onDestroy() {
        ui.removeCallbacks(loop)
        worker.shutdown()
        super.onDestroy()
    }

    private fun fmt(s: Float) = String.format(Locale.US, "%d:%02d", (s / 60).toInt(), (s % 60).toInt())

    private fun updateLabel() {
        val v = range.values
        if (v.size < 2) return
        val a = v[0]
        val b = v[1]
        label.text = "שומרים ${fmt(a)} עד ${fmt(b)} · ${(b - a).toInt()} שניות"
    }

    private fun save() {
        if (!prepared || range.values.size < 2) return
        val a = (range.values[0] * 1000).toLong()
        val b = (range.values[1] * 1000).toLong()
        if (b - a < 2000) {
            Toast.makeText(this, "צריך לפחות 2 שניות", Toast.LENGTH_SHORT).show()
            return
        }
        video.pause()
        findViewById<View>(R.id.btnSaveTrim).isEnabled = false
        label.text = "מקצר..."
        worker.execute {
            val result = try {
                Result.success(ClipTrimmer.trim(applicationContext, memory, a, b))
            } catch (e: Exception) {
                Result.failure(e)
            }
            runOnUiThread {
                result.onSuccess { m ->
                    MemoryStore.update(this, m)
                    Toast.makeText(this, "הרגע קוצר ל-${(b - a) / 1000} שניות", Toast.LENGTH_SHORT).show()
                    finish()
                }.onFailure { e ->
                    findViewById<View>(R.id.btnSaveTrim).isEnabled = true
                    label.text = "הקיצור נכשל: ${e.message}"
                }
            }
        }
    }
}
