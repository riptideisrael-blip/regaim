package com.regaim.app

import android.content.Context

/** The main picture of an album, chosen by the family. Albums are identified by a key like "m2026-10" or "milestones". */
object AlbumCovers {
    private fun key(album: String) = "album_cover_$album"
    fun get(ctx: Context, album: String): String? = Settings.prefs(ctx).getString(key(album), null)
    fun set(ctx: Context, album: String, memoryId: String?) {
        Settings.prefs(ctx).edit().apply { if (memoryId == null) remove(key(album)) else putString(key(album), memoryId) }.apply()
    }

    /** The album's moments with the chosen cover first (if it still belongs to the album), else best first. */
    fun ordered(ctx: Context, album: String, ms: List<Memory>): List<Memory> {
        val best = ReelMaker.best(ms)
        val chosen = get(ctx, album)?.let { id -> ms.firstOrNull { it.id == id } } ?: return best
        return listOf(chosen) + best.filter { it.id != chosen.id }
    }
}
