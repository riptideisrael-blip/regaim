package com.regaim.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** All user settings live in one prefs file; load() copies them into the live Status used by the recorder. */
object Settings {
    fun prefs(ctx: Context) = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)

    val BEFORE_OPTIONS = listOf(10, 15, 20)
    val AFTER_OPTIONS = listOf(10, 15, 20)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        Status.zoom = p.getFloat("zoom", 0.6f)
        Status.threshold = p.getFloat("threshold2", 0.15f)
        Status.wordsOn = p.getBoolean("words_on", true)
        Status.phrases = Phrases.parse(p.getString("phrases", null) ?: Phrases.DEFAULT.joinToString(", "))
        Status.facesOn = p.getBoolean("faces_on", true)
        Status.laughOn = p.getBoolean("laugh_on", true)
        Status.buzzOn = p.getBoolean("buzz_on", true)
        ClipSaver.PRE_US = p.getInt("before_s", 15).coerceIn(5, 20) * 1_000_000L
        ClipSaver.POST_US = p.getInt("after_s", 15).coerceIn(5, 20) * 1_000_000L
    }

    fun putBool(ctx: Context, key: String, v: Boolean) = prefs(ctx).edit().putBoolean(key, v).apply()
    fun putInt(ctx: Context, key: String, v: Int) = prefs(ctx).edit().putInt(key, v).apply()
    fun putFloat(ctx: Context, key: String, v: Float) = prefs(ctx).edit().putFloat(key, v).apply()
    fun putString(ctx: Context, key: String, v: String) = prefs(ctx).edit().putString(key, v).apply()
}

/** A child in the family profile. birth is yyyy-MM-dd, or empty if not given. */
data class Kid(val name: String, val birth: String)

/** The family profile: who is the parent, who are the kids and how old they are. Used by the AI. */
object Profile {
    private fun p(ctx: Context) = Settings.prefs(ctx)

    fun parentName(ctx: Context) = p(ctx).getString("parent_name", "") ?: ""
    fun role(ctx: Context) = p(ctx).getString("parent_role", "") ?: ""
    fun setParent(ctx: Context, name: String, role: String) =
        p(ctx).edit().putString("parent_name", name.trim()).putString("parent_role", role).apply()

    fun kids(ctx: Context): List<Kid> = try {
        val arr = JSONArray(p(ctx).getString("kids", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Kid(o.optString("name"), o.optString("birth"))
        }.filter { it.name.isNotBlank() }
    } catch (_: Exception) {
        emptyList()
    }

    fun saveKids(ctx: Context, kids: List<Kid>) {
        val arr = JSONArray()
        kids.forEach { arr.put(JSONObject().put("name", it.name.trim()).put("birth", it.birth)) }
        p(ctx).edit().putString("kids", arr.toString()).apply()
    }

    fun isEmpty(ctx: Context) = parentName(ctx).isEmpty() && kids(ctx).isEmpty()

    fun familyName(ctx: Context) = p(ctx).getString("family_name", "") ?: ""
    fun setFamilyName(ctx: Context, name: String) = p(ctx).edit().putString("family_name", name.trim()).apply()

    /** "בית משפחת רביבו": the family name, else the parent's last name, else a warm default. */
    fun homeTitle(ctx: Context): String {
        val fam = familyName(ctx).ifEmpty {
            parentName(ctx).split(" ").filter { it.isNotBlank() }.let { if (it.size >= 2) it.last() else "" }
        }
        return if (fam.isEmpty()) "הבית שלנו" else "בית משפחת $fam"
    }

    /** "גיל 3", "גיל 8 חודשים", "גיל 2 וחצי"; empty if no birthday. */
    fun ageText(birth: String, now: Long = System.currentTimeMillis()): String {
        val parts = birth.split("-").mapNotNull { it.toIntOrNull() }
        if (parts.size != 3) return ""
        val b = Calendar.getInstance().apply { set(parts[0], parts[1] - 1, parts[2], 0, 0, 0) }
        val n = Calendar.getInstance().apply { timeInMillis = now }
        var months = (n.get(Calendar.YEAR) - b.get(Calendar.YEAR)) * 12 + (n.get(Calendar.MONTH) - b.get(Calendar.MONTH))
        if (n.get(Calendar.DAY_OF_MONTH) < b.get(Calendar.DAY_OF_MONTH)) months--
        if (months < 0) return ""
        return when {
            months == 0 -> "פחות מחודש"
            months == 1 -> "גיל חודש"
            months < 24 && months % 12 != 0 && months < 18 -> "גיל $months חודשים"
            months % 12 in 5..7 -> "גיל ${months / 12} וחצי"
            else -> "גיל ${if (months % 12 >= 8) months / 12 + 1 else months / 12}"
        }
    }

    /** One line for AI prompts, at the time of a given moment. Empty if there's no profile. */
    fun describe(ctx: Context, at: Long = System.currentTimeMillis()): String {
        val name = parentName(ctx)
        val role = role(ctx)
        val kids = kids(ctx)
        if (name.isEmpty() && role.isEmpty() && kids.isEmpty()) return ""
        return buildString {
            append("המשפחה: ")
            if (name.isNotEmpty() || role.isNotEmpty()) {
                append("ההורה שמצלם הוא ")
                append(listOf(name, if (role.isNotEmpty()) "($role)" else "").filter { it.isNotEmpty() }.joinToString(" "))
                append(". ")
            }
            if (kids.isNotEmpty()) {
                append("הילדים: ")
                append(kids.joinToString(", ") { k ->
                    val age = ageText(k.birth, at)
                    if (age.isEmpty()) k.name else "${k.name} ($age)"
                })
                append(".")
            }
        }
    }
}
