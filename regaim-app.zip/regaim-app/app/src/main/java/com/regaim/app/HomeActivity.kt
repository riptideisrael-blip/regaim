package com.regaim.app

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import java.util.Calendar
import java.util.concurrent.Executors

/**
 * "בית": the family's home of memories. Opens on "what happened with us?", not on the camera.
 * On this day · today's story · our week (+ weekly video) · filters · latest moments.
 */
class HomeActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var fab: ExtendedFloatingActionButton
    private lateinit var mv: MemoryViews
    private lateinit var ui: Ui
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var filter = "הכל"
    private var recentBox: LinearLayout? = null
    private var shownCount = -1
    private var makingReel = false

    private val tick = object : Runnable {
        override fun run() {
            updateFab()
            // New moments while capturing: refresh quietly.
            if (MemoryStore.all(this@HomeActivity).size != shownCount) render()
            handler.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        Settings.load(this)
        content = findViewById(R.id.homeContent)
        fab = findViewById(R.id.fabCapture)
        mv = MemoryViews(this)
        ui = Ui(this)
        fab.setOnClickListener { openCapture() }
        Nav.setup(this, Nav.Tab.HOME)
        // First launch: the welcome / sign-in screen (it can be skipped).
        if (savedInstanceState == null && !Account.signedIn(this) && !Account.skipped(this)) WelcomeActivity.open(this)
    }

    override fun onResume() {
        super.onResume()
        render()
        handler.post(tick)
        if (ClaudeClient.hasKey(this) || PeopleStore.peopleEnabled(this)) {
            worker.execute {
                val described = try { MemoryStore.analyzePending(applicationContext) } catch (_: Exception) { 0 }
                val wrote = try { MemoryStore.refreshStories(applicationContext, 2) } catch (_: Exception) { false }
                if (described > 0 || wrote) runOnUiThread { if (!isFinishing) render() }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun openCapture() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private fun open(m: Memory) = MomentActivity.open(this, m.id)

    private fun updateFab() {
        if (Status.running) {
            fab.text = if (Status.pending) "נשמר רגע ✓" else "Moments איתכם"
            if (!fab.isExtended) fab.extend()
        } else {
            if (fab.isExtended) fab.shrink()
        }
    }

    // ---------- page ----------

    private fun render() {
        val all = MemoryStore.all(this)
        shownCount = all.size
        content.removeAllViews()
        header()
        updateFab()
        if (all.isEmpty()) {
            emptyState()
            return
        }
        filtersRow(all)
        heroSection(all)
        recentSection(all)
        storySection(all)
        weekSection(all)
    }

    private fun header() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val kid = Profile.kids(this).firstOrNull()?.name
        val avatarName = kid ?: Profile.familyName(this).ifEmpty { Profile.homeTitle(this).split(" ").last() }
        row.addView(mv.avatar(avatarName, 48).apply {
            setOnClickListener { startActivity(Intent(this@HomeActivity, FamilyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) }
        })
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(mv.dp(12), 0, mv.dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titles.addView(TextView(this).apply {
            text = Profile.homeTitle(this@HomeActivity)
            gravity = Gravity.CENTER
            textSize = 22f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@HomeActivity, R.color.ink))
            if (Profile.familyName(this@HomeActivity).isEmpty() && Profile.parentName(this@HomeActivity).isEmpty()) {
                setOnClickListener { startActivity(Intent(this@HomeActivity, ProfileActivity::class.java)) }
            }
        })
        titles.addView(TextView(this).apply {
            text = "הזיכרונות שלנו, תמיד איתנו"
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@HomeActivity, R.color.ink_soft))
        })
        row.addView(titles)
        row.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(ContextCompat.getColor(this@HomeActivity, R.color.ink))
            contentDescription = "חיפוש"
            val p = mv.dp(10)
            setPadding(p, p, p, p)
            setBackgroundResource(android.R.drawable.list_selector_background)
            layoutParams = LinearLayout.LayoutParams(mv.dp(44), mv.dp(44))
            setOnClickListener { startActivity(Intent(this@HomeActivity, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) }
        })
        content.addView(row)
    }

    private fun emptyState() {
        val card = ui.card(top = 28)
        card.setPadding(mv.dp(24), mv.dp(32), mv.dp(24), mv.dp(28))
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.addView(TextView(this).apply {
            text = "❤️"
            textSize = 44f
            gravity = Gravity.CENTER
        })
        card.addView(ui.text("עדיין אין לנו זיכרונות", 22f, bold = true, top = 8).apply { gravity = Gravity.CENTER })
        card.addView(ui.text("ברגע שיקרה משהו מיוחד, נתחיל לבנות את הסיפור המשפחתי שלכם.", 16f, R.color.ink_soft, top = 8).apply { gravity = Gravity.CENTER })
        card.addView(ui.button("הפעל את Moments", primary = true, top = 22) { openCapture() })
        card.addView(ui.hint("הטלפון על החזה, ו-Moments שומר לבד כל צחוק, חיוך או \"אבא תראה\".", top = 12).apply { gravity = Gravity.CENTER })
        if (Profile.isEmpty(this)) {
            card.addView(ui.action("בינתיים, ספרו לנו מי במשפחה ›") { startActivity(Intent(this, ProfileActivity::class.java)) }.apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = mv.dp(8)
                    gravity = Gravity.CENTER_HORIZONTAL
                }
            })
        }
        content.addView(card)
        mv.reveal(card)
    }

    // ---------- on this day ----------

    /** "היום לפני שנה" when there is one; until there's enough history, the closest meaningful fallback. */
    private fun pickHero(all: List<Memory>): Pair<String, Memory>? {
        val now = Calendar.getInstance()
        fun cal(t: Long) = Calendar.getInstance().apply { timeInMillis = t }
        val sameDay = all.filter {
            val c = cal(it.time)
            c.get(Calendar.MONTH) == now.get(Calendar.MONTH) && c.get(Calendar.DAY_OF_MONTH) == now.get(Calendar.DAY_OF_MONTH) &&
                c.get(Calendar.YEAR) < now.get(Calendar.YEAR)
        }
        ReelMaker.best(sameDay).firstOrNull()?.let { m ->
            val years = now.get(Calendar.YEAR) - cal(m.time).get(Calendar.YEAR)
            return (if (years == 1) "❤️ היום לפני שנה" else "❤️ היום לפני $years שנים") to m
        }
        val monthAgo = all.filter {
            val c = cal(it.time)
            c.get(Calendar.DAY_OF_MONTH) == now.get(Calendar.DAY_OF_MONTH) && !DateUtils.isToday(it.time) &&
                System.currentTimeMillis() - it.time in 25 * DateUtils.DAY_IN_MILLIS..35 * DateUtils.DAY_IN_MILLIS
        }
        ReelMaker.best(monthAgo).firstOrNull()?.let { return "❤️ היום לפני חודש" to it }
        val loved = all.filter { (it.favorite || it.milestone.isNotEmpty() || it.chosen) && System.currentTimeMillis() - it.time > 2 * DateUtils.DAY_IN_MILLIS }
        if (loved.isNotEmpty()) return "❤️ רגע שאהבתם" to loved[now.get(Calendar.DAY_OF_YEAR) % loved.size]
        return all.firstOrNull()?.let { "❤️ הרגע האחרון שלנו" to it }
    }

    private fun heroSection(all: List<Memory>) {
        val (label, m) = pickHero(all) ?: return
        val v = mv.hero(label, m) { open(m) }
        content.addView(v)
        mv.reveal(v)
    }

    // ---------- today's story ----------

    private fun storySection(all: List<Memory>) {
        val today = all.filter { DateUtils.isToday(it.time) }
        if (today.isEmpty()) return
        val story = MemoryStore.story(this, today.first().dayKey)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_accent_bg)
            setPadding(mv.dp(18), mv.dp(16), mv.dp(18), mv.dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = mv.dp(16) }
        }
        card.addView(TextView(this).apply {
            text = "✨ היום אצלנו · ${today.size} רגעים"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFB9B2FF.toInt())
        })
        val body = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.SERIF
            setLineSpacing(mv.dp(4).toFloat(), 1f)
            setTextColor(0xFFEEECFF.toInt())
            setPadding(0, mv.dp(6), 0, 0)
        }
        when {
            story.isNotEmpty() -> body.text = story
            !ClaudeClient.hasKey(this) -> body.text = "כדי שנכתוב לכם את סיפור היום, חברו את ה-AI בפרופיל."
            today.size < 2 -> body.text = "נשמר רגע אחד היום. מעוד רגע, נכתוב כאן את הסיפור של היום."
            else -> {
                body.text = "רגע, אנחנו כותבים את הסיפור של היום... ✨"
                mv.pulse(body)
            }
        }
        card.addView(body)
        card.addView(TextView(this).apply {
            text = "▶ צפו בסיפור של היום"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, mv.dp(12), 0, 0)
        })
        card.setOnClickListener { StoryActivity.day(this, today.first().dayKey) }
        content.addView(card)
    }

    // ---------- our week ----------

    private fun weekSection(all: List<Memory>) {
        val week = ReelMaker.weekMoments(this)
        if (week.isEmpty()) return
        content.addView(mv.sectionTitle("השבוע שלנו", icon = R.drawable.ic_sparkle))
        content.addView(ui.hint(if (week.size == 1) "רגע אחד השבוע" else "${week.size} רגעים השבוע", top = 2))
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in ReelMaker.best(week).take(8)) strip.addView(mv.mini(m) { open(m) })
        content.addView(ui.scrollRow(strip, top = 12))

        // The story (with music) is the main way to relive the week; the video file is for sharing.
        content.addView(ui.button("▶ צפו בסיפור של השבוע", primary = true, top = 14) { StoryActivity.week(this) })
        val last = ReelMaker.lastReel(this)
        if (last != null) {
            content.addView(ui.action("🎬 הסרטון ששמרתם מהשבוע ›") { playUri(last.first) })
        }
        val btn: MaterialButton = ui.button(
            if (last != null) "🎬 שמור סרטון חדש מהשבוע (לשיתוף)" else "🎬 שמור כסרטון (לשיתוף)",
            top = 6,
        ) { makeReel(week) }
        if (week.size < 2) {
            btn.isEnabled = false
            btn.text = "🎬 סרטון השבוע יחכה כאן מ-2 רגעים"
        }
        if (makingReel) {
            btn.isEnabled = false
            btn.text = "רגע, אנחנו מחברים את הרגעים לסרטון..."
        }
        content.addView(btn)
    }

    private fun makeReel(week: List<Memory>) {
        if (makingReel) return
        makingReel = true
        render()
        worker.execute {
            val result = try {
                Result.success(ReelMaker.make(applicationContext, week))
            } catch (e: Throwable) {
                Result.failure(e)
            }
            runOnUiThread {
                makingReel = false
                if (isFinishing) return@runOnUiThread
                render()
                result.onSuccess { r ->
                    Toast.makeText(this, "הסרטון של השבוע מוכן: ${r.count} רגעים ❤️", Toast.LENGTH_SHORT).show()
                    playUri(r.uri)
                }.onFailure { e ->
                    Toast.makeText(this, e.message ?: "לא הצלחתי ליצור את הסרטון", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun playUri(uri: String) {
        try {
            val u = if (uri.startsWith("content://")) Uri.parse(uri) else Uri.parse("file://$uri")
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, "הסרטון נשמר בגלריה, בתיקייה Movies/Moments", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- filters + latest ----------

    private fun filterOptions(all: List<Memory>): List<String> {
        val people = all.flatMap { Fmt.names(it) }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(4).map { it.key }
        val opts = mutableListOf("הכל")
        opts.addAll(people)
        if (all.any { it.category == "משפחה" || Fmt.names(it).size >= 2 }) opts.add("👨‍👩‍👦 משפחה")
        if (all.any { it.place.isNotEmpty() }) opts.add("📍 מקומות")
        if (all.any { it.favorite }) opts.add("⭐ מועדפים")
        if (all.any { it.category == "צחוק" }) opts.add("😂 צחוקים")
        if (all.any { it.milestone.isNotEmpty() }) opts.add("★ אבני דרך")
        return opts
    }

    private fun applyFilter(all: List<Memory>, f: String): List<Memory> = when (f) {
        "הכל" -> all
        "👨‍👩‍👦 משפחה" -> all.filter { it.category == "משפחה" || Fmt.names(it).size >= 2 }
        "📍 מקומות" -> all.filter { it.place.isNotEmpty() }
        "⭐ מועדפים" -> all.filter { it.favorite }
        "😂 צחוקים" -> all.filter { it.category == "צחוק" }
        "★ אבני דרך" -> all.filter { it.milestone.isNotEmpty() }
        else -> all.filter { Fmt.names(it).contains(f) }
    }

    private var showCount = 8
    private var allCache: List<Memory> = emptyList()

    private fun filtersRow(all: List<Memory>) {
        val opts = filterOptions(all)
        if (filter !in opts) filter = "הכל"
        if (opts.size > 1) {
            content.addView(ui.chips(opts, opts.indexOf(filter), top = 16) { i ->
                filter = opts[i]
                showCount = 8
                fillRecent(allCache, animate = true)
            })
        }
    }

    private fun recentSection(all: List<Memory>) {
        allCache = all
        content.addView(mv.sectionTitle("הזיכרונות האחרונים", top = 26, icon = R.drawable.ic_clock))
        recentBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(recentBox)
        fillRecent(all, animate = false)
    }

    private fun fillRecent(all: List<Memory>, animate: Boolean) {
        val box = recentBox ?: return
        box.removeAllViews()
        val filtered = applyFilter(all, filter)
        val list = filtered.take(showCount)
        if (list.isEmpty()) box.addView(ui.hint("עוד אין כאן רגעים.", top = 14))
        val grid = mv.grid(list.map { m -> mv.gridCard(m) { open(m) } })
        box.addView(grid)
        if (animate) mv.reveal(grid)
        if (filtered.size > showCount) {
            box.addView(ui.action("עוד זיכרונות ↓") {
                showCount += 8
                fillRecent(allCache, animate = false)
            }.apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = mv.dp(22).toFloat(); setColor(0xFFFFFFFF.toInt()); setStroke(mv.dp(1), 0xFFE4E0D8.toInt())
                }
                setPadding(mv.dp(20), mv.dp(10), mv.dp(20), mv.dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = mv.dp(18)
                    gravity = Gravity.CENTER_HORIZONTAL
                }
            })
        }
    }
}
