package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.util.concurrent.Executors

/** Premium: a moment as a Pixar-style animated film. */
@OptIn(markerClass = [UnstableApi::class])
class CartoonFilmActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA = "moment"
        private const val MUSIC_KEY = "cartoon_music"
        private const val CONSENT = "cartoon_consent"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, CartoonFilmActivity::class.java).putExtra(EXTRA, id))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private lateinit var memory: Memory
    private var mood: Music.Mood? = Music.Mood.WARM
    private var handle: CartoonFilm.Handle? = null
    private var statusView: TextView? = null
    private var progress: ProgressBar? = null
    private var result: File? = null
    private var building = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("סרט פיקסאר", "Pixar-style film")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        memory = MemoryStore.get(this, intent.getStringExtra(EXTRA) ?: "") ?: run { finish(); return }
        if (Settings.prefs(this).contains(MUSIC_KEY)) mood = Music.choice(this, MUSIC_KEY)
        render()
    }

    override fun onDestroy() {
        if (building) handle?.cancel?.invoke()
        Music.stop()
        super.onDestroy()
    }

    private fun render() {
        content.removeAllViews()
        statusView = null; progress = null
        content.addView(ui.text(L.t("הרגע הזה, כסרט אנימציה", "This moment, as an animated film"), 19f, bold = true, top = 14))
        content.addView(ui.hint(L.t("בוחרים רגע ואנחנו מציירים אותו סצנה אחרי סצנה בסגנון סרטי פיקסאר, ומחברים לסרט קצר עם מוזיקה. כ-${CartoonFilm.seconds(memory)} שניות.", "We redraw the moment scene by scene in the style of Pixar movies and cut it into a short film with music. About ${CartoonFilm.seconds(memory)} seconds."), top = 6))

        if (!Premium.isPremium(this)) {
            content.addView(ui.text(L.t("✨ זה פיצ'ר פרימיום", "✨ This is a premium feature"), 17f, bold = true, top = 20))
            content.addView(ui.hint(L.t("סרטי אנימציה מהרגעים שלכם יהיו זמינים במנוי הפרימיום. התשלום עדיין לא מחובר.", "Animated films from your moments will be part of the premium plan. Payments aren't connected yet."), top = 4))
            content.addView(ui.button(L.t("הפעלה לבדיקה (מצב מפתח)", "Turn on for testing (developer mode)"), primary = true, top = 16) { Premium.set(this, true); render() })
            return
        }
        if (!GeminiClient.hasKey(this)) {
            content.addView(ui.text(L.t("חסר מפתח Gemini", "A Gemini key is needed"), 17f, bold = true, top = 20))
            content.addView(ui.hint(L.t("הציור נעשה במודל התמונות של Google. הוסיפו מפתח בהגדרות ← מפתח Gemini. (בהמשך זה יעבור לשרת שלנו.)", "Drawing uses Google's image model. Add a key in Settings → Gemini key. (Later this will move to our server.)"), top = 4))
            content.addView(ui.button(L.t("פתחו הגדרות", "Open Settings"), primary = true, top = 14) { startActivity(Intent(this, SettingsActivity::class.java)) })
            return
        }
        val musicRow = ui.action("") { }
        musicRow.text = L.t("🎵 מוזיקה: ${mood?.title ?: "ללא"} ›", "🎵 Music: ${mood?.title ?: "none"} ›")
        musicRow.setOnClickListener {
            if (building) return@setOnClickListener
            Music.chooser(this, mood) { m -> mood = m; Music.setChoice(this, m, MUSIC_KEY); render() }
        }
        content.addView(musicRow.apply { setPadding(0, ui.dp(16), 0, ui.dp(4)) })

        val done = result
        if (done != null && done.exists()) { showResult(done); return }
        if (building) {
            statusView = ui.text(L.t("מציירים... זה לוקח כמה דקות, כדאי להישאר כאן.", "Drawing… this takes a few minutes. Stay on this screen."), 15f, top = 14)
            content.addView(statusView)
            progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; isIndeterminate = true
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(10) }
            }
            content.addView(progress)
            return
        }
        content.addView(ui.button(L.t("🎬 צרו את הסרט", "🎬 Create the film"), primary = true, top = 18) { confirmStart() })
        content.addView(ui.hint(L.t("תמונות מהרגע נשלחות ל-Google לצורך הציור. הן לא נשמרות אצלנו.", "Frames from the moment are sent to Google to be drawn. We don't keep them."), top = 6))
    }

    private fun confirmStart() {
        val prefs = Settings.prefs(this)
        if (prefs.getBoolean(CONSENT, false)) { start(); return }
        AlertDialog.Builder(this)
            .setTitle(L.t("לשלוח תמונות ל-AI?", "Send frames to AI?"))
            .setMessage(L.t("כדי לצייר את הסרט נשלח כמה תמונות מהרגע (שעלולות לכלול פנים, גם של ילדים) למודל התמונות של Google. נשלח רק מה שנדרש לסרט הזה. להמשיך?", "To draw the film we send a few frames from the moment (which may include faces, including children's) to Google's image model. Only what this film needs is sent. Continue?"))
            .setPositiveButton(L.t("המשך", "Continue")) { _, _ -> prefs.edit().putBoolean(CONSENT, true).apply(); start() }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .show()
    }

    private fun start() {
        building = true
        render()
        handle = CartoonFilm.make(applicationContext, memory, mood,
            onStatus = { d, t -> statusView?.text = if (d >= t) L.t("מרכיבים את הסרט...", "Putting the film together...") else L.t("מציירים סצנה ${d + 1} מתוך $t...", "Drawing scene ${d + 1} of $t...") },
            onProgress = { p -> progress?.let { it.isIndeterminate = false; it.progress = p } },
            onDone = { file, err ->
                building = false
                if (isFinishing || isDestroyed) return@make
                if (file == null) Toast.makeText(this, err ?: L.t("משהו השתבש", "Something went wrong"), Toast.LENGTH_LONG).show()
                result = file
                render()
            })
    }

    private fun showResult(file: File) {
        content.addView(ui.text(L.t("הסרט מוכן ✨", "Your film is ready ✨"), 18f, bold = true, top = 16))
        val box = FrameLayout(this).apply {
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5f).toInt()).apply { topMargin = ui.dp(10) }
        }
        box.addView(VideoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setVideoPath(file.absolutePath)
            setOnPreparedListener { it.isLooping = true; start() }
        })
        content.addView(box)
        content.addView(ui.button(L.t("שתף", "Share"), primary = true, top = 14) { share(file) })
        content.addView(ui.button(L.t("שמור בגלריה", "Save to gallery"), top = 6) { save(file) })
        content.addView(ui.action(L.t("ציור מחדש", "Draw again")) { result = null; render() }.apply { setPadding(0, ui.dp(14), 0, 0) })
    }

    private fun share(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val send = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, L.t("נעשה עם Moments 💜", "Made with Moments 💜"))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, L.t("לשתף עם...", "Share with...")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, L.t("לא הצלחנו לפתוח את השיתוף", "Couldn't open sharing"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun save(file: File) {
        Executors.newSingleThreadExecutor().execute {
            val ok = try { ReelMaker.publish(applicationContext, file); true } catch (_: Exception) { false }
            runOnUiThread {
                Toast.makeText(this, if (ok) L.t("נשמר בגלריה, בתיקייה Movies/Moments", "Saved to your gallery, in Movies/Moments") else L.t("לא הצלחנו לשמור", "Couldn't save"), Toast.LENGTH_LONG).show()
            }
        }
    }
}
