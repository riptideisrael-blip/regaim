package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.util.concurrent.Executors

/**
 * Premium: a moment as a 3D animated film, in three clear steps:
 * choose the sound → approve how the characters look → the film is made (you can leave; it's saved to the archive).
 */
@OptIn(markerClass = [UnstableApi::class])
class CartoonFilmActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA = "moment"
        private const val MUSIC_KEY = "cartoon_music"
        private const val VOICES_KEY = "cartoon_voices"
        private const val CONSENT = "cartoon_consent"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, CartoonFilmActivity::class.java).putExtra(EXTRA, id))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private lateinit var memory: Memory
    private var mood: Music.Mood? = Music.Mood.WARM
    private var voices = true
    private var session: CartoonFilm.Session? = null
    private var progressBar: ProgressBar? = null
    private var statusText: TextView? = null
    private var shownState: CartoonFilm.Session.State? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("סרט מצויר בתלת-ממד", "3D animated film")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        memory = MemoryStore.get(this, intent.getStringExtra(EXTRA) ?: "") ?: run { finish(); return }
        val prefs = Settings.prefs(this)
        if (prefs.contains(MUSIC_KEY)) mood = Music.choice(this, MUSIC_KEY)
        voices = prefs.getBoolean(VOICES_KEY, true)
        // Coming back to a film that's still being made for this moment.
        session = CartoonFilm.current?.takeIf { it.memory.id == memory.id }
        render()
    }

    override fun onResume() {
        super.onResume()
        session?.listener = { onSessionChanged() }
        if (::content.isInitialized) render()
    }

    override fun onPause() {
        super.onPause()
        session?.listener = null
    }

    override fun onDestroy() {
        // Leaving does NOT stop the film: it keeps going and is saved to the archive when ready.
        Music.stop()
        super.onDestroy()
    }

    /** Small changes (status text, progress) update in place; a new state redraws the screen. */
    private fun onSessionChanged() {
        val s = session ?: return
        if (isFinishing || isDestroyed) return
        if (s.state != shownState) { render(); return }
        statusText?.text = s.status
        progressBar?.let { if (s.progress in 0..100) { it.isIndeterminate = false; it.progress = s.progress } }
    }

    private fun render() {
        content.removeAllViews()
        progressBar = null; statusText = null
        val s = session
        shownState = s?.state
        content.addView(ui.text(L.t("הרגע הזה, כסרט אנימציה", "This moment, as an animated film"), 19f, bold = true, top = 14))

        if (!Premium.isPremium(this)) {
            content.addView(ui.hint(intro(), top = 6))
            content.addView(ui.text(L.t("✨ זה פיצ'ר פרימיום", "✨ This is a premium feature"), 17f, bold = true, top = 20))
            content.addView(ui.hint(L.t("סרטי אנימציה מהרגעים שלכם יהיו זמינים במנוי הפרימיום. התשלום עדיין לא מחובר.", "Animated films from your moments will be part of the premium plan. Payments aren't connected yet."), top = 4))
            content.addView(ui.button(L.t("הפעלה לבדיקה (מצב מפתח)", "Turn on for testing (developer mode)"), primary = true, top = 16) { Premium.set(this, true); render() })
            return
        }
        when (s?.state) {
            null, CartoonFilm.Session.State.CANCELLED -> renderStart()
            CartoonFilm.Session.State.PREPARING -> renderWorking(s, L.t("שלב 1 מתוך 2: איך הדמויות ייראו", "Step 1 of 2: how the characters look"), cancellable = true)
            CartoonFilm.Session.State.LOOK -> renderLook(s)
            CartoonFilm.Session.State.FILMING -> renderWorking(s, L.t("שלב 2 מתוך 2: הסרט בהכנה", "Step 2 of 2: making the film"), cancellable = true)
            CartoonFilm.Session.State.DONE -> renderResult(s)
            CartoonFilm.Session.State.FAILED -> renderFailed(s)
        }
    }

    private fun intro() = L.t(
        "אנחנו מציירים את הרגע מחדש כדמויות אנימציה בתלת-ממד, בסגנון סרטי פיקסאר: 3 סצנות, כ-${CartoonFilm.seconds(memory)} שניות, עם הקולות מהרגע עצמו. קודם תאשרו איך הדמויות נראות, ורק אז נכין את הסרט.",
        "We redraw the moment as 3D animated characters, Pixar-movie style: 3 scenes, about ${CartoonFilm.seconds(memory)} seconds, with the moment's own sound. First you approve how the characters look, then we make the film.")

    private fun renderStart() {
        content.addView(ui.hint(intro(), top = 6))
        val musicRow = ui.action("") { }
        musicRow.text = L.t("🎵 מוזיקה ברקע: ${mood?.title ?: "ללא"} ›", "🎵 Background music: ${mood?.title ?: "none"} ›")
        musicRow.setOnClickListener {
            Music.chooser(this, mood) { m -> mood = m; Music.setChoice(this, m, MUSIC_KEY); render() }
        }
        content.addView(musicRow.apply { setPadding(0, ui.dp(16), 0, ui.dp(4)) })
        if (memory.isVideo) content.addView(ui.switch(L.t("🗣 הקולות מהרגע (צחוקים, דיבור)", "🗣 The moment's own sound (laughs, voices)"), voices, top = 6) { on ->
            voices = on; Settings.prefs(this).edit().putBoolean(VOICES_KEY, on).apply()
        })
        content.addView(ui.button(L.t("🎨 ציירו את הדמויות לאישור", "🎨 Draw the characters for approval"), primary = true, top = 18) { confirmStart() })
        content.addView(ui.hint(L.t("ציור הדמויות לוקח כחצי דקה. תמונות מהרגע נשלחות לשירות ציור AI דרך השרת שלנו, רק לצורך הסרט הזה.", "Drawing the characters takes about 30 seconds. Frames from the moment are sent to an AI drawing service through our server, only for this film."), top = 6))
    }

    private fun renderWorking(s: CartoonFilm.Session, step: String, cancellable: Boolean) {
        content.addView(ui.text(step, 16f, R.color.accent_dark, bold = true, top = 18))
        statusText = ui.text(s.status, 15f, top = 8)
        content.addView(statusText)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = s.progress !in 0..100
            if (s.progress in 0..100) progress = s.progress
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(10) }
        }
        content.addView(progressBar)
        if (s.state == CartoonFilm.Session.State.FILMING)
            content.addView(ui.hint(L.t("זה לוקח כמה דקות. אפשר לצאת מהמסך: הסרט ימשיך להיווצר ויישמר בארכיון, ליד הרגע המקורי.", "This takes a few minutes. You can leave: the film keeps going and is saved to your archive, next to the original moment."), top = 10))
        if (cancellable) content.addView(ui.action(L.t("ביטול", "Cancel"), R.color.danger) {
            AlertDialog.Builder(this).setTitle(L.t("לבטל את הסרט?", "Cancel the film?"))
                .setMessage(L.t("הקרדיט יחזור אליכם.", "Your credit will be returned."))
                .setPositiveButton(L.t("ביטול הסרט", "Cancel film")) { _, _ -> s.cancel(); session = null; render() }
                .setNegativeButton(L.t("המשך", "Keep going"), null).show()
        }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun renderLook(s: CartoonFilm.Session) {
        content.addView(ui.text(L.t("שלב 1 מתוך 2: ככה הדמויות ייראו בסרט", "Step 1 of 2: this is how the characters will look"), 16f, R.color.accent_dark, bold = true, top = 18))
        val bmp = s.look
        if (bmp != null) {
            val box = FrameLayout(this).apply {
                setBackgroundResource(R.drawable.rounded_media)
                clipToOutline = true
                val h = (resources.displayMetrics.heightPixels * 0.5f).toInt()
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = ui.dp(10) }
            }
            box.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(bmp)
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            })
            content.addView(box)
        }
        content.addView(ui.hint(L.t("כל הסצנות בסרט יצוירו לפי הדמויות האלה: אותן פנים, גיל, שיער ובגדים.", "Every scene will be drawn like these characters: same faces, age, hair and clothes."), top = 8))
        val who = s.refNames
        content.addView(ui.hint(
            if (who.isNotEmpty()) L.t("✓ השתמשנו בתמונת הפרופיל של ${who.joinToString(" ו")} כדי שהדמות תהיה דומה.", "✓ We used ${who.joinToString(" and ")}'s profile photo so the character looks like them.")
            else L.t("טיפ: כדי שהדמות תהיה דומה יותר, הוסיפו תמונת פנים ברורה לילד בפרופיל (פרופיל ← המשפחה) ותייגו אותו ברגע.", "Tip: for a closer likeness, add a clear face photo of your child in the profile (Profile → Family) and tag them in the moment."),
            top = 6))
        content.addView(ui.button(L.t("✓ נראה מעולה, צרו את הסרט", "✓ Looks great, make the film"), primary = true, top = 14) {
            s.makeFilm(mood, voices && memory.isVideo)
        })
        if (s.redrawsLeft > 0) content.addView(ui.button(L.t("↻ ציירו שוב (עוד ${s.redrawsLeft})", "↻ Draw again (${s.redrawsLeft} left)"), top = 6) { s.redraw() })
        content.addView(ui.action(L.t("ביטול (הקרדיט יחזור)", "Cancel (credit returned)"), R.color.danger) { s.cancel(); session = null; render() }
            .apply { setPadding(0, ui.dp(14), 0, 0) })
    }

    private fun renderResult(s: CartoonFilm.Session) {
        val file = s.result
        content.addView(ui.text(L.t("הסרט מוכן ✨", "Your film is ready ✨"), 18f, bold = true, top = 16))
        if (s.note.isNotEmpty()) content.addView(ui.hint(s.note, top = 4))
        if (file != null && file.exists()) {
            val box = FrameLayout(this).apply {
                setBackgroundResource(R.drawable.rounded_media)
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5f).toInt()).apply { topMargin = ui.dp(10) }
            }
            box.addView(VideoView(this).apply {
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setVideoPath(file.absolutePath)
                setOnPreparedListener { it.isLooping = true; start() }
            })
            content.addView(box)
        }
        val savedId = s.savedId
        content.addView(ui.hint(
            if (savedId != null) L.t("✓ הסרט נשמר בגלריה (Movies/Moments) ובארכיון, ליד הרגע המקורי.", "✓ Saved to your gallery (Movies/Moments) and to your archive, next to the original moment.")
            else L.t("לא הצלחנו לשמור את הסרט אוטומטית. אפשר לשמור בכפתור למטה.", "We couldn't save the film automatically. Use the button below."), top = 10))
        if (file != null && file.exists()) content.addView(ui.button(L.t("שתף", "Share"), primary = true, top = 14) { share(file) })
        if (savedId != null) content.addView(ui.button(L.t("פתח את הסרט ברגעים", "Open the film in Moments"), top = 6) { MomentActivity.open(this, savedId) })
        else if (file != null && file.exists()) content.addView(ui.button(L.t("שמור בגלריה", "Save to gallery"), top = 6) { save(file) })
        content.addView(ui.action(L.t("סרט חדש מהרגע הזה", "A new film from this moment")) { session = null; render() }.apply { setPadding(0, ui.dp(14), 0, 0) })
    }

    private fun renderFailed(s: CartoonFilm.Session) {
        content.addView(ui.text(L.t("הסרט לא הצליח הפעם", "The film didn't work this time"), 17f, bold = true, top = 18))
        content.addView(ui.hint(s.error ?: L.t("משהו השתבש", "Something went wrong"), top = 6))
        content.addView(ui.hint(L.t("אם הקרדיט נלקח, הוא הוחזר.", "If a credit was used, it was returned."), top = 4))
        content.addView(ui.button(L.t("נסו שוב", "Try again"), primary = true, top = 16) { session = null; render() })
    }

    private fun confirmStart() {
        val prefs = Settings.prefs(this)
        if (prefs.getBoolean(CONSENT, false)) { start(); return }
        AlertDialog.Builder(this)
            .setTitle(L.t("לשלוח תמונות ל-AI?", "Send frames to AI?"))
            .setMessage(L.t("כדי לצייר את הסרט נשלח כמה תמונות מהרגע (שעלולות לכלול פנים, גם של ילדים) לשירות ציור והנפשה מבוסס AI, דרך השרת שלנו. נשלח רק מה שנדרש לסרט הזה. להמשיך?", "To draw the film we send a few frames from the moment (which may include faces, including children's) to an AI drawing and animation service, through our server. Only what this film needs is sent. Continue?"))
            .setPositiveButton(L.t("המשך", "Continue")) { _, _ -> prefs.edit().putBoolean(CONSENT, true).apply(); start() }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .show()
    }

    private fun start() {
        val running = CartoonFilm.current
        if (running != null && running.isActive && running.memory.id != memory.id) {
            Toast.makeText(this, L.t("כבר נוצר סרט מרגע אחר. אפשר להתחיל סרט חדש כשהוא יסתיים.", "Another film is already being made. Start a new one when it's done."), Toast.LENGTH_LONG).show()
            return
        }
        val s = CartoonFilm.start(this, memory)
        session = s
        s.listener = { onSessionChanged() }
        render()
    }

    private fun share(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val send = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, L.t("נעשה עם Moments 💜", "Made with Moments 💜"))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, L.t("לשתף עם...", "Share with...")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, L.t("לא הצלחנו לפתוח את השיתוף", "Couldn't open sharing"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun save(file: File) {
        Executors.newSingleThreadExecutor().execute {
            val ok = try { CartoonFilm.keep(applicationContext, memory, file); true } catch (_: Exception) { false }
            runOnUiThread {
                Toast.makeText(this, if (ok) L.t("נשמר בגלריה ובארכיון", "Saved to your gallery and archive") else L.t("לא הצלחנו לשמור", "Couldn't save"), Toast.LENGTH_LONG).show()
            }
        }
    }
}
