package com.regaim.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The detection lab: a test set of real family videos, each labelled with the truth, run through the same
 * moment finder (nothing is saved to memories). Shows recall, precision and false-alarm rates instead of a feeling.
 */
class DetectionLabActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, DetectionLabActivity::class.java))

        /** The 14 situations worth covering; the last one is the "nothing special" control. */
        val CASES = listOf(
            "ילד צוחק בלי דיבור" to "Child laughing, no talking",
            "ילד צוחק בזמן משחק" to "Child laughing while playing",
            "אמא מדגדגת ילד" to "Mom tickling a child",
            "אבא משחק עם ילד" to "Dad playing with a child",
            "חיבוק" to "Hug",
            "חיוך בלבד" to "Smile only",
            "צחוק שנשמע אבל קשה לראות" to "Laugh heard but hard to see",
            "חיוך שרואים אבל כמעט לא שומעים" to "Smile seen but barely heard",
            "מוזיקה ברקע" to "Music in the background",
            "רעש רקע" to "Background noise",
            "סרטון ללא קול" to "Video with no sound",
            "כמה אנשים בפריים" to "Several people in frame",
            "ילד שרץ וצוחק" to "Child running and laughing",
            "סרטון בלי רגע מיוחד" to "Video with no real moment",
        )
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val cancelled = AtomicBoolean(false)
    private var running: String? = null
    private var bar: ProgressBar? = null
    private var pendingCase = 0
    private var pendingHas = true
    private var pendingAt = -1L

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) run(uri)
    }

    private fun file() = File(filesDir, "detection_lab.json")
    private fun load(): JSONArray = try { JSONArray(file().readText()) } catch (_: Exception) { JSONArray() }
    private fun store(a: JSONArray) = try { file().writeText(a.toString()) } catch (_: Exception) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("מעבדת זיהוי", "Detection lab")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        render()
    }

    override fun onDestroy() {
        cancelled.set(true)
        worker.shutdown()
        super.onDestroy()
    }

    private fun cases(): List<Pair<JSONObject, LabScore.Case>> {
        val a = load()
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val found = o.optJSONArray("found") ?: JSONArray()
            val list = (0 until found.length()).mapNotNull { j ->
                val f = found.optJSONObject(j) ?: return@mapNotNull null
                Candidate(
                    f.optLong("start"), f.optLong("end"), f.optLong("peak"), 0, 0, f.optDouble("confidence").toFloat(), f.optDouble("rank").toFloat(),
                    Tier.valueOf(f.optString("tier", "maybe").uppercase()), null, null, 0f, 0f,
                    listOf((MomentType.values().firstOrNull { it.key == f.optString("type") } ?: MomentType.JOY) to 1f), emptyList(),
                )
            }
            o to LabScore.Case(o.optBoolean("has"), o.optLong("at", -1L), list)
        }
    }

    private fun render() {
        content.removeAllViews()
        bar = null
        content.addView(ui.text(L.t(
            "כאן בודקים את הזיהוי על סרטונים אמיתיים שלכם. לכל סרטון מסמנים מה באמת יש בו, ו-Moments מודד כמה הוא מצא וכמה פספס. שום דבר לא נשמר בזיכרונות.",
            "Test detection on your own real videos. For each one you mark what's really in it, and Moments measures what it found and what it missed. Nothing is saved to your memories.",
        ), 15f, top = 14))

        val all = cases()
        if (all.isNotEmpty()) {
            val card = ui.card(top = 14)
            card.addView(ui.text(L.t("תוצאות (${all.size} סרטונים)", "Results (${all.size} videos)"), 16f, bold = true))
            fun line(title: String, m: LabScore.Metrics) {
                card.addView(ui.text(title, 14f, bold = true, top = 10))
                card.addView(ui.hint(L.t(
                    "Recall ${pct(m.recall)} · Precision ${pct(m.precision)} · False positives ${pct(m.falsePositiveRate)} · False negatives ${pct(m.falseNegativeRate)}",
                    "Recall ${pct(m.recall)} · Precision ${pct(m.precision)} · False positive rate ${pct(m.falsePositiveRate)} · False negative rate ${pct(m.falseNegativeRate)}",
                ), top = 2))
                card.addView(ui.hint(L.t("נמצאו ${m.tp} · פוספסו ${m.fn} · התראות שווא ${m.fp} · נכון שאין ${m.tn}", "Found ${m.tp} · missed ${m.fn} · false alarms ${m.fp} · correctly empty ${m.tn}"), top = 2))
            }
            line(L.t("רק \"חזק\" ו\"טוב\"", "\"Strong\" and \"good\" only"), LabScore.metrics(all.map { it.second }, Tier.GOOD))
            line(L.t("כולל \"אולי\"", "Including \"maybe\""), LabScore.metrics(all.map { it.second }, Tier.MAYBE))
            val covered = all.map { it.first.optInt("case") }.toSet()
            val missing = CASES.indices.filter { it !in covered }
            if (missing.isNotEmpty()) card.addView(ui.hint(L.t("עוד חסרים: ", "Still missing: ") + missing.joinToString(", ") { L.t(CASES[it].first, CASES[it].second) }, top = 10))
            content.addView(card)
        }

        val busy = running
        if (busy != null) {
            content.addView(ui.text(busy, 15f, bold = true, top = 18))
            bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(10) }
            }
            content.addView(bar)
        } else {
            content.addView(ui.button(L.t("הוסיפו סרטון לבדיקה", "Add a test video"), primary = true, top = 16) { askCase() })
        }

        for ((o, c) in all.reversed()) {
            val card = ui.card(top = 10)
            val i = o.optInt("case")
            val title = CASES.getOrNull(i)?.let { L.t(it.first, it.second) } ?: ""
            val ok = if (c.hasMoment) LabScore.hit(c, Tier.GOOD) else !LabScore.alarm(c, Tier.GOOD)
            val okMaybe = if (c.hasMoment) LabScore.hit(c, Tier.MAYBE) else !LabScore.alarm(c, Tier.MAYBE)
            card.addView(ui.text((if (ok) "✓ " else if (okMaybe) "~ " else "✗ ") + title, 15f, bold = true))
            card.addView(ui.hint(o.optString("name") + (if (c.atMs >= 0) L.t(" · הרגע בשנייה ${c.atMs / 1000}", " · moment at ${c.atMs / 1000}s") else "") + " · ${o.optLong("took") / 1000}s", top = 2))
            val found = o.optJSONArray("found") ?: JSONArray()
            if (found.length() == 0) card.addView(ui.hint(L.t("לא נמצא כלום", "Nothing found"), top = 4))
            for (j in 0 until found.length()) {
                val f = found.getJSONObject(j)
                card.addView(ui.hint(
                    "${f.optString("tier")} · ${f.optString("type")} · ${f.optLong("start") / 1000}–${f.optLong("end") / 1000}s · " +
                        "conf ${f.opt("confidence")} · A ${f.opt("audio")} · V ${f.opt("visual")} · I ${f.opt("interaction")} · T ${f.opt("temporal")}\n" +
                        (f.optJSONArray("evidence")?.let { e -> (0 until e.length()).joinToString(", ") { e.optString(it) } } ?: ""),
                    top = 4,
                ))
            }
            card.addView(ui.hint(L.t("פריימים ${o.optInt("frames")} · עם פנים ${o.optInt("faces")} · קול ${if (o.optBoolean("audio")) "כן" else "לא"}", "Frames ${o.optInt("frames")} · with faces ${o.optInt("faces")} · sound ${if (o.optBoolean("audio")) "yes" else "no"}"), top = 4))
            o.optJSONObject("ai")?.let { r ->
                val v = r.optJSONArray("violations") ?: JSONArray()
                val txt = if (r.has("error")) L.t("AI: שגיאה · ${r.optString("error")}", "AI: error · ${r.optString("error")}")
                else if (v.length() == 0) L.t("AI (גרסה ${r.optInt("prompt")}): נקי", "AI (version ${r.optInt("prompt")}): clean")
                else L.t("AI (גרסה ${r.optInt("prompt")}): ", "AI (version ${r.optInt("prompt")}): ") + (0 until v.length()).joinToString("\n") { v.optString(it) }
                card.addView(ui.hint(txt, top = 4))
            }
            card.addView(ui.action(L.t("הסירו מהבדיקה", "Remove from the test")) {
                val a = load()
                val keep = JSONArray()
                for (k in 0 until a.length()) if (a.optJSONObject(k)?.optString("id") != o.optString("id")) keep.put(a.get(k))
                store(keep); render()
            })
            content.addView(card)
        }

        if (all.isNotEmpty() && busy == null) {
            // The AI honesty test: the same fixed clips, every time the description prompt changes.
            val ai = ui.card(top = 16)
            ai.addView(ui.text(L.t("בדיקת כנות של ה-AI", "AI honesty test"), 16f, bold = true))
            val tested = all.filter { it.first.optJSONObject("ai")?.optInt("prompt") == ClaudeClient.PROMPT_VERSION }
            val clean = tested.count { (it.first.optJSONObject("ai")?.optJSONArray("violations")?.length() ?: 0) == 0 }
            ai.addView(ui.hint(
                if (tested.isEmpty()) L.t("מריצים את תיאור ה-AI על כל סרטוני הבדיקה ובודקים את רשימת \"אסור לומר\": דיבור שלא נשמע, אדם מהפרופיל שלא זוהה, \"פעם ראשונה\", ומה קרה בסוף הסרטון.", "Runs the AI description on every test video and checks the \"never say\" list: speech that wasn't heard, a profile person who wasn't recognized, \"first time\", and what happened at the end of the video.")
                else L.t("גרסת פרומפט ${ClaudeClient.PROMPT_VERSION}: $clean מתוך ${tested.size} תיאורים נקיים", "Prompt version ${ClaudeClient.PROMPT_VERSION}: $clean of ${tested.size} descriptions clean"),
                top = 4,
            ))
            if (ClaudeClient.hasKey(this)) ai.addView(ui.button(L.t("הריצו את בדיקת ה-AI", "Run the AI test"), top = 10) {
                AlertDialog.Builder(this).setMessage(L.t("הבדיקה משתמשת ב-${all.size} בקשות מהמכסה החודשית. להמשיך?", "The test uses ${all.size} requests from the monthly allowance. Continue?"))
                    .setPositiveButton(L.t("כן", "Yes")) { _, _ -> runAiTest() }
                    .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
            })
            content.addView(ai)
            content.addView(ui.button(L.t("שתפו את הדוח", "Share the report"), top = 16) { share() })
            content.addView(ui.action(L.t("נקו את כל הבדיקה", "Clear the whole test")) {
                AlertDialog.Builder(this).setMessage(L.t("למחוק את כל סרטוני הבדיקה והתוצאות?", "Delete all test videos and results?"))
                    .setPositiveButton(L.t("מחיקה", "Delete")) { _, _ -> file().delete(); render() }
                    .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
            }.apply { setPadding(0, ui.dp(14), 0, 0) })
        }
    }

    private fun runAiTest() {
        if (running != null) return
        running = L.t("בודקים את ה-AI...", "Testing the AI…")
        render()
        worker.execute {
            val list = load()
            val profile = Profile.names(applicationContext)
            for (i in 0 until list.length()) {
                val o = list.optJSONObject(i) ?: continue
                runOnUiThread { bar?.progress = 100 * i / list.length() }
                val id = "lab_" + o.optString("id")
                val top = o.optJSONArray("found")?.optJSONObject(0)
                val m = Memory(
                    id = id, uri = o.optString("uri"), name = o.optString("name"), time = System.currentTimeMillis(),
                    label = top?.optString("type")?.let { t -> MomentType.values().firstOrNull { it.key == t }?.label } ?: "manual",
                    lat = null, lon = null, place = "", thumb = "", durationMs = o.optLong("duration"),
                    highlightMs = top?.optLong("peak") ?: -1L,
                )
                val result = JSONObject().put("prompt", ClaudeClient.PROMPT_VERSION)
                try {
                    ClaudeClient.lastRaw = ""
                    ClaudeClient.analyze(applicationContext, m)
                    val raw = try { JSONObject(ClaudeClient.lastRaw.substring(ClaudeClient.lastRaw.indexOf('{'), ClaudeClient.lastRaw.lastIndexOf('}') + 1)) } catch (_: Exception) { JSONObject() }
                    val said = listOf("title", "description", "reason").joinToString(" ") { raw.optString(it) }
                    // Nobody was recognized in a lab clip, so any profile name the AI uses is a guess.
                    val v = HonestyRules.check(said, HonestyRules.Context(emptySet(), profile))
                    result.put("text", said.take(400)).put("violations", JSONArray().also { a -> v.forEach { a.put(it.kind.name.lowercase() + ": " + it.sentence.take(120)) } })
                } catch (e: Exception) {
                    result.put("error", e.message ?: "error").put("violations", JSONArray())
                }
                Facts.remove(applicationContext, id)
                o.put("ai", result)
            }
            store(list)
            runOnUiThread {
                running = null
                if (isFinishing || isDestroyed) return@runOnUiThread
                render()
            }
        }
    }

    private fun askCase() {
        AlertDialog.Builder(this)
            .setTitle(L.t("מה יש בסרטון באמת?", "What's really in the video?"))
            .setItems(CASES.map { L.t(it.first, it.second) }.toTypedArray()) { _, which ->
                pendingCase = which
                pendingHas = which != CASES.size - 1 && which != 8 && which != 9
                if (which == 8 || which == 9) {
                    // Music / noise: the video may or may not also have a real moment in it.
                    AlertDialog.Builder(this).setMessage(L.t("יש בסרטון גם רגע אמיתי (צחוק, חיוך, חיבוק)?", "Is there also a real moment in it (laugh, smile, hug)?"))
                        .setPositiveButton(L.t("כן", "Yes")) { _, _ -> pendingHas = true; askTime() }
                        .setNegativeButton(L.t("לא", "No")) { _, _ -> pendingHas = false; askTime() }.show()
                } else askTime()
            }.show()
    }

    private fun askTime() {
        if (!pendingHas) { pendingAt = -1L; pick(); return }
        val field = EditText(this).apply {
            hint = L.t("למשל 12 (לא חובה)", "e.g. 12 (optional)")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val box = LinearLayout(this).apply { setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0); addView(field, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        AlertDialog.Builder(this)
            .setTitle(L.t("בערך באיזו שנייה הרגע?", "Roughly which second is the moment?"))
            .setView(box)
            .setPositiveButton(L.t("בחירת סרטון", "Choose the video")) { _, _ -> pendingAt = field.text.toString().toLongOrNull()?.times(1000L) ?: -1L; pick() }
            .show()
    }

    private fun pick() {
        try { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) } catch (_: Exception) { }
    }

    private fun run(uri: Uri) {
        if (running != null) return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        val case = pendingCase
        val has = pendingHas
        val at = pendingAt
        running = L.t("בודקים...", "Testing…")
        cancelled.set(false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
        worker.execute {
            Settings.load(applicationContext)
            val name = try {
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()
            val r = MomentScanner.scan(applicationContext, uri, cancelled) { p -> runOnUiThread { bar?.progress = p } }
            val o = JSONObject()
                .put("id", System.currentTimeMillis().toString()).put("case", case).put("has", has).put("at", at)
                .put("name", name).put("uri", uri.toString()).put("duration", r.durationMs).put("took", r.tookMs)
                .put("frames", r.frames).put("faces", r.framesWithFaces).put("audio", r.hasAudio)
                .put("error", r.error ?: "").put("version", MomentFusion.VERSION)
                .put("found", JSONArray().also { a -> r.candidates.forEach { a.put(Detections.toJson(it, "lab")) } })
            val list = load(); list.put(o); store(list)
            runOnUiThread {
                running = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.error != null) Toast.makeText(this, r.error, Toast.LENGTH_LONG).show()
                render()
            }
        }
    }

    private fun share() {
        val all = cases()
        val good = LabScore.metrics(all.map { it.second }, Tier.GOOD)
        val any = LabScore.metrics(all.map { it.second }, Tier.MAYBE)
        val report = JSONObject()
            .put("app", "Moments detection lab").put("fusion_version", MomentFusion.VERSION)
            .put("good_or_better", JSONObject().put("tp", good.tp).put("fn", good.fn).put("fp", good.fp).put("tn", good.tn))
            .put("including_maybe", JSONObject().put("tp", any.tp).put("fn", any.fn).put("fp", any.fp).put("tn", any.tn))
            .put("cases", JSONArray().also { a -> all.forEach { (o, _) -> a.put(JSONObject(o.toString()).apply { remove("uri") }) } })
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report.toString(1))
        startActivity(Intent.createChooser(send, L.t("שיתוף הדוח", "Share the report")))
    }

    private fun pct(f: Float) = "${(f * 100).toInt()}%"
}
