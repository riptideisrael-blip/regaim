package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * The best photos of a child for their book, chosen automatically on the phone (nothing is uploaded here):
 * the moments where face recognition found the child, opened again at full quality; every face measured for
 * size, sharpness, light, angle, open eyes, how sure we are it's the child, and how recent it is (kids change fast).
 * The parent is asked only when there aren't enough good photos or recognition isn't sure.
 */
object BookPhotos {
    /** [print]/[anchorDist]: the face print and its distance to the child's reference photos (null for a parent's own photo). */
    class Chosen(val crop: Bitmap, val memoryId: String, val score: Float, val print: FloatArray? = null, val anchorDist: Float = 0f)
    class Result(val photos: List<Chosen>, val problem: String?)

    private const val MAX_MOMENTS = 40
    private const val MAX_FRAMES = 100
    /** Lowest quality still offered (the best come first; the parent sees them before anything is drawn). */
    private const val POOL_MIN = 0.3f
    /** A face this close to a face recognition already named in the same moment is that same face. */
    private const val LABEL_SAME = 0.7f
    /** "Recent" for a young child's face. */
    private const val RECENT_DAYS = 180L
    /** Two prints this close are the same picture (or nearly), not two photos. */
    private const val SAME_PICTURE = 0.3f
    /** How many photos are kept ready (3 are shown and used; the others replace any the parent removes). */
    const val OFFER = 8
    /**
     * Stricter than everyday recognition (MATCH 0.82, margin 0.06): siblings look alike, and a book drawn from a
     * brother's face is useless. The face must be close to this child and clearly farther from everyone else.
     */
    private const val STRICT = PeopleStore.MATCH
    private const val STRICT_MARGIN = 0.10f

    /** Background thread only. */
    fun pick(ctx: Context, child: FamilyMember, progress: (Int) -> Unit = {}): Result {
        if (!FaceId.ensureModel(ctx)) return Result(emptyList(), L.t("לא הצלחנו להכין את זיהוי הפנים. בדקו את החיבור ונסו שוב.", "Couldn't set up face recognition. Check the connection and try again."))
        try { PeopleStore.enrollFamily(ctx) } catch (_: Exception) { }
        val people = PeopleStore.people(ctx)
        val person = people.firstOrNull { it.name.trim() == child.name.trim() }
        if (person == null || person.prints.isEmpty()) {
            return Result(emptyList(), L.t("עוד לא זיהינו את ${child.name} ברגעים. בחרו תמונה ברורה שלו/ה, או הוסיפו תמונת פרופיל.", "We haven't recognized ${child.name} in your moments yet. Pick a clear photo, or add a profile photo."))
        }
        // The moments where this child was found, newest first.
        val ids = PeopleStore.faces(ctx).filter { it.personId == person.id }.map { it.memoryId }.toSet()
        // All the family's moments on the phone (kept or still waiting for approval): nothing leaves the phone before the parent confirms.
        val shotsByMemory = PeopleStore.faces(ctx).filter { !it.ignored }.groupBy { it.memoryId }
        val moments = MemoryStore.all(ctx).filter { it.id in ids || child.name in Fmt.names(it) }
            .sortedByDescending { it.time }.take(MAX_MOMENTS)

        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setMinFaceSize(0.06f)
                .build()
        )
        val stats = ArrayList<FaceQuality.Stats>()
        val prints = HashMap<String, FloatArray>()
        val anchors = HashMap<String, Float>()
        val crops = HashMap<String, Pair<Bitmap, String>>()
        val now = System.currentTimeMillis()
        var frames = 0
        try {
            // The profile photo too: often the clearest face there is.
            if (child.photo.isNotBlank()) MediaImages.decode(ctx, child.photo, 1600)?.let { bmp ->
                val age = (now - File(child.photo).lastModified().coerceAtLeast(0L)) / 86_400_000L
                measure(ctx, detector, bmp, "profile", "profile", age, people, person, stats, crops, prints, anchors, emptyList())
            }
            moments.forEachIndexed { k, m ->
                if (frames >= MAX_FRAMES) return@forEachIndexed
                progress(100 * k / max(1, moments.size))
                val group = m.dayKey
                for ((n, bmp) in framesOf(ctx, m).withIndex()) {
                    frames++
                    measure(ctx, detector, bmp, "${m.id}#$n", group, (now - m.time) / 86_400_000L, people, person, stats, crops, prints, anchors, shotsByMemory[m.id].orEmpty(), m.id)
                    bmp.recycle()
                }
            }
        } finally {
            try { detector.close() } catch (_: Exception) { }
        }
        progress(100)
        // Same child only: drop faces like ones the parent already rejected, and a sibling's group if the faces split in two.
        val cands = crops.keys.mapNotNull { k -> prints[k]?.let { p -> FaceGroups.Cand(k, p, anchors[k] ?: 1f) } }
        val kept = FaceGroups.sameChild(FaceGroups.notRejected(cands, Rejects.load(ctx, child.name))).map { it.key }.toSet()
        // Kids change fast: photos from the last half year first (older ones only fill in), and never the same
        // picture twice (the profile photo is often one of the moments).
        val ranked = FaceQuality.pick(stats.filter { it.key in kept }, OFFER * 2, POOL_MIN)
            .sortedWith(compareBy<FaceQuality.Stats> { if (it.ageDays <= RECENT_DAYS) 0 else 1 }.thenByDescending { FaceQuality.score(it) })
        val unique = ArrayList<FaceQuality.Stats>()
        for (st in ranked) {
            val p = prints[st.key] ?: continue
            if (unique.none { u -> prints[u.key]?.let { FaceId.dist(it, p) < SAME_PICTURE } == true }) unique.add(st)
            if (unique.size >= OFFER) break
        }
        val chosen = unique.mapNotNull { s ->
            crops[s.key]?.let { (bmp, mem) -> Chosen(bmp, mem, FaceQuality.score(s), prints[s.key], anchors[s.key] ?: 1f) }
        }
        if (chosen.isEmpty()) return Result(emptyList(), L.t(
            "לא מצאנו תמונה מספיק ברורה של ${child.name}. כדאי להוסיף תמונת פרופיל עדכנית וברורה בפרופיל המשפחה.",
            "We couldn't find a clear enough photo of ${child.name}. Add a clear, recent profile photo in the family profile.",
        ))
        return Result(chosen, null)
    }

    /** The biggest clear face in a saved photo (the parent's profile photo). Null if there's none. Background thread only. */
    fun faceFromPath(ctx: Context, path: String): Bitmap? {
        if (path.isBlank()) return null
        val bmp = MediaImages.decode(ctx, path, 1600) ?: return null
        val detector = FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).build())
        return try {
            val f = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null
            if (min(f.boundingBox.width(), f.boundingBox.height()) < 90) null else shrink(crop(bmp, f.boundingBox), 1024)
        } catch (_: Exception) { null } finally { try { detector.close() } catch (_: Exception) { } }
    }

    /** "father", "mother"… for the illustrator, from the parent's role in the profile. */
    fun roleEn(role: String): String = when (role) { "אבא" -> "father"; "אמא" -> "mother"; "סבא" -> "grandfather"; "סבתא" -> "grandmother"; else -> "parent" }

    /** A photo the parent picked: its biggest face. Null when there's no usable face in it. Background thread only. */
    fun fromParentPhoto(ctx: Context, uri: Uri): Chosen? {
        val bmp = MediaImages.decode(ctx, uri.toString(), 1600) ?: return null
        val detector = FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).build())
        return try {
            val f = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null
            if (min(f.boundingBox.width(), f.boundingBox.height()) < 90) return null
            Chosen(crop(bmp, f.boundingBox), "parent", 1f)
        } catch (_: Exception) { null } finally { try { detector.close() } catch (_: Exception) { } }
    }

    private fun framesOf(ctx: Context, m: Memory): List<Bitmap> {
        if (!m.isVideo) return listOfNotNull(MediaImages.decode(ctx, m.uri, 1600))
        val mmr = MediaMetadataRetriever()
        return try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: max(m.durationMs, 1L)
            val spots = (listOf(m.highlight) + listOf(0.25, 0.5, 0.75).map { (dur * it).toLong() }).distinct()
            spots.mapNotNull { t ->
                mmr.getFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)?.let { shrink(it, 1600) }
            }
        } catch (_: Exception) { emptyList() } finally { try { mmr.release() } catch (_: Exception) { } }
    }

    /** Measures every face in [bmp] that is [person] (by face print, with the same margin rule as recognition). */
    private fun measure(
        ctx: Context, detector: com.google.mlkit.vision.face.FaceDetector, bmp: Bitmap, key: String, group: String, ageDays: Long,
        people: List<Person>, person: Person, out: MutableList<FaceQuality.Stats>, crops: MutableMap<String, Pair<Bitmap, String>>,
        prints: MutableMap<String, FloatArray>, anchors: MutableMap<String, Float>, shots: List<FaceShot>, memoryId: String = "profile",
    ) {
        val faces = try { Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0))) } catch (_: Exception) { emptyList<Face>() }
        for ((i, f) in faces.withIndex()) {
            val box = f.boundingBox
            val side = min(box.width(), box.height())
            if (side < 80) continue
            val tight = tightCrop(bmp, box) ?: continue
            // The print from the same crop recognition uses (else distances aren't comparable and good faces fail).
            val print = PeopleStore.cropFace(bmp, box)?.let { FaceId.embed(ctx, it) } ?: continue
            val dist = person.prints.minOf { FaceId.dist(print, it) }
            // 1) What recognition already decided for this moment: the named face nearest to this one.
            val named = shots.minByOrNull { FaceId.dist(print, it.print) }?.takeIf { FaceId.dist(print, it.print) < LABEL_SAME }
            if (named?.personId != null && named.personId != person.id) continue // named as someone else (a sibling)
            val namedAsChild = named?.personId == person.id
            // 2) Or recognition is sure now: close to this child, clearly closer than to anyone else.
            val nearestOther = people.filter { it.id != person.id && it.prints.isNotEmpty() }
                .minOfOrNull { o -> o.prints.minOf { FaceId.dist(print, it) } } ?: Float.MAX_VALUE
            val sureNow = dist < STRICT && nearestOther - dist >= STRICT_MARGIN
            if (!namedAsChild && !sureNow) continue
            val gray = luma(tight)
            val crowded = faces.any { o -> o !== f && Rect.intersects(grow(o.boundingBox, 0.3f), grow(box, 0.3f)) }
            val eyes = listOfNotNull(f.leftEyeOpenProbability, f.rightEyeOpenProbability).minOrNull() ?: -1f
            val k = "$key#$i"
            // A face recognition named as the child counts as sure (its distance only lowers the quality score a little).
            val sureDist = if (namedAsChild) min(dist, 0.6f) else dist
            val st = FaceQuality.Stats(k, group, side, ReelSignals.sharpness(tight), gray.first, gray.second, f.headEulerAngleY, f.headEulerAngleZ, eyes, sureDist, ageDays, crowded)
            out.add(st)
            // Keep pictures only of the faces that could be offered, and only the best 16 (memory).
            if (FaceQuality.score(st) >= POOL_MIN) {
                crops[k] = shrink(crop(bmp, box), 1024) to memoryId
                prints[k] = print
                anchors[k] = dist
                if (crops.size > 16) {
                    val worst = out.filter { it.key in crops }.minByOrNull { FaceQuality.score(it) }
                    worst?.let { crops.remove(it.key) }
                }
            }
        }
    }

    /** Mean brightness and the share of burnt / black pixels of a face. */
    private fun luma(b: Bitmap): Pair<Float, Float> {
        val s = Bitmap.createScaledBitmap(b, 64, 64, true)
        val px = IntArray(64 * 64)
        s.getPixels(px, 0, 64, 0, 0, 64, 64)
        var sum = 0f
        var clip = 0
        for (c in px) {
            val y = 0.299f * ((c shr 16) and 0xff) + 0.587f * ((c shr 8) and 0xff) + 0.114f * (c and 0xff)
            sum += y
            if (y < 12f || y > 245f) clip++
        }
        return sum / px.size to clip.toFloat() / px.size
    }

    private fun grow(r: Rect, f: Float): Rect {
        val dx = (r.width() * f).toInt(); val dy = (r.height() * f).toInt()
        return Rect(r.left - dx, r.top - dy, r.right + dx, r.bottom + dy)
    }

    private fun tightCrop(src: Bitmap, box: Rect): Bitmap? {
        val l = max(0, box.left); val t = max(0, box.top)
        val r = min(src.width, box.right); val b = min(src.height, box.bottom)
        if (r - l < 40 || b - t < 40) return null
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    /** The face with room for hair and chin (what the illustrator needs), from the full-quality frame. */
    private fun crop(src: Bitmap, box: Rect): Bitmap {
        val pad = (max(box.width(), box.height()) * 0.5f).toInt()
        val l = (box.left - pad).coerceAtLeast(0)
        val t = (box.top - (pad * 1.2f).toInt()).coerceAtLeast(0)
        val r = (box.right + pad).coerceAtMost(src.width)
        val b = (box.bottom + pad).coerceAtMost(src.height)
        val c = Bitmap.createBitmap(src, l, t, max(1, r - l), max(1, b - t))
        // The whole frame comes back as the same object: copy it, the frame is recycled after measuring.
        return if (c === src) src.copy(Bitmap.Config.ARGB_8888, false) else c
    }

    private fun shrink(b: Bitmap, limit: Int): Bitmap {
        val big = max(b.width, b.height)
        if (big <= limit) return b
        val s = limit.toFloat() / big
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true).also { if (it !== b) b.recycle() }
    }
}

/**
 * Faces the parent said aren't this child (removed on the confirm screen), kept per child so the next book
 * doesn't offer that face, or faces like it, again. Prints only (numbers), on the phone.
 */
object Rejects {
    private fun p(ctx: Context) = ctx.getSharedPreferences("book_rejects", Context.MODE_PRIVATE)
    private fun key(child: String) = "c_" + child.trim()

    fun load(ctx: Context, child: String): List<FloatArray> = try {
        val a = org.json.JSONArray(p(ctx).getString(key(child), "[]"))
        (0 until a.length()).map { i -> a.getJSONArray(i).let { r -> FloatArray(r.length()) { r.getDouble(it).toFloat() } } }
    } catch (_: Exception) { emptyList() }

    @Synchronized fun add(ctx: Context, child: String, print: FloatArray) {
        val all = (load(ctx, child) + print).takeLast(30)
        val a = org.json.JSONArray()
        for (f in all) a.put(org.json.JSONArray().also { r -> f.forEach { r.put(it.toDouble()) } })
        p(ctx).edit().putString(key(child), a.toString()).apply()
    }
}
