package com.regaim.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** A family member drawn as a book character and approved by the parent (kept for the next books). */
data class SavedCharacter(
    val id: String,
    /** The family member it is (profile member id, "self" for the parent using the app). */
    val member: String,
    val name: String,
    /** The picture, in the characters folder. */
    val file: String,
    val created: Long,
    /** The book it was approved in. */
    val book: String,
)

/**
 * "The family's characters": every character the parent approved in a book is kept here, on the phone only, so the
 * next book uses it by default (no new drawing: cheaper, faster, and the same characters in every book). The parent
 * can always pick another saved version, draw from a photo, or draw a new one. A few versions per person are kept.
 */
object CharacterStore {
    private const val KEEP = 5

    private fun dir(ctx: Context) = File(ctx.filesDir, "characters").apply { mkdirs() }
    private fun index(ctx: Context) = File(dir(ctx), "characters.json")

    @Synchronized
    fun all(ctx: Context): List<SavedCharacter> = try {
        val a = JSONArray(index(ctx).readText())
        (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
            SavedCharacter(it.optString("id"), it.optString("member"), it.optString("name"), it.optString("file"), it.optLong("created"), it.optString("book"))
        }.filter { File(dir(ctx), it.file).exists() }.sortedByDescending { it.created }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    private fun write(ctx: Context, list: List<SavedCharacter>) {
        val a = JSONArray()
        list.forEach { c -> a.put(JSONObject().put("id", c.id).put("member", c.member).put("name", c.name).put("file", c.file).put("created", c.created).put("book", c.book)) }
        val tmp = File(dir(ctx), "characters.json.tmp")
        tmp.writeText(a.toString())
        tmp.renameTo(index(ctx))
    }

    /** The newest saved character of [member], or null. */
    fun latest(ctx: Context, member: String): SavedCharacter? = if (member.isBlank()) null else all(ctx).firstOrNull { it.member == member }

    fun versions(ctx: Context, member: String): List<SavedCharacter> = all(ctx).filter { it.member == member }

    fun file(ctx: Context, c: SavedCharacter) = File(dir(ctx), c.file)

    /** Keeps an approved character. The same picture isn't kept twice (a book that reused it). */
    @Synchronized
    fun save(ctx: Context, member: String, name: String, src: File, book: String, created: Long = System.currentTimeMillis()) {
        if (member.isBlank() || !src.exists()) return
        val list = all(ctx)
        val bytes = src.readBytes()
        if (list.any { it.member == member && file(ctx, it).let { f -> f.length() == bytes.size.toLong() && f.readBytes().contentEquals(bytes) } }) return
        val f = "char_${UUID.randomUUID()}.jpg"
        File(dir(ctx), f).writeBytes(bytes)
        val fresh = listOf(SavedCharacter(UUID.randomUUID().toString(), member, name.trim(), f, created, book)) + list
        // A few versions per person: the oldest go.
        val keep = fresh.groupBy { it.member }.flatMap { (_, v) -> v.sortedByDescending { it.created }.take(KEEP) }.toSet()
        fresh.filter { it !in keep }.forEach { File(dir(ctx), it.file).delete() }
        write(ctx, fresh.filter { it in keep })
    }

    /**
     * Once: the characters of books made before characters were kept (the newest finished book of each child) are
     * kept too, so the next book can use them. Background thread only.
     */
    fun backfill(ctx: Context) {
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        if (prefs.getBoolean("characters_backfilled", false)) return
        try {
            val members = Profile.members(ctx)
            for (b in BookStore.all(ctx).filter { it.done || it.state == "pages" }.sortedBy { it.created }) {
                val dir = BookStore.dir(ctx, b.id)
                members.firstOrNull { it.name.trim() == b.child.trim() }?.let { m ->
                    if (b.character.isNotEmpty()) save(ctx, m.id, b.child, File(dir, b.character), b.id, b.created)
                }
                for (c in b.cast) if (c.memberId.isNotEmpty() && c.sheet.isNotEmpty()) save(ctx, c.memberId, c.name, File(dir, c.sheet), b.id, b.created)
            }
        } catch (_: Exception) { }
        prefs.edit().putBoolean("characters_backfilled", true).apply()
    }

    @Synchronized
    fun delete(ctx: Context, id: String) {
        val list = all(ctx)
        list.firstOrNull { it.id == id }?.let { File(dir(ctx), it.file).delete() }
        write(ctx, list.filterNot { it.id == id })
    }
}
