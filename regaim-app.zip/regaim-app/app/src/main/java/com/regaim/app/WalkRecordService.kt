package com.regaim.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File

/**
 * Records a walk with Pitzki (the screen and the room's sound: Pitzki's voice from the speaker and the child's
 * answers), for the parent to keep and share. Asked for each time (Android shows its own "start recording?"), kept
 * only on this phone until the parent shares it. The watermark is drawn by the lesson screen itself, so it's in
 * the video as it's recorded.
 */
class WalkRecordService : Service() {
    companion object {
        private const val CHANNEL = "pitzki_record"
        private const val ID = 7311
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var recording = false
            private set
        /** The video being recorded now (or just finished). */
        @Volatile var file: File? = null
            private set
        @Volatile private var instance: WalkRecordService? = null
        /** Called on the main thread when the recording couldn't start (no permission, the phone refused). */
        @Volatile var onFailed: ((String) -> Unit)? = null

        fun start(ctx: Context, code: Int, data: Intent) {
            val i = Intent(ctx, WalkRecordService::class.java).putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data)
            androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }

        /** Stops and returns the finished video (null if nothing was recorded). */
        fun stop(): File? {
            val s = instance ?: return null
            s.finishRecording()
            s.stopSelf()
            return file?.takeIf { it.exists() && it.length() > 10_000 }
        }
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm?.createNotificationChannel(NotificationChannel(CHANNEL, L.t("הקלטת טיול", "Recording a walk"), NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle(L.t("מקליטים את הטיול עם פיצקי 🎥", "Recording the walk with Pitzki 🎥"))
            .setOngoing(true).build()
        try {
            val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                else if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
            ServiceCompat.startForeground(this, ID, n, type)
        } catch (e: Exception) { fail(e.message ?: ""); return START_NOT_STICKY }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { fail(""); return START_NOT_STICKY }
        try { begin(code, data) } catch (e: Exception) { fail(e.message ?: "") }
        return START_NOT_STICKY
    }

    private fun begin(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("no projection")
        projection = p
        // The screen, scaled to 1280 on its long side (even sizes, as the encoder needs).
        val m = resources.displayMetrics
        val long = maxOf(m.widthPixels, m.heightPixels); val short = minOf(m.widthPixels, m.heightPixels)
        val scale = 1280f / long
        // The walk is sideways, like a film: the video too.
        val w = (long * scale).toInt() / 2 * 2
        val h = (short * scale).toInt() / 2 * 2
        val out = File(File(cacheDir, "walks").apply { mkdirs() }, "pitzki_walk_${System.currentTimeMillis()}.mp4")
        file = out
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(128_000); r.setAudioSamplingRate(44_100)
        r.setVideoSize(w, h); r.setVideoFrameRate(30); r.setVideoEncodingBitRate(5_000_000)
        r.setOutputFile(out.absolutePath)
        r.prepare()
        recorder = r
        if (Build.VERSION.SDK_INT >= 34) p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { finishRecording() }
        }, Handler(Looper.getMainLooper()))
        display = p.createVirtualDisplay("pitzki-walk", w, h, m.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        r.start()
        recording = true
    }

    private fun finishRecording() {
        if (!recording && recorder == null) return
        recording = false
        try { recorder?.stop() } catch (_: Exception) { file?.delete() }
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun fail(why: String) {
        finishRecording()
        val cb = onFailed
        Handler(Looper.getMainLooper()).post { cb?.invoke(why) }
        stopSelf()
    }

    override fun onDestroy() {
        finishRecording()
        if (instance === this) instance = null
        super.onDestroy()
    }
}
