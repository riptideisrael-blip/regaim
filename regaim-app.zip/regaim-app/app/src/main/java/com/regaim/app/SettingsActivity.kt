package com.regaim.app

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/** "הגדרות": family profile, what saves a moment, the camera, people & faces, AI keys, learning and privacy. */
open class SettingsActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private var parentField: EditText? = null
    private var familyField: EditText? = null
    private var role = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        Settings.load(this)
        content = findViewById(R.id.screenContent)
        val tab = this is ProfileActivity
        findViewById<TextView>(R.id.screenTitle).text = if (tab) "פרופיל" else "הגדרות"
        findViewById<View>(R.id.btnClose).apply {
            visibility = if (tab) View.GONE else View.VISIBLE
            setOnClickListener { finish() }
        }
        if (tab) {
            findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
            Nav.setup(this, Nav.Tab.PROFILE)
        }
        // A clear "save" bar under the settings.
        val root = findViewById<View>(R.id.screenScroll).parent as LinearLayout
        saveBar = ui.button("✓ הכל שמור", top = 0) { saveAll() }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(ui.dp(20), ui.dp(6), ui.dp(20), ui.dp(8))
            }
        }
        root.addView(saveBar, root.indexOfChild(findViewById(R.id.bottomNav)))
        ui.onChange = { if (!rendering) markDirty() }
    }

    private var saveBar: com.google.android.material.button.MaterialButton? = null
    private var phrasesField: EditText? = null
    private var rendering = false

    private fun markDirty() {
        saveBar?.apply {
            text = "שמור שינויים"
            backgroundTintList = android.content.res.ColorStateList.valueOf(ui.color(R.color.accent))
            setTextColor(ui.color(R.color.white))
        }
    }

    private fun markSaved() {
        saveBar?.apply {
            text = "✓ הכל שמור"
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFE9E7FB.toInt())
            setTextColor(ui.color(R.color.accent_dark))
        }
    }

    /** Saves everything typed on the screen (switches and choices are saved the moment you change them). */
    private fun saveAll() {
        saveParent()
        phrasesField?.let { f ->
            val list = Phrases.parse(f.text.toString())
            if (list.isNotEmpty()) {
                Status.phrases = list
                Settings.putString(this, "phrases", list.joinToString(", "))
            }
        }
        Settings.load(this)
        markSaved()
        Toast.makeText(this, "נשמר ✓", Toast.LENGTH_SHORT).show()
        if (Status.running) restartNote()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onPause() {
        super.onPause()
        // Never lose what was typed, even without pressing save.
        saveParent()
        phrasesField?.let { f ->
            val list = Phrases.parse(f.text.toString())
            if (list.isNotEmpty()) { Status.phrases = list; Settings.putString(this, "phrases", list.joinToString(", ")) }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun restartNote() { if (Status.running) toast("השינוי ייכנס לתוקף כשתעצור ותתחיל שוב") }

    private fun render() {
        val y = findViewById<View>(R.id.screenScroll).scrollY
        rendering = true
        content.removeAllViews()
        if (this is ProfileActivity) profileHeader()
        profileSection()
        triggersSection()
        cameraSection()
        peopleSection()
        aiSection()
        learningSection()
        privacySection()
        content.post {
            findViewById<View>(R.id.screenScroll).scrollTo(0, y)
            rendering = false
        }
    }

    // ---------- profile ----------

    /** Top of the Profile tab: the family at a glance, and the ways in to what matters. */
    private fun profileHeader() {
        val all = MemoryStore.all(this)
        val card = ui.card(top = 8)
        card.addView(ui.text(Profile.homeTitle(this), 22f, bold = true))
        val kids = Profile.kids(this)
        val line = listOf(
            "${all.size} זיכרונות",
            "${all.count { it.favorite }} מועדפים",
            if (kids.isNotEmpty()) kids.joinToString(" · ") { it.name } else "",
        ).filter { it.isNotEmpty() }.joinToString(" · ")
        card.addView(ui.hint(line, top = 2))
        card.addView(ui.row(if (Status.running) "● Moments איתכם עכשיו" else "מצב צילום", "פתח", top = 8) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        })
        card.addView(ui.row("מה Moments למד עליכם", "") { LearnedActivity.open(this) })
        card.addView(ui.row("אנשים ופנים", "") { PeopleActivity.open(this) })
        card.addView(ui.row("💌 מעגל המשפחה (אב טיפוס)", if (Circle.joined(this)) Circle.name(this) else "") { CircleActivity.open(this) })
        content.addView(card)
    }

    private fun saveParent() {
        familyField?.let { Profile.setFamilyName(this, it.text.toString()) }
        val f = parentField ?: return
        Profile.setParent(this, f.text.toString(), role)
    }

    private fun profileSection() {
        content.addView(ui.section("הפרופיל שלך"))
        content.addView(ui.hint("עוזר ל-AI לכתוב עליכם נכון, ולזהות אבני דרך שמתאימות לגיל."))
        val card = ui.card()
        card.addView(ui.text("שם המשפחה", 14f, R.color.ink_soft))
        familyField = ui.field("למשל: רביבו", Profile.familyName(this), top = 4).also { card.addView(it) }
        card.addView(ui.text("השם שלך", 14f, R.color.ink_soft, top = 10))
        parentField = ui.field("למשל: יוסף", Profile.parentName(this), top = 4).also { card.addView(it) }
        role = Profile.role(this)
        val roles = listOf("אבא", "אמא", "סבא", "סבתא", "אחר")
        card.addView(ui.chips(roles, roles.indexOf(role), top = 10) { i ->
            role = roles[i]
            saveParent()
        })
        card.addView(ui.divider())
        card.addView(ui.text("הילדים", 14f, R.color.ink_soft, top = 4))
        val kids = Profile.kids(this)
        if (kids.isEmpty()) card.addView(ui.hint("עוד לא הוספת ילדים."))
        kids.forEachIndexed { i, k ->
            val age = Profile.ageText(k.birth)
            val people = PeopleStore.people(this).any { it.name == k.name }
            val sub = listOf(age, if (people) "מזוהה בפנים ✓" else "").filter { it.isNotEmpty() }.joinToString(" · ")
            card.addView(ui.row(k.name, sub.ifEmpty { "ערוך" }) { editKid(i) })
        }
        card.addView(ui.button("+ הוסף ילד") { editKid(-1) })
        card.addView(ui.hint("טיפ: כשתיתן שם לפנים במסך \"אנשים\", כתוב בדיוק את אותו שם, ו-Moments יחבר בין הפרופיל לפנים.", top = 8))
        content.addView(card)
    }

    private fun editKid(index: Int) {
        val kids = Profile.kids(this).toMutableList()
        val old = kids.getOrNull(index)
        var birth = old?.birth ?: ""
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val name = ui.field("שם", old?.name ?: "")
        box.addView(name)
        val birthBtn = ui.button("") {}
        fun showBirth() {
            birthBtn.text = if (birth.isEmpty()) "בחר תאריך לידה" else "נולד/ה: ${birth.split("-").reversed().joinToString(".")}  (${Profile.ageText(birth)})"
        }
        showBirth()
        birthBtn.setOnClickListener {
            val c = Calendar.getInstance()
            val p = birth.split("-").mapNotNull { it.toIntOrNull() }
            if (p.size == 3) c.set(p[0], p[1] - 1, p[2])
            DatePickerDialog(this, { _, yy, mm, dd ->
                birth = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd)
                showBirth()
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply {
                datePicker.maxDate = System.currentTimeMillis()
            }.show()
        }
        box.addView(birthBtn)
        val b = AlertDialog.Builder(this)
            .setTitle(if (old == null) "ילד חדש" else "עריכת ${old.name}")
            .setView(box)
            .setPositiveButton("שמור") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) return@setPositiveButton
                val kid = Kid(n, birth)
                if (index >= 0 && index < kids.size) kids[index] = kid else kids.add(kid)
                Profile.saveKids(this, kids)
                render()
            }
            .setNegativeButton("ביטול", null)
        if (old != null) b.setNeutralButton("הסר") { _, _ ->
            kids.removeAt(index)
            Profile.saveKids(this, kids)
            render()
        }
        b.show()
    }

    // ---------- what saves a moment ----------

    private fun triggersSection() {
        content.addView(ui.section("מה שומר רגע"))
        val card = ui.card()

        card.addView(ui.switch("צחוק וקריאות שמחה", Status.laughOn, top = 0) { on ->
            Status.laughOn = on
            Settings.putBool(this, "laugh_on", on)
        })
        val label = ui.hint("")
        val bar = SeekBar(this).apply {
            max = 55
            progress = ((0.6f - Status.threshold) * 100).roundToInt().coerceIn(0, 55)
        }
        fun showLabel() {
            val p = bar.progress
            val word = when {
                p >= 48 -> "גבוהה מאוד"
                p >= 38 -> "גבוהה"
                p >= 22 -> "בינונית"
                else -> "נמוכה"
            }
            label.text = "רגישות: $word (שומר כשהצחוק מעל ${(Status.threshold * 100).roundToInt()}%)"
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Status.threshold = 0.6f - p / 100f
                Settings.putFloat(this@SettingsActivity, "threshold2", Status.threshold)
                showLabel()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        showLabel()
        card.addView(label)
        card.addView(bar)
        card.addView(ui.hint("נשמרים רגעים מיותרים? הזז שמאלה. מפספס צחוקים? הזז ימינה."))

        card.addView(ui.divider())
        card.addView(ui.switch("מילים ומשפטים (״אבא תראה״, ״וואו״...)", Status.wordsOn) { on ->
            Status.wordsOn = on
            Settings.putBool(this, "words_on", on)
            restartNote()
        })
        val phrases = ui.field("מילים מופרדות בפסיקים", Status.phrases.joinToString(", "), multiline = true)
        phrasesField = phrases
        card.addView(phrases)
        card.addView(ui.hint("מילה שמתחילה ב״שמור״ (כמו ״שמור רגע״) תמיד שומרת, גם מיד אחרי רגע אחר."))
        val btns = ui.horizontal()
        btns.addView(ui.action("שמור מילים") {
            val list = Phrases.parse(phrases.text.toString())
            Status.phrases = list
            Settings.putString(this, "phrases", list.joinToString(", "))
            phrases.setText(list.joinToString(", "))
            toast("נשמרו ${list.size} מילים")
        })
        btns.addView(ui.action("החזר לברירת מחדל", R.color.ink_soft) {
            Status.phrases = Phrases.DEFAULT
            Settings.putString(this, "phrases", Phrases.DEFAULT.joinToString(", "))
            phrases.setText(Phrases.DEFAULT.joinToString(", "))
        })
        card.addView(btns)

        card.addView(ui.divider())
        card.addView(ui.switch("חיוך גדול או ילד שרץ אליך", Status.facesOn) { on ->
            Status.facesOn = on
            Settings.putBool(this, "faces_on", on)
            restartNote()
        })
        card.addView(ui.hint("לכל היותר רגע אחד כזה בדקה, כדי לא למלא את הגלריה."))

        card.addView(ui.divider())
        card.addView(ui.switch("🤗 חיבוק", Status.hugOn) { on ->
            Status.hugOn = on
            Settings.putBool(this, "hug_on", on)
            restartNote()
        })
        card.addView(ui.hint("כשמישהו מתקרב ומחבק אותך (המצלמה על החזה מתכסה לכ-3 שניות), או כששניים מתחבקים מולך יותר מ-3 שניות. זיהוי בקירוב: לפעמים יפספס, ולפעמים ישמור כשמשהו מכסה את המצלמה."))

        card.addView(ui.divider())
        card.addView(ui.switch("❤️ ״אני אוהב אותך״", Status.loveOn) { on ->
            Status.loveOn = on
            Settings.putBool(this, "love_on", on)
            restartNote()
        })
        card.addView(ui.hint("״אוהב אותך״, ״אוהבת אותך״, ״אוהבים אותך״ תמיד נשמרים, גם מיד אחרי רגע אחר."))

        card.addView(ui.divider())
        card.addView(ui.switch("🎵 שירה", Status.singOn) { on ->
            Status.singOn = on
            Settings.putBool(this, "sing_on", on)
        })
        card.addView(ui.hint("ילד שר, או המשפחה שרה ביחד. שיר שמתנגן מרמקול לא נחשב."))

        card.addView(ui.divider())
        card.addView(ui.text("שמירה ידנית", 15f, top = 4))
        card.addView(ui.hint("כפתור ♥ במסך היום, כפתור בהתראה, או אריח \"שמור רגע\" בתפריט המהיר של הטלפון (משוך מלמעלה ← עריכה)."))
        content.addView(card)
    }

    // ---------- camera & clips ----------

    private fun cameraSection() {
        content.addView(ui.section("מצלמה וקליפים"))
        val card = ui.card()
        card.addView(ui.text("עדשה בהתחלה", 14f, R.color.ink_soft, top = 0))
        val zooms = listOf(0.6f, 1f, 2f, 3f, 5f)
        val sel = zooms.indexOfFirst { kotlin.math.abs(it - Status.zoom) < 0.01f }.coerceAtLeast(0)
        card.addView(ui.chips(listOf("0.6x רחבה", "1x", "2x", "3x", "5x"), sel) { i ->
            Status.zoom = zooms[i]
            Settings.putFloat(this, "zoom", zooms[i])
            if (Status.running) startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_ZOOM))
        })
        card.addView(ui.hint("0.6x תופס הכי הרבה כשהטלפון על החזה."))

        val p = Settings.prefs(this)
        card.addView(ui.text("כמה לשמור לפני הרגע", 14f, R.color.ink_soft, top = 14))
        val before = Settings.BEFORE_OPTIONS
        card.addView(ui.chips(before.map { "$it שנ׳" }, before.indexOf(p.getInt("before_s", 15)).coerceAtLeast(0)) { i ->
            Settings.putInt(this, "before_s", before[i])
            Settings.load(this)
        })
        card.addView(ui.text("כמה לשמור אחרי", 14f, R.color.ink_soft, top = 12))
        val after = Settings.AFTER_OPTIONS
        card.addView(ui.chips(after.map { "$it שנ׳" }, after.indexOf(p.getInt("after_s", 15)).coerceAtLeast(0)) { i ->
            Settings.putInt(this, "after_s", after[i])
            Settings.load(this)
        })
        card.addView(ui.hint("אפשר תמיד לקצר רגע אחר כך עם \"קצר\" במסך הרגע."))

        card.addView(ui.divider())
        card.addView(ui.switch("רטט קצר כשנשמר רגע", Status.buzzOn) { on ->
            Status.buzzOn = on
            Settings.putBool(this, "buzz_on", on)
        })
        content.addView(card)
    }

    // ---------- people ----------

    private fun peopleSection() {
        content.addView(ui.section("אנשים וזיהוי פנים"))
        val card = ui.card()
        card.addView(ui.switch("זיהוי מי מופיע בכל רגע", PeopleStore.peopleEnabled(this), top = 0) { on ->
            Settings.putBool(this, "people_on", on)
        })
        card.addView(ui.hint("הזיהוי נעשה רק בטלפון. הפנים לא נשלחות לשום מקום."))
        val people = PeopleStore.people(this)
        val unknown = try { PeopleStore.unknownGroups(this).size } catch (_: Exception) { 0 }
        card.addView(ui.row("האנשים שלך", if (people.isEmpty()) "עוד אין" else "${people.size} אנשים") { PeopleActivity.open(this) })
        if (people.isNotEmpty()) card.addView(ui.hint(people.joinToString(" · ") { "${it.name} (${PeopleStore.countFor(this, it.name)})" }, top = 0))
        if (unknown > 0) card.addView(ui.row("פנים שמחכות לשם", "$unknown") { PeopleActivity.open(this) })
        val pending = MemoryStore.all(this).count { !it.facesScanned }
        if (pending > 0) card.addView(ui.button("חפש פנים ב-$pending רגעים שלא נבדקו") {
            toast("מחפש פנים ברקע...")
            worker.execute {
                var n = 0
                while (true) {
                    val k = PeopleStore.scanPending(applicationContext, 6)
                    n += k
                    if (k == 0) break
                }
                runOnUiThread { if (!isFinishing) { toast("נבדקו $n רגעים"); render() } }
            }
        })
        card.addView(ui.action("התחל את זיהוי הפנים מאפס", R.color.danger) {
            AlertDialog.Builder(this)
                .setTitle("למחוק את כל זיהוי הפנים?")
                .setMessage("כל השמות והפנים יימחקו, והרגעים ייסרקו מחדש. הקליפים עצמם לא נמחקים.")
                .setPositiveButton("מחק") { _, _ ->
                    worker.execute {
                        PeopleStore.clearAll(applicationContext)
                        runOnUiThread { if (!isFinishing) render() }
                    }
                }
                .setNegativeButton("ביטול", null)
                .show()
        })
        content.addView(card)
    }

    // ---------- AI ----------

    private fun aiSection() {
        content.addView(ui.section("AI"))
        val card = ui.card()
        val claude = ClaudeClient.hasKey(this)
        card.addView(ui.row("מפתח Claude (תיאורים, סיפור היום, שאלות)", if (claude) "מחובר ✓" else "לא מוגדר", top = 0) {
            askKey(
                "מפתח Claude", "sk-ant-...", ClaudeClient.apiKey(this),
                "המפתח נשמר רק בטלפון. בלעדיו הרגעים נשמרים, אבל בלי תיאור, סיפור וחיפוש.",
                "https://console.anthropic.com/settings/keys",
            ) { ClaudeClient.setApiKey(this, it) }
        })
        card.addView(ui.row("מפתח Gemini (ציורי קומיקס)", if (GeminiClient.hasKey(this)) "מחובר ✓" else "לא חובה") {
            askKey(
                "מפתח Gemini", "AIza...", GeminiClient.apiKey(this),
                "עם המפתח כל פאנל בקומיקס מצויר מחדש. התמונות מהרגע נשלחות לגוגל לציור.",
                "https://aistudio.google.com/apikey",
            ) { GeminiClient.setApiKey(this, it) }
        })
        if (claude) {
            val all = MemoryStore.all(this)
            card.addView(ui.action("תאר מחדש את כל ${all.size} הרגעים") {
                AlertDialog.Builder(this)
                    .setTitle("לתאר מחדש את כל הרגעים?")
                    .setMessage("שימושי אחרי שעדכנת פרופיל, שמות או מה ש-Moments למד. זה עולה בערך ${(all.size * 0.02 * 3.7).let { String.format(Locale.US, "%.1f", it) }}₪ במפתח שלך. תיקונים שעשית ידנית לכותרת ולתיאור יוחלפו.")
                    .setPositiveButton("כן") { _, _ ->
                        for (m in all) MemoryStore.update(this, m.copy(analyzed = false))
                        toast("מתאר מחדש ברקע...")
                        worker.execute {
                            val n = MemoryStore.analyzePending(applicationContext)
                            runOnUiThread { if (!isFinishing) toast("תוארו $n רגעים") }
                        }
                    }
                    .setNegativeButton("ביטול", null)
                    .show()
            })
        }
        content.addView(card)
    }

    private fun askKey(title: String, hint: String, value: String, message: String, url: String, save: (String) -> Unit) {
        val field = ui.field(hint, value, password = true)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(box)
            .setPositiveButton("שמור") { _, _ -> save(field.text.toString().trim()); render() }
            .setNeutralButton("איפה משיגים?") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    // ---------- learning ----------

    private fun learningSection() {
        content.addView(ui.section("מה Moments למד"))
        val card = ui.card()
        val items = Learning.items(this)
        val liked = Learning.liked(this).size
        val deleted = Learning.rejected(this).size
        card.addView(ui.row("תובנות על מה שחשוב לך", if (items.isEmpty()) "עוד אין" else "${items.size}", top = 0) { LearnedActivity.open(this) })
        card.addView(ui.hint("נלמד מ-$liked רגעים ששמרת/אהבת ו-$deleted שמחקת. אפשר לראות על מה כל תובנה מבוססת ולתקן.", top = 0))
        card.addView(ui.action("שכח את כל מה שנלמד", R.color.danger) {
            AlertDialog.Builder(this)
                .setTitle("לשכוח את כל מה ש-Moments למד?")
                .setMessage("התובנות, הכללים שכתבת והדוגמאות של רגעים שמחקת יימחקו. הרגעים עצמם נשארים.")
                .setPositiveButton("שכח") { _, _ ->
                    worker.execute {
                        Learning.resetAll(applicationContext)
                        runOnUiThread { if (!isFinishing) render() }
                    }
                }
                .setNegativeButton("ביטול", null)
                .show()
        })
        content.addView(card)
    }

    // ---------- privacy ----------

    private fun privacySection() {
        content.addView(ui.section("פרטיות"))
        val card = ui.card()
        val clips = MemoryStore.all(this)
        val mb = clips.sumOf { it.durationMs } / 1000.0 * 0.8
        card.addView(ui.text("נשמר בטלפון בלבד: הקליפים (בגלריה, Movies/Moments), הפנים והשמות, הפרופיל וההגדרות.", 14f, top = 0))
        card.addView(ui.text("נשלח ל-AI רק אם הגדרת מפתח: 3 תמונות מכל רגע לתיאור (Claude), ותמונות לקומיקס מצויר (Gemini). הקליפים עצמם לא נשלחים.", 14f, top = 8))
        card.addView(ui.text("זיהוי המילים נעשה על ידי שירות הדיבור של גוגל שבטלפון.", 14f, top = 8))
        card.addView(ui.hint("${clips.size} רגעים · בערך ${mb.roundToInt()}MB בגלריה", top = 10))
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        card.addView(ui.hint("Moments $version", top = 2))
        content.addView(card)
    }
}

/** Removes every face, name and print, so moments are scanned again from scratch. */
fun PeopleStore.clearAll(ctx: Context) {
    synchronized(this) {
        File(ctx.filesDir, "people.json").delete()
        File(ctx.filesDir, "faces.json").delete()
        File(ctx.filesDir, "faces").listFiles()?.forEach { it.delete() }
    }
    for (m in MemoryStore.all(ctx)) {
        if (m.people.isNotEmpty() || m.facesScanned) MemoryStore.update(ctx, m.copy(people = "", facesScanned = false))
    }
}

/** The "פרופיל" tab: the same settings, as a tab with the family header. */
class ProfileActivity : SettingsActivity()
