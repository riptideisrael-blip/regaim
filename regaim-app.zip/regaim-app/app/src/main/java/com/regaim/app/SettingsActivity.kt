package com.regaim.app

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/** "הגדרות": family profile, what saves a moment, the camera, people & faces, AI keys, learning and privacy. */
open class SettingsActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private var parentField: EditText? = null
    private var familyField: EditText? = null
    private var role = ""
    private var advanced = false
    private var onPhotoPicked: ((String) -> Unit)? = null
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val callback = onPhotoPicked
            worker.execute {
                val result = try {
                    val dir = File(filesDir, "family_photos").apply { mkdirs() }
                    val target = File(dir, "${UUID.randomUUID()}.jpg")
                    val options = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
                    options.inJustDecodeBounds = false
                    options.inSampleSize = (maxOf(options.outWidth, options.outHeight) / 768).coerceAtLeast(1)
                    val bitmap = contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
                        ?: throw IllegalStateException("לא ניתן לקרוא את התמונה")
                    target.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, it) }
                    bitmap.recycle()
                    Result.success(target.absolutePath)
                } catch (_: Exception) { Result.failure<String>(IllegalStateException(L.t("לא הצלחנו לשמור את התמונה. נסו תמונה אחרת.", "Couldn't save the photo. Try another one."))) }
                runOnUiThread { if (!isFinishing) result.onSuccess { callback?.invoke(it) }.onFailure { toast(it.message.orEmpty()) } }
            }
        }
        onPhotoPicked = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        Settings.load(this)
        content = findViewById(R.id.screenContent)
        val tab = this is ProfileActivity
        findViewById<TextView>(R.id.screenTitle).text = if (tab) L.t("פרופיל", "Profile") else L.t("הגדרות", "Settings")
        findViewById<View>(R.id.btnClose).apply {
            visibility = if (tab) View.GONE else View.VISIBLE
            setOnClickListener { finish() }
        }
        if (tab) {
            findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
            Nav.setup(this, Nav.Tab.PROFILE)
        }
        // A clear "save" bar under the settings.
        val root = findViewById<View>(R.id.screenScroll).parent as LinearLayout
        saveBar = ui.button(L.t("✓ הכל שמור", "✓ All saved"), top = 0) { saveAll() }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(ui.dp(20), ui.dp(6), ui.dp(20), ui.dp(8))
            }
        }
        root.addView(saveBar, root.indexOfChild(findViewById(R.id.bottomNav)))
        ui.onChange = { if (!rendering) markDirty() }
    }

    private var saveBar: com.google.android.material.button.MaterialButton? = null
    private var phrasesField: EditText? = null
    private var rendering = false

    private fun markDirty() {
        saveBar?.apply {
            text = L.t("שמור שינויים", "Save changes")
            backgroundTintList = android.content.res.ColorStateList.valueOf(ui.color(R.color.accent))
            setTextColor(ui.color(R.color.white))
        }
    }

    private fun markSaved() {
        saveBar?.apply {
            text = L.t("✓ הכל שמור", "✓ All saved")
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFEDE6DB.toInt())
            setTextColor(ui.color(R.color.accent_dark))
        }
    }

    /** Saves everything typed on the screen (switches and choices are saved the moment you change them). */
    private fun saveAll() {
        saveParent()
        phrasesField?.let { f ->
            val list = Phrases.parse(f.text.toString())
            if (list.isNotEmpty()) {
                Status.phrases = list
                Settings.putString(this, "phrases", list.joinToString(", "))
            }
        }
        Settings.load(this)
        markSaved()
        Toast.makeText(this, L.t("נשמר ✓", "Saved ✓"), Toast.LENGTH_SHORT).show()
        if (Status.running) restartNote()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onPause() {
        super.onPause()
        // Never lose what was typed, even without pressing save.
        saveParent()
        phrasesField?.let { f ->
            val list = Phrases.parse(f.text.toString())
            if (list.isNotEmpty()) { Status.phrases = list; Settings.putString(this, "phrases", list.joinToString(", ")) }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun restartNote() { if (Status.running) toast(L.t("השינוי ייכנס לתוקף כשתעצור ותתחיל שוב", "This takes effect next time you stop and start")) }

    private fun render() {
        val y = findViewById<View>(R.id.screenScroll).scrollY
        rendering = true
        content.removeAllViews()
        if (this is ProfileActivity) profileHeader()
        languageSection()
        profileSection()
        privacySection()
        content.addView(ui.section(L.t("הגדרות נוספות", "More settings")))
        content.addView(ui.row(L.t("הגדרות צילום, הבנת רגעים ולמידה", "Recording, moment understanding & learning"), if (advanced) L.t("הסתר", "Hide") else L.t("פתח", "Open")) {
            saveParent()
            phrasesField?.let { Settings.putString(this, "phrases", it.text.toString()) }
            advanced = !advanced
            render()
        })
        if (advanced || this !is ProfileActivity) {
            triggersSection()
            cameraSection()
            peopleSection()
            aiSection()
            learningSection()
        }
        content.post {
            findViewById<View>(R.id.screenScroll).scrollTo(0, y)
            rendering = false
        }
    }

    // ---------- language ----------

    /** "שפה": switch the whole app between Hebrew and English. */
    private fun languageSection() {
        val card = ui.card(top = 8)
        card.addView(ui.row("🌐 " + L.t("שפה", "Language"), if (L.isEn) "English" else "עברית", top = 0) {
            val codes = arrayOf(L.HE, L.EN)
            AlertDialog.Builder(this)
                .setTitle(L.t("שפה", "Language"))
                .setSingleChoiceItems(arrayOf("עברית", "English"), if (L.isEn) 1 else 0) { d, which ->
                    d.dismiss()
                    val chosen = codes[which]
                    if (chosen != L.lang) {
                        saveParent()
                        phrasesField?.let { Settings.putString(this, "phrases", it.text.toString()) }
                        L.set(this, chosen)
                        recreate()
                    }
                }
                .setNegativeButton(L.t("ביטול", "Cancel"), null)
                .show()
        })
        content.addView(card)
    }

    // ---------- profile ----------

    /** Who is signed in (photo, name, email), or a way to sign in. */
    private fun accountCard() {
        val card = ui.card(top = 8)
        val row = ui.horizontal(top = 0)
        val mv = MemoryViews(this)
        val name = Profile.parentName(this).ifEmpty { Account.name(this) }.ifEmpty { L.t("החשבון שלי", "My account") }
        val avatar = mv.avatar(name, 56).apply {
            contentDescription = L.t("שינוי תמונת הפרופיל", "Change profile photo")
            setOnClickListener {
                saveParent()
                onPhotoPicked = { path -> Profile.setPhoto(this@SettingsActivity, path); render() }
                pickPhoto.launch("image/*")
            }
        }
        row.addView(avatar)
        val photo = Account.avatar(this)
        if (photo.isNotEmpty() && Profile.photo(this).isEmpty()) worker.execute {
            val bmp = Circle.image(applicationContext, photo)
            runOnUiThread {
                if (bmp != null && !isFinishing) {
                    val img = android.widget.ImageView(this).apply {
                        setImageBitmap(bmp)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                        background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL }
                        clipToOutline = true
                        layoutParams = avatar.layoutParams
                    }
                    img.setOnClickListener { avatar.performClick() }
                    img.contentDescription = L.t("שינוי תמונת הפרופיל", "Change profile photo")
                    val i = row.indexOfChild(avatar)
                    if (i >= 0) { row.removeViewAt(i); row.addView(img, i) }
                }
            }
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(14), 0, ui.dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(ui.text(name, 18f, bold = true))
        texts.addView(ui.hint(if (Account.signedIn(this)) Account.email(this) else L.t("לא מחובר · הזיכרונות שמורים בטלפון", "Not signed in · Memories are saved on this phone"), top = 0))
        row.addView(texts)
        card.addView(row)
        if (Account.isAdmin(this)) card.addView(ui.row(L.t("ניהול", "Admin"), L.t("משתמשים ופעילות", "Users and activity")) { AdminActivity.open(this) })
        if (Account.signedIn(this)) {
            card.addView(ui.action(L.t("התנתקות", "Sign out"), R.color.ink_soft) {
                AlertDialog.Builder(this).setTitle(L.t("להתנתק?", "Sign out?"))
                    .setMessage(L.t("הזיכרונות נשארים בטלפון. מעגל המשפחה יעבוד שוב אחרי שתתחברו.", "Your memories stay on this phone. Family circle will work again once you sign back in."))
                    .setPositiveButton(L.t("התנתק", "Sign out")) { _, _ ->
                        worker.execute {
                            Account.signOut(applicationContext)
                            runOnUiThread { if (!isFinishing) render() }
                        }
                    }
                    .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
            })
        } else {
            card.addView(ui.button(L.t("התחברות או הרשמה", "Sign in or sign up"), primary = true, top = 12) { WelcomeActivity.open(this) })
        }
        content.addView(card)
    }

    /** Top of the Profile tab: the family at a glance, and the ways in to what matters. */
    private fun profileHeader() {
        val all = MemoryStore.all(this)
        accountCard()
        val card = ui.card(top = 8)
        card.addView(ui.text(Profile.homeTitle(this), 22f, bold = true))
        val members = Profile.members(this)
        val line = listOf(
            L.t("${all.size} זיכרונות", "${all.size} memories"),
            L.t("${all.count { it.favorite }} מועדפים", "${all.count { it.favorite }} favorites"),
            if (members.isNotEmpty()) members.joinToString(" · ") { it.name } else "",
        ).filter { it.isNotEmpty() }.joinToString(" · ")
        card.addView(ui.hint(line, top = 2))
        card.addView(ui.row(if (Status.running) L.t("רגעים מצלם עכשיו", "Moments is recording now") else L.t("מצב צילום", "Recording mode"), L.t("פתח", "Open"), top = 8) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        })
        card.addView(ui.row(L.t("מה רגעים למד עליכם", "What Moments learned about you"), "") { LearnedActivity.open(this) })
        card.addView(ui.row(L.t("אנשים ופנים", "People and faces"), "") { PeopleActivity.open(this) })
        card.addView(ui.row(L.t("מעגל המשפחה", "Family circle"), if (Circle.joined(this)) Circle.name(this) else L.t("פתחו מעגל", "Start a circle")) { CircleActivity.open(this) })
        content.addView(card)
    }

    private fun saveParent() {
        familyField?.let { Profile.setFamilyName(this, it.text.toString()) }
        val f = parentField ?: return
        Profile.setParent(this, f.text.toString(), role)
    }

    private fun profileSection() {
        content.addView(ui.section(L.t("הפרופיל שלך", "Your profile")))
        content.addView(ui.hint(L.t("עוזר ל-AI לכתוב עליכם נכון, ולזהות אבני דרך שמתאימות לגיל.", "Helps the AI write about you accurately and spot age-appropriate milestones.")))
        val card = ui.card()
        card.addView(ui.text(L.t("שם המשפחה", "Family name"), 14f, R.color.ink_soft))
        familyField = ui.field(L.t("שם המשפחה שלכם", "Your family name"), Profile.familyName(this), top = 4).also { card.addView(it) }
        card.addView(ui.text(L.t("השם שלך", "Your name"), 14f, R.color.ink_soft, top = 10))
        parentField = ui.field(L.t("איך לקרוא לך?", "What should we call you?"), Profile.parentName(this), top = 4).also { card.addView(it) }
        role = Profile.role(this)
        val roles = listOf("אני", "אבא", "אמא", "סבא", "סבתא", "אחר")
        card.addView(ui.chips(roles.map { Profile.relationLabel(it) }, roles.indexOf(role), top = 10) { i ->
            role = roles[i]
            saveParent()
        })
        card.addView(ui.divider())
        card.addView(ui.text(L.t("בני המשפחה", "Family members"), 14f, R.color.ink_soft, top = 4))
        val members = Profile.members(this).filter { it.id != "self" }
        if (members.isEmpty()) card.addView(ui.hint(L.t("אפשר להוסיף בן או בת זוג, ילדים, וגם חיות מחמד.", "Add your partner, kids and pets.")))
        members.forEach { m ->
            val sub = listOf(Profile.relationLabel(m.relation), Profile.ageText(m.birth)).filter { it.isNotEmpty() }.joinToString(" · ")
            card.addView(ui.row(m.name, sub.ifEmpty { L.t("ערוך", "Edit") }) { saveParent(); editMember(m.id) })
        }
        card.addView(ui.button(L.t("הוסיפו בן משפחה או חיית מחמד", "Add a family member or pet")) { saveParent(); editMember(null) })
        card.addView(ui.hint(L.t("פרטי המשפחה נשמרים כאן. כדי לזהות מי מופיע בזיכרון, תנו שם לפנים במסך אנשים.", "Family details are saved here. To recognize who's in a memory, name faces in People."), top = 8))
        content.addView(card)
    }

    private fun editMember(id: String?) {
        val members = Profile.members(this).toMutableList()
        val old = members.firstOrNull { it.id == id }
        val memberId = old?.id ?: UUID.randomUUID().toString()
        var birth = old?.birth ?: ""
        var photo = old?.photo ?: ""
        var relation = old?.relation ?: "בן משפחה"
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val name = ui.field(L.t("שם", "Name"), old?.name ?: "")
        box.addView(name)
        val relations = listOf("בן זוג", "בת זוג", "ילד", "ילדה", "אבא", "אמא", "סבא", "סבתא", "אח", "אחות", "בן משפחה", "בת משפחה", "כלב", "חתול", "חיית מחמד")
        box.addView(ui.chips(relations.map { Profile.relationLabel(it) }, relations.indexOf(relation), top = 8) { relation = relations[it] })
        val photoButton = ui.button(if (photo.isEmpty()) L.t("הוסיפו תמונה", "Add photo") else L.t("החליפו תמונה", "Change photo")) {}
        photoButton.setOnClickListener {
            onPhotoPicked = { path ->
                photo = path
                photoButton.text = L.t("התמונה נבחרה ✓", "Photo selected ✓")
            }
            pickPhoto.launch("image/*")
        }
        box.addView(photoButton)
        val birthBtn = ui.button("") {}
        fun showBirth() {
            birthBtn.text = if (birth.isEmpty()) L.t("בחר תאריך לידה", "Choose birthday") else L.t("נולד/ה: ${birth.split("-").reversed().joinToString(".")}  (${Profile.ageText(birth)})", "Born ${birth.split("-").reversed().joinToString(".")}  (${Profile.ageText(birth)})")
        }
        showBirth()
        birthBtn.setOnClickListener {
            val c = Calendar.getInstance()
            val p = birth.split("-").mapNotNull { it.toIntOrNull() }
            if (p.size == 3) c.set(p[0], p[1] - 1, p[2])
            DatePickerDialog(this, { _, yy, mm, dd ->
                birth = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd)
                showBirth()
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply {
                datePicker.maxDate = System.currentTimeMillis()
            }.show()
        }
        box.addView(birthBtn)
        val b = AlertDialog.Builder(this)
            .setTitle(if (old == null) L.t("בן משפחה או חיית מחמד חדשים", "New family member or pet") else L.t("עריכת ${old.name}", "Edit ${old.name}"))
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton(L.t("שמור", "Save")) { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) return@setPositiveButton
                val updated = FamilyMember(memberId, n, relation, birth, photo)
                val current = Profile.members(this).filterNot { it.id == memberId }
                Profile.saveMembers(this, current + updated)
                if (updated.isPet || old?.isPet == true) Pets.invalidate(this)
                render()
            }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
        if (old != null) b.setNeutralButton(L.t("הסר", "Remove")) { _, _ ->
            Profile.saveMembers(this, Profile.members(this).filterNot { it.id == memberId })
            if (old.isPet) Pets.invalidate(this)
            render()
        }
        b.show()
    }

    // ---------- what saves a moment ----------

    private fun triggersSection() {
        content.addView(ui.section(L.t("מה שומר רגע", "What saves a moment")))
        val card = ui.card()

        card.addView(ui.switch(L.t("צחוק וקריאות שמחה", "Laughter and happy shouts"), Status.laughOn, top = 0) { on ->
            Status.laughOn = on
            Settings.putBool(this, "laugh_on", on)
        })
        val label = ui.hint("")
        val bar = SeekBar(this).apply {
            max = 55
            progress = ((0.6f - Status.threshold) * 100).roundToInt().coerceIn(0, 55)
        }
        fun showLabel() {
            val p = bar.progress
            val word = when {
                p >= 48 -> L.t("גבוהה מאוד", "very high")
                p >= 38 -> L.t("גבוהה", "high")
                p >= 22 -> L.t("בינונית", "medium")
                else -> L.t("נמוכה", "low")
            }
            label.text = L.t("רגישות: $word (שומר כשהצחוק מעל ${(Status.threshold * 100).roundToInt()}%)", "Sensitivity: $word (saves when laughter is above ${(Status.threshold * 100).roundToInt()}%)")
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Status.threshold = 0.6f - p / 100f
                Settings.putFloat(this@SettingsActivity, "threshold2", Status.threshold)
                showLabel()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        showLabel()
        card.addView(label)
        card.addView(bar)
        card.addView(ui.hint(L.t("נשמרים רגעים מיותרים? הזז שמאלה. מפספס צחוקים? הזז ימינה.", "Saving too much? Slide left. Missing laughs? Slide right.")))

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("מילים ומשפטים (״אבא תראה״, ״וואו״...)", "Words and phrases (\"Daddy look\", \"wow\"…)"), Status.wordsOn) { on ->
            Status.wordsOn = on
            Settings.putBool(this, "words_on", on)
            restartNote()
        })
        val phrases = ui.field(L.t("מילים מופרדות בפסיקים", "Words, separated by commas"), Status.phrases.joinToString(", "), multiline = true)
        phrasesField = phrases
        card.addView(phrases)
        card.addView(ui.hint(L.t("מילה שמתחילה ב״שמור״ (כמו ״שמור רגע״) תמיד שומרת, גם מיד אחרי רגע אחר.", "A phrase starting with \"שמור\" (like \"שמור רגע\") always saves, even right after another moment.")))
        val btns = ui.horizontal()
        btns.addView(ui.action(L.t("שמור מילים", "Save words")) {
            val list = Phrases.parse(phrases.text.toString())
            Status.phrases = list
            Settings.putString(this, "phrases", list.joinToString(", "))
            phrases.setText(list.joinToString(", "))
            toast(L.t("נשמרו ${list.size} מילים", "${list.size} words saved"))
        })
        btns.addView(ui.action(L.t("החזר לברירת מחדל", "Reset to default"), R.color.ink_soft) {
            Status.phrases = Phrases.DEFAULT
            Settings.putString(this, "phrases", Phrases.DEFAULT.joinToString(", "))
            phrases.setText(Phrases.DEFAULT.joinToString(", "))
        })
        card.addView(btns)

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("חיוך גדול או מישהו שרץ אליכם", "A big smile or someone running to you"), Status.facesOn) { on ->
            Status.facesOn = on
            Settings.putBool(this, "faces_on", on)
            restartNote()
        })
        card.addView(ui.hint(L.t("לכל היותר רגע אחד כזה בדקה, כדי לא למלא את הגלריה.", "At most one of these a minute, so your gallery doesn't fill up.")))

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("🤗 חיבוק", "🤗 Hugs"), Status.hugOn) { on ->
            Status.hugOn = on
            Settings.putBool(this, "hug_on", on)
            restartNote()
        })
        card.addView(ui.hint(L.t("כשמישהו מתקרב ומחבק אותך (המצלמה על החזה מתכסה לכ-3 שניות), או כששניים מתחבקים מולך יותר מ-3 שניות. זיהוי בקירוב: לפעמים יפספס, ולפעמים ישמור כשמשהו מכסה את המצלמה.", "When someone comes in for a hug (the chest camera is covered for about 3 seconds), or two people hug in front of you for over 3 seconds. It's approximate: it may miss some, or save when something covers the camera.")))

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("❤️ ״אני אוהב אותך״", "❤️ \"I love you\""), Status.loveOn) { on ->
            Status.loveOn = on
            Settings.putBool(this, "love_on", on)
            restartNote()
        })
        card.addView(ui.hint(L.t("״אוהב אותך״, ״אוהבת אותך״, ״אוהבים אותך״ תמיד נשמרים, גם מיד אחרי רגע אחר.", "\"I love you\" (said in Hebrew) is always saved, even right after another moment.")))

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("🎵 שירה", "🎵 Singing"), Status.singOn) { on ->
            Status.singOn = on
            Settings.putBool(this, "sing_on", on)
        })
        card.addView(ui.hint(L.t("מנסה לזהות שירה בזמן הצילום. לפעמים גם מוזיקה ברקע עשויה לשמור רגע.", "Listens for singing while recording. Background music may sometimes save a moment too.")))

        card.addView(ui.divider())
        card.addView(ui.text(L.t("שמירה ידנית", "Save manually"), 15f, top = 4))
        card.addView(ui.hint(L.t("כפתור ♥ במסך היום, כפתור בהתראה, או אריח \"שמור רגע\" בתפריט המהיר של הטלפון (משוך מלמעלה ← עריכה).", "The ♥ button on Today, the notification button, or the \"Save moment\" tile in Quick Settings (swipe down → Edit).")))
        content.addView(card)
    }

    // ---------- camera & clips ----------

    private fun cameraSection() {
        content.addView(ui.section(L.t("מצלמה וקליפים", "Camera and clips")))
        val card = ui.card()
        card.addView(ui.text(L.t("עדשה בהתחלה", "Starting lens"), 14f, R.color.ink_soft, top = 0))
        val zooms = listOf(0.6f, 1f, 2f, 3f, 5f)
        val sel = zooms.indexOfFirst { kotlin.math.abs(it - Status.zoom) < 0.01f }.coerceAtLeast(0)
        card.addView(ui.chips(listOf(L.t("0.6x רחבה", "0.6x wide"), "1x", "2x", "3x", "5x"), sel) { i ->
            Status.zoom = zooms[i]
            Settings.putFloat(this, "zoom", zooms[i])
            if (Status.running) startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_ZOOM))
        })
        card.addView(ui.hint(L.t("0.6x תופס הכי הרבה כשהטלפון על החזה.", "0.6x captures the most with the phone on your chest.")))

        val p = Settings.prefs(this)
        card.addView(ui.text(L.t("כמה לשמור לפני הרגע", "How much to keep before"), 14f, R.color.ink_soft, top = 14))
        val before = Settings.BEFORE_OPTIONS
        card.addView(ui.chips(before.map { L.t("$it שנ׳", "${it}s") }, before.indexOf(p.getInt("before_s", 15)).coerceAtLeast(0)) { i ->
            Settings.putInt(this, "before_s", before[i])
            Settings.load(this)
        })
        card.addView(ui.text(L.t("כמה לשמור אחרי", "How much to keep after"), 14f, R.color.ink_soft, top = 12))
        val after = Settings.AFTER_OPTIONS
        card.addView(ui.chips(after.map { L.t("$it שנ׳", "${it}s") }, after.indexOf(p.getInt("after_s", 15)).coerceAtLeast(0)) { i ->
            Settings.putInt(this, "after_s", after[i])
            Settings.load(this)
        })
        card.addView(ui.hint(L.t("אפשר תמיד לקצר רגע אחר כך עם \"קצר\" במסך הרגע.", "You can always trim a moment later with \"Trim\" on the moment screen.")))

        card.addView(ui.divider())
        card.addView(ui.switch(L.t("תמונות חיות בזיכרונות (3 שניות מהרגע עצמו)", "Live photos in memories (3 seconds from the moment)"), Motion.enabled(this)) { on ->
            Settings.putBool(this, "motion_on", on)
        })
        card.addView(ui.switch(L.t("רטט קצר כשנשמר רגע", "Short vibration when a moment is saved"), Status.buzzOn) { on ->
            Status.buzzOn = on
            Settings.putBool(this, "buzz_on", on)
        })
        content.addView(card)
    }

    // ---------- people ----------

    private fun peopleSection() {
        content.addView(ui.section(L.t("אנשים וזיהוי פנים", "People and face recognition")))
        val card = ui.card()
        card.addView(ui.switch(L.t("זיהוי מי מופיע בכל רגע", "Recognize who's in each moment"), PeopleStore.peopleEnabled(this), top = 0) { on ->
            Settings.putBool(this, "people_on", on)
        })
        card.addView(ui.hint(L.t("דוגמאות זיהוי הפנים נשמרות בטלפון. אם חיברתם הבנת רגעים, תמונות הזיכרון עשויות להישלח לשירות המחובר.", "Face samples stay on this phone. If you've connected moment understanding, memory photos may be sent to that service.")))
        val people = PeopleStore.people(this)
        val unknown = try { PeopleStore.unknownGroups(this).size } catch (_: Exception) { 0 }
        card.addView(ui.row(L.t("האנשים שלך", "Your people"), if (people.isEmpty()) L.t("עוד אין", "None yet") else L.t("${people.size} אנשים", "${people.size} people")) { PeopleActivity.open(this) })
        if (people.isNotEmpty()) card.addView(ui.hint(people.joinToString(" · ") { "${it.name} (${PeopleStore.countFor(this, it.name)})" }, top = 0))
        if (unknown > 0) card.addView(ui.row(L.t("פנים שמחכות לשם", "Faces waiting for a name"), "$unknown") { PeopleActivity.open(this) })
        val pending = MemoryStore.all(this).count { !it.facesScanned }
        if (pending > 0) card.addView(ui.button(L.t("חפש פנים ב-$pending רגעים שלא נבדקו", "Find faces in $pending unchecked moments")) {
            toast(L.t("מחפש פנים ברקע...", "Finding faces in the background…"))
            worker.execute {
                var n = 0
                while (true) {
                    val k = PeopleStore.scanPending(applicationContext, 6)
                    n += k
                    if (k == 0) break
                }
                runOnUiThread { if (!isFinishing) { toast(L.t("נבדקו $n רגעים", "$n moments checked")); render() } }
            }
        })
        card.addView(ui.action(L.t("התחל את זיהוי הפנים מאפס", "Reset face recognition"), R.color.danger) {
            AlertDialog.Builder(this)
                .setTitle(L.t("למחוק את כל זיהוי הפנים?", "Delete all face recognition?"))
                .setMessage(L.t("כל השמות והפנים יימחקו, והרגעים ייסרקו מחדש. הקליפים עצמם לא נמחקים.", "All names and faces will be deleted and your moments scanned again. Your clips won't be deleted."))
                .setPositiveButton(L.t("מחק", "Delete")) { _, _ ->
                    worker.execute {
                        PeopleStore.clearAll(applicationContext)
                        runOnUiThread { if (!isFinishing) render() }
                    }
                }
                .setNegativeButton(L.t("ביטול", "Cancel"), null)
                .show()
        })
        content.addView(card)
    }

    // ---------- AI ----------

    private fun aiSection() {
        content.addView(ui.section("AI"))
        val card = ui.card()
        val claude = ClaudeClient.hasKey(this)
        card.addView(ui.row(L.t("מפתח Claude (תיאורים, סיפור היום, שאלות)", "Claude key (descriptions, daily story, questions)"), if (claude) L.t("מחובר ✓", "Connected ✓") else L.t("לא מוגדר", "Not set"), top = 0) {
            askKey(
                L.t("מפתח Claude", "Claude key"), "sk-ant-...", ClaudeClient.apiKey(this),
                L.t("המפתח נשמר רק בטלפון. בלעדיו הרגעים נשמרים, אבל בלי תיאור, סיפור וחיפוש.", "The key is stored only on this phone. Without it, moments are still saved, but without descriptions, stories or search."),
                "https://console.anthropic.com/settings/keys",
            ) { ClaudeClient.setApiKey(this, it) }
        })
        card.addView(ui.row(L.t("מפתח Gemini (ציורי קומיקס)", "Gemini key (comic drawings)"), if (GeminiClient.hasKey(this)) L.t("מחובר ✓", "Connected ✓") else L.t("לא חובה", "Optional")) {
            askKey(
                L.t("מפתח Gemini", "Gemini key"), "AIza...", GeminiClient.apiKey(this),
                L.t("עם המפתח כל פאנל בקומיקס מצויר מחדש. התמונות מהרגע נשלחות לגוגל לציור.", "With a key, every comic panel is redrawn. Photos from the moment are sent to Google for drawing."),
                "https://aistudio.google.com/apikey",
            ) { GeminiClient.setApiKey(this, it) }
        })
        if (claude) {
            val all = MemoryStore.all(this)
            card.addView(ui.action(L.t("תאר מחדש את כל ${all.size} הרגעים", "Re-describe all ${all.size} moments")) {
                AlertDialog.Builder(this)
                    .setTitle(L.t("לתאר מחדש את כל הרגעים?", "Re-describe all moments?"))
                    .setMessage(L.t("שימושי אחרי שעדכנתם פרופיל, שמות או מה שרגעים למד. הפעולה משתמשת בשירות המחובר שלכם ועשויה להיות בתשלום. תיקוני כותרת ותיאור שביצעתם ידנית יוחלפו.", "Useful after updating your profile, names or what Moments learned. This uses your connected service and may cost money. Titles and descriptions you edited by hand will be replaced."))
                    .setPositiveButton(L.t("כן", "Yes")) { _, _ ->
                        for (m in all) MemoryStore.update(this, m.copy(analyzed = false))
                        toast(L.t("מתאר מחדש ברקע...", "Re-describing in the background…"))
                        worker.execute {
                            val n = MemoryStore.analyzePending(applicationContext)
                            runOnUiThread { if (!isFinishing) toast(L.t("תוארו $n רגעים", "$n moments described")) }
                        }
                    }
                    .setNegativeButton(L.t("ביטול", "Cancel"), null)
                    .show()
            })
        }
        content.addView(card)
    }

    private fun askKey(title: String, hint: String, value: String, message: String, url: String, save: (String) -> Unit) {
        val field = ui.field(hint, value, password = true)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(box)
            .setPositiveButton(L.t("שמור", "Save")) { _, _ -> save(field.text.toString().trim()); render() }
            .setNeutralButton(L.t("איפה משיגים?", "Where do I get one?")) { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
            }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .show()
    }

    // ---------- learning ----------

    private fun learningSection() {
        content.addView(ui.section(L.t("מה רגעים למד", "What Moments learned")))
        val card = ui.card()
        val items = Learning.items(this)
        val liked = Learning.liked(this).size
        val deleted = Learning.rejected(this).size
        card.addView(ui.row(L.t("תובנות על מה שחשוב לך", "Insights on what matters to you"), if (items.isEmpty()) L.t("עוד אין", "None yet") else "${items.size}", top = 0) { LearnedActivity.open(this) })
        card.addView(ui.hint(L.t("נלמד מ-$liked רגעים ששמרת/אהבת ו-$deleted שמחקת. אפשר לראות על מה כל תובנה מבוססת ולתקן.", "Learned from $liked moments you saved or loved and $deleted you deleted. See what each insight is based on, and fix it."), top = 0))
        card.addView(ui.action(L.t("שכח את כל מה שנלמד", "Forget everything learned"), R.color.danger) {
            AlertDialog.Builder(this)
                .setTitle(L.t("לשכוח את כל מה שרגעים למד?", "Forget everything Moments learned?"))
                .setMessage(L.t("התובנות, הכללים שכתבת והדוגמאות של רגעים שמחקת יימחקו. הרגעים עצמם נשארים.", "Insights, rules you wrote and examples of deleted moments will be erased. Your moments stay."))
                .setPositiveButton(L.t("שכח", "Forget")) { _, _ ->
                    worker.execute {
                        Learning.resetAll(applicationContext)
                        runOnUiThread { if (!isFinishing) render() }
                    }
                }
                .setNegativeButton(L.t("ביטול", "Cancel"), null)
                .show()
        })
        content.addView(card)
    }

    // ---------- privacy ----------

    private fun privacySection() {
        content.addView(ui.section(L.t("פרטיות", "Privacy")))
        val card = ui.card()
        val clips = MemoryStore.all(this)
        card.addView(ui.text(L.t("הזיכרונות נשמרים בטלפון. שיתוף עם המשפחה מעלה רק את התוכן שבחרתם למעגל שאליו הצטרפתם.", "Memories are saved on your phone. Sharing with family uploads only what you choose, to the circle you joined."), 14f, top = 0))
        card.addView(ui.text(L.t("כאשר מחברים שירות להבנת רגעים, תמונות מתוך הזיכרון ופרטי ההקשר נשלחים אליו. התמונות עשויות לכלול פנים; זיהוי הפנים המקומי והדוגמאות שלו נשארים בטלפון.", "When you connect a moment-understanding service, photos from the memory and context details are sent to it. Photos may include faces; on-device face recognition and its samples stay on your phone."), 14f, top = 8))
        card.addView(ui.text(L.t("ציור קומיקס שולח תמונות לשירות הציור. זיהוי מילים נעשה באמצעות שירות הדיבור שבטלפון, בהתאם להגדרות השירות.", "Comic drawing sends photos to the drawing service. Word detection uses your phone's speech service, according to its settings."), 14f, top = 8))
        card.addView(ui.hint(L.t("${clips.size} זיכרונות שמורים בטלפון · השיתוף בשליטתכם", "${clips.size} memories saved on this phone · You control sharing"), top = 10))
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        card.addView(ui.hint(L.t("רגעים $version", "Moments $version"), top = 2))
        content.addView(card)
    }
}

/** Removes every face, name and print, so moments are scanned again from scratch. */
fun PeopleStore.clearAll(ctx: Context) {
    synchronized(this) {
        File(ctx.filesDir, "people.json").delete()
        File(ctx.filesDir, "faces.json").delete()
        File(ctx.filesDir, "faces").listFiles()?.forEach { it.delete() }
    }
    for (m in MemoryStore.all(ctx)) {
        if (m.people.isNotEmpty() || m.facesScanned) MemoryStore.update(ctx, m.copy(people = "", facesScanned = false))
    }
}

/** The "פרופיל" tab: the same settings, as a tab with the family header. */
class ProfileActivity : SettingsActivity()
