package com.regaim.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.graphics.ImageFormat
import android.media.ImageReader
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.util.Size
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Runs in the background (screen can be off):
 *  - camera -> H.264 encoder -> rolling 40s buffer in memory
 *  - microphone -> AAC encoder -> rolling 40s buffer, and -> YAMNet laughter detection
 *  - when a moment is detected, waits 15s and saves 15s before + 15s after to the gallery
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.regaim.app.START"
        const val ACTION_STOP = "com.regaim.app.STOP"
        const val ACTION_SAVE_NOW = "com.regaim.app.SAVE_NOW"
        const val ACTION_ZOOM = "com.regaim.app.ZOOM"

        private const val TAG = "Regaim"
        private const val CHANNEL = "regaim_capture"
        private const val MOMENTS_CHANNEL = "regaim_moments"
        private const val NOTIF_ID = 7
        private const val MODEL_RATE = 16000
        private const val KEEP_US = 50_000_000L
        private const val COOLDOWN_US = 5_000_000L
    }

    private val videoRing = SampleRing(KEEP_US)
    private val audioRing = SampleRing(KEEP_US)
    @Volatile private var videoFormat: MediaFormat? = null
    @Volatile private var audioFormat: MediaFormat? = null

    private var camThread: HandlerThread? = null
    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var videoEncoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var previewReader: ImageReader? = null
    @Volatile private var lastPreviewMs = 0L
    private var videoDrainThread: Thread? = null
    private var audioThread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var rotation = 90
    private var zoomRatio = 1f
    private var zoomRange: Pair<Float, Float>? = null
    @Volatile private var repeatingBuilder: CaptureRequest.Builder? = null

    /** Changes zoom live, without stopping the recording. */
    private fun applyZoom() {
        val range = zoomRange ?: return
        val b = repeatingBuilder ?: return
        camHandler?.post {
            try {
                zoomRatio = Status.zoom.coerceIn(range.first, range.second)
                if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoomRatio)
                session?.setRepeatingRequest(b.build(), null, camHandler)
                Status.zoomApplied = zoomRatio
            } catch (e: Exception) {
                Log.w(TAG, "zoom", e)
            }
        }
    }

    @Volatile private var running = false
    @Volatile private var pendingTriggerUs = -1L
    @Volatile private var pendingLabel = ""
    @Volatile private var lastTriggerUs = 0L
    @Volatile private var lastVisualUs = 0L

    @Volatile private var lastLocation: Location? = null
    @Volatile private var pendingLocation: Location? = null
    private var listeningLocation = false
    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLocation = location
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var spotter: KeywordSpotter? = null
    @Volatile private var faceWatcher: FaceWatcher? = null
    @Volatile private var lastFaceMs = 0L
    private val saveExecutor = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (!running) startCapture()
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
            ACTION_SAVE_NOW -> if (running) trigger("manual")
            ACTION_ZOOM -> if (running) applyZoom()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopCapture()
        saveExecutor.shutdown()
        super.onDestroy()
    }

    // ---------- start / stop ----------

    private fun startCapture() {
        Settings.load(this)
        createChannel()
        try {
            var type = 0
            if (Build.VERSION.SDK_INT >= 30) {
                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (hasLocationPermission()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification("מאזין לרגעים..."), type)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground", e)
            Status.error = "לא ניתן להפעיל הקלטה ברקע: ${e.message}"
            stopSelf()
            return
        }

        Status.reset()
        running = true
        Status.running = true
        Status.startedAt = System.currentTimeMillis()

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "regaim:capture").apply {
            acquire(6 * 60 * 60 * 1000L)
        }

        try {
            startVideo()
        } catch (e: Exception) {
            Log.e(TAG, "video", e)
            Status.error = "שגיאת מצלמה: ${e.message}"
            stopCapture()
            stopSelf()
            return
        }
        audioThread = Thread({ audioLoop() }, "regaim-audio").also { it.start() }
        startLocation()
        if (Status.facesOn) {
            faceWatcher = try {
                FaceWatcher { label -> main.post { trigger(label) } }
            } catch (e: Exception) {
                Log.w(TAG, "faces", e)
                null
            }
        }
        if (Status.wordsOn) {
            spotter = KeywordSpotter(this, { Status.phrases }) { phrase ->
                trigger("״$phrase״", force = Phrases.isCommand(phrase))
            }.also { it.start() }
        }
    }

    // ---------- location (optional: "where was I?") ----------

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (!hasLocationPermission()) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val candidates = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 31) candidates.add(LocationManager.FUSED_PROVIDER)
            candidates.add(LocationManager.NETWORK_PROVIDER)
            candidates.add(LocationManager.GPS_PROVIDER)
            lastLocation = candidates.mapNotNull { p ->
                try { lm.getLastKnownLocation(p) } catch (_: Exception) { null }
            }.maxByOrNull { it.time }
            val provider = candidates.firstOrNull { p -> try { lm.isProviderEnabled(p) } catch (_: Exception) { false } } ?: return
            lm.requestLocationUpdates(provider, 60_000L, 30f, locationListener, Looper.getMainLooper())
            listeningLocation = true
        } catch (e: Exception) {
            Log.w(TAG, "location", e)
        }
    }

    private fun stopLocation() {
        if (!listeningLocation) return
        try {
            (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locationListener)
        } catch (_: Exception) {
        }
        listeningLocation = false
    }

    private fun placeName(loc: Location?): String {
        if (loc == null || !Geocoder.isPresent()) return ""
        return try {
            @Suppress("DEPRECATION")
            val a = Geocoder(this, Locale("he")).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                ?: return ""
            listOfNotNull(a.thoroughfare, a.locality).joinToString(", ").ifEmpty { a.featureName ?: "" }
        } catch (_: Exception) {
            ""
        }
    }

    private fun stopCapture() {
        if (!running) return
        main.removeCallbacksAndMessages(null)
        val pending = pendingTriggerUs
        if (pending >= 0) saveClip(pending, pendingLabel) // keep a moment that was mid-way

        running = false
        spotter?.stop()
        spotter = null
        faceWatcher?.close()
        faceWatcher = null
        try { session?.close() } catch (_: Exception) {}
        session = null
        try { camera?.close() } catch (_: Exception) {}
        camera = null

        try { videoDrainThread?.join(1500) } catch (_: Exception) {}
        try { audioThread?.join(3000) } catch (_: Exception) {}
        videoDrainThread = null
        audioThread = null

        try { videoEncoder?.stop() } catch (_: Exception) {}
        try { videoEncoder?.release() } catch (_: Exception) {}
        videoEncoder = null
        try { inputSurface?.release() } catch (_: Exception) {}
        inputSurface = null
        try { previewReader?.close() } catch (_: Exception) {}
        previewReader = null
        Status.preview = null
        camHandler?.removeCallbacksAndMessages(null)
        camHandler = null
        camThread?.quitSafely()
        camThread = null

        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopLocation()

        videoRing.clear()
        audioRing.clear()
        videoFormat = null
        audioFormat = null
        Status.running = false
        Status.pending = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    // ---------- video ----------

    @SuppressLint("MissingPermission")
    private fun startVideo() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val backIds = cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        var camId = backIds.firstOrNull() ?: cm.cameraIdList.first()
        zoomRatio = 1f
        val range = if (Build.VERSION.SDK_INT >= 30) {
            cm.getCameraCharacteristics(camId).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
        } else null
        zoomRange = range?.let { it.lower to it.upper }
        if (range != null) {
            // The main camera switches lenses by itself: 0.6x = ultra-wide, 3x / 5x = telephoto.
            zoomRatio = Status.zoom.coerceIn(range.lower, range.upper)
        } else if (Status.zoom < 0.99f) {
            run {
                // Fallback: pick the back camera with the shortest focal length (= widest).
                val widest = backIds.minByOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.minOrNull() ?: Float.MAX_VALUE
                }
                if (widest != null && widest != camId) camId = widest
            }
        }
        Status.zoomApplied = zoomRatio
        val chars = cm.getCameraCharacteristics(camId)
        rotation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?: throw IllegalStateException("no stream map")
        val sizes = map.getOutputSizes(MediaCodec::class.java) ?: emptyArray()
        val size = sizes.firstOrNull { it.width == 1920 && it.height == 1080 }
            ?: sizes.firstOrNull { it.width == 1280 && it.height == 720 }
            ?: sizes.filter { it.width <= 1920 && it.width * 9 == it.height * 16 }.maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)
        val bitrate = if (size.width >= 1920) 6_000_000 else 3_000_000
        Status.videoSize = "${size.height}p"
        Status.videoFrames = 0L

        // Small extra stream for the live "bubble" viewfinder on screen.
        val yuvSizes = map.getOutputSizes(ImageFormat.YUV_420_888) ?: emptyArray()
        val pSize = yuvSizes.filter { it.width in 320..960 && it.width * 9 == it.height * 16 }.minByOrNull { it.width }
            ?: yuvSizes.filter { it.width in 320..960 }.minByOrNull { it.width }
        previewReader = pSize?.let { ImageReader.newInstance(it.width, it.height, ImageFormat.YUV_420_888, 2) }

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, size.width, size.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        videoEncoder = enc
        inputSurface = surface
        videoDrainThread = Thread({ drainVideo(enc) }, "regaim-video").also { it.start() }

        val thread = HandlerThread("regaim-camera").also { it.start() }
        camThread = thread
        val handler = Handler(thread.looper)
        previewReader?.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                val wantFace = faceWatcher != null && now - lastFaceMs > 800
                if ((Status.uiVisible && now - lastPreviewMs > 350) || wantFace) {
                    lastPreviewMs = now
                    val bmp = Preview.toBitmap(img, rotation)
                    if (Status.uiVisible) Status.preview = bmp
                    if (wantFace && bmp != null) {
                        lastFaceMs = now
                        faceWatcher?.feed(bmp)
                    }
                }
            } catch (_: Exception) {
            } finally {
                img.close()
            }
        }, handler)
        cameraId = camId
        camHandler = handler
        reopenAttempts = 0
        openCam()
    }

    private var cameraId = ""
    private var camHandler: Handler? = null
    private var reopenAttempts = 0

    /** Opens the camera; if it gets taken away (another app, system), keeps trying to come back. */
    @SuppressLint("MissingPermission")
    private fun openCam() {
        val handler = camHandler ?: return
        val surface = inputSurface ?: return
        if (!running) return
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            cm.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    if (!running) {
                        device.close()
                        return
                    }
                    camera = device
                    createSession(device, surface, handler, previewReader != null)
                }

                override fun onDisconnected(device: CameraDevice) {
                    device.close()
                    camera = null
                    session = null
                    scheduleReopen("המצלמה נלקחה לרגע על ידי אפליקציה אחרת, מתחבר מחדש...")
                }

                override fun onError(device: CameraDevice, error: Int) {
                    device.close()
                    camera = null
                    session = null
                    scheduleReopen("תקלת מצלמה (קוד $error), מתחבר מחדש...")
                }
            }, handler)
        } catch (e: Exception) {
            Log.w(TAG, "openCam", e)
            scheduleReopen("המצלמה לא זמינה כרגע, מנסה שוב...")
        }
    }

    private fun scheduleReopen(msg: String) {
        if (!running) return
        reopenAttempts++
        if (reopenAttempts > 30) {
            Status.error = "המצלמה לא חוזרת. עצור והתחל שוב."
            return
        }
        Status.error = msg
        camHandler?.postDelayed({ if (running && camera == null) openCam() }, 2000)
    }

    @Suppress("DEPRECATION")
    private fun createSession(device: CameraDevice, surface: Surface, handler: Handler, withPreview: Boolean) {
        val previewSurface = if (withPreview) previewReader?.surface else null
        try {
            device.createCaptureSession(listOfNotNull(surface, previewSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (!running) {
                        s.close()
                        return
                    }
                    session = s
                    reopenAttempts = 0
                    if (Status.error?.contains("מצלמה") == true) Status.error = null
                    try {
                        val req = device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                            addTarget(surface)
                            if (previewSurface != null) addTarget(previewSurface)
                            set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                            if (Build.VERSION.SDK_INT >= 30 && zoomRange != null) {
                                set(CaptureRequest.CONTROL_ZOOM_RATIO, zoomRatio)
                            }
                        }
                        repeatingBuilder = req
                        s.setRepeatingRequest(req.build(), null, handler)
                    } catch (e: Exception) {
                        Log.e(TAG, "repeating", e)
                        Status.error = "המצלמה לא התחילה לצלם: ${e.message}"
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    // Some cameras refuse two streams: keep recording, just without the live viewfinder.
                    if (previewSurface != null && running) createSession(device, surface, handler, false)
                    else Status.error = "הגדרת המצלמה נכשלה"
                }
            }, handler)
        } catch (e: Exception) {
            Log.e(TAG, "session", e)
            Status.error = "הגדרת המצלמה נכשלה: ${e.message}"
        }
    }

    private fun drainVideo(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val idx = try {
                enc.dequeueOutputBuffer(info, 10_000)
            } catch (e: IllegalStateException) {
                break
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                videoFormat = enc.outputFormat
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                    val data = ByteArray(info.size)
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    buf.get(data)
                    videoRing.add(EncodedSample(data, nowUs(), info.flags))
                    Status.videoFrames = Status.videoFrames + 1
                    Status.lastFrameMs = System.currentTimeMillis()
                }
                enc.releaseOutputBuffer(idx, false)
            }
        }
    }

    // ---------- audio + detection ----------

    /** Opens the microphone: 48 kHz (good clip audio) with the clean voice-recognition source, with fallbacks. */
    @SuppressLint("MissingPermission")
    private fun openMic(): AudioRecord? {
        val sources = listOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        for (rate in listOf(48_000, 16_000)) {
            for (src in sources) {
                try {
                    val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    if (minBuf <= 0) continue
                    val rec = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, rate * 2 * 2))
                    if (rec.state == AudioRecord.STATE_INITIALIZED) return rec
                    rec.release()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun audioLoop() {
        val detector = try {
            LaughDetector(this)
        } catch (e: Exception) {
            Log.e(TAG, "detector", e)
            Status.error = "מודל זיהוי הצחוק לא נטען: ${e.message}"
            null
        }

        val rec = openMic()
        if (rec == null) {
            Status.error = "המיקרופון לא זמין"
            detector?.close()
            return
        }
        val rate = rec.sampleRate
        val down = Downsampler(rate / MODEL_RATE)

        val aac = createAacEncoder(rate)
        val window = FloatArray(detector?.requiredSamples ?: 15600)
        val chunk = ShortArray(rate / 10) // 0.1 second
        val info = MediaCodec.BufferInfo()
        var totalSamples = 0L
        var chunksSinceClassify = 0

        try {
            rec.startRecording()
            val anchorUs = nowUs()
            while (running) {
                val n = rec.read(chunk, 0, chunk.size)
                if (n <= 0) continue
                val ptsUs = anchorUs + totalSamples * 1_000_000L / rate
                totalSamples += n

                if (aac != null) {
                    feedAac(aac, chunk, n, ptsUs)
                    drainAac(aac, info)
                }

                // Model input: 16 kHz, low-passed and decimated from the mic stream.
                val small = down.process(chunk, n)
                spotter?.feed(small)
                val m = small.size
                val w = window.size
                if (m >= w) {
                    System.arraycopy(small, m - w, window, 0, w)
                } else if (m > 0) {
                    System.arraycopy(window, m, window, 0, w - m)
                    System.arraycopy(small, 0, window, w - m, m)
                }

                // Classify twice a second.
                if (detector != null && ++chunksSinceClassify >= 5) {
                    chunksSinceClassify = 0
                    val r = detector.classify(window)
                    Status.lastScore = r.score
                    if (r.score > Status.peakScore) Status.peakScore = r.score
                    Status.top3 = r.top3
                    Status.lastLabel = r.label
                    Status.topLabel = r.top
                    if (Status.laughOn && r.label.isNotEmpty() && r.score >= Status.threshold) trigger(r.label)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "audio loop", e)
            Status.error = "שגיאת אודיו: ${e.message}"
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            try { aac?.stop() } catch (_: Exception) {}
            try { aac?.release() } catch (_: Exception) {}
            detector?.close()
        }
    }

    private fun createAacEncoder(rate: Int): MediaCodec? = try {
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, if (rate >= 44_100) 128_000 else 64_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32_768)
        }
        MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
            configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            start()
        }
    } catch (e: Exception) {
        Log.e(TAG, "aac", e)
        null
    }

    private fun feedAac(enc: MediaCodec, chunk: ShortArray, n: Int, ptsUs: Long) {
        val idx = enc.dequeueInputBuffer(5_000)
        if (idx < 0) return
        val buf = enc.getInputBuffer(idx) ?: return
        buf.clear()
        val samples = min(n, buf.remaining() / 2)
        buf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(chunk, 0, samples)
        enc.queueInputBuffer(idx, 0, samples * 2, ptsUs, 0)
    }

    private fun drainAac(enc: MediaCodec, info: MediaCodec.BufferInfo) {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, 0)
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                audioFormat = enc.outputFormat
                continue
            }
            if (idx < 0) break
            val buf = enc.getOutputBuffer(idx)
            if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                val data = ByteArray(info.size)
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                buf.get(data)
                audioRing.add(EncodedSample(data, info.presentationTimeUs, info.flags))
            }
            enc.releaseOutputBuffer(idx, false)
        }
    }

    // ---------- moments ----------

    @Synchronized
    private fun trigger(label: String, force: Boolean = label == "manual") {
        if (!running || pendingTriggerUs >= 0) return
        val now = nowUs()
        if (!force && now - lastTriggerUs < COOLDOWN_US) return
        // Smiles and faces can last long: at most one visual moment a minute.
        if (label in Labels.VISUAL) {
            if (now - lastVisualUs < 60_000_000L) return
            lastVisualUs = now
        }
        pendingTriggerUs = now
        pendingLabel = label
        pendingLocation = lastLocation
        lastTriggerUs = now
        Status.pending = true
        buzz()
        main.postDelayed({ saveClip(now, label) }, ClipSaver.POST_US / 1000)
    }

    /** A short double buzz so you know a moment was caught, even with the phone in your pocket. */
    private fun buzz() {
        if (!Status.buzzOn) return
        try {
            val v = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            }
            v.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 60, 80, 60), -1))
        } catch (_: Exception) {
        }
    }

    private fun saveClip(triggerUs: Long, label: String) {
        val vf = videoFormat
        val video = videoRing.snapshot()
        val audio = audioRing.snapshot()
        val af = audioFormat
        val rot = rotation
        val loc = pendingLocation
        pendingTriggerUs = -1L
        Status.pending = false
        if (vf == null) return

        saveExecutor.execute {
            try {
                val saved = ClipSaver.save(applicationContext, video, audio, vf, af, rot, triggerUs, label)
                if (saved != null) {
                    val id = UUID.randomUUID().toString()
                    val bubble = saved.frame?.let {
                        try { MemoryStore.saveBubble(applicationContext, id, it) } catch (_: Exception) { "" }
                    } ?: ""
                    val memory = Memory(
                        id = id,
                        uri = saved.uri,
                        name = saved.name,
                        time = System.currentTimeMillis(),
                        label = label,
                        lat = loc?.latitude,
                        lon = loc?.longitude,
                        place = placeName(loc),
                        thumb = bubble,
                        durationMs = saved.durationMs,
                        chosen = Labels.isChosen(label),
                    )
                    MemoryStore.add(applicationContext, memory)
                    Status.clips = Status.clips + 1
                    Status.lastClipLabel = label
                    Status.lastClipAt = memory.time
                    if (running) updateNotification()
                    notifyMoment(memory)
                    // Let the AI describe it right away (only if an API key was set).
                    MemoryStore.analyzePending(applicationContext)
                }
            } catch (e: Exception) {
                Log.e(TAG, "save", e)
                Status.error = "שמירת קליפ נכשלה: ${e.message}"
            }
        }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "הקלטת רגעים", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(MOMENTS_CHANNEL, "רגעים חדשים", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), flags
        )
        val save = PendingIntent.getService(
            this, 3, Intent(this, CaptureService::class.java).setAction(ACTION_SAVE_NOW), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Moments פועל")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "♥ שמור רגע", save)
            .addAction(0, "עצור", stop)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    /** A small bubble notification for each new memory. */
    private fun notifyMoment(m: Memory) {
        try {
            val open = PendingIntent.getActivity(
                this, 2, Intent(this, MemoriesActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val text = Labels.he(m.label) + if (m.place.isNotEmpty()) " · ${m.place}" else ""
            val b = NotificationCompat.Builder(this, MOMENTS_CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("רגע חדש נשמר")
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true)
                .setSilent(true)
            if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb)?.let { b.setLargeIcon(it) }
            getSystemService(NotificationManager::class.java).notify(m.id.hashCode(), b.build())
        } catch (e: Exception) {
            Log.w(TAG, "notify", e)
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification("נשמרו ${Status.clips} רגעים"))
    }
}
