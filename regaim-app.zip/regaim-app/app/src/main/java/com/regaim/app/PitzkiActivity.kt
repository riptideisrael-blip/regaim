package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * "The magic forest with Pitzki": a colors lesson for ages 3–5 where the child walks with Pitzki.
 * The child comes from what the family already has: the character approved in a book, or their photos (drawn as a
 * character first, which the parent approves). Then the forest scenes are drawn with the child in them and brought to
 * life (kept on the phone, made again only when the child's look changes).
 */
class PitzkiActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, PitzkiActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var voice: PitzkiVoice
    private lateinit var ears: PitzkiEars
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var destroyed = false

    private var children: List<PitzkiStore.Child> = emptyList()
    private var chosen: PitzkiStore.Child? = null
    private val kid: PitzkiKid get() = chosen?.kid ?: PitzkiKid("", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        ui = Ui(this)
        voice = PitzkiVoice(this)
        ears = PitzkiEars(this)
        PitzkiStore.upgrade(this)
        children = PitzkiStore.children(this)
        chosen = children.firstOrNull()
        // An animation cut off when the app was closed: picked up again (what was already sent isn't paid again).
        children.firstOrNull { PitzkiStore.interrupted(this, it) }?.let { PitzkiStore.resume(this, it); chosen = it }
        setup()
    }

    private var resumedOnce = false

    override fun onResume() {
        super.onResume()
        PitzkiService.screenOpen = true
        PitzkiService.clearNotice(this)
        // Back from outside the app while a film was being made: the screen catches up.
        if (resumedOnce && !inLesson) { renderSetup(); watchDrawing() }
        resumedOnce = true
    }

    override fun onPause() {
        super.onPause()
        PitzkiService.screenOpen = false
        stopWaitSong()
        if (inLesson && !paused) pause()
    }

    override fun onDestroy() {
        destroyed = true
        stopWaitSong()
        token++
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        ears.stop()
        stopSong()
        stopClip()
        clipIo.shutdown()
        bg.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inLesson) { stopLesson(); setup() } else super.onBackPressed()
    }

    // =====================================================================
    // The start screen (for the parent)
    // =====================================================================

    private var setupBox: LinearLayout? = null

    private fun setup() {
        inLesson = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val scroll = ScrollView(this).apply { setBackgroundColor(DS.bg(this@PitzkiActivity)); isFillViewport = true }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(12), ui.dp(20), ui.dp(32))
        }
        scroll.addView(box)
        setupBox = box
        setContentView(scroll)
        renderSetup()
        watchDrawing()
        // Pitzki's shared close-ups: fetched quietly in the background (the lesson works without them).
        bg.execute {
            val before = PitzkiStore.sharedReady(applicationContext)
            try { PitzkiStore.fetchShared(applicationContext) } catch (_: Throwable) {}
            if (PitzkiStore.sharedReady(applicationContext) != before) main.post { if (!destroyed && !inLesson && setupBox === box) renderSetup() }
        }
    }

    private fun renderSetup() {
        val box = setupBox ?: return
        box.removeAllViews()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(DS.ink(this@PitzkiActivity))
            setPadding(ui.dp(4), ui.dp(8), ui.dp(16), ui.dp(8))
            contentDescription = L.t("סגירה", "Close")
            setOnClickListener { finish() }
        })
        top.addView(ui.text(L.t("היער של פיצקי", "Pitzki's forest"), 18f).apply { typeface = DS.emphasis })
        box.addView(top)

        // Pitzki himself.
        val hero = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(230)).apply { topMargin = ui.dp(8) }
            background = DS.rounded(DS.card(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
            clipToOutline = true
        }
        hero.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            PitzkiStore.art(this@PitzkiActivity, "face")?.let { setImageBitmap(it) }
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        })
        box.addView(hero)
        box.addView(ui.heading(L.t("שלום, אני פיצקי", "Hi, I'm Pitzki"), 28f, top = 14))
        box.addView(ui.text(L.t("טיול קצר ביער: חמישה צבעים בעברית ובאנגלית, והילד/ה שלכם בתוך הסיפור. לגילאי 3–5, בלי פרסומות ובלי צ׳אט.",
            "A short forest walk: five colors in Hebrew and English, with your child in the story. Ages 3–5, no ads, no chat."), 15f, R.color.ink_soft, top = 6))

        // Who goes on the walk.
        if (children.isNotEmpty()) {
            box.addView(ui.section(L.t("מי יוצא לטיול?", "Who's coming?")))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(10), 0, 0) }
            for (c in children) row.addView(childChip(c))
            box.addView(ui.scrollRow(row, top = 0))
        } else {
            box.addView(ui.hint(L.t("טיפ: הוסיפו את הילדים בפרופיל המשפחה, ופיצקי יפנה אליהם בשם ויצייר אותם ביער.",
                "Tip: add your kids in the family profile, and Pitzki will call them by name and draw them in the forest."), top = 14))
        }

        chosen?.let { box.addView(childCard(it)) }
        // Admin: what this child's film cost so far at fal (an estimate from the server's price list).
        chosen?.takeIf { Account.isAdmin(this) }?.let { c ->
            val ref = PitzkiStore.lastRef(this, c.memberId)
            if (ref.isNotEmpty()) {
                val line = ui.hint("", top = 6)
                box.addView(line)
                bg.execute {
                    val r = try { Account.token(applicationContext)?.let { t -> CartoonFilm.callEdge(Circle.url(applicationContext) + "/functions/v1/cartoon-film", t, mapOf("action" to "cost_ref", "ref" to ref)) } } catch (_: Exception) { null }
                    main.post {
                        if (destroyed || r == null || r.optInt("_code", 200) !in 200..299) return@post
                        line.text = L.t("מנהל · עלות משוערת של הסרט ב-fal: $%.2f (%d בקשות)", "Admin · estimated fal cost of this film: $%.2f (%d requests)")
                            .format(java.util.Locale.US, r.optDouble("usd", 0.0), r.optInt("n"))
                    }
                }
            }
        }
        // How Pitzki says the child's name (אוֹרִי or אוּרִי: the same letters): the parent can set it.
        chosen?.let { c ->
            PitzkiVoice.sayName = c.kid.name to PitzkiStore.sayName(this, c.memberId)
            if (c.kid.named) box.addView(ui.action(L.t("🔊 איך פיצקי אומר את השם \"${c.kid.name}\"?", "🔊 How does Pitzki say \"${c.kid.name}\"?")) { nameDialog(c) })
        }
        // Pitzki's voice for this child, made ahead in the background (quietly: the phone's voice until it's ready).
        PitzkiStore.prepareVoice(this, kid)
        if (Account.isAdmin(this)) PitzkiStore.voicePrep?.let { v ->
            box.addView(ui.hint(L.t("מנהל · הקול של פיצקי: ${v.ready} מתוך ${v.total} משפטים מוכנים", "Admin · Pitzki's voice: ${v.ready} of ${v.total} lines ready") +
                (if (v.problem.isNotEmpty()) " · " + v.problem else ""), top = 10))
        }
        if (Account.isAdmin(this)) box.addView(sharedCard())

        // The parent decides whether Pitzki listens to the child's answers.
        box.addView(ui.switch(L.t("פיצקי מקשיב לתשובות של הילד (מיקרופון)", "Pitzki listens to the child's answers (microphone)"), PitzkiStore.listenOn(this), top = 18) { on ->
            PitzkiStore.setListen(this, on)
        })
        box.addView(ui.hint(L.t("הילד עונה בקול, ופיצקי אומר \"נכון מאוד!\" או את התשובה הנכונה. אפשר לכבות בכל רגע, גם מתוך הטיול. הזיהוי נעשה בשירות הדיבור של הטלפון (לפעמים של Google), ולא נשמר אצלנו.",
            "The child answers out loud, and Pitzki says \"Right!\" or the right answer. You can turn it off any time, even during the walk. Recognition uses the phone's speech service (sometimes Google's) and nothing is kept by us."), top = 2))

        // Go.
        box.addView(ui.button(L.t("יוצאים לטיול ›", "Let's go ›"), primary = true, top = 22) { startLesson() })
        val stars = chosen?.let { PitzkiStore.stars(this, it.memberId) } ?: 0
        val done = chosen?.let { PitzkiStore.lessonsDone(this, it.memberId) } ?: 0
        if (done > 0) box.addView(ui.hint(L.t("⭐ $stars כוכבים · $done טיולים", "⭐ $stars stars · $done walks"), top = 8).apply { gravity = Gravity.CENTER })
        // Said once the phone's voices are known: no Hebrew voice means subtitles only.
        main.postDelayed({
            if (!destroyed && !inLesson && !voice.heOk && setupBox === box) box.addView(ui.hint(
                L.t("בטלפון הזה אין קול בעברית, אז פיצקי ידבר בכתוביות. אפשר להוסיף קול עברי בהגדרות הטלפון ‹ נגישות ‹ פלט טקסט לדיבור.",
                    "This phone has no Hebrew voice, so Pitzki will speak in subtitles. You can add a Hebrew voice in the phone's text-to-speech settings."), top = 12))
        }, 1500)
    }

    private fun childChip(c: PitzkiStore.Child): View {
        val on = chosen?.memberId == c.memberId
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ui.dp(6), 0, ui.dp(6), 0)
            alpha = if (on) 1f else 0.6f
            setOnClickListener { chosen = c; renderSetup() }
        }
        col.addView(lookCircle(c, 64, ring = on))
        col.addView(ui.text(c.kid.name, 14f, R.color.ink, top = 4).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (on) typeface = DS.emphasis
        })
        return col
    }

    /** The child's look in a circle (book character, or photo), or their initial. */
    private fun lookCircle(c: PitzkiStore.Child, sizeDp: Int, ring: Boolean): View {
        val size = ui.dp(sizeDp)
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            background = DS.oval(if (ring) DS.button(this@PitzkiActivity) else DS.line(this@PitzkiActivity))
        }
        val inset = ui.dp(if (ring) 3 else 1)
        val bmp = c.look?.let { Avatars.photo(it.file.absolutePath, size * 2) }
        if (bmp != null) frame.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = RoundVideo.OVAL
            clipToOutline = true
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(inset, inset, inset, inset) }
        }) else {
            val (bgc, fg) = DS.avatar(this, c.kid.name)
            frame.addView(TextView(this).apply {
                text = Avatars.initial(c.kid.name)
                gravity = Gravity.CENTER
                textSize = sizeDp / 2.6f
                typeface = DS.heading
                setTextColor(fg)
                background = DS.oval(bgc)
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(inset, inset, inset, inset) }
            })
        }
        return frame
    }

    /** What Pitzki knows about the child: their look, and whether the forest scenes are drawn with them. */
    private fun childCard(c: PitzkiStore.Child): View {
        val card = ui.card(top = 14)
        val name = c.kid.name
        fun g(boy: String, girl: String) = if (c.kid.girl) girl else boy
        val look = c.look
        card.addView(ui.text(when {
            look == null -> L.t("אין עדיין תמונה של $name", "No picture of $name yet")
            look.drawn -> L.t("$name ${g("מגיע", "מגיעה")} עם הדמות המצוירת מהספר", "$name comes with the character from the book")
            else -> L.t("$name ${g("מגיע", "מגיעה")} עם התמונה מהפרופיל", "$name comes with the profile picture")
        }, 16f).apply { typeface = DS.emphasis })
        if (look == null) {
            card.addView(ui.hint(L.t("הוסיפו תמונה של $name בפרופיל המשפחה, או צרו ספר ילדים: הדמות שתאשרו שם תצטרף לפיצקי.",
                "Add a picture of $name in the family profile, or make a children's book: the character you approve there joins Pitzki."), top = 4))
            return card
        }
        val d = PitzkiStore.drawing?.takeIf { it.member == c.memberId }
        val clips = PitzkiStore.clips(this, c)
        val candidate = PitzkiStore.candidate(this, c.memberId)
        when {
            d != null && !d.finished && d.phase == "character" -> {
                card.addView(ui.hint(L.t("מציירים את $name כדמות מהתמונות… (דקה-שתיים)", "Drawing $name as a character from the photos… (a minute or two)"), top = 4))
                card.addView(ui.hint(L.t("אפשר לצאת מהמסך, זה ממשיך.", "You can leave this screen; it keeps going."), top = 2))
            }
            candidate.exists() -> {
                // The parent's OK first: the film is only as good as the likeness.
                card.addView(ui.text(L.t("זה $name?", "Is this $name?"), 18f, top = 6).apply { typeface = DS.heading })
                card.addView(ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true
                    background = DS.rounded(DS.bg(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(300)).apply { topMargin = ui.dp(8) }
                    bg.execute {
                        val b = try { BitmapFactory.decodeFile(candidate.absolutePath) } catch (_: Throwable) { null }
                        main.post { if (!destroyed && b != null) setImageBitmap(b) }
                    }
                })
                card.addView(ui.button(L.t("כן, זה $name! לאשר", "Yes, that's $name! Approve"), primary = true, top = 10) {
                    if (PitzkiStore.approveCharacter(this, c)) {
                        children = PitzkiStore.children(this)
                        chosen = children.firstOrNull { it.memberId == c.memberId }
                        chosen?.let { PitzkiStore.confirmLook(this, it) } // the parent just approved it
                    }
                    renderSetup()
                })
                val row = ui.horizontal(top = 4)
                row.addView(ui.action(L.t("לצייר שוב", "Draw again")) { if (PitzkiStore.makeCharacter(this, c)) { renderSetup(); watchDrawing() } })
                row.addView(ui.action(L.t("ביטול", "Cancel"), R.color.ink_soft) { candidate.delete(); renderSetup() })
                card.addView(row)
            }
            d != null && !d.finished && d.phase != "character" -> waiting(card, c, d)
            d != null && !d.finished -> {
                card.addView(ui.text(
                    if (d.phase == "anim") L.t("שלב 2 מתוך 2: מנפישים", "Step 2 of 2: animating")
                    else L.t("שלב 1 מתוך 2: מציירים את $name ביער", "Step 1 of 2: drawing $name in the forest"), 15f, top = 6).apply { typeface = DS.emphasis })
                card.addView(android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    isIndeterminate = d.phase == "anim" && d.animated == 0
                    max = d.total.coerceAtLeast(1)
                    progress = if (d.phase == "anim") d.animated else d.done
                    progressTintList = android.content.res.ColorStateList.valueOf(DS.button(this@PitzkiActivity))
                    indeterminateTintList = android.content.res.ColorStateList.valueOf(DS.button(this@PitzkiActivity))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(8) }
                })
                card.addView(ui.hint(
                    if (d.phase == "anim") L.t("כל הסצנות קמות לחיים ביחד, וזה לוקח בערך 3–8 דקות. מוכנות: ${d.animated} מתוך ${d.total}.", "All the scenes come to life together; it takes about 3–8 minutes. Ready: ${d.animated} of ${d.total}.")
                    else L.t("${d.done} מתוך ${d.total} ציורים. אחר כך הם יקומו לחיים.", "${d.done} of ${d.total} drawings. Then they come to life."), top = 6))
                if (d.note.isNotEmpty()) card.addView(ui.text(d.note, 13f, R.color.ds_error, top = 4))
                card.addView(ui.hint(L.t("אפשר לצאת מהמסך, זה ממשיך.", "You can leave this screen; it keeps going."), top = 2))
            }
            !PitzkiStore.lookConfirmed(this, c) -> {
                // The parent approves how the child looks before anything is drawn with it.
                if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
                card.addView(ui.text(L.t("זה $name?", "Is this $name?"), 18f, top = 6).apply { typeface = DS.heading })
                card.addView(ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = DS.rounded(DS.bg(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(260)).apply { topMargin = ui.dp(8) }
                    bg.execute {
                        val b = try { BitmapFactory.decodeFile(look.file.absolutePath) } catch (_: Throwable) { null }
                        main.post { if (!destroyed && b != null) setImageBitmap(b) }
                    }
                })
                card.addView(ui.hint(
                    if (look.drawn) L.t("זו הדמות של $name מהספר. להשתמש בה בסרט של פיצקי, או ליצור דמות חדשה מהתמונות?", "This is $name's character from the book. Use it in Pitzki's film, or make a new one from the photos?")
                    else L.t("זו התמונה של $name. לדמיון הכי טוב כדאי ליצור ממנה דמות מצוירת ולאשר אותה.", "This is $name's photo. For the best likeness, make a drawn character from it and approve it."), top = 6))
                card.addView(ui.button(
                    if (look.drawn) L.t("כן, להשתמש בדמות הזאת", "Yes, use this character") else L.t("להמשיך עם התמונה", "Continue with the photo"),
                    primary = look.drawn, top = 10) { PitzkiStore.confirmLook(this, c); renderSetup() })
                if (c.photos.isNotEmpty()) card.addView(ui.button(L.t("ליצור דמות חדשה מהתמונות של $name", "Make a new character from $name's photos"),
                    primary = !look.drawn, top = 6) { confirmCharacter(c) })
            }
            PitzkiStore.awaitingIntro(this, c) -> introApproval(card, c)
            PitzkiStore.scenesReady(this, c) -> {
                if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
                card.addView(ui.hint(
                    if (clips == PitzkiScript.SCENES) L.t("✓ הסרט של $name מוכן: ${PitzkiScript.SCENES} סצנות שבהן פיצקי ו$name זזים ומטיילים.", "✓ $name's film is ready: ${PitzkiScript.SCENES} scenes where Pitzki and $name move and explore.")
                    else if (clips > 0) L.t("✓ $name ${g("מצויר", "מצוירת")} ביער. $clips מתוך ${PitzkiScript.SCENES} סצנות כבר זזות.", "✓ $name is drawn in. $clips of ${PitzkiScript.SCENES} scenes already move.")
                    else L.t("✓ $name ${g("מצויר", "מצוירת")} בתוך היער, ב-${PitzkiScript.SCENES} סצנות (עדיין בלי תנועה).", "✓ $name is drawn into the forest, in ${PitzkiScript.SCENES} scenes (not moving yet)."), top = 4))
                card.addView(scenesStrip(c))
                if (PitzkiStore.needsAnimation(this, c)) card.addView(ui.button(
                    L.t("להנפיש: פיצקי ו$name ילכו ויטיילו", "Animate: Pitzki and $name walk and explore"), primary = true, top = 10) { confirmDraw(c, again = false, animate = true) })
                if (c.photos.isNotEmpty()) card.addView(ui.action(L.t("$name לא מספיק דומה? ליצור דמות מהתמונות", "Not like $name enough? Make a character from the photos")) { confirmCharacter(c) })
                val row = ui.horizontal(top = 6)
                row.addView(ui.action(L.t("ליצור מחדש", "Make again")) { confirmDraw(c, again = true, animate = clips > 0) })
                // The same drawings, moving anew (e.g. after the motion was improved): only the animations are paid.
                if (clips > 0) row.addView(ui.action(L.t("להנפיש מחדש", "Animate again")) {
                    AlertDialog.Builder(this)
                        .setMessage(L.t("הציורים נשארים, ורק התנועה של $name ופיצקי נוצרת מחדש (קרדיט סרט אחד).", "The drawings stay; only $name and Pitzki's motion is made again (one film credit)."))
                        .setPositiveButton(L.t("להנפיש מחדש", "Animate again")) { _, _ ->
                            for (k in PitzkiScript.CHILD_KEYS) PitzkiStore.clipFile(this, c.memberId, k).delete()
                            confirmDraw(c, again = false, animate = true)
                        }
                        .setNegativeButton(L.t("ביטול", "Cancel"), null)
                        .show()
                })
                row.addView(ui.action(L.t("למחוק", "Delete"), R.color.ds_error) {
                    PitzkiStore.deleteScenes(this, c.memberId); renderSetup()
                })
                card.addView(row)
            }
            else -> {
                if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
                card.addView(ui.hint(
                    if (PitzkiStore.partial(this, c) > 0) L.t("נוספו לסרט צבעים חדשים! ${PitzkiStore.partial(this, c)} סצנות כבר מוכנות, ונוצרות רק החסרות.", "New colors were added to the film! ${PitzkiStore.partial(this, c)} scenes are ready; only the missing ones are made.")
                    else if (PitzkiStore.scenesOutdated(this, c)) L.t("נשמרה דמות חדשה של $name. אפשר ליצור את הסרט מחדש איתה.", "A new look of $name was saved. You can make the film again with it.")
                    else L.t("בינתיים $name ${g("מופיע", "מופיעה")} בעיגול ליד פיצקי. בסרט עצמו $name ${g("נמצא", "נמצאת")} בתוך היער, ${g("הולך", "הולכת")} ו${g("מטייל", "מטיילת")} עם פיצקי בכל סצנות היער. נוצר פעם אחת ונשמר בטלפון.",
                        "For now $name shows in a circle next to Pitzki. In the film itself $name is inside the forest, walking and exploring with Pitzki in every forest scene. Made once, kept on the phone."), top = 4))
                if (!look.drawn && c.photos.isNotEmpty()) {
                    // Most like the child: first a character from the photos (the parent approves), then the film.
                    card.addView(ui.hint(L.t("כדי ש$name ${g("ייראה", "תיראה")} בדיוק כמו בחיים: קודם מציירים דמות מהתמונות ${g("שלו", "שלה")}, אתם מאשרים, ורק אז הסרט.",
                        "So $name looks just like in real life: first a character is drawn from the photos, you approve it, then the film."), top = 8))
                    card.addView(ui.button(L.t("שלב 1: ליצור את הדמות של $name", "Step 1: make $name's character"), primary = true, top = 10) { confirmCharacter(c) })
                    card.addView(ui.action(L.t("לדלג ולהכין את הסרט עכשיו", "Skip and make the film now")) { confirmDraw(c, again = false, animate = true) })
                } else {
                    card.addView(ui.button(L.t("ליצור את הסרט של $name", "Make $name's film"), primary = true, top = 10) { confirmDraw(c, again = false, animate = true) })
                    card.addView(ui.action(L.t("רק ציורים, בלי תנועה", "Drawings only, no motion")) { confirmDraw(c, again = false, animate = false) })
                }
            }
        }
        return card
    }

    /**
     * The first scene is drawn: the parent sees how the child looks in the film and says "yes" before the other
     * drawings and the animations are made (and paid for). Not like the child: draw it again, or make a character.
     */
    private fun introApproval(card: LinearLayout, c: PitzkiStore.Child) {
        val name = c.kid.name
        val d = PitzkiStore.drawing?.takeIf { it.member == c.memberId }
        if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
        card.addView(ui.text(L.t("ככה $name ${if (c.kid.girl) "תיראה" else "ייראה"} בסרט. ${if (c.kid.girl) "דומה" else "דומה"}?", "This is how $name looks in the film. Like $name?"), 18f, top = 6).apply { typeface = DS.heading })
        val f = PitzkiStore.sceneFile(this, c.memberId, "intro")
        card.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(200)).apply { topMargin = ui.dp(8) }
            bg.execute {
                val b = try { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 }) } catch (_: Throwable) { null }
                main.post { if (!destroyed && b != null) setImageBitmap(b) }
            }
        })
        card.addView(ui.hint(L.t("רק אחרי האישור נוצרות שאר הסצנות וההנפשה. ככה לא משלמים על סרט שלא דומה.",
            "Only after you approve are the other scenes and the animation made, so you don't pay for a film that doesn't look right."), top = 6))
        card.addView(ui.button(L.t("כן, זה $name! להמשיך", "Yes, that's $name! Continue"), primary = true, top = 10) {
            if (PitzkiStore.approveIntro(this, c)) { renderSetup(); watchDrawing() }
        })
        val row = ui.horizontal(top = 4)
        row.addView(ui.action(L.t("לצייר שוב", "Draw again")) { if (PitzkiStore.redrawIntro(this, c)) { renderSetup(); watchDrawing() } })
        if (c.photos.isNotEmpty()) row.addView(ui.action(L.t("ליצור דמות חדשה מהתמונות", "New character from the photos")) { confirmCharacter(c) })
        card.addView(row)
    }

    // ---------- while the film is being made: something worth the wait ----------

    private var waitSong: android.media.MediaPlayer? = null
    private var heroShown: Pair<String, android.graphics.Bitmap>? = null

    private fun stopWaitSong() {
        val p = waitSong ?: return
        waitSong = null
        try { p.release() } catch (_: Exception) {}
    }

    /** Pitzki's song while waiting (the same one that opens the film). */
    private fun toggleWaitSong(button: TextView) {
        if (waitSong != null) { stopWaitSong(); button.text = L.t("🎵 לשמוע את השיר של פיצקי", "🎵 Hear Pitzki's song"); return }
        try {
            val fd = assets.openFd("pitzki/song.m4a")
            val p = android.media.MediaPlayer()
            p.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            fd.close()
            p.setOnCompletionListener { stopWaitSong(); if (button.isAttachedToWindow) button.text = L.t("🎵 לשמוע שוב", "🎵 Hear it again") }
            p.prepare()
            p.start()
            waitSong = p
            button.text = L.t("⏸ לעצור את השיר", "⏸ Stop the song")
        } catch (_: Exception) { }
    }

    /**
     * The film is being made (a few minutes): instead of a bar, a "making of" — the newest drawing large, the
     * scenes filling in one by one, a few playful words about what's happening, and something to do together
     * (Pitzki's song, the colors to say). The parent can leave the app: a notification says when it's ready.
     */
    private fun waiting(card: LinearLayout, c: PitzkiStore.Child, d: PitzkiStore.Drawing) {
        val name = c.kid.name
        val anim = d.phase == "anim"
        card.addView(ui.text(L.t("✨ פיצקי מכין את הסרט של $name", "✨ Pitzki is making $name's film"), 18f, top = 6).apply { typeface = DS.heading })

        // The newest drawing, large (Pitzki himself until the first one is ready).
        val keys = PitzkiScript.CHILD_KEYS
        val newest = keys.map { PitzkiStore.sceneFile(this, c.memberId, it) }.filter { it.exists() }.maxByOrNull { it.lastModified() }
        val hero = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(190)).apply { topMargin = ui.dp(10) }
        }
        card.addView(hero)
        val heroKey = newest?.let { it.absolutePath + it.lastModified() } ?: "pitzki"
        val cached = heroShown?.takeIf { it.first == heroKey }?.second
        if (cached != null) hero.setImageBitmap(cached) else bg.execute {
            val b = try {
                if (newest != null) BitmapFactory.decodeFile(newest.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 })
                else PitzkiStore.art(applicationContext, "pitzki")
            } catch (_: Throwable) { null }
            main.post {
                if (destroyed || b == null) return@post
                heroShown = heroKey to b
                hero.alpha = 0f
                hero.setImageBitmap(b)
                hero.animate().alpha(1f).setDuration(700).start()
            }
        }

        // The scenes filling in: drawn ones show, the next one waits with a sparkle; ▶ once it moves.
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(8), 0, 0) }
        for (k in keys) {
            val f = PitzkiStore.sceneFile(this, c.memberId, k)
            val moving = PitzkiStore.clipFile(this, c.memberId, k).exists()
            val cell = FrameLayout(this).apply {
                background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusChip(this@PitzkiActivity))
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(0, ui.dp(56), 1f).apply { marginEnd = ui.dp(6) }
            }
            if (f.exists()) {
                val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = FrameLayout.LayoutParams(match, match) }
                cell.addView(img)
                bg.execute {
                    val b = try { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 8 }) } catch (_: Throwable) { null }
                    main.post { if (!destroyed && b != null) img.setImageBitmap(b) }
                }
                if (moving) cell.addView(TextView(this).apply {
                    text = "▶"; textSize = 14f; setTextColor(DS.onPhoto(this@PitzkiActivity))
                    setShadowLayer(6f, 0f, 1f, DS.scrim(this@PitzkiActivity))
                    layoutParams = FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER)
                })
            } else cell.addView(TextView(this).apply {
                text = "✨"; textSize = 18f; gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(match, match)
                alpha = 0.6f
            })
            row.addView(cell)
        }
        card.addView(row)

        // A few playful words about what's happening right now (changing every few seconds).
        val lines = if (anim) listOf(
            L.t("פיצקי ו$name לומדים ללכת ביחד…", "Pitzki and $name learn to walk together…"),
            L.t("מוסיפים חיוכים, נפנופים וכפיים…", "Adding smiles, waves and high-fives…"),
            L.t("החיפושית מתאמנת על ההליכה שלה…", "The beetle practices its walk…"),
            L.t("הציפורים מתכוננות לשיר…", "The birds get ready to sing…"),
            L.t("עוד רגע הכול זז!", "In a moment everything moves!"),
        ) else listOf(
            L.t("פיצקי מחפש את $name ביער…", "Pitzki looks for $name in the forest…"),
            L.t("מציירים את השביל הכי יפה…", "Drawing the prettiest path…"),
            L.t("פיצקי מסדר את הכובע שלו…", "Pitzki fixes his hat…"),
            L.t("$name ופיצקי נפגשים בפעם הראשונה…", "$name and Pitzki meet for the first time…"),
            L.t("מוסיפים פרחים, עלים ואור שמש…", "Adding flowers, leaves and sunshine…"),
        )
        val caption = ui.text(lines[((System.currentTimeMillis() / 4000) % lines.size).toInt()], 15f, R.color.ds_primary, top = 10).apply { typeface = DS.emphasis }
        card.addView(caption)
        main.postDelayed(object : Runnable {
            override fun run() {
                if (destroyed || !caption.isAttachedToWindow) return
                caption.animate().alpha(0f).setDuration(250).withEndAction {
                    caption.text = lines[((System.currentTimeMillis() / 4000) % lines.size).toInt()]
                    caption.animate().alpha(1f).setDuration(250).start()
                }.start()
                main.postDelayed(this, 4000)
            }
        }, 4000)

        // How far, and about how long.
        val left = if (anim) L.t("קמים לחיים: ${d.animated} מתוך ${d.total} · עוד כמה דקות", "Coming to life: ${d.animated} of ${d.total} · a few more minutes")
            else L.t("ציורים: ${d.done} מתוך ${d.total} · עוד בערך ${((d.total - d.done).coerceAtLeast(0) + 6)} דקות", "Drawings: ${d.done} of ${d.total} · about ${((d.total - d.done).coerceAtLeast(0) + 6)} more minutes")
        card.addView(ui.hint(left, top = 4))
        if (d.note.isNotEmpty()) card.addView(ui.text(d.note, 13f, R.color.ds_error, top = 4))

        // Something to do together meanwhile.
        card.addView(ui.text(L.t("בינתיים, ביחד:", "Meanwhile, together:"), 14f, top = 12).apply { typeface = DS.emphasis })
        lateinit var songBtn: TextView
        songBtn = ui.action(if (waitSong != null) L.t("⏸ לעצור את השיר", "⏸ Stop the song") else L.t("🎵 לשמוע את השיר של פיצקי", "🎵 Hear Pitzki's song")) { toggleWaitSong(songBtn) }
        card.addView(songBtn)
        card.addView(ui.hint(L.t("🎨 להתאמן על הצבעים: לוחצים, ופיצקי אומר את הצבע בעברית ובאנגלית", "🎨 Practice the colors: tap, and Pitzki says the color in Hebrew and English"), top = 4))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(6), 0, 0) }
        for (col in PitzkiScript.ORDER) colors.addView(TextView(this).apply {
            text = col.emoji; textSize = 26f; gravity = Gravity.CENTER
            background = DS.pressable(this@PitzkiActivity, DS.rounded(DS.bg(this@PitzkiActivity), ui.dp(16).toFloat()))
            setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6))
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = ui.dp(6) }
            contentDescription = "${col.he}, ${col.en}"
            emojiColor(this, col)
            setOnClickListener {
                pulse(this)
                stopWaitSong()
                voice.say("${col.he}!") { voice.word(col.en) {} }
            }
        })
        card.addView(ui.scrollRow(colors, top = 0))
        card.addView(ui.hint(L.t("🔔 אפשר לצאת מהאפליקציה: נשלח התראה כשהסרט מוכן.", "🔔 You can leave the app: we'll notify you when the film is ready."), top = 12))
    }

    /** Admin: one close-up drawn and animated again, replacing it for every family. */
    private fun redrawShared(key: String, label: String) {
        AlertDialog.Builder(this)
            .setTitle(L.t("לצייר מחדש: $label?", "Draw again: $label?"))
            .setMessage(L.t("התקריב יצויר מחדש, יונפש מחדש (10 שניות) ויחליף את הקודם בשרת. עלות משוערת: פחות מדולר.",
                "The close-up is drawn again, animated again (10 seconds) and replaces the old one on the server. About under a dollar."))
            .setPositiveButton(L.t("לצייר מחדש", "Draw again")) { _, _ -> if (PitzkiStore.buildShared(this, setOf(key))) { renderSetup(); watchDrawing() } }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .show()
    }

    /** The parent writes the name the way it's said (with niqqud), hears it, and saves it. */
    private fun nameDialog(c: PitzkiStore.Child) {
        val name = c.kid.name
        val field = ui.field(name, PitzkiStore.sayName(this, c.memberId).ifBlank { name }, top = 6)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(ui.hint(L.t("כתבו את השם כמו שאומרים אותו, עם ניקוד. למשל אוֹרִי (ולא אוּרִי). אפשר ללחוץ \"להשמיע\" ולנסות עד שזה נשמע נכון.",
                "Write the name the way it's said, with niqqud (e.g. אוֹרִי, not אוּרִי). Tap \"Play\" and try until it sounds right."), top = 0))
            addView(field)
        }
        val d = AlertDialog.Builder(this)
            .setTitle(L.t("איך אומרים את השם?", "How is the name said?"))
            .setView(box)
            .setPositiveButton(L.t("שמירה", "Save")) { _, _ ->
                val said = field.text.toString().trim()
                PitzkiStore.setSayName(this, c.memberId, if (said == name) "" else said)
                renderSetup()
            }
            .setNeutralButton(L.t("להשמיע", "Play"), null)
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val said = field.text.toString().trim().ifBlank { name }
                val before = PitzkiVoice.sayName
                PitzkiVoice.sayName = name to said
                voice.say(L.t("שלום $name!", "Hello $name!")) { PitzkiVoice.sayName = before }
            }
        }
        d.show()
    }

    /**
     * Admin only: Pitzki's close-ups, made once for every family. Each child's film then needs only the scenes the
     * child is in, which keeps it cheap.
     */
    private fun sharedCard(): View {
        val card = ui.card(top = 14)
        card.addView(ui.text(L.t("מנהל: הסצנות המשותפות של פיצקי", "Admin: Pitzki's shared scenes"), 16f).apply { typeface = DS.emphasis })
        val (drawn, moving) = PitzkiStore.sharedReady(this)
        val all = PitzkiStore.SHARED_KEYS.size
        val d = PitzkiStore.drawing?.takeIf { it.member == "shared" }
        if (d != null && !d.finished) {
            card.addView(ui.hint(if (d.phase == "anim") L.t("מנפישים ומעלים לשרת… ${d.animated} מתוך ${d.total}", "Animating and uploading… ${d.animated} of ${d.total}")
                else L.t("מציירים ומעלים לשרת… ${d.done} מתוך ${d.total}", "Drawing and uploading… ${d.done} of ${d.total}"), top = 4))
            if (d.note.isNotEmpty()) card.addView(ui.text(d.note, 13f, R.color.ds_error, top = 4))
            return card
        }
        if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
        card.addView(ui.hint(L.t("תקריבים של פיצקי לבד עם כל צבע (בלי הילד), אותם לכל המשפחות: $drawn מתוך $all מצוירים, $moving זזים. כל ילד משלם רק על הסצנות שהוא בהן.",
            "Close-ups of Pitzki alone with each color (no child), the same for every family: $drawn of $all drawn, $moving moving. Each child pays only for the scenes they're in."), top = 4))
        // Each close-up: tap one to draw and animate it again (a bad drawing, e.g. two Pitzkis). It replaces the old one.
        if (drawn > 0) {
            card.addView(ui.hint(L.t("לחיצה על תקריב: לצייר ולהנפיש אותו מחדש.", "Tap a close-up to draw and animate it again."), top = 8))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(6), 0, 0) }
            for (key in PitzkiStore.SHARED_KEYS) {
                val f = PitzkiStore.sharedScene(this, key)
                if (!f.exists()) continue
                val label = PColor.values().firstOrNull { it.name.lowercase() == key }?.he ?: L.t("השיר", "The song")
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = ui.dp(6) }
                    setOnClickListener { redrawShared(key, label) }
                }
                val img = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusChip(this@PitzkiActivity))
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ui.dp(96), ui.dp(54))
                }
                cell.addView(img)
                cell.addView(ui.hint(label + if (PitzkiStore.sharedClip(this, key).exists()) " ▶" else "", top = 2))
                bg.execute {
                    val b = try { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 8 }) } catch (_: Throwable) { null }
                    main.post { if (!destroyed && b != null) img.setImageBitmap(b) }
                }
                row.addView(cell)
            }
            card.addView(ui.scrollRow(row, top = 0))
        }
        // The lip-sync test: Pitzki sings his song with matching lips.
        val talk = PitzkiStore.drawing?.takeIf { it.member == "talk" }
        if (talk != null && !talk.finished) card.addView(ui.hint(L.t("מכינים את הניסיון: פיצקי שר עם שפתיים מסונכרנות… (כמה דקות)", "Making the test: Pitzki sings with matching lips… (a few minutes)"), top = 8))
        else {
            if (talk != null && talk.failed.isNotEmpty()) card.addView(ui.text(talk.failed, 14f, R.color.ds_error, top = 6))
            if (PitzkiStore.talkTest(this).exists()) card.addView(ui.button(L.t("▶ לצפות בניסיון: פיצקי שר", "▶ Watch the test: Pitzki sings"), primary = true, top = 10) { playTalkTest() })
            card.addView(ui.action(L.t("ניסיון: פיצקי שר עם שפתיים מסונכרנות (קרדיט סרט אחד)", "Test: Pitzki sings with matching lips (one film credit)")) {
                if (PitzkiStore.makeTalkTest(this)) { renderSetup(); watchDrawing() }
            })
        }
        if (moving < all) card.addView(ui.button(L.t("ליצור ולהעלות את החסרות", "Make and upload the missing ones"), primary = true, top = 10) {
            AlertDialog.Builder(this)
                .setMessage(L.t("נוצרים ${all - drawn} ציורים ו-${all - moving} הנפשות (קרדיט סרט אחד), והם עולים לשרת לכל המשפחות. צריך שקובץ pitzki-shared-scenes.sql כבר הורץ ב-Supabase.",
                    "${all - drawn} drawings and ${all - moving} animations are made (one film credit) and uploaded for every family. pitzki-shared-scenes.sql must already be run in Supabase."))
                .setPositiveButton(L.t("ליצור", "Make them")) { _, _ -> if (PitzkiStore.buildShared(this)) { renderSetup(); watchDrawing() } }
                .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
                .show()
        })
        return card
    }

    /** Opens the lip-sync test in the phone's video player (with its sound). */
    private fun playTalkTest() {
        try {
            val dir = java.io.File(cacheDir, "share").apply { mkdirs() }
            val f = java.io.File(dir, "pitzki_song_test.mp4")
            PitzkiStore.talkTest(this).copyTo(f, overwrite = true)
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, L.t("לא הצלחנו לפתוח את הסרטון", "Couldn't open the video"), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun scenesStrip(c: PitzkiStore.Child): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(8), 0, 0) }
        for (n in PitzkiScript.KEYS) {
            val f = PitzkiStore.sceneFile(this, c.memberId, n)
            row.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusChip(this@PitzkiActivity))
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(ui.dp(96), ui.dp(72)).apply { marginEnd = ui.dp(6) }
                bg.execute {
                    val b = try { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 4 }) } catch (_: Throwable) { null }
                    main.post { if (!destroyed && b != null) setImageBitmap(b) }
                }
            })
        }
        return ui.scrollRow(row, top = 0)
    }

    /** The character from the child's photos: says what is sent and what it costs, then draws it. */
    private fun confirmCharacter(c: PitzkiStore.Child) {
        AiGate.askConsent(this) {
            AlertDialog.Builder(this)
                .setTitle(L.t("ליצור את הדמות של ${c.kid.name}?", "Make ${c.kid.name}'s character?"))
                .setMessage(L.t("נשלחות לשרת של Moments, ומשם לשירות fal ולמודל הציור של OpenAI (GPT Image), ${c.photos.size} תמונות של ${c.kid.name} (מהפרופיל ומהפנים שהאפליקציה למדה). נוצרת דמות מצוירת שאתם מאשרים, והיא תשמש גם בספרים. זה משתמש בקרדיט סרט אחד, ואותו קרדיט מכסה גם את הסרט של פיצקי אם תכינו אותו בשעות הקרובות. השרת לא שומר את התמונות.",
                    "${c.photos.size} photos of ${c.kid.name} (profile and the face the app learned) go to Moments' server and from there to the drawing model. A drawn character is made for you to approve; books will use it too. It uses one film credit, which also covers Pitzki's film if you make it in the next few hours. The server doesn't keep the photos."))
                .setPositiveButton(L.t("ליצור", "Make it")) { _, _ ->
                    if (!PitzkiStore.makeCharacter(this, c)) android.widget.Toast.makeText(this, L.t("משהו אחר עוד רץ. רגע.", "Something else is still running."), android.widget.Toast.LENGTH_SHORT).show()
                    renderSetup()
                    watchDrawing()
                }
                .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
                .show()
        }
    }

    /** Says exactly what is sent, then draws. */
    private fun confirmDraw(c: PitzkiStore.Child, again: Boolean, animate: Boolean = false) {
        val look = c.look ?: return
        // The scenes are drawn through Moments' server (fal): only a signed-in account is needed.
        if (!PitzkiStore.scenesReady(this, c) && !Account.signedIn(this)) {
            AlertDialog.Builder(this).setMessage(L.t("כדי לצייר צריך להתחבר לחשבון.", "Please sign in to draw.")).setPositiveButton(L.t("הבנתי", "OK"), null).show()
            return
        }
        AiGate.askConsent(this) {
            val what = if (look.drawn) L.t("הדמות המצוירת של ${c.kid.name} מהספר", "${c.kid.name}'s drawn character from the book")
                else L.t("התמונה של ${c.kid.name} מהפרופיל", "${c.kid.name}'s profile picture")
            AlertDialog.Builder(this)
                .setTitle(if (animate) L.t("ליצור את הסרט של ${c.kid.name}?", "Make ${c.kid.name}'s film?") else L.t("לצייר את ${c.kid.name} ביער?", "Draw ${c.kid.name} in the forest?"))
                .setMessage(L.t("נשלחים לשרת של Moments, ומשם לשירות fal ולמודל הציור של OpenAI (GPT Image, אותו מודל שמצייר את הספרים): $what, תמונה אמיתית של ${c.kid.name} לדמיון, ותמונה של פיצקי. קודם מצוירת סצנה אחת, ואתם מאשרים שהיא דומה. רק אז נוצרות שאר ${PitzkiScript.CHILD_KEYS.size} הסצנות שבהן ${c.kid.name} מופיע (הציורים משתמשים בקרדיט הסרט)",
                    "Sent to Moments' server, and from there to fal and OpenAI's drawing model (GPT Image, the same one that draws the books): $what, a real photo of ${c.kid.name} for the likeness, and a picture of Pitzki. One scene is drawn first and you approve the likeness; only then are the other ${PitzkiScript.CHILD_KEYS.size} scenes with ${c.kid.name} made (the drawings use the film credit)") +
                    (if (animate) L.t(", ואז כל ציור קם לחיים לכמה שניות: פיצקי ו${c.kid.name} הולכים, מצביעים ומנופפים. ההנפשה משתמשת בקרדיט סרט אחד ולוקחת כמה דקות.", ", then each drawing comes to life for a few seconds: Pitzki and ${c.kid.name} walk, point and wave. The animation uses one film credit and takes a few minutes.") else ".") +
                    L.t(" הסרט נשמר רק בטלפון. השרת שלנו לא שומר את התמונות, ו-fal מוחקים אותן כשהן מגיעות לטלפון (לכל היותר אחרי 16 שעות).",
                        " The film is kept only on this phone. Our server doesn't keep the pictures, and fal deletes them once they reach the phone (at most after 16 hours)."))
                .setPositiveButton(if (animate) L.t("ליצור", "Make it") else L.t("לצייר", "Draw")) { _, _ ->
                    if (again) PitzkiStore.deleteScenes(this, c.memberId)
                    if (!PitzkiStore.drawScenes(this, c, animate)) android.widget.Toast.makeText(this, L.t("ציור אחר עוד רץ. רגע.", "Another drawing is still running."), android.widget.Toast.LENGTH_SHORT).show()
                    renderSetup()
                    watchDrawing()
                }
                .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
                .show()
        }
    }

    /** Refreshes the card while scenes are being drawn. */
    private var watching: PitzkiStore.Drawing? = null

    private fun watchDrawing() {
        val d = PitzkiStore.drawing ?: return
        if (d.finished || watching === d) return
        watching = d
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 42)
        var last = "${d.done}/${d.animated}/${d.note}"
        main.postDelayed(object : Runnable {
            override fun run() {
                if (destroyed || inLesson) { if (watching === d) watching = null; return }
                val now = "${d.done}/${d.animated}/${d.note}"
                if (now != last || d.finished) { last = now; renderSetup() }
                if (!d.finished) main.postDelayed(this, 700) else if (watching === d) watching = null
            }
        }, 700)
    }

    // =====================================================================
    // The lesson (for the child)
    // =====================================================================

    private var inLesson = false
    private var scenes: List<PitzkiScene> = emptyList()
    private var sceneIdx = 0
    private var beatIdx = 0
    private var token = 0
    private var paused = false
    private var asking: PColor? = null
    private var askSeq = 0
    private var misses = 0
    private var praiseN = 0
    private var starsNow = 0
    private var useDrawn = false

    private lateinit var stage: FrameLayout
    private lateinit var sceneImg: ImageView
    private lateinit var objectView: TextView
    private lateinit var childBubble: View
    private lateinit var wordBubble: TextView
    private lateinit var burst: TextView
    private lateinit var subtitle: TextView
    private lateinit var progress: LinearLayout
    private lateinit var starsLabel: TextView
    private lateinit var strip: LinearLayout
    private lateinit var pausedLayer: LinearLayout
    private lateinit var listening: TextView
    private lateinit var micBtn: TextView
    private val items = HashMap<PColor, View>()
    /** Changes with every scene, so a picture that loads late never lands on the next scene. */
    private var sceneSeq = 0
    private lateinit var clipView: android.view.TextureView
    private var clipPlayer: android.media.MediaPlayer? = null
    private var clipSurface: android.view.Surface? = null
    private var clipEnded = false
    private val clipIo = Executors.newSingleThreadExecutor() // opening a clip never on the main thread

    /**
     * Some phones draw the beetle emoji green: for "black" the picture is shown black (and nothing else is changed),
     * so the child taps a black beetle when Pitzki asks for the black one.
     */
    private fun emojiColor(v: TextView, c: PColor?) {
        if (c == PColor.BLACK) {
            val m = android.graphics.ColorMatrix().apply { setSaturation(0f) }
            m.postConcat(android.graphics.ColorMatrix(floatArrayOf(0.35f, 0f, 0f, 0f, 0f, 0f, 0.35f, 0f, 0f, 0f, 0f, 0f, 0.35f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
            v.setLayerType(View.LAYER_TYPE_HARDWARE, android.graphics.Paint().apply { colorFilter = android.graphics.ColorMatrixColorFilter(m) })
        } else v.setLayerType(View.LAYER_TYPE_NONE, null)
    }

    private fun colorOf(c: PColor) = ui.color(when (c) {
        PColor.GREEN -> R.color.pitzki_green
        PColor.BROWN -> R.color.pitzki_brown
        PColor.RED -> R.color.pitzki_red
        PColor.YELLOW -> R.color.pitzki_yellow
        PColor.GRAY -> R.color.pitzki_gray
        PColor.WHITE -> R.color.pitzki_white
        PColor.BLACK -> R.color.pitzki_black
        PColor.PURPLE -> R.color.pitzki_purple
        PColor.PINK -> R.color.pitzki_pink
        PColor.BLUE -> R.color.pitzki_blue
    })

    private fun startLesson() {
        inLesson = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Like a film: sideways, the whole screen, no bars.
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        immersive(true)
        stopSong()
        scenes = PitzkiScript.lesson(kid)
        sceneIdx = 0; beatIdx = 0; starsNow = 0; praiseN = 0; asking = null; paused = false
        // The child's own drawings wherever they exist (also when the lesson grew and some are still missing).
        useDrawn = chosen?.let { PitzkiStore.partial(this, it) > 0 } == true
        if (PitzkiStore.listenOn(this) && !micGranted()) requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 41)
        buildLesson()
        showScene()
        runBeat()
        showMicTip()
    }

    private fun stopLesson() {
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        ears.stop()
        stopSong()
        stopClip()
        inLesson = false
        immersive(false)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    private fun immersive(on: Boolean) {
        val c = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        } else c.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
    }

    private fun lp(w: Int, h: Int, gravity: Int) = FrameLayout.LayoutParams(w, h, gravity)
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    /**
     * The whole screen is the forest (sideways, like a film). Over it: the words Pitzki says (subtitles), the color
     * word in a bubble, the child, and the five things to tap — only when it's
     * the child's turn. One tap anywhere pauses.
     */
    private fun buildLesson() {
        val black = DS.alpha(DS.ink(this), 1f)
        stage = FrameLayout(this).apply {
            setBackgroundColor(black)
            layoutDirection = View.LAYOUT_DIRECTION_LTR // positions are fixed to the art: Pitzki stands on the right
            // A tap pauses (not while it's the child's turn: little fingers tap everywhere).
            setOnClickListener { if (paused) resume() else if (asking == null) pause() }
        }
        sceneImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = lp(match, match, Gravity.CENTER) }
        stage.addView(sceneImg)
        // The scene come to life (when it was animated): plays over the still, then fades back to it.
        clipView = android.view.TextureView(this).apply { alpha = 0f; layoutParams = lp(match, match, Gravity.CENTER) }
        stage.addView(clipView)
        // Soft dark at the bottom so the subtitles read well over any picture.
        stage.addView(View(this).apply {
            setBackgroundResource(R.drawable.cover_scrim)
            layoutParams = lp(match, ui.dp(170), Gravity.BOTTOM)
        })
        stage.addView(View(this).apply {
            setBackgroundResource(R.drawable.scrim_top)
            layoutParams = lp(match, ui.dp(70), Gravity.TOP)
        })

        objectView = TextView(this).apply {
            textSize = 70f
            gravity = Gravity.CENTER
            background = DS.oval(DS.alpha(DS.bg(this@PitzkiActivity), 0.9f))
            elevation = ui.dp(6).toFloat()
            visibility = View.GONE
            layoutParams = lp(ui.dp(150), ui.dp(150), Gravity.CENTER).apply { rightMargin = ui.dp(60) }
        }
        stage.addView(objectView)
        childBubble = chosen?.let { lookCircle(it, 150, ring = true) } ?: View(this)
        childBubble.layoutParams = lp(ui.dp(150), ui.dp(150), Gravity.LEFT or Gravity.CENTER_VERTICAL).apply { leftMargin = ui.dp(36); bottomMargin = ui.dp(20) }
        childBubble.elevation = ui.dp(8).toFloat()
        stage.addView(childBubble)
        wordBubble = TextView(this).apply {
            textSize = 44f
            typeface = DS.heading
            gravity = Gravity.CENTER
            setPadding(ui.dp(28), ui.dp(6), ui.dp(28), ui.dp(10))
            background = DS.rounded(DS.alpha(DS.bg(this@PitzkiActivity), 0.96f), ui.dp(34).toFloat())
            elevation = ui.dp(8).toFloat()
            visibility = View.GONE
            // Top middle, under the dots: never on Pitzki's face (he stands on the right in his close-ups).
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(40) }
        }
        stage.addView(wordBubble)
        burst = TextView(this).apply {
            text = "⭐"; textSize = 110f; gravity = Gravity.CENTER; visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.CENTER)
        }
        stage.addView(burst)

        // Subtitles: what Pitzki says, large and white, at the bottom.
        subtitle = TextView(this).apply {
            textSize = 24f
            typeface = DS.emphasis
            gravity = Gravity.CENTER
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(10f, 0f, 2f, DS.scrim(this@PitzkiActivity))
            textDirection = View.TEXT_DIRECTION_RTL
            maxLines = 2
            layoutParams = lp(match, wrap, Gravity.BOTTOM).apply { leftMargin = ui.dp(90); rightMargin = ui.dp(90); bottomMargin = ui.dp(18) }
        }
        stage.addView(subtitle)

        // The five things to tap: slide up only when it's the child's turn.
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ui.dp(76) }
        }
        items.clear()
        for (c in PitzkiScript.ORDER) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = DS.pressable(this@PitzkiActivity, DS.rounded(DS.alpha(DS.bg(this@PitzkiActivity), 0.95f), ui.dp(22).toFloat()))
                elevation = ui.dp(6).toFloat()
                setPadding(ui.dp(4), ui.dp(6), ui.dp(4), ui.dp(6))
                layoutParams = LinearLayout.LayoutParams(ui.dp(68), wrap).apply { marginStart = ui.dp(3); marginEnd = ui.dp(3) }
                contentDescription = "${c.he}, ${c.en}"
                setOnClickListener { tap(c) }
            }
            item.addView(TextView(this).apply { text = c.emoji; textSize = 30f; gravity = Gravity.CENTER; emojiColor(this, c) })
            item.addView(TextView(this).apply {
                text = c.en; textSize = 13f; gravity = Gravity.CENTER; typeface = DS.heading; maxLines = 1
                setTextColor(colorOf(c))
            })
            items[c] = item
            strip.addView(item)
        }
        stage.addView(strip)

        // Top: close (right), where we are (dots), stars and sound (left).
        stage.addView(TextView(this).apply {
            text = "✕"; textSize = 22f; setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(8f, 0f, 1f, DS.scrim(this@PitzkiActivity))
            setPadding(ui.dp(18), ui.dp(12), ui.dp(18), ui.dp(12))
            contentDescription = L.t("יציאה", "Exit")
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.RIGHT)
            setOnClickListener { stopLesson(); setup() }
        })
        progress = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(20) }
        }
        repeat(scenes.size) {
            progress.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(ui.dp(16), ui.dp(4)).apply { marginStart = ui.dp(2); marginEnd = ui.dp(2) }
            })
        }
        stage.addView(progress)
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.LEFT).apply { topMargin = ui.dp(8); leftMargin = ui.dp(12) }
        }
        starsLabel = TextView(this).apply {
            text = "⭐ 0"; textSize = 18f; typeface = DS.heading
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(8f, 0f, 1f, DS.scrim(this@PitzkiActivity))
            setPadding(ui.dp(6), ui.dp(6), ui.dp(10), ui.dp(6))
        }
        left.addView(TextView(this).apply {
            text = if (voice.muted) "🔇" else "🔊"; textSize = 18f
            setPadding(ui.dp(6), ui.dp(6), ui.dp(10), ui.dp(6))
            contentDescription = L.t("קול", "Sound")
            setOnClickListener { voice.muted = !voice.muted; text = if (voice.muted) "🔇" else "🔊" }
        })
        left.addView(starsLabel)
        micBtn = TextView(this).apply {
            textSize = 13f
            typeface = DS.emphasis
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            background = DS.rounded(DS.scrim(this@PitzkiActivity), ui.dp(14).toFloat())
            setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4))
            contentDescription = L.t("מיקרופון: פיצקי מקשיב לתשובות", "Microphone: Pitzki listens to answers")
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = ui.dp(8) }
            setOnClickListener {
                PitzkiStore.setListen(this@PitzkiActivity, !PitzkiStore.listenOn(this@PitzkiActivity))
                showMic()
                if (PitzkiStore.listenOn(this@PitzkiActivity) && !micGranted()) requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 41)
                if (!PitzkiStore.listenOn(this@PitzkiActivity)) { ears.stop(); listening.visibility = View.GONE }
            }
        }
        left.addView(micBtn)
        showMic()
        stage.addView(left)
        // While Pitzki listens: a small "listening" sign in the middle, so the child knows to talk.
        listening = TextView(this).apply {
            text = L.t("🎤 פיצקי מקשיב…", "🎤 Pitzki is listening…")
            textSize = 22f
            typeface = DS.emphasis
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            background = DS.rounded(DS.scrim(this@PitzkiActivity), ui.dp(22).toFloat())
            setPadding(ui.dp(18), ui.dp(8), ui.dp(18), ui.dp(8))
            visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ui.dp(84) }
        }
        stage.addView(listening)

        // Paused: a calm layer with play, scene again and next scene.
        pausedLayer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(DS.scrimSoft(this@PitzkiActivity))
            visibility = View.GONE
            layoutParams = lp(match, match, Gravity.CENTER)
            setOnClickListener { resume() }
        }
        fun round(label: String, sizeDp: Int, primary: Boolean, desc: String, go: () -> Unit) = TextView(this).apply {
            text = label; textSize = if (primary) 30f else 22f; gravity = Gravity.CENTER
            setTextColor(if (primary) DS.onButton(this@PitzkiActivity) else DS.primary(this@PitzkiActivity))
            background = DS.pressable(this@PitzkiActivity, DS.oval(if (primary) DS.button(this@PitzkiActivity) else DS.bg(this@PitzkiActivity)), onDark = primary)
            contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(ui.dp(sizeDp), ui.dp(sizeDp)).apply { marginStart = ui.dp(18); marginEnd = ui.dp(18) }
            setOnClickListener { go() }
        }
        pausedLayer.addView(round("↻", 60, false, L.t("הסצנה מההתחלה", "Scene again")) { jump(sceneIdx) })
        pausedLayer.addView(round("▶", 88, true, L.t("המשך", "Play")) { resume() })
        pausedLayer.addView(round("⏭", 60, false, L.t("לסצנה הבאה", "Next scene")) { if (sceneIdx + 1 < scenes.size) jump(sceneIdx + 1) else resume() })
        stage.addView(pausedLayer)
        setContentView(stage)
    }

    private fun showProgress() {
        for (i in 0 until progress.childCount) progress.getChildAt(i).background =
            DS.rounded(if (i <= sceneIdx) DS.onPhoto(this) else DS.onPhoto(this, 0.35f), ui.dp(2).toFloat())
    }

    private fun showScene() {
        val s = scenes[sceneIdx]
        showProgress()
        wordBubble.visibility = View.GONE
        burst.visibility = View.GONE
        strip.visibility = View.GONE
        val member = chosen?.memberId
        // The child's own drawing (the child is in it), or Pitzki's shared close-up; otherwise Pitzki's forest, the thing,
        // and the child in a circle.
        val owner = if (useDrawn) member else null
        val drawn = PitzkiStore.sceneFor(this, owner, s.key)
        val clip = PitzkiStore.clipFor(this, owner, s.key)
        val seq = ++sceneSeq
        bg.execute {
            val b = try {
                if (drawn != null && drawn.exists()) BitmapFactory.decodeFile(drawn.absolutePath) else PitzkiStore.art(applicationContext, "forest")
            } catch (_: Throwable) { null }
            main.post {
                if (destroyed || seq != sceneSeq || !inLesson || b == null) return@post
                sceneImg.alpha = 0f
                sceneImg.setImageBitmap(b)
                sceneImg.animate().alpha(1f).setDuration(600).start()
            }
        }
        stopClip()
        clip?.let { playClip(it, seq) }
        val c = s.color
        objectView.visibility = if (drawn == null && c != null) View.VISIBLE else View.GONE
        if (c != null) { objectView.text = c.emoji; emojiColor(objectView, c) }
        childBubble.visibility = if (drawn == null) View.VISIBLE else View.GONE
        kenBurns()
        if (objectView.visibility == View.VISIBLE) {
            objectView.scaleX = 0.4f; objectView.scaleY = 0.4f
            objectView.animate().scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(android.view.animation.OvershootInterpolator()).start()
        }
    }

    /** Plays a scene's animation once, silently (Pitzki talks over it), then its last frame stays on screen. */
    private fun playClip(f: java.io.File, seq: Int) {
        val st = clipView.surfaceTexture
        if (st == null) {
            clipView.surfaceTextureListener = object : android.view.TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(t: android.graphics.SurfaceTexture, w: Int, h: Int) { if (seq == sceneSeq && inLesson) playClip(f, seq) }
                override fun onSurfaceTextureSizeChanged(t: android.graphics.SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(t: android.graphics.SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(t: android.graphics.SurfaceTexture) {}
            }
            return
        }
        val mp = android.media.MediaPlayer()
        val surface = android.view.Surface(st)
        clipPlayer = mp
        clipSurface = surface
        clipEnded = false
        mp.setOnInfoListener { _, what, _ ->
            if (what == android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && clipPlayer === mp) {
                clipView.animate().alpha(1f).setDuration(400).start()
                sceneImg.animate().cancel()
            }
            false
        }
        mp.setOnCompletionListener {
            if (clipPlayer !== mp) return@setOnCompletionListener
            // The last frame stays on screen (where the characters ended up), no jump back to the still drawing.
            clipEnded = true
        }
        mp.setOnErrorListener { _, _, _ -> if (clipPlayer === mp) { clipEnded = true; clipView.alpha = 0f }; true }
        clipIo.execute {
            val ok = try {
                mp.setDataSource(f.absolutePath)
                mp.setSurface(surface)
                mp.setVolume(0f, 0f)
                mp.prepare()
                true
            } catch (_: Throwable) { false }
            main.post {
                if (clipPlayer !== mp || destroyed) return@post
                if (!ok) { stopClip(); return@post }
                try {
                    fillClip(mp.videoWidth, mp.videoHeight)
                    if (!paused) mp.start()
                } catch (_: Exception) { stopClip() }
            }
        }
    }

    /** The clip fills the screen (cropped, not stretched). */
    private fun fillClip(vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0 || clipView.width == 0 || clipView.height == 0) return
        val sx = clipView.width.toFloat() / vw
        val sy = clipView.height.toFloat() / vh
        val k = maxOf(sx, sy)
        clipView.setTransform(android.graphics.Matrix().apply { setScale(k / sx, k / sy, clipView.width / 2f, clipView.height / 2f) })
    }

    private fun stopClip() {
        val p = clipPlayer
        val sf = clipSurface
        clipPlayer = null
        clipSurface = null
        clipEnded = true
        if (::clipView.isInitialized) { clipView.animate().cancel(); clipView.alpha = 0f }
        if (p != null || sf != null) try {
            clipIo.execute {
                try { p?.release() } catch (_: Exception) {}
                try { sf?.release() } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    // ---------- Pitzki's song ----------

    private var songPlayer: android.media.MediaPlayer? = null
    private var songEnded = false

    private fun hasSong() = try { assets.openFd("pitzki/song.m4a").close(); true } catch (_: Exception) { false }

    /** Plays the sung song from [b]'s part (one recording across the song's scenes), lines shown as they're sung. */
    private fun sing(b: Beat.Song, my: Int, done: () -> Unit) {
        if (!hasSong()) { sayAll(b.lines.map { it.second }, my, done); return }
        val mp = songPlayer ?: try {
            android.media.MediaPlayer().also { p ->
                assets.openFd("pitzki/song.m4a").use { fd -> p.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length) }
                p.setOnCompletionListener { songEnded = true }
                p.prepare() // a small file in the app: quick
                songPlayer = p
                songEnded = false
            }
        } catch (_: Exception) { null }
        if (mp == null) { sayAll(b.lines.map { it.second }, my, done); return }
        val end = if (b.toMs > 0) b.toMs else mp.duration.toLong()
        try {
            val v = if (voice.muted) 0f else 1f
            mp.setVolume(v, v)
            val pos = if (songEnded) end else mp.currentPosition.toLong()
            if (pos < b.fromMs - 500 || pos >= end) { songEnded = false; mp.seekTo(b.fromMs.toInt()) }
            if (!mp.isPlaying) mp.start()
        } catch (_: Exception) { sayAll(b.lines.map { it.second }, my, done); return }
        main.post(object : Runnable {
            override fun run() {
                if (my != token || paused || destroyed) return
                val pos = if (songEnded) end else try { mp.currentPosition.toLong() } catch (_: Exception) { end }
                b.lines.lastOrNull { it.first <= pos }?.let { if (subtitle.text != it.second) subtitle.text = it.second }
                if (pos >= end - 100) {
                    if (b.toMs == 0L) stopSong() // the song is over
                    done()
                    return
                }
                main.postDelayed(this, 120)
            }
        })
    }

    /** The song's lines said one after another (no recording, or it couldn't play). */
    private fun sayAll(lines: List<String>, my: Int, done: () -> Unit) {
        if (lines.isEmpty()) { done(); return }
        subtitle.text = lines.first()
        voice.say(lines.first()) { if (my == token && !paused) sayAll(lines.drop(1), my, done) }
    }

    private fun stopSong() {
        val p = songPlayer ?: return
        songPlayer = null
        try { p.release() } catch (_: Exception) {}
    }

    private fun micGranted() = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Pitzki can listen right now: the parent allows it, the phone allows the microphone, and can recognize speech. */
    private fun canListen() = PitzkiStore.listenOn(this) && micGranted() && ears.available()

    private fun showMic() {
        if (!::micBtn.isInitialized) return
        micBtn.text = if (PitzkiStore.listenOn(this)) L.t("🎤 מיקרופון פועל", "🎤 Mic on") else L.t("🎤 מיקרופון כבוי", "🎤 Mic off")
        micBtn.alpha = if (PitzkiStore.listenOn(this)) 1f else 0.6f
    }

    /** The first time: a little cloud by the microphone button says what it is and how to turn it off. */
    private fun showMicTip() {
        if (PitzkiStore.micTipShown(this)) return
        PitzkiStore.setMicTipShown(this)
        val tip = TextView(this).apply {
            text = L.t("🎤 פיצקי מקשיב לתשובות של הילד ועונה לו.\nלא מתאים? לחצו על הכפתור הזה כדי לכבות.", "🎤 Pitzki listens to the child's answers and replies.\nNot right for your child? Tap this button to turn it off.")
            textSize = 14f
            setTextColor(DS.ink(this@PitzkiActivity))
            background = DS.rounded(DS.bg(this@PitzkiActivity), ui.dp(18).toFloat())
            elevation = ui.dp(10).toFloat()
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.LEFT).apply { topMargin = ui.dp(56); leftMargin = ui.dp(12) }
            setOnClickListener { visibility = View.GONE }
        }
        stage.addView(tip)
        tip.alpha = 0f
        tip.animate().alpha(1f).setStartDelay(1200).setDuration(400).start()
        main.postDelayed({ tip.animate().alpha(0f).setDuration(500).withEndAction { tip.visibility = View.GONE }.start() }, 10_000)
    }

    /** A slow, gentle push-in: the forest feels alive, never jumpy (ages 3–5). */
    private fun kenBurns() {
        sceneImg.animate().cancel()
        sceneImg.scaleX = 1f; sceneImg.scaleY = 1f; sceneImg.translationX = 0f
        sceneImg.animate().scaleX(1.12f).scaleY(1.12f).translationX(-ui.dp(18).toFloat())
            .setDuration(28_000).setInterpolator(android.view.animation.LinearInterpolator()).start()
    }

    private fun jump(index: Int) {
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        ears.stop()
        stopSong()
        listening.visibility = View.GONE
        asking = null
        sceneIdx = index; beatIdx = 0
        paused = false
        pausedLayer.visibility = View.GONE
        showScene()
        runBeat()
    }

    private fun pause() {
        paused = true
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        if (::pausedLayer.isInitialized) pausedLayer.visibility = View.VISIBLE
        try { songPlayer?.takeIf { it.isPlaying }?.pause() } catch (_: Exception) {}
        ears.stop()
        if (::listening.isInitialized) listening.visibility = View.GONE
        sceneImg.animate().cancel()
        try { clipPlayer?.takeIf { it.isPlaying }?.pause() } catch (_: Exception) {}
    }

    private fun resume() {
        paused = false
        pausedLayer.visibility = View.GONE
        kenBurns()
        if (!clipEnded) try { clipPlayer?.start() } catch (_: Exception) {}
        runBeat() // the current line again, from its start
    }

    private fun next() {
        beatIdx++
        if (beatIdx >= scenes[sceneIdx].beats.size) {
            if (sceneIdx + 1 >= scenes.size) { finishLesson(); return }
            sceneIdx++
            beatIdx = 0
            showScene()
        }
        runBeat()
    }

    private fun runBeat() {
        if (!inLesson || paused || destroyed) return
        val my = ++token
        fun then() { if (my == token && !paused) next() }
        when (val b = scenes[sceneIdx].beats[beatIdx]) {
            is Beat.Say -> {
                subtitle.text = b.text
                voice.say(b.text, if (b.personal) "" else b.id) { then() }
            }
            is Beat.Word -> {
                showWord(b.color)
                bounce(b.color)
                voice.word(b.color.en) { then() }
            }
            is Beat.Wait -> main.postDelayed({ then() }, b.ms)
            is Beat.Listen -> {
                if (!canListen()) { main.postDelayed({ then() }, 2500); return }
                listening.text = L.t("🎤 פיצקי מקשיב… איזה צבע?", "🎤 Pitzki is listening… what color?")
                listening.visibility = View.VISIBLE
                pulse(listening)
                ears.listen(6500) { heard, said ->
                    if (my != token || paused || destroyed) { listening.visibility = View.GONE; return@listen }
                    // What the phone heard, for a moment (so a parent sees that it really listens).
                    val first = heard.firstOrNull { it.isNotBlank() }
                    if (first != null) {
                        listening.text = L.t("👂 שמעתי: ", "👂 I heard: ") + first.take(30)
                        main.postDelayed({ if (my == token) listening.visibility = View.GONE }, 1800)
                    } else listening.visibility = View.GONE
                    val c = PitzkiScript.heard(heard)
                    when {
                        c == b.color -> {
                            starsNow++
                            starsLabel.text = "⭐ $starsNow"
                            celebrate()
                            val p = PitzkiScript.rightSaid(kid)
                            subtitle.text = p
                            voice.say(p) { then() }
                        }
                        c != null -> {
                            // In short pieces, each in Pitzki's own voice (not the phone's).
                            sayAll(PitzkiScript.wrongSaidParts(kid, c, b.color), my) { then() }
                        }
                        said -> {
                            val t = PitzkiScript.notHeard(kid)
                            subtitle.text = t
                            voice.say(t) { then() }
                        }
                        // Nothing heard at all: Pitzki says it with them, so the turn never just passes silently.
                        else -> {
                            val t = PitzkiScript.notHeard(kid)
                            subtitle.text = t
                            voice.say(t) { then() }
                        }
                    }
                }
            }
            is Beat.Ask -> {
                asking = b.color
                misses = 0
                showStrip(true)
                val seq = ++askSeq
                items[b.color]?.let { pulse(it) }
                // No answer for a while: Pitzki shows it, kindly.
                main.postDelayed({ if (my == token && asking == b.color && askSeq == seq) help(b.color) }, 12_000)
            }
            is Beat.Song -> sing(b, my) { then() }
            is Beat.Celebrate -> {
                celebrate()
                val p = PitzkiScript.praise(kid, praiseN++)
                subtitle.text = p
                voice.say(p) { then() }
            }
        }
    }

    private fun tap(c: PColor) {
        if (!inLesson) return
        bounce(c)
        val wanted = asking
        if (wanted == null || paused) { showWord(c); return } // just exploring: the word, no score
        val my = ++token // the waiting for an answer ends here
        if (c == wanted) {
            asking = null
            starsNow++
            starsLabel.text = "⭐ $starsNow"
            celebrate()
            val p = PitzkiScript.praise(kid, praiseN++)
            subtitle.text = p
            voice.say(p) { if (my == token && !paused) next() }
        } else {
            misses++
            if (misses >= 2) { help(wanted); return }
            val seq = ++askSeq
            sayAll(PitzkiScript.tryAgainParts(kid, c, wanted), my) {}
            main.postDelayed({ if (my == token && asking == wanted && askSeq == seq) help(wanted) }, 12_000)
        }
    }

    /** Shows the right answer, no score lost, and goes on. */
    private fun help(c: PColor) {
        asking = null
        val my = ++token
        items[c]?.let { pulse(it) }
        showWord(c)
        val t = PitzkiScript.showAnswer(c)
        subtitle.text = t
        voice.say(t) { if (my == token && !paused) next() }
    }

    /** The five things slide up when it's the child's turn, and step aside after. */
    private fun showStrip(on: Boolean) {
        if (on == (strip.visibility == View.VISIBLE)) return
        strip.animate().cancel()
        if (on) {
            strip.visibility = View.VISIBLE
            strip.translationY = ui.dp(80).toFloat(); strip.alpha = 0f
            strip.animate().translationY(0f).alpha(1f).setDuration(350).start()
        } else {
            strip.animate().translationY(ui.dp(80).toFloat()).alpha(0f).setDuration(300).withEndAction { strip.visibility = View.GONE }.start()
        }
    }

    private fun showWord(c: PColor) {
        wordBubble.text = c.en
        wordBubble.setTextColor(colorOf(c))
        wordBubble.visibility = View.VISIBLE
        wordBubble.scaleX = 0.5f; wordBubble.scaleY = 0.5f
        wordBubble.animate().scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(android.view.animation.OvershootInterpolator()).start()
    }

    private fun bounce(c: PColor) {
        val v = items[c] ?: return
        v.animate().cancel()
        v.scaleX = 1f; v.scaleY = 1f
        v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(140).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(160).start() }.start()
    }

    private fun pulse(v: View) {
        v.animate().cancel()
        v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(450).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(450).start()
        }.start()
    }

    private fun celebrate() {
        burst.visibility = View.VISIBLE
        burst.alpha = 1f; burst.scaleX = 0.3f; burst.scaleY = 0.3f
        burst.animate().scaleX(1.4f).scaleY(1.4f).alpha(0f).setDuration(1100).withEndAction { burst.visibility = View.GONE }.start()
    }

    private fun finishLesson() {
        asking = null
        chosen?.let { PitzkiStore.addStars(this, it.memberId, starsNow); PitzkiStore.markDone(this, it.memberId) }
        celebrate()
        subtitle.text = if (kid.named) L.t("כל הכבוד, ${kid.name}! $starsNow כוכבים ⭐", "Well done, ${kid.name}! $starsNow stars ⭐")
            else L.t("כל הכבוד! $starsNow כוכבים ⭐", "Well done! $starsNow stars ⭐")
        // The end: once more, or back to the start screen.
        strip.visibility = View.GONE
        pausedLayer.removeAllViews()
        pausedLayer.setOnClickListener(null)
        pausedLayer.addView(TextView(this).apply {
            text = L.t("עוד פעם ↻", "Again ↻"); textSize = 20f; typeface = DS.emphasis; gravity = Gravity.CENTER
            setTextColor(DS.onButton(this@PitzkiActivity))
            background = DS.buttonBackground(this@PitzkiActivity, primary = true)
            setPadding(ui.dp(26), ui.dp(14), ui.dp(26), ui.dp(14))
            setOnClickListener { startLesson() }
        })
        pausedLayer.addView(TextView(this).apply {
            text = L.t("סיום", "Done"); textSize = 20f; typeface = DS.emphasis; gravity = Gravity.CENTER
            setTextColor(DS.ink(this@PitzkiActivity))
            background = DS.buttonBackground(this@PitzkiActivity, primary = false)
            setPadding(ui.dp(26), ui.dp(14), ui.dp(26), ui.dp(14))
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = ui.dp(16) }
            setOnClickListener { stopLesson(); setup() }
        })
        main.postDelayed({ if (!destroyed && inLesson) { paused = true; pausedLayer.visibility = View.VISIBLE } }, 2500)
    }
}
