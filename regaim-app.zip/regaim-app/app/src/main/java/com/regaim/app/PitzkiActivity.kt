package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * "The magic forest with Pitzki": a colors lesson for ages 3–5 where the child walks with Pitzki.
 * The child comes from what the family already has: the character approved in a book, or their photo; the
 * family's own moments show up for each color ("and at home too!"). With one tap the parent can have the 8 forest
 * scenes drawn with the child inside them (kept on the phone, drawn again only when the child's look changes).
 */
class PitzkiActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, PitzkiActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var voice: PitzkiVoice
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val scan = Executors.newSingleThreadExecutor() // the family's photos: may take a few seconds
    private var destroyed = false

    private var children: List<PitzkiStore.Child> = emptyList()
    private var chosen: PitzkiStore.Child? = null
    private val kid: PitzkiKid get() = chosen?.kid ?: PitzkiKid("", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        ui = Ui(this)
        voice = PitzkiVoice(this)
        children = PitzkiStore.children(this)
        chosen = children.firstOrNull()
        setup()
    }

    override fun onPause() {
        super.onPause()
        if (inLesson && !paused) pause()
    }

    override fun onDestroy() {
        destroyed = true
        token++
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        stopClip()
        clipIo.shutdown()
        bg.shutdownNow()
        scan.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inLesson) { stopLesson(); setup() } else super.onBackPressed()
    }

    // =====================================================================
    // The start screen (for the parent)
    // =====================================================================

    private var setupBox: LinearLayout? = null

    private fun setup() {
        inLesson = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val scroll = ScrollView(this).apply { setBackgroundColor(DS.bg(this@PitzkiActivity)); isFillViewport = true }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(12), ui.dp(20), ui.dp(32))
        }
        scroll.addView(box)
        setupBox = box
        setContentView(scroll)
        renderSetup()
        watchDrawing()
    }

    private fun renderSetup() {
        val box = setupBox ?: return
        box.removeAllViews()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(DS.ink(this@PitzkiActivity))
            setPadding(ui.dp(4), ui.dp(8), ui.dp(16), ui.dp(8))
            contentDescription = L.t("סגירה", "Close")
            setOnClickListener { finish() }
        })
        top.addView(ui.text(L.t("היער של פיצקי", "Pitzki's forest"), 18f).apply { typeface = DS.emphasis })
        box.addView(top)

        // Pitzki himself.
        val hero = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(230)).apply { topMargin = ui.dp(8) }
            background = DS.rounded(DS.card(this@PitzkiActivity), DS.radiusMedia(this@PitzkiActivity))
            clipToOutline = true
        }
        hero.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            PitzkiStore.art(this@PitzkiActivity, "face")?.let { setImageBitmap(it) }
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        })
        box.addView(hero)
        box.addView(ui.heading(L.t("שלום, אני פיצקי", "Hi, I'm Pitzki"), 28f, top = 14))
        box.addView(ui.text(L.t("טיול קצר ביער: חמישה צבעים בעברית ובאנגלית, והילד/ה שלכם בתוך הסיפור. לגילאי 3–5, בלי פרסומות ובלי צ׳אט.",
            "A short forest walk: five colors in Hebrew and English, with your child in the story. Ages 3–5, no ads, no chat."), 15f, R.color.ink_soft, top = 6))

        // Who goes on the walk.
        if (children.isNotEmpty()) {
            box.addView(ui.section(L.t("מי יוצא לטיול?", "Who's coming?")))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(10), 0, 0) }
            for (c in children) row.addView(childChip(c))
            box.addView(ui.scrollRow(row, top = 0))
        } else {
            box.addView(ui.hint(L.t("טיפ: הוסיפו את הילדים בפרופיל המשפחה, ופיצקי יפנה אליהם בשם ויצייר אותם ביער.",
                "Tip: add your kids in the family profile, and Pitzki will call them by name and draw them in the forest."), top = 14))
        }

        chosen?.let { box.addView(childCard(it)) }

        // Go.
        box.addView(ui.button(L.t("יוצאים לטיול ›", "Let's go ›"), primary = true, top = 22) { startLesson() })
        val stars = chosen?.let { PitzkiStore.stars(this, it.memberId) } ?: 0
        val done = chosen?.let { PitzkiStore.lessonsDone(this, it.memberId) } ?: 0
        if (done > 0) box.addView(ui.hint(L.t("⭐ $stars כוכבים · $done טיולים", "⭐ $stars stars · $done walks"), top = 8).apply { gravity = Gravity.CENTER })
        // Said once the phone's voices are known: no Hebrew voice means subtitles only.
        main.postDelayed({
            if (!destroyed && !inLesson && !voice.heOk && setupBox === box) box.addView(ui.hint(
                L.t("בטלפון הזה אין קול בעברית, אז פיצקי ידבר בכתוביות. אפשר להוסיף קול עברי בהגדרות הטלפון ‹ נגישות ‹ פלט טקסט לדיבור.",
                    "This phone has no Hebrew voice, so Pitzki will speak in subtitles. You can add a Hebrew voice in the phone's text-to-speech settings."), top = 12))
        }, 1500)
    }

    private fun childChip(c: PitzkiStore.Child): View {
        val on = chosen?.memberId == c.memberId
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ui.dp(6), 0, ui.dp(6), 0)
            alpha = if (on) 1f else 0.6f
            setOnClickListener { chosen = c; renderSetup() }
        }
        col.addView(lookCircle(c, 64, ring = on))
        col.addView(ui.text(c.kid.name, 14f, R.color.ink, top = 4).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (on) typeface = DS.emphasis
        })
        return col
    }

    /** The child's look in a circle (book character, or photo), or their initial. */
    private fun lookCircle(c: PitzkiStore.Child, sizeDp: Int, ring: Boolean): View {
        val size = ui.dp(sizeDp)
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            background = DS.oval(if (ring) DS.button(this@PitzkiActivity) else DS.line(this@PitzkiActivity))
        }
        val inset = ui.dp(if (ring) 3 else 1)
        val bmp = c.look?.let { Avatars.photo(it.file.absolutePath, size * 2) }
        if (bmp != null) frame.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = RoundVideo.OVAL
            clipToOutline = true
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(inset, inset, inset, inset) }
        }) else {
            val (bgc, fg) = DS.avatar(this, c.kid.name)
            frame.addView(TextView(this).apply {
                text = Avatars.initial(c.kid.name)
                gravity = Gravity.CENTER
                textSize = sizeDp / 2.6f
                typeface = DS.heading
                setTextColor(fg)
                background = DS.oval(bgc)
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(inset, inset, inset, inset) }
            })
        }
        return frame
    }

    /** What Pitzki knows about the child: their look, and whether the forest scenes are drawn with them. */
    private fun childCard(c: PitzkiStore.Child): View {
        val card = ui.card(top = 14)
        val name = c.kid.name
        val look = c.look
        card.addView(ui.text(when {
            look == null -> L.t("אין עדיין תמונה של $name", "No picture of $name yet")
            look.drawn -> L.t("$name מגיע/ה עם הדמות המצוירת מהספר", "$name comes with the character from the book")
            else -> L.t("$name מגיע/ה עם התמונה מהפרופיל", "$name comes with the profile picture")
        }, 16f).apply { typeface = DS.emphasis })
        if (look == null) {
            card.addView(ui.hint(L.t("הוסיפו תמונה של $name בפרופיל המשפחה, או צרו ספר ילדים: הדמות שתאשרו שם תצטרף לפיצקי.",
                "Add a picture of $name in the family profile, or make a children's book: the character you approve there joins Pitzki."), top = 4))
            return card
        }
        val d = PitzkiStore.drawing?.takeIf { it.member == c.memberId }
        val clips = PitzkiStore.clips(this, c)
        when {
            d != null && !d.finished -> {
                card.addView(ui.hint(
                    if (d.phase == "anim") L.t("מנפישים: פיצקי ו$name זזים ומטיילים… ${d.animated} מתוך ${PitzkiScript.SCENES} (כמה דקות)", "Animating: Pitzki and $name come to life… ${d.animated} of ${PitzkiScript.SCENES} (a few minutes)")
                    else L.t("מציירים את $name בתוך היער… ${d.done} מתוך ${PitzkiScript.SCENES}", "Drawing $name in the forest… ${d.done} of ${PitzkiScript.SCENES}"), top = 4))
                card.addView(ui.hint(L.t("אפשר לצאת מהמסך, זה ממשיך.", "You can leave this screen; it keeps going."), top = 2))
            }
            PitzkiStore.scenesReady(this, c) -> {
                if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
                card.addView(ui.hint(
                    if (clips == PitzkiScript.SCENES) L.t("✓ הסרט של $name מוכן: 8 סצנות שבהן פיצקי ו$name זזים ומטיילים.", "✓ $name's film is ready: 8 scenes where Pitzki and $name move and explore.")
                    else if (clips > 0) L.t("✓ $name מצויר/ת ביער. $clips מתוך 8 סצנות כבר זזות.", "✓ $name is drawn in. $clips of 8 scenes already move.")
                    else L.t("✓ $name מצויר/ת בתוך היער, ב-8 סצנות (עדיין בלי תנועה).", "✓ $name is drawn into the forest, in 8 scenes (not moving yet)."), top = 4))
                card.addView(scenesStrip(c))
                if (clips < PitzkiScript.SCENES) card.addView(ui.button(
                    L.t("להנפיש: פיצקי ו$name ילכו ויטיילו", "Animate: Pitzki and $name walk and explore"), primary = true, top = 10) { confirmDraw(c, again = false, animate = true) })
                val row = ui.horizontal(top = 6)
                row.addView(ui.action(L.t("ליצור מחדש", "Make again")) { confirmDraw(c, again = true, animate = clips > 0) })
                row.addView(ui.action(L.t("למחוק", "Delete"), R.color.ds_error) {
                    PitzkiStore.deleteScenes(this, c.memberId); renderSetup()
                })
                card.addView(row)
            }
            else -> {
                if (d != null && d.failed.isNotEmpty()) card.addView(ui.text(d.failed, 14f, R.color.ds_error, top = 4))
                card.addView(ui.hint(
                    if (PitzkiStore.scenesOutdated(this, c)) L.t("נשמרה דמות חדשה של $name. אפשר ליצור את הסרט מחדש איתה.", "A new look of $name was saved. You can make the film again with it.")
                    else L.t("בינתיים $name מופיע/ה בעיגול ליד פיצקי. בסרט עצמו $name נמצא/ת בתוך היער, הולך/ת ומטייל/ת עם פיצקי בכל 8 הסצנות. נוצר פעם אחת ונשמר בטלפון.",
                        "For now $name shows in a circle next to Pitzki. In the film itself $name is inside the forest, walking and exploring with Pitzki in all 8 scenes. Made once, kept on the phone."), top = 4))
                card.addView(ui.button(L.t("ליצור את הסרט של $name", "Make $name's film"), primary = true, top = 10) { confirmDraw(c, again = false, animate = true) })
                card.addView(ui.action(L.t("רק ציורים, בלי תנועה", "Drawings only, no motion")) { confirmDraw(c, again = false, animate = false) })
            }
        }
        return card
    }

    private fun scenesStrip(c: PitzkiStore.Child): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ui.dp(8), 0, 0) }
        for (n in 1..PitzkiScript.SCENES) {
            val f = PitzkiStore.sceneFile(this, c.memberId, n)
            row.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = DS.rounded(DS.buttonSecondary(this@PitzkiActivity), DS.radiusChip(this@PitzkiActivity))
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(ui.dp(96), ui.dp(72)).apply { marginEnd = ui.dp(6) }
                bg.execute {
                    val b = try { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 4 }) } catch (_: Throwable) { null }
                    main.post { if (!destroyed && b != null) setImageBitmap(b) }
                }
            })
        }
        return ui.scrollRow(row, top = 0)
    }

    /** Says exactly what is sent, then draws. */
    private fun confirmDraw(c: PitzkiStore.Child, again: Boolean, animate: Boolean = false) {
        val look = c.look ?: return
        if (!PitzkiStore.scenesReady(this, c) && !GeminiClient.hasKey(this) && AiGate.consented(this) && Account.signedIn(this)) {
            AlertDialog.Builder(this).setMessage(L.t("הציור עוד לא זמין בשרת. נסו שוב מאוחר יותר.", "Drawing isn't available on the server yet. Try again later.")).setPositiveButton(L.t("הבנתי", "OK"), null).show()
            return
        }
        AiGate.askConsent(this) {
            val what = if (look.drawn) L.t("הדמות המצוירת של ${c.kid.name} מהספר", "${c.kid.name}'s drawn character from the book")
                else L.t("התמונה של ${c.kid.name} מהפרופיל", "${c.kid.name}'s profile picture")
            AlertDialog.Builder(this)
                .setTitle(if (animate) L.t("ליצור את הסרט של ${c.kid.name}?", "Make ${c.kid.name}'s film?") else L.t("לצייר את ${c.kid.name} ביער?", "Draw ${c.kid.name} in the forest?"))
                .setMessage(L.t("נשלחים לשרת של Moments ומשם למודל הציור: $what ותמונה של פיצקי. נוצרים 8 ציורים (נספרים במכסה החודשית של המשפחה)", "Sent to Moments' server and from there to the drawing model: $what and a picture of Pitzki. 8 drawings are made (counted in the family's monthly allowance)") +
                    (if (animate) L.t(", ואז כל ציור קם לחיים לכמה שניות: פיצקי ו${c.kid.name} הולכים, מצביעים ומנופפים. ההנפשה משתמשת בקרדיט סרט אחד ולוקחת כמה דקות.", ", then each drawing comes to life for a few seconds: Pitzki and ${c.kid.name} walk, point and wave. The animation uses one film credit and takes a few minutes.") else ".") +
                    L.t(" הכול נשמר רק בטלפון. השרת לא שומר את התמונות.", " Everything is kept only on this phone. The server doesn't keep the pictures."))
                .setPositiveButton(if (animate) L.t("ליצור", "Make it") else L.t("לצייר", "Draw")) { _, _ ->
                    if (again) PitzkiStore.deleteScenes(this, c.memberId)
                    if (!PitzkiStore.drawScenes(this, c, animate)) android.widget.Toast.makeText(this, L.t("ציור אחר עוד רץ. רגע.", "Another drawing is still running."), android.widget.Toast.LENGTH_SHORT).show()
                    renderSetup()
                    watchDrawing()
                }
                .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
                .show()
        }
    }

    /** Refreshes the card while scenes are being drawn. */
    private fun watchDrawing() {
        val d = PitzkiStore.drawing ?: return
        if (d.finished) return
        var last = d.done * 100 + d.animated
        main.postDelayed(object : Runnable {
            override fun run() {
                if (destroyed || inLesson) return
                val now = d.done * 100 + d.animated
                if (now != last || d.finished) { last = now; renderSetup() }
                if (!d.finished) main.postDelayed(this, 700)
            }
        }, 700)
    }

    // =====================================================================
    // The lesson (for the child)
    // =====================================================================

    private var inLesson = false
    private var scenes: List<PitzkiScene> = emptyList()
    private var sceneIdx = 0
    private var beatIdx = 0
    private var token = 0
    private var paused = false
    private var asking: PColor? = null
    private var askSeq = 0
    private var misses = 0
    private var praiseN = 0
    private var starsNow = 0
    private var useDrawn = false
    @Volatile private var family: Map<PColor, Memory> = emptyMap()

    private lateinit var stage: FrameLayout
    private lateinit var sceneImg: ImageView
    private lateinit var objectView: TextView
    private lateinit var childBubble: View
    private lateinit var familyBubble: FrameLayout
    private lateinit var familyImg: ImageView
    private lateinit var wordBubble: TextView
    private lateinit var burst: TextView
    private lateinit var subtitle: TextView
    private lateinit var progress: LinearLayout
    private lateinit var starsLabel: TextView
    private lateinit var strip: LinearLayout
    private lateinit var pausedLayer: LinearLayout
    private val items = HashMap<PColor, View>()
    /** Changes with every scene, so a picture that loads late never lands on the next scene. */
    private var sceneSeq = 0
    private lateinit var clipView: android.view.TextureView
    private var clipPlayer: android.media.MediaPlayer? = null
    private var clipSurface: android.view.Surface? = null
    private var clipEnded = false
    private val clipIo = Executors.newSingleThreadExecutor() // opening a clip never on the main thread

    private fun colorOf(c: PColor) = ui.color(when (c) {
        PColor.GREEN -> R.color.pitzki_green
        PColor.BROWN -> R.color.pitzki_brown
        PColor.RED -> R.color.pitzki_red
        PColor.YELLOW -> R.color.pitzki_yellow
        PColor.GRAY -> R.color.pitzki_gray
    })

    private fun startLesson() {
        inLesson = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Like a film: sideways, the whole screen, no bars.
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        immersive(true)
        scenes = PitzkiScript.lesson(kid)
        sceneIdx = 0; beatIdx = 0; starsNow = 0; praiseN = 0; asking = null; paused = false
        useDrawn = chosen?.let { PitzkiStore.scenesReady(this, it) } == true
        family = emptyMap()
        val name = kid.name
        scan.execute {
            val found = try { PitzkiStore.familyPhotos(applicationContext, name) } catch (_: Throwable) { emptyMap() }
            family = found
        }
        buildLesson()
        showScene()
        runBeat()
    }

    private fun stopLesson() {
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        stopClip()
        inLesson = false
        immersive(false)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    private fun immersive(on: Boolean) {
        val c = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        } else c.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
    }

    private fun lp(w: Int, h: Int, gravity: Int) = FrameLayout.LayoutParams(w, h, gravity)
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    /**
     * The whole screen is the forest (sideways, like a film). Over it: the words Pitzki says (subtitles), the color
     * word in a bubble, the child, a family photo when there is one, and the five things to tap — only when it's
     * the child's turn. One tap anywhere pauses.
     */
    private fun buildLesson() {
        val black = DS.alpha(DS.ink(this), 1f)
        stage = FrameLayout(this).apply {
            setBackgroundColor(black)
            layoutDirection = View.LAYOUT_DIRECTION_LTR // positions are fixed to the art: Pitzki stands on the right
            // A tap pauses (not while it's the child's turn: little fingers tap everywhere).
            setOnClickListener { if (paused) resume() else if (asking == null) pause() }
        }
        sceneImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = lp(match, match, Gravity.CENTER) }
        stage.addView(sceneImg)
        // The scene come to life (when it was animated): plays over the still, then fades back to it.
        clipView = android.view.TextureView(this).apply { alpha = 0f; layoutParams = lp(match, match, Gravity.CENTER) }
        stage.addView(clipView)
        // Soft dark at the bottom so the subtitles read well over any picture.
        stage.addView(View(this).apply {
            setBackgroundResource(R.drawable.cover_scrim)
            layoutParams = lp(match, ui.dp(170), Gravity.BOTTOM)
        })
        stage.addView(View(this).apply {
            setBackgroundResource(R.drawable.scrim_top)
            layoutParams = lp(match, ui.dp(70), Gravity.TOP)
        })

        objectView = TextView(this).apply {
            textSize = 70f
            gravity = Gravity.CENTER
            background = DS.oval(DS.alpha(DS.bg(this@PitzkiActivity), 0.9f))
            elevation = ui.dp(6).toFloat()
            visibility = View.GONE
            layoutParams = lp(ui.dp(150), ui.dp(150), Gravity.CENTER).apply { rightMargin = ui.dp(60) }
        }
        stage.addView(objectView)
        childBubble = chosen?.let { lookCircle(it, 150, ring = true) } ?: View(this)
        childBubble.layoutParams = lp(ui.dp(150), ui.dp(150), Gravity.LEFT or Gravity.CENTER_VERTICAL).apply { leftMargin = ui.dp(36); bottomMargin = ui.dp(20) }
        childBubble.elevation = ui.dp(8).toFloat()
        stage.addView(childBubble)
        familyBubble = FrameLayout(this).apply {
            background = DS.oval(DS.star(this@PitzkiActivity))
            elevation = ui.dp(10).toFloat()
            visibility = View.GONE
            layoutParams = lp(ui.dp(140), ui.dp(140), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(40) }
        }
        familyImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = RoundVideo.OVAL
            clipToOutline = true
            layoutParams = FrameLayout.LayoutParams(match, match).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) }
        }
        familyBubble.addView(familyImg)
        stage.addView(familyBubble)
        wordBubble = TextView(this).apply {
            textSize = 44f
            typeface = DS.heading
            gravity = Gravity.CENTER
            setPadding(ui.dp(28), ui.dp(6), ui.dp(28), ui.dp(10))
            background = DS.rounded(DS.alpha(DS.bg(this@PitzkiActivity), 0.96f), ui.dp(34).toFloat())
            elevation = ui.dp(8).toFloat()
            visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.RIGHT).apply { topMargin = ui.dp(34); rightMargin = ui.dp(170) }
        }
        stage.addView(wordBubble)
        burst = TextView(this).apply {
            text = "⭐"; textSize = 110f; gravity = Gravity.CENTER; visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.CENTER)
        }
        stage.addView(burst)

        // Subtitles: what Pitzki says, large and white, at the bottom.
        subtitle = TextView(this).apply {
            textSize = 24f
            typeface = DS.emphasis
            gravity = Gravity.CENTER
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(10f, 0f, 2f, DS.scrim(this@PitzkiActivity))
            textDirection = View.TEXT_DIRECTION_RTL
            maxLines = 2
            layoutParams = lp(match, wrap, Gravity.BOTTOM).apply { leftMargin = ui.dp(90); rightMargin = ui.dp(90); bottomMargin = ui.dp(18) }
        }
        stage.addView(subtitle)

        // The five things to tap: slide up only when it's the child's turn.
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = lp(wrap, wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ui.dp(76) }
        }
        items.clear()
        for (c in PitzkiScript.ORDER) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = DS.pressable(this@PitzkiActivity, DS.rounded(DS.alpha(DS.bg(this@PitzkiActivity), 0.95f), ui.dp(22).toFloat()))
                elevation = ui.dp(6).toFloat()
                setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
                layoutParams = LinearLayout.LayoutParams(ui.dp(96), wrap).apply { marginStart = ui.dp(6); marginEnd = ui.dp(6) }
                contentDescription = "${c.he}, ${c.en}"
                setOnClickListener { tap(c) }
            }
            item.addView(TextView(this).apply { text = c.emoji; textSize = 38f; gravity = Gravity.CENTER })
            item.addView(TextView(this).apply {
                text = c.en; textSize = 15f; gravity = Gravity.CENTER; typeface = DS.heading
                setTextColor(colorOf(c))
            })
            items[c] = item
            strip.addView(item)
        }
        stage.addView(strip)

        // Top: close (right), where we are (dots), stars and sound (left).
        stage.addView(TextView(this).apply {
            text = "✕"; textSize = 22f; setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(8f, 0f, 1f, DS.scrim(this@PitzkiActivity))
            setPadding(ui.dp(18), ui.dp(12), ui.dp(18), ui.dp(12))
            contentDescription = L.t("יציאה", "Exit")
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.RIGHT)
            setOnClickListener { stopLesson(); setup() }
        })
        progress = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(20) }
        }
        repeat(scenes.size) {
            progress.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(ui.dp(26), ui.dp(4)).apply { marginStart = ui.dp(3); marginEnd = ui.dp(3) }
            })
        }
        stage.addView(progress)
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(wrap, wrap, Gravity.TOP or Gravity.LEFT).apply { topMargin = ui.dp(8); leftMargin = ui.dp(12) }
        }
        starsLabel = TextView(this).apply {
            text = "⭐ 0"; textSize = 18f; typeface = DS.heading
            setTextColor(DS.onPhoto(this@PitzkiActivity))
            setShadowLayer(8f, 0f, 1f, DS.scrim(this@PitzkiActivity))
            setPadding(ui.dp(6), ui.dp(6), ui.dp(10), ui.dp(6))
        }
        left.addView(TextView(this).apply {
            text = if (voice.muted) "🔇" else "🔊"; textSize = 18f
            setPadding(ui.dp(6), ui.dp(6), ui.dp(10), ui.dp(6))
            contentDescription = L.t("קול", "Sound")
            setOnClickListener { voice.muted = !voice.muted; text = if (voice.muted) "🔇" else "🔊" }
        })
        left.addView(starsLabel)
        stage.addView(left)

        // Paused: a calm layer with play, scene again and next scene.
        pausedLayer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(DS.scrimSoft(this@PitzkiActivity))
            visibility = View.GONE
            layoutParams = lp(match, match, Gravity.CENTER)
            setOnClickListener { resume() }
        }
        fun round(label: String, sizeDp: Int, primary: Boolean, desc: String, go: () -> Unit) = TextView(this).apply {
            text = label; textSize = if (primary) 30f else 22f; gravity = Gravity.CENTER
            setTextColor(if (primary) DS.onButton(this@PitzkiActivity) else DS.primary(this@PitzkiActivity))
            background = DS.pressable(this@PitzkiActivity, DS.oval(if (primary) DS.button(this@PitzkiActivity) else DS.bg(this@PitzkiActivity)), onDark = primary)
            contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(ui.dp(sizeDp), ui.dp(sizeDp)).apply { marginStart = ui.dp(18); marginEnd = ui.dp(18) }
            setOnClickListener { go() }
        }
        pausedLayer.addView(round("↻", 60, false, L.t("הסצנה מההתחלה", "Scene again")) { jump(sceneIdx) })
        pausedLayer.addView(round("▶", 88, true, L.t("המשך", "Play")) { resume() })
        pausedLayer.addView(round("⏭", 60, false, L.t("לסצנה הבאה", "Next scene")) { if (sceneIdx + 1 < scenes.size) jump(sceneIdx + 1) else resume() })
        stage.addView(pausedLayer)
        setContentView(stage)
    }

    private fun showProgress() {
        for (i in 0 until progress.childCount) progress.getChildAt(i).background =
            DS.rounded(if (i <= sceneIdx) DS.onPhoto(this) else DS.onPhoto(this, 0.35f), ui.dp(2).toFloat())
    }

    private fun showScene() {
        val s = scenes[sceneIdx]
        showProgress()
        wordBubble.visibility = View.GONE
        familyBubble.visibility = View.GONE
        burst.visibility = View.GONE
        strip.visibility = View.GONE
        val member = chosen?.memberId
        val drawn = if (useDrawn && member != null) PitzkiStore.sceneFile(this, member, s.n) else null
        // Drawn scenes: the child is in the picture. Otherwise Pitzki's forest, the thing, and the child in a circle.
        val seq = ++sceneSeq
        bg.execute {
            val b = try {
                if (drawn != null && drawn.exists()) BitmapFactory.decodeFile(drawn.absolutePath) else PitzkiStore.art(applicationContext, "forest")
            } catch (_: Throwable) { null }
            main.post {
                if (destroyed || seq != sceneSeq || !inLesson || b == null) return@post
                sceneImg.alpha = 0f
                sceneImg.setImageBitmap(b)
                sceneImg.animate().alpha(1f).setDuration(600).start()
            }
        }
        stopClip()
        if (member != null && useDrawn) PitzkiStore.clipFile(this, member, s.n).takeIf { it.exists() && it.length() > 0 }?.let { playClip(it, seq) }
        val c = s.color
        objectView.visibility = if (!useDrawn && c != null) View.VISIBLE else View.GONE
        if (c != null) objectView.text = c.emoji
        childBubble.visibility = if (useDrawn) View.GONE else View.VISIBLE
        kenBurns()
        if (objectView.visibility == View.VISIBLE) {
            objectView.scaleX = 0.4f; objectView.scaleY = 0.4f
            objectView.animate().scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(android.view.animation.OvershootInterpolator()).start()
        }
    }

    /** Plays a scene's animation once, silently (Pitzki talks over it), then its last frame stays on screen. */
    private fun playClip(f: java.io.File, seq: Int) {
        val st = clipView.surfaceTexture
        if (st == null) {
            clipView.surfaceTextureListener = object : android.view.TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(t: android.graphics.SurfaceTexture, w: Int, h: Int) { if (seq == sceneSeq && inLesson) playClip(f, seq) }
                override fun onSurfaceTextureSizeChanged(t: android.graphics.SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(t: android.graphics.SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(t: android.graphics.SurfaceTexture) {}
            }
            return
        }
        val mp = android.media.MediaPlayer()
        val surface = android.view.Surface(st)
        clipPlayer = mp
        clipSurface = surface
        clipEnded = false
        mp.setOnInfoListener { _, what, _ ->
            if (what == android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && clipPlayer === mp) {
                clipView.animate().alpha(1f).setDuration(400).start()
                sceneImg.animate().cancel()
            }
            false
        }
        mp.setOnCompletionListener {
            if (clipPlayer !== mp) return@setOnCompletionListener
            // The last frame stays on screen (where the characters ended up), no jump back to the still drawing.
            clipEnded = true
        }
        mp.setOnErrorListener { _, _, _ -> if (clipPlayer === mp) { clipEnded = true; clipView.alpha = 0f }; true }
        clipIo.execute {
            val ok = try {
                mp.setDataSource(f.absolutePath)
                mp.setSurface(surface)
                mp.setVolume(0f, 0f)
                mp.prepare()
                true
            } catch (_: Throwable) { false }
            main.post {
                if (clipPlayer !== mp || destroyed) return@post
                if (!ok) { stopClip(); return@post }
                try {
                    fillClip(mp.videoWidth, mp.videoHeight)
                    if (!paused) mp.start()
                } catch (_: Exception) { stopClip() }
            }
        }
    }

    /** The clip fills the screen (cropped, not stretched). */
    private fun fillClip(vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0 || clipView.width == 0 || clipView.height == 0) return
        val sx = clipView.width.toFloat() / vw
        val sy = clipView.height.toFloat() / vh
        val k = maxOf(sx, sy)
        clipView.setTransform(android.graphics.Matrix().apply { setScale(k / sx, k / sy, clipView.width / 2f, clipView.height / 2f) })
    }

    private fun stopClip() {
        val p = clipPlayer
        val sf = clipSurface
        clipPlayer = null
        clipSurface = null
        clipEnded = true
        if (::clipView.isInitialized) { clipView.animate().cancel(); clipView.alpha = 0f }
        if (p != null || sf != null) try {
            clipIo.execute {
                try { p?.release() } catch (_: Exception) {}
                try { sf?.release() } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    /** A slow, gentle push-in: the forest feels alive, never jumpy (ages 3–5). */
    private fun kenBurns() {
        sceneImg.animate().cancel()
        sceneImg.scaleX = 1f; sceneImg.scaleY = 1f; sceneImg.translationX = 0f
        sceneImg.animate().scaleX(1.12f).scaleY(1.12f).translationX(-ui.dp(18).toFloat())
            .setDuration(28_000).setInterpolator(android.view.animation.LinearInterpolator()).start()
    }

    private fun jump(index: Int) {
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        asking = null
        sceneIdx = index; beatIdx = 0
        paused = false
        pausedLayer.visibility = View.GONE
        showScene()
        runBeat()
    }

    private fun pause() {
        paused = true
        token++
        main.removeCallbacksAndMessages(null)
        voice.stop()
        if (::pausedLayer.isInitialized) pausedLayer.visibility = View.VISIBLE
        sceneImg.animate().cancel()
        try { clipPlayer?.takeIf { it.isPlaying }?.pause() } catch (_: Exception) {}
    }

    private fun resume() {
        paused = false
        pausedLayer.visibility = View.GONE
        kenBurns()
        if (!clipEnded) try { clipPlayer?.start() } catch (_: Exception) {}
        runBeat() // the current line again, from its start
    }

    private fun next() {
        beatIdx++
        if (beatIdx >= scenes[sceneIdx].beats.size) {
            if (sceneIdx + 1 >= scenes.size) { finishLesson(); return }
            sceneIdx++
            beatIdx = 0
            showScene()
        }
        runBeat()
    }

    private fun runBeat() {
        if (!inLesson || paused || destroyed) return
        val my = ++token
        fun then() { if (my == token && !paused) next() }
        when (val b = scenes[sceneIdx].beats[beatIdx]) {
            is Beat.Say -> {
                subtitle.text = b.text
                voice.say(b.text, if (b.personal) "" else b.id) { then() }
            }
            is Beat.Word -> {
                showWord(b.color)
                bounce(b.color)
                voice.word(b.color.en) { then() }
            }
            is Beat.Wait -> main.postDelayed({ then() }, b.ms)
            is Beat.Ask -> {
                asking = b.color
                misses = 0
                showStrip(true)
                val seq = ++askSeq
                items[b.color]?.let { pulse(it) }
                // No answer for a while: Pitzki shows it, kindly.
                main.postDelayed({ if (my == token && asking == b.color && askSeq == seq) help(b.color) }, 12_000)
            }
            is Beat.Family -> {
                val m = family[b.color]
                if (m == null) { then(); return }
                familyBubble.visibility = View.VISIBLE
                familyBubble.scaleX = 0.3f; familyBubble.scaleY = 0.3f
                familyBubble.animate().scaleX(1f).scaleY(1f).setDuration(500).setInterpolator(android.view.animation.OvershootInterpolator()).start()
                Covers.load(familyImg, m)
                subtitle.text = b.text
                voice.say(b.text) { then() }
            }
            is Beat.Celebrate -> {
                celebrate()
                val p = PitzkiScript.praise(kid, praiseN++)
                subtitle.text = p
                voice.say(p) { then() }
            }
        }
    }

    private fun tap(c: PColor) {
        if (!inLesson) return
        bounce(c)
        val wanted = asking
        if (wanted == null || paused) { showWord(c); return } // just exploring: the word, no score
        val my = ++token // the waiting for an answer ends here
        if (c == wanted) {
            asking = null
            starsNow++
            starsLabel.text = "⭐ $starsNow"
            celebrate()
            val p = PitzkiScript.praise(kid, praiseN++)
            subtitle.text = p
            voice.say(p) { if (my == token && !paused) next() }
        } else {
            misses++
            if (misses >= 2) { help(wanted); return }
            val t = PitzkiScript.tryAgain(kid, c, wanted)
            subtitle.text = t
            val seq = ++askSeq
            voice.say(t) {}
            main.postDelayed({ if (my == token && asking == wanted && askSeq == seq) help(wanted) }, 12_000)
        }
    }

    /** Shows the right answer, no score lost, and goes on. */
    private fun help(c: PColor) {
        asking = null
        val my = ++token
        items[c]?.let { pulse(it) }
        showWord(c)
        val t = PitzkiScript.showAnswer(c)
        subtitle.text = t
        voice.say(t) { if (my == token && !paused) next() }
    }

    /** The five things slide up when it's the child's turn, and step aside after. */
    private fun showStrip(on: Boolean) {
        if (on == (strip.visibility == View.VISIBLE)) return
        strip.animate().cancel()
        if (on) {
            strip.visibility = View.VISIBLE
            strip.translationY = ui.dp(80).toFloat(); strip.alpha = 0f
            strip.animate().translationY(0f).alpha(1f).setDuration(350).start()
        } else {
            strip.animate().translationY(ui.dp(80).toFloat()).alpha(0f).setDuration(300).withEndAction { strip.visibility = View.GONE }.start()
        }
    }

    private fun showWord(c: PColor) {
        wordBubble.text = c.en
        wordBubble.setTextColor(colorOf(c))
        wordBubble.visibility = View.VISIBLE
        wordBubble.scaleX = 0.5f; wordBubble.scaleY = 0.5f
        wordBubble.animate().scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(android.view.animation.OvershootInterpolator()).start()
    }

    private fun bounce(c: PColor) {
        val v = items[c] ?: return
        v.animate().cancel()
        v.scaleX = 1f; v.scaleY = 1f
        v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(140).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(160).start() }.start()
    }

    private fun pulse(v: View) {
        v.animate().cancel()
        v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(450).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(450).start()
        }.start()
    }

    private fun celebrate() {
        burst.visibility = View.VISIBLE
        burst.alpha = 1f; burst.scaleX = 0.3f; burst.scaleY = 0.3f
        burst.animate().scaleX(1.4f).scaleY(1.4f).alpha(0f).setDuration(1100).withEndAction { burst.visibility = View.GONE }.start()
    }

    private fun finishLesson() {
        asking = null
        chosen?.let { PitzkiStore.addStars(this, it.memberId, starsNow); PitzkiStore.markDone(this, it.memberId) }
        celebrate()
        subtitle.text = if (kid.named) L.t("כל הכבוד, ${kid.name}! $starsNow כוכבים ⭐", "Well done, ${kid.name}! $starsNow stars ⭐")
            else L.t("כל הכבוד! $starsNow כוכבים ⭐", "Well done! $starsNow stars ⭐")
        // The end: once more, or back to the start screen.
        strip.visibility = View.GONE
        pausedLayer.removeAllViews()
        pausedLayer.setOnClickListener(null)
        pausedLayer.addView(TextView(this).apply {
            text = L.t("עוד פעם ↻", "Again ↻"); textSize = 20f; typeface = DS.emphasis; gravity = Gravity.CENTER
            setTextColor(DS.onButton(this@PitzkiActivity))
            background = DS.buttonBackground(this@PitzkiActivity, primary = true)
            setPadding(ui.dp(26), ui.dp(14), ui.dp(26), ui.dp(14))
            setOnClickListener { startLesson() }
        })
        pausedLayer.addView(TextView(this).apply {
            text = L.t("סיום", "Done"); textSize = 20f; typeface = DS.emphasis; gravity = Gravity.CENTER
            setTextColor(DS.ink(this@PitzkiActivity))
            background = DS.buttonBackground(this@PitzkiActivity, primary = false)
            setPadding(ui.dp(26), ui.dp(14), ui.dp(26), ui.dp(14))
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = ui.dp(16) }
            setOnClickListener { stopLesson(); setup() }
        })
        main.postDelayed({ if (!destroyed && inLesson) { paused = true; pausedLayer.visibility = View.VISIBLE } }, 2500)
    }
}
