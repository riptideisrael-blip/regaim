package com.regaim.app

import android.content.Context

/**
 * The shared gallery of two parents: every moment one of them keeps (from the day it was turned on) is shared
 * automatically with the other parent only, not with the rest of the family circle. Short clips, a few at a time, in the
 * background. Both parents choose each other in the family circle screen (server/partner-gallery.sql).
 */
object PartnerShare {
    private fun p(ctx: Context) = Settings.prefs(ctx)

    /** Turned on (on this phone) since then; 0 = off. */
    fun since(ctx: Context): Long = p(ctx).getLong("partner_since", 0L)
    fun partner(ctx: Context): String = p(ctx).getString("partner_id", "").orEmpty()

    fun turnOn(ctx: Context, partnerId: String) {
        p(ctx).edit().putString("partner_id", partnerId).putLong("partner_since", if (since(ctx) > 0 && partner(ctx) == partnerId) since(ctx) else System.currentTimeMillis()).apply()
    }

    fun turnOff(ctx: Context) { p(ctx).edit().remove("partner_id").remove("partner_since").apply() }

    private fun doneKey(id: String) = "partner_shared_$id"

    /** Share also everything kept before it was turned on (moments and films), a few at a time in the background. */
    fun shareOld(ctx: Context) { p(ctx).edit().putLong("partner_since", 1L).apply() }
    fun sharingOld(ctx: Context) = since(ctx) == 1L

    @Volatile private var running = false

    /**
     * Background thread. Shares what the other parent doesn't have yet: moments kept since it was turned on (or all
     * of them, after [shareOld]) — films made in the app whole, other videos as short clips — and the children's
     * Pitzki films; and takes the Pitzki films the other parent shared. Never twice; a problem waits for next time.
     */
    fun sync(ctx: Context, max: Int = 30) {
        if (running) return
        val app = ctx.applicationContext
        val partner = partner(app)
        val from = since(app)
        if (partner.isEmpty() || from == 0L || !Circle.joined(app) || !Account.signedIn(app)) return
        // Any connection (mobile data too: most plans here have no limit).
        val cm = app.getSystemService(android.net.ConnectivityManager::class.java) ?: return
        if (cm.activeNetwork == null) return
        running = true
        try {
            // Only when both chose each other (the server checks it too).
            val status = Circle.partnerStatus(app) ?: return
            if (status.first != partner || !status.second) return
            receivePitzki(app, partner)
            sendPitzki(app, partner)
            var left = max
            while (left > 0) {
                val todo = MemoryStore.kept(app).filter { it.time >= from && !p(app).getBoolean(doneKey(it.id), false) }
                    .sortedByDescending { it.time }.take(minOf(5, left))
                if (todo.isEmpty()) break
                for (m in todo) {
                    Circle.shareMoment(app, m, Circle.Draft(Fmt.title(m), "", true, "plain"), onlyFor = partner, whole = m.origin == "film") { }
                    p(app).edit().putBoolean(doneKey(m.id), true).apply()
                    left--
                }
            }
        } catch (_: Exception) { // no connection, or the server isn't ready: next time
        } finally { running = false }
    }

    /** Each child's Pitzki film, when it changed since it was last sent (all its drawings and animations). */
    private fun sendPitzki(app: Context, partner: String) {
        for (c in PitzkiStore.children(app)) {
            val files = PitzkiStore.filmFiles(app, c.memberId)
            if (files.none { it.name.startsWith("clip_") }) continue
            val stamp = files.maxOf { it.lastModified() }
            val key = "partner_pitzki_${c.memberId}"
            if (p(app).getLong(key, 0L) == stamp) continue
            val folder = "pitzki/${c.memberId.filter { it.isLetterOrDigit() }.take(24)}-$stamp"
            val paths = org.json.JSONObject()
            for (f in files) paths.put(f.name, Circle.uploadForPartner(app, partner, "$folder/${f.name}", f, if (f.name.endsWith(".mp4")) "video/mp4" else "image/jpeg"))
            val cover = paths.optString("scene_${TrainWorld.INTRO}.jpg").ifEmpty { paths.optString("scene_intro.jpg") }.ifEmpty { paths.optString(paths.keys().next()) }
            Circle.postPitzkiFilm(app, partner, c.kid.name, cover, org.json.JSONObject().put("child", c.kid.name).put("files", paths))
            p(app).edit().putLong(key, stamp).apply()
        }
    }

    /** The other parent's Pitzki films: the newest for each child (matched by the child's name), once. */
    private fun receivePitzki(app: Context, partner: String) {
        val kids = PitzkiStore.children(app)
        if (kids.isEmpty()) return
        val seen = HashSet<String>()
        for ((postId, manifest) in Circle.pitzkiFilmsFrom(app, partner)) {
            val name = manifest.optString("child").trim()
            if (!seen.add(name)) continue // only the newest one of each child
            val key = "partner_pitzki_got_$postId"
            if (p(app).getBoolean(key, false)) continue
            val c = kids.firstOrNull { it.kid.name.trim() == name } ?: continue
            val files = manifest.optJSONObject("files") ?: continue
            val names = files.keys().asSequence().toList()
            val got = PitzkiStore.adoptFilm(app, c, names) { n, to -> Circle.downloadShared(app, files.optString(n), to) }
            if (got == names.size) p(app).edit().putBoolean(key, true).apply()
        }
    }
}
