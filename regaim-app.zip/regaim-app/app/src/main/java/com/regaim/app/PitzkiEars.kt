package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Pitzki's ears: listens a few seconds for the child's answer (the phone's own speech recognition, Hebrew; English
 * color words come through too). Main thread only. [listen]'s callback runs once: what was heard (best guesses first,
 * possibly empty) and whether the child said anything at all.
 */
class PitzkiEars(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var done: ((List<String>, Boolean) -> Unit)? = null
    private var partial: List<String> = emptyList()
    private var spoke = false
    private var seq = 0

    fun available(): Boolean = try { SpeechRecognizer.isRecognitionAvailable(ctx) } catch (_: Exception) { false }

    fun listen(ms: Long, onHeard: (List<String>, Boolean) -> Unit) {
        stop()
        val r = try { SpeechRecognizer.createSpeechRecognizer(ctx) } catch (_: Exception) { null }
        if (r == null) { onHeard(emptyList(), false); return }
        rec = r
        done = onHeard
        partial = emptyList()
        spoke = false
        val my = ++seq
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { spoke = true }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { if (my == seq) finish(partial, spoke) }
            override fun onResults(results: Bundle?) {
                if (my != seq) return
                val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                finish(if (l.isEmpty()) partial else l, true)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                if (my != seq) return
                val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (l.isNotEmpty()) partial = l
                // A color already heard: answer at once, a little child doesn't wait for the end of the sentence.
                if (PitzkiScript.heard(l) != null) finish(l, true)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // On the phone itself when it can (the child's voice stays on the phone).
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
        try { r.startListening(intent) } catch (_: Exception) { finish(emptyList(), false); return }
        main.postDelayed({ if (my == seq) finish(partial, spoke) }, ms)
    }

    private fun finish(heard: List<String>, said: Boolean) {
        val cb = done ?: return
        done = null
        seq++
        release()
        cb(heard, said)
    }

    /** Stops listening; the callback is not called. */
    fun stop() {
        done = null
        seq++
        release()
    }

    private fun release() {
        val r = rec ?: return
        rec = null
        try { r.cancel() } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }
}
