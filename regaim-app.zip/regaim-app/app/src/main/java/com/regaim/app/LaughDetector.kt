package com.regaim.app

import android.content.Context
import org.tensorflow.lite.support.audio.TensorAudio
import org.tensorflow.lite.task.audio.classifier.AudioClassifier

/**
 * Wraps Google's YAMNet sound classifier (runs fully on the phone, offline).
 * Input: ~1 second of 16 kHz mono audio. Output: the strongest "moment" sound.
 */
class LaughDetector(context: Context) {

    data class Result(val score: Float, val label: String, val top: String, val top3: String)

    private val classifier: AudioClassifier = AudioClassifier.createFromFile(context, "yamnet.tflite")
    private val tensor: TensorAudio = classifier.createInputTensorAudio()

    /** Number of samples the model expects (15600 for YAMNet). */
    val requiredSamples: Int = classifier.requiredInputBufferSize.toInt()

    fun classify(window: FloatArray): Result {
        tensor.load(window)
        val output = classifier.classify(tensor)
        // Laughter is spread over several classes (Laughter, Giggle, Baby laughter...),
        // so we add them up instead of taking only the strongest one.
        var group = 0f
        var best = 0f
        var bestLabel = ""
        val categories = output.firstOrNull()?.categories ?: emptyList()
        for (c in categories) {
            if (Labels.TRIGGERS.containsKey(c.label)) {
                group += c.score
                if (c.score > best) {
                    best = c.score
                    bestLabel = c.label
                }
            }
        }
        val sorted = categories.sortedByDescending { it.score }
        val top = sorted.firstOrNull()?.label ?: ""
        val top3 = sorted.take(3).joinToString(" · ") { "${Labels.he(it.label)} ${(it.score * 100).toInt()}%" }
        return Result(group.coerceAtMost(1f), bestLabel, top, top3)
    }

    fun close() {
        try {
            classifier.close()
        } catch (_: Exception) {
        }
    }
}
