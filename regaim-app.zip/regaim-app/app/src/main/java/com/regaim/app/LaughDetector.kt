package com.regaim.app

import android.content.Context
import org.tensorflow.lite.support.audio.TensorAudio
import org.tensorflow.lite.task.audio.classifier.AudioClassifier

/**
 * Wraps Google's YAMNet sound classifier (runs fully on the phone, offline).
 * Input: ~1 second of 16 kHz mono audio. Output: the strongest "moment" sound.
 */
class LaughDetector(context: Context) {

    data class Result(val score: Float, val label: String, val top: String)

    private val classifier: AudioClassifier = AudioClassifier.createFromFile(context, "yamnet.tflite")
    private val tensor: TensorAudio = classifier.createInputTensorAudio()

    /** Number of samples the model expects (15600 for YAMNet). */
    val requiredSamples: Int = classifier.requiredInputBufferSize.toInt()

    fun classify(window: FloatArray): Result {
        tensor.load(window)
        val output = classifier.classify(tensor)
        var best = 0f
        var bestLabel = ""
        var top = ""
        var topScore = 0f
        val categories = output.firstOrNull()?.categories ?: emptyList()
        for (c in categories) {
            if (c.score > topScore) {
                topScore = c.score
                top = c.label
            }
            if (Labels.TRIGGERS.containsKey(c.label) && c.score > best) {
                best = c.score
                bestLabel = c.label
            }
        }
        return Result(best, bestLabel, top)
    }

    fun close() {
        try {
            classifier.close()
        } catch (_: Exception) {
        }
    }
}
