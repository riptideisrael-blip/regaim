package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A video of a week or a month: a title card, then the best moments (a few seconds each), with music and the
 * Moments mark. Built with the same media3 pipeline as sharing.
 */
@OptIn(markerClass = [UnstableApi::class])
object PeriodVideo {
    enum class Period(private val he: String, private val en: String) {
        THIS_WEEK("השבוע", "This week"), LAST_WEEK("שבוע שעבר", "Last week"),
        THIS_MONTH("החודש", "This month"), LAST_MONTH("חודש שעבר", "Last month");
        val title: String get() = L.t(he, en)
        val videoTitle: String get() = when (this) {
            THIS_WEEK -> L.t("השבוע שלנו", "Our week")
            LAST_WEEK -> L.t("השבוע שעבר", "Last week")
            THIS_MONTH, LAST_MONTH -> L.t("החודש שלנו", "Our month")
        }
    }

    private const val MAX_ITEMS = 10
    private const val VIDEO_MS = 4500L
    private const val PHOTO_MS = 3500L
    private const val INTRO_MS = 2500L
    private val worker = Executors.newSingleThreadExecutor()

    /** [from, to) in epoch millis. */
    fun range(p: Period, now: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val day = 24L * 3600_000L
        fun monthStart(offset: Int) = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.MONTH, offset)
        }.timeInMillis
        return when (p) {
            Period.THIS_WEEK -> (now - 7 * day) to now + 1
            Period.LAST_WEEK -> (now - 14 * day) to (now - 7 * day)
            Period.THIS_MONTH -> monthStart(0) to now + 1
            Period.LAST_MONTH -> monthStart(-1) to monthStart(0)
        }
    }

    fun moments(ctx: Context, p: Period): List<Memory> {
        val (from, to) = range(p)
        return MemoryStore.all(ctx).filter { it.time in from until to }
    }

    /** The best moments of the period, in the order they happened. */
    fun pick(list: List<Memory>): List<Memory> = ReelMaker.best(list).take(MAX_ITEMS).sortedBy { it.time }

    fun seconds(picks: List<Memory>): Int = ((INTRO_MS + picks.sumOf { segmentLength(it) }) / 1000L).toInt()

    private fun segmentLength(m: Memory): Long =
        if (!m.isVideo) PHOTO_MS else if (m.durationMs in 1 until VIDEO_MS) m.durationMs else VIDEO_MS

    private fun segmentStart(m: Memory): Long {
        if (!m.isVideo || m.durationMs <= VIDEO_MS) return 0L
        val w = m.previewWindow
        val mid = if (w != null) (w.startMs + w.endMs) / 2 else m.highlight
        return (mid - VIDEO_MS / 2).coerceIn(0L, m.durationMs - VIDEO_MS)
    }

    private fun source(m: Memory): Uri = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.fromFile(File(m.uri))

    class Handle { @Volatile var cancel: (() -> Unit)? = null }

    /**
     * Builds the video. All callbacks run on the main thread.
     * [onDone] gets the finished file, or null and a message.
     */
    fun make(
        ctx: Context, period: Period, picks: List<Memory>, mood: Music.Mood?,
        onProgress: (Int) -> Unit, onDone: (File?, String?) -> Unit,
    ): Handle {
        val handle = Handle()
        val main = Handler(Looper.getMainLooper())
        val cancelled = AtomicBoolean(false)
        val finished = AtomicBoolean(false)
        handle.cancel = { cancelled.set(true) }
        worker.execute {
            val temp = ArrayList<File>()
            try {
                if (picks.isEmpty()) throw IllegalStateException(L.t("אין רגעים בתקופה הזאת", "No moments in this period"))
                // Output shape: portrait unless most clips are landscape.
                var portrait = 0
                var landscape = 0
                for (m in picks.filter { it.isVideo }) {
                    val (w, h) = SocialShare.displaySize(ctx, m)
                    if (h >= w) portrait++ else landscape++
                }
                val outW = if (landscape > portrait) 1280 else 720
                val outH = if (landscape > portrait) 720 else 1280

                val items = ArrayList<EditedMediaItem>()
                val withMark = Settings.prefs(ctx).getBoolean("share_watermark", true)
                val markBitmap = if (withMark) SocialShare.badge(ctx, (minOf(outW, outH) * 0.30f).toInt()) else null
                fun effects(): Effects {
                    val list = ArrayList<Effect>()
                    list.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
                    if (markBitmap != null) {
                        val settings = OverlaySettings.Builder()
                            .setBackgroundFrameAnchor(0.92f, -0.92f)
                            .setOverlayFrameAnchor(1f, -1f)
                            .setAlphaScale(0.92f)
                            .build()
                        list.add(OverlayEffect(ImmutableList.of(BitmapOverlay.createStaticBitmapOverlay(markBitmap, settings))))
                    }
                    return Effects(emptyList<AudioProcessor>(), list)
                }
                fun imageItem(file: File, ms: Long) = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(file)))
                    .setDurationUs(ms * 1000L).setFrameRate(30).setEffects(effects()).build()

                val card = File(ctx.cacheDir, "card_${System.currentTimeMillis()}.jpg").also { temp.add(it) }
                FileOutputStream(card).use { introCard(ctx, period, picks, outW, outH).compress(Bitmap.CompressFormat.JPEG, 92, it) }
                items.add(imageItem(card, INTRO_MS))
                var totalMs = INTRO_MS

                for (m in picks) {
                    if (m.isVideo) {
                        val start = segmentStart(m)
                        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(start + segmentLength(m)).build()
                        val mi = MediaItem.Builder().setUri(source(m)).setClippingConfiguration(clip).build()
                        items.add(EditedMediaItem.Builder(mi).setRemoveAudio(true).setEffects(effects()).build())
                        totalMs += segmentLength(m)
                    } else {
                        val bmp = MediaImages.decode(ctx, m.uri, 1600) ?: continue
                        val f = File(ctx.cacheDir, "photo_${System.nanoTime()}.jpg").also { temp.add(it) }
                        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                        items.add(imageItem(f, PHOTO_MS))
                        totalMs += PHOTO_MS
                    }
                }
                if (items.size < 2) throw IllegalStateException(L.t("לא הצלחנו לקרוא את הרגעים", "Couldn't read the moments"))

                val wav = if (mood != null) File(ctx.cacheDir, "music_${System.currentTimeMillis()}.wav").also {
                    temp.add(it); Music.renderWav(mood, totalMs, 0.8f, it)
                } else null

                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, "moments_${period.name.lowercase()}_${System.currentTimeMillis()}.mp4")
                main.post {
                    if (cancelled.get()) { temp.forEach { it.delete() }; return@post }
                    try {
                        val sequences = ArrayList<EditedMediaItemSequence>()
                        sequences.add(EditedMediaItemSequence(*items.toTypedArray()))
                        if (wav != null) sequences.add(EditedMediaItemSequence(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).setRemoveVideo(true).build()))
                        val transformer = Transformer.Builder(ctx)
                            .setVideoMimeType(MimeTypes.VIDEO_H264)
                            .addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    finished.set(true); temp.forEach { it.delete() }
                                    onDone(out, null)
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    finished.set(true); temp.forEach { it.delete() }; out.delete()
                                    onDone(null, L.t("לא הצלחנו ליצור את הסרטון. נסו תקופה אחרת או בלי מוזיקה.", "Couldn't create the video. Try another period, or no music."))
                                }
                            })
                            .build()
                        transformer.start(Composition.Builder(*sequences.toTypedArray()).build(), out.absolutePath)
                        handle.cancel = { cancelled.set(true); finished.set(true); try { transformer.cancel() } catch (_: Throwable) {}; temp.forEach { it.delete() }; out.delete() }
                        val holder = ProgressHolder()
                        val poll = object : Runnable {
                            override fun run() {
                                if (cancelled.get() || finished.get()) return
                                val state = try { transformer.getProgress(holder) } catch (_: Throwable) { Transformer.PROGRESS_STATE_NOT_STARTED }
                                if (state == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                                main.postDelayed(this, 500)
                            }
                        }
                        main.postDelayed(poll, 500)
                    } catch (t: Throwable) {
                        temp.forEach { it.delete() }
                        onDone(null, L.t("לא הצלחנו ליצור את הסרטון", "Couldn't create the video"))
                    }
                }
            } catch (e: Throwable) {
                temp.forEach { it.delete() }
                main.post { if (!cancelled.get()) onDone(null, e.message ?: L.t("לא הצלחנו ליצור את הסרטון", "Couldn't create the video")) }
            }
        }
        return handle
    }

    /** The first frame: a soft gradient, the Moments mark, the title and the dates. */
    private fun introCard(ctx: Context, period: Period, picks: List<Memory>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, w * 0.6f, h.toFloat(), Color.rgb(91, 79, 224), Color.rgb(229, 122, 111), Shader.TileMode.CLAMP)
        })
        val side = minOf(w, h)
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); textSize = side * 0.115f
        }
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(230, 255, 255, 255); textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.NORMAL); textSize = side * 0.05f
        }
        val cy = h / 2f
        c.drawText(period.videoTitle, w / 2f, cy, title)
        val first = picks.firstOrNull()?.time ?: System.currentTimeMillis()
        val label = if (period == Period.THIS_MONTH || period == Period.LAST_MONTH) Fmt.month(first)
        else java.text.SimpleDateFormat("d MMM", L.locale).let { f -> "${f.format(java.util.Date(picks.minOf { it.time }))} – ${f.format(java.util.Date(picks.maxOf { it.time }))}" }
        c.drawText(label, w / 2f, cy + side * 0.10f, sub)
        val mark = SocialShare.badge(ctx, (side * 0.34f).toInt())
        c.drawBitmap(mark, (w - mark.width) / 2f, h - mark.height - side * 0.08f, null)
        return bmp
    }
}
