package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.util.concurrent.Executors

/**
 * The first screen: welcome, then continue with Google, sign up with email, or sign in.
 * Also receives moments://auth when Google sign-in comes back from the browser.
 */
class WelcomeActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, WelcomeActivity::class.java))
    }

    private enum class Mode { START, SIGN_UP, SIGN_IN }

    private lateinit var ui: Ui
    private lateinit var root: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private var mode = Mode.START
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ui.dp(28), ui.dp(48), ui.dp(28), ui.dp(32))
        }
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(ContextCompat.getColor(this@WelcomeActivity, R.color.bg))
            addView(root)
        })
        render()
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    /** Back from the browser after "continue with Google". */
    private fun handle(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme != "moments" || uri.host != "auth") return
        run("מחברים אותך...") {
            if (!Account.handleRedirect(applicationContext, uri)) throw IllegalStateException("ההתחברות לא הושלמה")
        }
    }

    private fun run(text: String, work: () -> Unit) {
        if (busy) return
        busy = true
        render(text)
        worker.execute {
            val r = try { work(); null } catch (e: Exception) { e.message ?: "משהו השתבש" }
            runOnUiThread {
                busy = false
                if (isFinishing) return@runOnUiThread
                if (r == null && Account.signedIn(this)) done() else {
                    if (r != null) Toast.makeText(this, r, Toast.LENGTH_LONG).show()
                    render()
                }
            }
        }
    }

    private fun done() {
        val first = Profile.isEmpty(this)
        Toast.makeText(this, "שלום ${Account.name(this).split(" ").first().ifEmpty { "" }} ❤️".replace("  ", " "), Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        if (first) startActivity(Intent(this, ProfileActivity::class.java))
        finish()
    }

    // ---------- screens ----------

    private fun render(progress: String = "") {
        root.removeAllViews()
        if (mode == Mode.START && progress.isEmpty()) {
            root.setPadding(ui.dp(24), ui.dp(24), ui.dp(24), ui.dp(28))
            landing()
            start()
            return
        }
        root.setPadding(ui.dp(28), ui.dp(48), ui.dp(28), ui.dp(32))
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_mark)
            layoutParams = LinearLayout.LayoutParams(ui.dp(84), ui.dp(84)).apply { topMargin = ui.dp(24) }
        })
        root.addView(TextView(this).apply {
            text = "רגעים"
            textSize = 34f
            gravity = Gravity.CENTER
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
            setPadding(0, ui.dp(14), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "הזיכרונות של המשפחה, נשמרים לבד"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink_soft))
            setPadding(0, ui.dp(6), 0, ui.dp(30))
        })
        if (progress.isNotEmpty()) {
            root.addView(TextView(this).apply {
                text = progress
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.accent))
            }.also { MemoryViews(this).pulse(it) })
            return
        }
        when (mode) {
            Mode.START -> start()
            Mode.SIGN_UP -> form(signUp = true)
            Mode.SIGN_IN -> form(signUp = false)
        }
    }

    // ---------- landing ----------

    private val tileColors = listOf(
        0xFFFFD9B8.toInt() to 0xFFF6A97A.toInt(), 0xFFCFE3FF.toInt() to 0xFF8FB8F2.toInt(), 0xFFFFE3A8.toInt() to 0xFFF2B01E.toInt(),
        0xFFD6F0E0.toInt() to 0xFF7CCBA0.toInt(), 0xFFF3D4F0.toInt() to 0xFFD596CF.toInt(), 0xFFDAD6FA.toInt() to 0xFF9C93EE.toInt(),
    )
    private val tileEmoji = listOf("👶", "👨‍👩‍👧", "🎂", "🏖️", "👵", "🐶")

    /**
     * A photo tile. If a picture named landing_1 ... landing_6 exists in res/drawable-nodpi it is used;
     * until then, a warm colored tile stands in.
     */
    private fun photoTile(i: Int, heightDp: Int): View {
        val radius = ui.dp(20).toFloat()
        val resId = resources.getIdentifier("landing_${i + 1}", "drawable", packageName)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(heightDp)).apply { bottomMargin = ui.dp(10) }
        if (resId != 0) {
            return ImageView(this).apply {
                setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply { cornerRadius = radius; setColor(0xFFECE7E1.toInt()) }
                clipToOutline = true
                layoutParams = lp
            }
        }
        val (a, b) = tileColors[i % tileColors.size]
        return TextView(this).apply {
            text = tileEmoji[i % tileEmoji.size]
            textSize = 44f
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply { cornerRadius = radius }
            layoutParams = lp
        }
    }

    private fun landing() {
        val bgColor = ContextCompat.getColor(this, R.color.bg)
        // The picture wall: three columns, the middle one lower.
        val wall = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(330))
            clipChildren = true
        }
        val heights = listOf(listOf(150, 120), listOf(120, 160), listOf(160, 110))
        for (c in 0 until 3) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = if (c == 0) 0 else ui.dp(5); marginEnd = if (c == 2) 0 else ui.dp(5)
                }
                setPadding(0, if (c == 1) ui.dp(36) else 0, 0, 0)
            }
            for (r in 0 until 2) col.addView(photoTile(c * 2 + r, heights[c][r]))
            wall.addView(col)
        }
        val hero = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(330)) }
        hero.addView(wall)
        // Fade the pictures into the page.
        hero.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00FFFFFF and bgColor, bgColor))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(120), Gravity.BOTTOM)
        })
        root.addView(hero)
        MemoryViews(this).reveal(hero)

        root.addView(TextView(this).apply {
            text = "רגעים"
            textSize = 36f
            gravity = Gravity.CENTER
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
            setPadding(0, ui.dp(4), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "הרגעים הקטנים של המשפחה, נשמרים לבד"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink_soft))
            setPadding(0, ui.dp(6), 0, ui.dp(22))
        })

        val points = listOf(
            Triple("🎥", "תופס את הרגעים הטובים", "צחוק, חיבוק ושיר נשמרים לבד, בלי שתצטרכו להחזיק מצלמה ביד."),
            Triple("✨", "מבין מה קרה ומספר את זה", "כותרת, תיאור וסיפור שבועי עם מוזיקה, כדי לחזור לרגעים גם אחרי שנים."),
            Triple("👨‍👩‍👧", "משפחה אחת, מעגל פרטי", "משתפים רגעים נבחרים עם סבא וסבתא ועם מי שתזמינו, ורק איתם."),
        )
        for ((icon, title, body) in points) {
            val card = ui.card(top = 8)
            val line = ui.horizontal(top = 0)
            line.addView(TextView(this).apply { text = icon; textSize = 26f; setPadding(0, 0, ui.dp(12), 0) })
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            texts.addView(ui.text(title, 16f, bold = true))
            texts.addView(ui.hint(body, top = 2))
            line.addView(texts)
            card.addView(line)
            root.addView(card)
        }
        root.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, ui.dp(14)) })
    }

    private fun bigButton(text: String, filled: Boolean, onClick: () -> Unit): MaterialButton = MaterialButton(this).apply {
        this.text = text
        textSize = 16f
        setAllCaps(false)
        cornerRadius = ui.dp(28)
        insetTop = 0
        insetBottom = 0
        if (filled) {
            backgroundTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.white))
        } else {
            backgroundTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this@WelcomeActivity, R.color.white))
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
            strokeColor = android.content.res.ColorStateList.valueOf(0xFFE4E0D8.toInt())
            strokeWidth = ui.dp(1)
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(56)).apply { topMargin = ui.dp(12) }
        setOnClickListener { onClick() }
    }

    private fun start() {
        root.addView(bigButton("המשך עם Google", filled = false) {
            if (busy) return@bigButton
            busy = true
            worker.execute {
                val enabled = Account.googleEnabled(applicationContext)
                runOnUiThread {
                    busy = false
                    if (isFinishing) return@runOnUiThread
                    when (enabled) {
                        false -> Toast.makeText(this, "ההתחברות עם Google עוד לא הופעלה בשרת (Supabase). אפשר להירשם עם אימייל בינתיים.", Toast.LENGTH_LONG).show()
                        else -> try {
                            // null = could not check; try anyway, the browser shows the real answer.
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Account.googleUrl(this))))
                        } catch (_: Exception) {
                            Toast.makeText(this, "לא נמצא דפדפן בטלפון", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        })
        root.addView(bigButton("הרשמה עם אימייל", filled = true) { mode = Mode.SIGN_UP; render() })
        root.addView(link("כבר יש לי חשבון · התחברות", R.color.accent, 18) { mode = Mode.SIGN_IN; render() })
        root.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 0, 1f) })
        root.addView(link("להמשיך בלי חשבון", R.color.ink_soft, 28) {
            Account.skip(this)
            startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        })
        root.addView(ui.hint("הסרטונים נשמרים בטלפון שלכם. החשבון משמש לשיתוף עם המשפחה.", top = 10).apply { gravity = Gravity.CENTER })
    }

    private fun link(text: String, colorRes: Int, top: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 15f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(ContextCompat.getColor(this@WelcomeActivity, colorRes))
        setPadding(ui.dp(12), ui.dp(12), ui.dp(12), ui.dp(12))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(top) }
        setOnClickListener { onClick() }
    }

    private fun input(hint: String, type: Int): EditText = EditText(this).apply {
        this.hint = hint
        inputType = type
        textSize = 16f
        setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
        background = GradientDrawable().apply {
            cornerRadius = ui.dp(16).toFloat()
            setColor(0xFFFFFFFF.toInt())
            setStroke(ui.dp(1), 0xFFE4E0D8.toInt())
        }
        setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(10) }
    }

    private fun form(signUp: Boolean) {
        root.addView(TextView(this).apply {
            text = if (signUp) "יוצרים חשבון משפחתי" else "ברוכים השבים"
            textSize = 20f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@WelcomeActivity, R.color.ink))
        })
        val name = if (signUp) input("השם שלך", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PERSON_NAME).also { root.addView(it) } else null
        val email = input("אימייל", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS).also { root.addView(it) }
        val password = input("סיסמה (לפחות 6 תווים)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD).also { root.addView(it) }
        root.addView(bigButton(if (signUp) "יצירת חשבון" else "התחברות", filled = true) {
            val e = email.text.toString().trim()
            val pw = password.text.toString()
            val n = name?.text?.toString()?.trim().orEmpty()
            when {
                signUp && n.isEmpty() -> Toast.makeText(this, "איך לקרוא לך?", Toast.LENGTH_SHORT).show()
                !e.contains("@") -> Toast.makeText(this, "כתובת האימייל לא תקינה", Toast.LENGTH_SHORT).show()
                pw.length < 6 -> Toast.makeText(this, "הסיסמה צריכה להיות לפחות 6 תווים", Toast.LENGTH_SHORT).show()
                signUp -> run("יוצרים את החשבון...") {
                    if (!Account.signUp(applicationContext, n, e, pw)) {
                        throw IllegalStateException("שלחנו לך מייל לאישור. אחרי האישור, חזרו לכאן והתחברו.")
                    }
                }
                else -> run("מתחברים...") { Account.signIn(applicationContext, e, pw) }
            }
        })
        root.addView(link(if (signUp) "כבר יש לי חשבון · התחברות" else "אין לי חשבון · הרשמה", R.color.accent, 14) {
            mode = if (signUp) Mode.SIGN_IN else Mode.SIGN_UP
            render()
        })
        root.addView(link("‹ חזרה", R.color.ink_soft, 4) { mode = Mode.START; render() })
    }
}
