package com.regaim.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * "סטודיו": one clear place for everything you can MAKE from your moments —
 * a 3D animated film, a comic, a video with music, the story of the week.
 */
class StudioActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, StudioActivity::class.java))

        /** A grid of moments (videos first) to choose from. Shared by every "make something" entry point. */
        fun pickMoment(a: Activity, title: String, onPick: (Memory) -> Unit) {
            val all = MemoryStore.all(a)
            if (all.isEmpty()) {
                Toast.makeText(a, L.t("עוד אין רגעים. צלמו או הוסיפו רגע קודם.", "No moments yet. Capture or add one first."), Toast.LENGTH_LONG).show()
                return
            }
            val ui = Ui(a)
            val items = (all.filter { it.isVideo } + all.filter { !it.isVideo }).take(60)
            val grid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(8)) }
            if (items.any { it.isVideo }) grid.addView(ui.hint(L.t("סרטונים נותנים את התוצאה הכי טובה. הם מופיעים ראשונים.", "Videos give the best result. They're shown first."), top = 0))
            var dialog: AlertDialog? = null
            items.chunked(3).forEach { rowItems ->
                val r = LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(6) }
                }
                rowItems.forEachIndexed { i, m ->
                    val frame = FrameLayout(a).apply {
                        setBackgroundResource(R.drawable.rounded_media)
                        clipToOutline = true
                        layoutParams = LinearLayout.LayoutParams(0, ui.dp(120), 1f).apply { if (i > 0) marginStart = ui.dp(6) }
                        setOnClickListener { dialog?.dismiss(); onPick(m) }
                    }
                    val img = ImageView(a).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    }
                    frame.addView(img)
                    Covers.load(img, m)
                    frame.addView(TextView(a).apply {
                        text = if (m.isVideo) "▶ " + Fmt.shortDuration(m.durationMs) else Fmt.day(m.time)
                        textSize = 11f
                        setTextColor(0xFFFFFFFF.toInt())
                        setShadowLayer(4f, 0f, 1f, 0xAA000000.toInt())
                        setPadding(ui.dp(6), ui.dp(4), ui.dp(6), ui.dp(4))
                        layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
                    })
                    r.addView(frame)
                }
                repeat(3 - rowItems.size) { r.addView(View(a).apply { layoutParams = LinearLayout.LayoutParams(0, ui.dp(120), 1f).apply { marginStart = ui.dp(6) } }) }
                grid.addView(r)
            }
            dialog = AlertDialog.Builder(a)
                .setTitle(title)
                .setView(android.widget.ScrollView(a).apply { addView(grid) })
                .setNegativeButton(L.t("ביטול", "Cancel"), null)
                .show()
        }

        fun makeFilm(a: Activity) = pickMoment(a, L.t("איזה רגע להפוך לסרט מצויר?", "Which moment becomes a film?")) { CartoonFilmActivity.open(a, it.id) }
        fun makeComic(a: Activity) = pickMoment(a, L.t("מאיזה רגע לעשות קומיקס?", "Which moment becomes a comic?")) { ComicActivity.forMoment(a, it.id) }
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("✨ סטודיו", "✨ Studio")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        render()
    }

    private fun render() {
        content.removeAllViews()
        content.addView(ui.hint(L.t("כאן הופכים רגעים למשהו שאפשר לשלוח, להראות ולשמור.", "Turn your moments into something to send, show and keep."), top = 4))

        // The headline feature: big, dark, impossible to miss.
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_accent_bg)
            setPadding(ui.dp(22), ui.dp(22), ui.dp(22), ui.dp(22))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(16) }
            setOnClickListener { makeFilm(this@StudioActivity) }
        }
        hero.addView(TextView(this).apply {
            text = L.t("פרימיום ✨", "Premium ✨")
            textSize = 13f
            setTextColor(0xB3FFFFFF.toInt())
        })
        hero.addView(TextView(this).apply {
            text = L.t("🎬 סרט מצויר בתלת-ממד", "🎬 3D animated film")
            textSize = 26f
            typeface = Fonts.display
            setTextColor(ContextCompat.getColor(this@StudioActivity, R.color.white))
            setPadding(0, ui.dp(6), 0, 0)
        })
        hero.addView(TextView(this).apply {
            text = L.t("בוחרים רגע, ואנחנו מציירים אותו מחדש כדמויות אנימציה בתלת-ממד, בסגנון סרטי פיקסאר, ומחברים לסרט קצר עם מוזיקה.",
                "Pick a moment and we redraw it as 3D animated characters, Pixar-movie style, cut into a short film with music.")
            textSize = 15f
            setLineSpacing(ui.dp(3).toFloat(), 1f)
            setTextColor(0xDDFFFFFF.toInt())
            setPadding(0, ui.dp(8), 0, ui.dp(16))
        })
        hero.addView(TextView(this).apply {
            text = L.t("בחרו רגע ›", "Choose a moment ›")
            textSize = 16f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@StudioActivity, R.color.ink))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = ui.dp(26).toFloat(); setColor(ContextCompat.getColor(this@StudioActivity, R.color.surface)) }
            setPadding(ui.dp(16), ui.dp(13), ui.dp(16), ui.dp(13))
            setOnClickListener { makeFilm(this@StudioActivity) }
        })
        content.addView(hero)

        content.addView(ui.section(L.t("עוד דברים שאפשר ליצור", "More to make")))
        option(L.t("📖 קומיקס מרגע", "📖 Comic from a moment"),
            L.t("הרגע הופך לעמוד קומיקס עם סיפור. אפשר לבחור סגנון: ספר ילדים, מנגה, סקיצה ועוד.", "The moment becomes a comic page with a story. Styles: picture book, manga, sketch and more.")) { makeComic(this) }
        option(L.t("🎵 סרטון עם מוזיקה", "🎵 Video with music"),
            L.t("הרגעים הכי טובים של השבוע או החודש, ערוכים לסרטון אחד עם מוזיקה.", "The best moments of the week or month, edited into one video with music.")) { PeriodVideoActivity.open(this) }
        if (ReelMaker.weekMoments(this).isNotEmpty()) option(L.t("▶ הסיפור של השבוע", "▶ This week's story"),
            L.t("כל רגעי השבוע ברצף, כמו סטורי.", "All of this week's moments in a row, like a story.")) { StoryActivity.week(this) }
        option(L.t("📚 סיפורים לפי נושא", "📚 Stories by topic"),
            L.t("הרגעים שלכם מסודרים לפי נושאים: אמבטיה, משחק, טיולים ועוד.", "Your moments grouped by topic: bath time, play, outings and more.")) { StoriesActivity.open(this) }
    }

    private fun option(title: String, sub: String, go: () -> Unit) {
        val card = ui.card(top = 10)
        card.addView(ui.text(title, 18f, bold = true))
        card.addView(ui.hint(sub, top = 4))
        card.addView(ui.action(L.t("ליצירה ›", "Make it ›")) { go() })
        card.setOnClickListener { go() }
        content.addView(card)
    }
}
