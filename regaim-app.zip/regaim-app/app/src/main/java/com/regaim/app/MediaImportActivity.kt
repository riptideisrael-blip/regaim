package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/** Android's document picker grants access only to the selected family memory. */
class MediaImportActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_PICK_NOW = "pickNow"
        /** [pickNow]: open the phone's picker at once (photos and videos), without the intro screen. */
        fun open(ctx: Context, pickNow: Boolean = false) =
            ctx.startActivity(Intent(ctx, MediaImportActivity::class.java).putExtra(EXTRA_PICK_NOW, pickNow))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var title: EditText
    private lateinit var status: TextView
    private lateinit var actions: LinearLayout
    private var importing = false
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        importing = true
        actions.visibility = View.GONE
        status.text = "רגע, אנחנו מוסיפים את הזיכרון הזה..."
        val requestedTitle = title.text.toString()
        worker.execute {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val memory = MediaImporter.add(applicationContext, uri, requestedTitle)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (memory.isVideo && memory.durationMs > NewMemory.MAX_STORY_MS) {
                        // A long video: offer to pick the part worth keeping before opening it.
                        androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("הסרטון ארוך")
                            .setMessage("הסרטון באורך ${Fmt.duration(memory.durationMs)}. לקצר אותו לפני שנמשיך?")
                            .setPositiveButton("קצר") { _, _ -> TrimActivity.open(this, memory.id); finish() }
                            .setNegativeButton("שמור כמו שהוא") { _, _ -> MomentActivity.open(this, memory.id); finish() }
                            .setCancelable(false)
                            .show()
                    } else {
                        MomentActivity.open(this, memory.id)
                        finish()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        importing = false
                        actions.visibility = View.VISIBLE
                        status.text = "לא הצלחנו להוסיף את הזיכרון. בחרו קובץ שנגיש בטלפון ונסו שוב."
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = "להוסיף זיכרון"
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        val ui = Ui(this)
        val content = findViewById<LinearLayout>(R.id.screenContent)
        content.addView(ui.text("גם התמונות והסרטונים שכבר אצלכם יכולים להיות חלק מהסיפור המשפחתי.", 17f, top = 18))
        content.addView(ui.hint("רק מה שתבחרו יתווסף. הזיכרון יישאר פרטי עד שתחליטו לשתף אותו עם המשפחה.", top = 10))
        title = ui.field("איך תרצו לקרוא לרגע הזה? (לא חובה)", "", top = 22)
        content.addView(title)
        actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(ui.button("בחרו תמונה", primary = true, top = 20) { if (!importing) picker.launch(arrayOf("image/*")) })
        actions.addView(ui.button("בחרו סרטון", top = 8) { if (!importing) picker.launch(arrayOf("video/*")) })
        content.addView(actions)
        status = ui.hint("בסרטון שתוסיפו תוכלו לבחור בעצמכם את הקטע שתרצו לזכור.", top = 18)
        content.addView(status)
        if (savedInstanceState == null && intent.getBooleanExtra(EXTRA_PICK_NOW, false)) picker.launch(arrayOf("image/*", "video/*"))
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
