package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Talks to the Claude API.
 *  - analyze(): looks at 3 frames of a moment and writes a Hebrew description + tags.
 *  - ask(): answers a question about all moments and points at the matching ones.
 */
object ClaudeClient {
    private const val URL_MESSAGES = "https://api.anthropic.com/v1/messages"
    private const val VISION_MODEL = "claude-sonnet-5-5"
    private const val CHAT_MODEL = "claude-haiku-4-5-20251001"

    class ApiException(msg: String) : Exception(msg)

    fun apiKey(ctx: Context): String =
        ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).getString("api_key", "") ?: ""

    fun setApiKey(ctx: Context, key: String) {
        ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).edit().putString("api_key", key.trim()).apply()
    }

    fun hasKey(ctx: Context) = apiKey(ctx).startsWith("sk-")

    // ---------- analysis of one moment ----------

    /** Returns the memory with description/tags filled in. Runs on a background thread. */
    fun analyze(ctx: Context, m: Memory): Memory {
        val frames = extractFrames(ctx, m)
        if (frames.isEmpty()) throw ApiException("לא הצלחתי לקרוא תמונות מהקליפ")

        val when_ = describeTime(m.time)
        val context = buildString {
            append("זמן: $when_. ")
            if (m.place.isNotEmpty()) append("מקום: ${m.place}. ")
            append("מה הפעיל את השמירה: ${Labels.he(m.label)}.")
            if (m.chosen) append(" ההורה בחר לשמור את הרגע הזה בעצמו, כלומר הוא חשוב לו.")
            if (m.people.isNotEmpty()) append(" זוהו בקליפ (זיהוי פנים של ההורה): ${m.people}. השתמש בשמות האלה בתיאור.")
            val family = Profile.describe(ctx, m.time)
            if (family.isNotEmpty()) append("\n$family (אל תניח מי מהם בקליפ אם לא זוהה בזיהוי פנים; הגילאים עוזרים לזהות אבני דרך מתאימות.)")
            val taste = MemoryStore.taste(ctx)
            if (taste.isNotEmpty()) append("\nמה ידוע על מה שחשוב להורה הזה לשמור:\n$taste")
        }
        val prompt = """
            אלה 3 תמונות מתוך קליפ קצר של רגע משפחתי, שצולם ממצלמה על החזה של הורה.
            $context
            תאר מה קורה בעברית פשוטה, כדי שאפשר יהיה לחפש את הרגע אחר כך.
            שים לב במיוחד לאבני דרך של ילדים: צעדים ראשונים, זחילה, עמידה, מילה ראשונה, שן ראשונה, אכילה עצמאית, רכיבה על אופניים.
            אל תנחש שמות שלא נמסרו לך. החזר רק JSON בפורמט הזה, בלי שום טקסט נוסף:
            {"title":"כותרת חמה של 3 עד 5 מילים","description":"משפט או שניים","category":"אחת מהרשימה","milestone":"שם אבן הדרך אם רואים אחת בבירור, אחרת ריק","people":"מי מופיע","activity":"הפעילות העיקרית","tags":["תגית","תגית"],"reason":"משפט קצר: מה הופך את הרגע הזה למיוחד להורה (למשל: הילד רץ אליו בהתלהבות, חיבוק, צחוק משותף)","signals":["סימני התלהבות שרואים: חיוך גדול, ידיים באוויר, ריצה לכיוון המצלמה, קפיצה, חיבוק"],"score":"מספר 1 עד 10: כמה הרגע מתאים למה שההורה אוהב לשמור"}
            הקטגוריות האפשריות: ${Categories.ALL.joinToString(", ")}
        """.trimIndent()

        val content = JSONArray()
        for (f in frames) {
            content.put(JSONObject().apply {
                put("type", "image")
                put("source", JSONObject().apply {
                    put("type", "base64")
                    put("media_type", "image/jpeg")
                    put("data", f)
                })
            })
        }
        content.put(JSONObject().put("type", "text").put("text", prompt))

        val text = call(ctx, VISION_MODEL, null, content, 500)
        val json = extractJson(text)
        val tags = json.optJSONArray("tags")
        val tagList = if (tags != null) (0 until tags.length()).map { tags.optString(it) } else emptyList()
        val extra = listOf(json.optString("people"), json.optString("activity")).filter { it.isNotBlank() }
        val category = json.optString("category").trim().let { c -> if (c in Categories.ALL) c else "אחר" }
        val milestone = json.optString("milestone").trim()
        val signals = json.optJSONArray("signals")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
        val score = json.optString("score").filter { it.isDigit() }.take(2).toIntOrNull()?.coerceIn(1, 10) ?: 0
        return m.copy(
            reason = json.optString("reason").trim(),
            score = score,
            title = json.optString("title").trim().take(40),
            description = json.optString("description").ifBlank { text.take(200) },
            tags = (tagList + extra + signals).filter { it.isNotBlank() }.joinToString(", "),
            category = if (milestone.isNotEmpty()) "אבן דרך" else category,
            milestone = m.milestone.ifEmpty { milestone },
            analyzed = true,
        )
    }

    private fun extractFrames(ctx: Context, m: Memory): List<String> {
        val mmr = MediaMetadataRetriever()
        try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: max(m.durationMs, 1L)
            return listOf(0.2, 0.5, 0.8).mapNotNull { p ->
                val bmp = mmr.getFrameAtTime((durMs * p * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bmp?.let { toJpegBase64(it) }
            }
        } catch (_: Exception) {
            return emptyList()
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    private fun toJpegBase64(src: Bitmap): String {
        val maxSide = 640
        val scale = maxSide.toFloat() / max(src.width, src.height)
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- story of the day ----------

    fun dayStory(ctx: Context, items: List<Memory>): String {
        val lines = items.joinToString("\n") { m ->
            val t = SimpleDateFormat("HH:mm", Locale.US).format(Date(m.time))
            "- $t ${m.place}: ${m.title}. ${m.description}" + if (m.people.isNotEmpty()) " (משתתפים: ${m.people})" else ""
        }
        val system = """
            את כותבת יומן משפחתי חם בעברית. מתוך רשימת הרגעים של יום אחד, כתבי 2 עד 3 משפטים קצרים
            שמספרים את סיפור היום, בגוף ראשון רבים ("היום..."), בחום ובלי פאתוס.
            היצמדי רק למה שכתוב ברשימה: אל תוסיפי חפצים, רגשות או פעולות שלא מופיעים בה. שמות מותר רק אם מופיעים ברשימה.
            אם יש רק 2 עד 3 רגעים, מספיק משפט אחד או שניים. החזירי רק את הטקסט.
            ${Profile.describe(ctx, items.first().time)}
        """.trimIndent()
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", "הרגעים של ${describeTime(items.first().time).substringBeforeLast(" ")}:\n$lines"))
        return callMessages(ctx, CHAT_MODEL, system, messages, 300).trim()
    }

    // ---------- what this parent likes to keep ----------

    class Learned(val text: String, val like: Boolean, val liked: List<Int>, val deleted: List<Int>)

    /**
     * Learns what this parent likes to keep. Each item says which moments it is based on
     * (m1.. = moments kept/loved, d1.. = moments deleted), so the app can show the evidence.
     */
    fun learn(ctx: Context, liked: List<Memory>, deleted: List<String>, mine: List<Insight>, dismissed: List<String>): List<Learned> {
        val likedText = liked.mapIndexed { i, m ->
            val why = listOfNotNull(
                if (m.chosen) "שמר בעצמו" else null,
                if (m.favorite) "סימן כמועדף" else null,
                if (m.milestone.isNotEmpty()) "אבן דרך" else null,
            ).joinToString(", ")
            "m${i + 1} ($why) ${m.title}. ${m.description} ${m.reason}" + if (m.people.isNotEmpty()) " [משתתפים: ${m.people}]" else ""
        }.joinToString("\n")
        val deletedText = deleted.mapIndexed { i, t -> "d${i + 1} $t" }.joinToString("\n")
        val family = Profile.describe(ctx)
        val system = """
            את עוזרת ללמוד מה הורה אוהב לשמור כזיכרונות משפחתיים, כדי לזהות רגעים כאלה בעתיד.
            מתוך הרגעים שהוא שמר או אהב (m1, m2...) ומהרגעים שמחק (d1, d2...), כתבי עד 5 תובנות על מה שחשוב לו
            ועד 3 על מה שפחות מעניין אותו. כל תובנה: משפט קצר (עד 12 מילים), ספציפי, בעברית פשוטה.
            לכל תובנה ציין על אילו רגעים היא מבוססת. כתבי רק תובנה שיש לה לפחות רגע אחד שתומך בה.
            החזירי רק JSON: {"items":[{"text":"...","kind":"like או dislike","based_on":["m1","d2"]}]}
        """.trimIndent()
        val content = buildString {
            if (family.isNotEmpty()) append(family).append("\n\n")
            append("רגעים ששמר או אהב:\n").append(likedText.ifEmpty { "- אין עדיין" })
            append("\n\nרגעים שמחק:\n").append(deletedText.ifEmpty { "- אין עדיין" })
            if (mine.isNotEmpty()) {
                append("\n\nכללים שההורה כתב בעצמו (הם כבר שמורים: אל תחזרי עליהם ואל תסתרי אותם):\n")
                append(mine.joinToString("\n") { (if (it.like) "✓ " else "✗ ") + it.text })
            }
            if (dismissed.isNotEmpty()) {
                append("\n\nתובנות שההורה מחק כי הן לא נכונות (אל תכתבי אותן שוב, וגם לא משהו דומה):\n")
                append(dismissed.takeLast(20).joinToString("\n") { "- $it" })
            }
        }
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        val json = extractJson(callMessages(ctx, CHAT_MODEL, system, messages, 900))
        val arr = json.optJSONArray("items") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val text = o.optString("text").trim()
            if (text.isEmpty()) return@mapNotNull null
            val refs = o.optJSONArray("based_on")?.let { a -> (0 until a.length()).map { a.optString(it).trim().lowercase() } } ?: emptyList()
            fun idx(prefix: String) = refs.filter { it.startsWith(prefix) }.mapNotNull { it.drop(1).toIntOrNull()?.minus(1) }.distinct()
            Learned(text, o.optString("kind") != "dislike", idx("m"), idx("d"))
        }
    }

    // ---------- comic ----------

    class ComicScript(val title: String, val panels: List<Pair<String, String>>)

    /** Writes a title, captions and speech bubbles for a comic of these moments. */
    fun comicScript(ctx: Context, moments: List<Memory>, panelCount: Int): ComicScript {
        val lines = moments.mapIndexed { i, m ->
            "${i + 1}. ${m.title}. ${m.description} (${Labels.he(m.label)})" + if (m.people.isNotEmpty()) " [משתתפים: ${m.people}]" else ""
        }.joinToString("\n")
        val single = moments.distinctBy { it.id }.size == 1
        val system = """
            את כותבת קומיקס משפחתי קצר, חם ומצחיק בעברית, מתוך רגעים אמיתיים.
            ${if (single) "כל הפאנלים הם אותו רגע: פתיחה, אמצע ושיא." else "כל פאנל הוא רגע אחר, לפי הסדר."}
            לכל פאנל: caption = משפט מספר קצר (עד 8 מילים), bubble = משפט דיבור קצר ומשעשע (עד 6 מילים) שמתאים למה שקורה.
            אל תמציאי אנשים או חפצים שלא מופיעים בתיאור. שמות מותר רק מתוך "משתתפים".
            החזירי רק JSON: {"title":"כותרת של 2 עד 5 מילים","panels":[{"caption":"...","bubble":"..."}]} עם בדיוק $panelCount פאנלים.
        """.trimIndent()
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", lines))
        val json = extractJson(callMessages(ctx, CHAT_MODEL, system, messages, 600))
        val arr = json.optJSONArray("panels") ?: JSONArray()
        val panels = (0 until arr.length()).map {
            val o = arr.optJSONObject(it) ?: JSONObject()
            o.optString("caption").trim() to o.optString("bubble").trim()
        }
        return ComicScript(json.optString("title").ifBlank { "הסיפור שלנו" }, panels)
    }

    // ---------- chat ----------

    class Answer(val text: String, val ids: List<String>)

    fun ask(ctx: Context, question: String, memories: List<Memory>, history: List<Pair<String, String>>): Answer {
        val list = JSONArray()
        for (m in memories) {
            list.put(JSONObject().apply {
                put("id", m.id)
                put("when", describeTime(m.time))
                if (m.place.isNotEmpty()) put("place", m.place)
                put("sound", Labels.he(m.label))
                if (m.description.isNotEmpty()) put("description", m.description)
                if (m.tags.isNotEmpty()) put("tags", m.tags)
                if (m.title.isNotEmpty()) put("title", m.title)
                if (m.category.isNotEmpty()) put("category", m.category)
                if (m.milestone.isNotEmpty()) put("milestone", m.milestone)
                if (m.favorite) put("favorite", true)
                if (m.people.isNotEmpty()) put("people", m.people)
            })
        }
        val system = """
            את "Moments", עוזרת זיכרונות משפחתית חמה. את עונה בעברית, בקצרה ובחום.
            עכשיו: ${describeTime(System.currentTimeMillis())}.
            ${Profile.describe(ctx)}
            "people" ברגע = מי זוהה בזיהוי פנים. אם שואלים על "הבן שלי" או על ילד לפי שם, השתמשי בזה.
            יש לך רק את רשימת הרגעים השמורים שלמטה (כל רגע הוא קליפ של 30 שניות). אל תמציאי רגעים שלא ברשימה.
            אם שואלים על "הפעם הראשונה" של משהו, מצאי את הרגע המוקדם ביותר שמתאים, ואמרי בעדינות שזה הראשון שתועד.
            אם אין רגע מתאים, אמרי את זה בכנות.
            החזירי רק JSON בפורמט: {"answer":"התשובה","ids":["מזהי הרגעים להצגה, מהמתאים ביותר"]}

            הרגעים:
            $list
        """.trimIndent()

        val messages = JSONArray()
        for ((role, text) in history.takeLast(6)) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val text = callMessages(ctx, CHAT_MODEL, system, messages, 700)
        return try {
            val json = extractJson(text)
            val ids = json.optJSONArray("ids")
            Answer(
                json.optString("answer").ifBlank { text },
                if (ids != null) (0 until ids.length()).map { ids.optString(it) } else emptyList(),
            )
        } catch (_: Exception) {
            Answer(text, emptyList())
        }
    }

    // ---------- helpers ----------

    private val HE_DAYS = arrayOf("", "ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת")

    /** e.g. "יום שני 05.10.2026 17:42" — gives the model enough to answer "yesterday" or "last week". */
    fun describeTime(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val day = HE_DAYS[c.get(Calendar.DAY_OF_WEEK)]
        return "יום $day " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(t))
    }

    private fun extractJson(text: String): JSONObject {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) throw ApiException("תשובה לא צפויה מה-AI")
        return JSONObject(text.substring(start, end + 1))
    }

    private fun call(ctx: Context, model: String, system: String?, content: JSONArray, maxTokens: Int): String {
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        return callMessages(ctx, model, system, messages, maxTokens)
    }

    private fun callMessages(ctx: Context, model: String, system: String?, messages: JSONArray, maxTokens: Int): String {
        val key = apiKey(ctx)
        if (key.isEmpty()) throw ApiException("חסר מפתח API")
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", maxTokens)
            if (system != null) put("system", system)
            put("messages", messages)
        }
        val conn = (URL(URL_MESSAGES).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw
                } catch (_: Exception) {
                    raw
                }
                throw ApiException(
                    when (code) {
                        401 -> "מפתח ה-API לא תקין"
                        429 -> "יותר מדי בקשות, נסה שוב בעוד רגע"
                        else -> "שגיאה מה-AI ($code): ${msg.take(150)}"
                    }
                )
            }
            val arr = JSONObject(raw).optJSONArray("content") ?: JSONArray()
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val block = arr.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
