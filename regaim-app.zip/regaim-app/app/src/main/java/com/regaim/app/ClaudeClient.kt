package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Talks to the Claude API.
 *  - analyze(): looks at 3 frames of a moment and writes a Hebrew description + tags.
 *  - ask(): answers a question about all moments and points at the matching ones.
 */
object ClaudeClient {
    private const val URL_MESSAGES = "https://api.anthropic.com/v1/messages"
    private const val VISION_MODEL = "claude-sonnet-5-5"
    private const val CHAT_MODEL = "claude-haiku-4-5-20251001"

    class ApiException(msg: String) : Exception(msg)

    fun apiKey(ctx: Context): String =
        ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).getString("api_key", "") ?: ""

    fun setApiKey(ctx: Context, key: String) {
        ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).edit().putString("api_key", key.trim()).apply()
    }

    fun hasKey(ctx: Context) = apiKey(ctx).startsWith("sk-")

    // ---------- analysis of one moment ----------

    /** Returns the memory with description/tags filled in. Runs on a background thread. */
    fun analyze(ctx: Context, m: Memory): Memory {
        val frames = extractFrames(ctx, m)
        if (frames.isEmpty()) throw ApiException(L.t("לא הצלחתי לקרוא תמונות מהקליפ", "Couldn't read images from this clip"))

        val when_ = describeTime(m.time)
        val context = buildString {
            append(if (m.timeSource == "imported") "זמן הוספת הזיכרון (זמן הצילום לא ידוע): $when_. " else "זמן הצילום: $when_. ")
            if (m.place.isNotEmpty()) append("מקום: ${m.place}. ")
            append("מה הפעיל את השמירה: ${Labels.he(m.label)}.")
            if (m.chosen) append(" ההורה בחר לשמור את הרגע הזה בעצמו, כלומר הוא חשוב לו.")
            if (m.allPeople.isNotEmpty()) append(" מופיעים בקליפ (לפי ההורה וזיהוי הפנים): ${m.allPeople}. השתמש בשמות האלה בתיאור.")
            val family = Profile.describe(ctx, m.time)
            if (family.isNotEmpty()) append("\n$family (אל תניח מי מהם בקליפ אם לא זוהה בזיהוי פנים; הגילאים עוזרים לזהות אבני דרך מתאימות.)")
            val taste = MemoryStore.taste(ctx)
            if (taste.isNotEmpty()) append("\nמה ידוע על מה שחשוב להורה הזה לשמור:\n$taste")
        }
        val prompt = """
            ${if (m.isVideo) "אלה ${frames.size} תמונות דגימה מתוך סרטון משפחתי." else "זאת תמונה משפחתית שנבחרה על ידי המשתמש."}
            $context
            תאר מה קורה $inLang פשוטה, כדי שאפשר יהיה לחפש את הרגע אחר כך.
            אין לך אודיו או תמליל. סימן צחוק או דיבור הוא רק השערת הגלאי, לא הוכחה למה שנאמר או נשמע.
            אין לך רצף וידאו מלא; אי אפשר להסיק מה קרה בין הדגימות או בסוף הסרטון. אין לקבוע שזה אירוע ראשון בחיים מתוך תמונות בלבד.
            אל תמציא רגשות, קשרים משפחתיים או פעולות שאינן נראות. אם אי אפשר לתאר בביטחון, כתוב שהתמונות אינן מספיקות לתיאור מדויק.
            שמות מותרים רק מתוך רשימת המשתתפים שזוהו או סומנו בזיכרון; פרופיל המשפחה אינו הוכחה לנוכחות. אל תשייך פעולה לשם מסוים כשאין התאמה בין הפנים לשם.
            אבן דרך רק אם המשתמש כבר סימן אותה; אחרת החזר milestone ריק. החזר רק JSON בפורמט הזה, בלי שום טקסט נוסף:
            {"title":"כותרת חמה של 3 עד 5 מילים","description":"משפט או שניים","category":"אחת מהרשימה","milestone":"שם אבן הדרך אם רואים אחת בבירור, אחרת ריק","people":"מי מופיע","activity":"הפעילות העיקרית","tags":["תגית","תגית"],"reason":"משפט קצר: מה הופך את הרגע הזה למיוחד להורה (למשל: הילד רץ אליו בהתלהבות, חיבוק, צחוק משותף)","signals":["סימני התלהבות שרואים: חיוך גדול, ידיים באוויר, ריצה לכיוון המצלמה, קפיצה, חיבוק"],"score":"מספר 1 עד 10: כמה הרגע מתאים למה שההורה אוהב לשמור"}
            הקטגוריות האפשריות: ${Categories.ALL.joinToString(", ")}
        """.trimIndent() + L.t("", "\nWrite every text value in ${L.aiLanguage}. The \"category\" value must stay exactly one of the Hebrew categories listed above.")

        val content = JSONArray()
        for (f in frames) {
            content.put(JSONObject().apply {
                put("type", "image")
                put("source", JSONObject().apply {
                    put("type", "base64")
                    put("media_type", "image/jpeg")
                    put("data", f)
                })
            })
        }
        content.put(JSONObject().put("type", "text").put("text", prompt))

        val text = call(ctx, VISION_MODEL, null, content, 500)
        val json = extractJson(text)
        val tags = json.optJSONArray("tags")
        val tagList = if (tags != null) (0 until tags.length()).map { tags.optString(it) } else emptyList()
        val extra = listOf(json.optString("people"), json.optString("activity")).filter { it.isNotBlank() }
        val category = json.optString("category").trim().let { c -> if (c in Categories.ALL) c else "אחר" }
        val description = json.optString("description").trim()
        if (description.isEmpty()) throw ApiException(L.t("התקבלה תשובה ללא תיאור. ננסה שוב מאוחר יותר", "The response had no description. We'll try again later"))
        val signals = json.optJSONArray("signals")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
        val score = json.optString("score").filter { it.isDigit() }.take(2).toIntOrNull()?.coerceIn(1, 10) ?: 0
        return m.copy(
            reason = json.optString("reason").trim(),
            score = score,
            title = json.optString("title").trim().take(40),
            description = description,
            descriptionSource = "sampled_images",
            tags = (tagList + extra + signals).filter { it.isNotBlank() }.joinToString(", "),
            category = if (m.milestone.isNotEmpty()) "אבן דרך" else category.takeIf { it != "אבן דרך" } ?: "אחר",
            milestone = m.milestone,
            analyzed = true,
        )
    }

    private fun extractFrames(ctx: Context, m: Memory): List<String> {
        if (!m.isVideo) return MediaImages.decode(ctx, m.uri, 640)?.let { listOf(toJpegBase64(it)) } ?: emptyList()
        val mmr = MediaMetadataRetriever()
        try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: max(m.durationMs, 1L)
            return listOf(0.2, 0.5, 0.8).mapNotNull { p ->
                val bmp = mmr.getFrameAtTime((durMs * p * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bmp?.let { toJpegBase64(it) }
            }
        } catch (_: Exception) {
            return emptyList()
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    private fun toJpegBase64(src: Bitmap): String {
        val maxSide = 640
        val scale = maxSide.toFloat() / max(src.width, src.height)
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- story of the day ----------

    fun dayStory(ctx: Context, items: List<Memory>): String {
        val lines = items.joinToString("\n") { m ->
            val t = SimpleDateFormat("HH:mm", Locale.US).format(Date(m.time))
            "- $t ${if (m.timeSource == "imported") "נוסף לאוסף; מועד האירוע אינו ידוע. " else ""}${m.place}: ${m.title}. ${m.description}" + if (m.allPeople.isNotEmpty()) " (משתתפים: ${m.allPeople})" else ""
        }
        val system = """
            את כותבת יומן משפחתי חם $inLang. מתוך רשימת הרגעים של יום אחד, כתבי 2 עד 3 משפטים קצרים
            שמספרים את סיפור היום, בגוף ראשון רבים ("היום..."), בחום ובלי פאתוס.
            היצמדי רק למה שכתוב ברשימה: אל תוסיפי חפצים, רגשות או פעולות שלא מופיעים בה. שמות מותר רק אם מופיעים ברשימה.
            זיכרון שנוסף לאוסף עם מועד אירוע לא ידוע אינו אירוע שהתרחש היום. תארי את עצם ההוספה בלי לשייך את הפעילות לתאריך ההוספה.
            אם יש רק 2 עד 3 רגעים, מספיק משפט אחד או שניים. החזירי רק את הטקסט.
            ${Profile.describe(ctx, items.first().time)}
        """.trimIndent() + L.t("", "\nWrite the story in ${L.aiLanguage}.")
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", "הרגעים של ${describeTime(items.first().time).substringBeforeLast(" ")}:\n$lines"))
        return callMessages(ctx, CHAT_MODEL, system, messages, 300).trim()
    }

    // ---------- what this parent likes to keep ----------

    class Learned(val text: String, val like: Boolean, val liked: List<Int>, val deleted: List<Int>)

    /**
     * Learns what this parent likes to keep. Each item says which moments it is based on
     * (m1.. = moments kept/loved, d1.. = moments deleted), so the app can show the evidence.
     */
    fun learn(ctx: Context, liked: List<Memory>, deleted: List<String>, mine: List<Insight>, dismissed: List<String>): List<Learned> {
        val likedText = liked.mapIndexed { i, m ->
            val why = listOfNotNull(
                if (m.chosen) "שמר בעצמו" else null,
                if (m.favorite) "סימן כמועדף" else null,
                if (m.milestone.isNotEmpty()) "אבן דרך" else null,
            ).joinToString(", ")
            "m${i + 1} ($why) ${m.title}. ${m.description} ${m.reason}" + if (m.allPeople.isNotEmpty()) " [משתתפים: ${m.allPeople}]" else ""
        }.joinToString("\n")
        val deletedText = deleted.mapIndexed { i, t -> "d${i + 1} $t" }.joinToString("\n")
        val family = Profile.describe(ctx)
        val system = """
            את עוזרת ללמוד מה הורה אוהב לשמור כזיכרונות משפחתיים, כדי לזהות רגעים כאלה בעתיד.
            מתוך הרגעים שהוא שמר או אהב (m1, m2...) ומהרגעים שמחק (d1, d2...), כתבי עד 5 תובנות על מה שחשוב לו
            ועד 3 על מה שפחות מעניין אותו. כל תובנה: משפט קצר (עד 12 מילים), ספציפי, $inLang פשוטה.
            לכל תובנה ציין על אילו רגעים היא מבוססת. כתבי רק תובנה שיש לה לפחות רגע אחד שתומך בה.
            החזירי רק JSON: {"items":[{"text":"...","kind":"like או dislike","based_on":["m1","d2"]}]}
        """.trimIndent() + L.t("", "\nWrite each insight text in ${L.aiLanguage}.")
        val content = buildString {
            if (family.isNotEmpty()) append(family).append("\n\n")
            append("רגעים ששמר או אהב:\n").append(likedText.ifEmpty { "- אין עדיין" })
            append("\n\nרגעים שמחק:\n").append(deletedText.ifEmpty { "- אין עדיין" })
            if (mine.isNotEmpty()) {
                append("\n\nכללים שההורה כתב בעצמו (הם כבר שמורים: אל תחזרי עליהם ואל תסתרי אותם):\n")
                append(mine.joinToString("\n") { (if (it.like) "✓ " else "✗ ") + it.text })
            }
            if (dismissed.isNotEmpty()) {
                append("\n\nתובנות שההורה מחק כי הן לא נכונות (אל תכתבי אותן שוב, וגם לא משהו דומה):\n")
                append(dismissed.takeLast(20).joinToString("\n") { "- $it" })
            }
        }
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        val json = extractJson(callMessages(ctx, CHAT_MODEL, system, messages, 900))
        val arr = json.optJSONArray("items") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val text = o.optString("text").trim()
            if (text.isEmpty()) return@mapNotNull null
            val refs = o.optJSONArray("based_on")?.let { a -> (0 until a.length()).map { a.optString(it).trim().lowercase() } } ?: emptyList()
            fun idx(prefix: String) = refs.filter { it.startsWith(prefix) }.mapNotNull { it.drop(1).toIntOrNull()?.minus(1) }.distinct()
            Learned(text, o.optString("kind") != "dislike", idx("m"), idx("d"))
        }
    }

    // ---------- comic ----------

    class ComicScript(val title: String, val panels: List<Pair<String, String>>)

    /** Writes a title, captions and speech bubbles for a comic of these moments. */
    fun comicScript(ctx: Context, moments: List<Memory>, panelCount: Int): ComicScript =
        comicScripts(ctx, moments, panelCount, 0, 0, emptyList(), 1).first()

    /**
     * Writes [versions] clearly different comic scripts in one call.
     * tone = index in ComicStyles.TONES; page > 0 continues a story whose earlier page titles are in [previous].
     */
    fun comicScripts(
        ctx: Context, moments: List<Memory>, panelCount: Int, tone: Int, page: Int,
        previous: List<String>, versions: Int,
    ): List<ComicScript> {
        val lines = moments.mapIndexed { i, m ->
            "${i + 1}. ${m.title}. ${m.description} (${Labels.he(m.label)})" + if (m.allPeople.isNotEmpty()) " [משתתפים: ${m.allPeople}]" else ""
        }.joinToString("\n")
        val single = moments.distinctBy { it.id }.size == 1
        val n = versions.coerceIn(1, 3)
        val toneText = ComicStyles.TONE_PROMPTS.getOrElse(tone) { ComicStyles.TONE_PROMPTS[0] }
        val system = """
            את כותבת קומיקס משפחתי קצר $inLang מתוך רגעים אמיתיים. הסגנון: $toneText.
            ${if (single) "כל הפאנלים הם אותו רגע, לפי הסדר: פתיחה, אמצע ושיא." else "כל פאנל הוא רגע אחר, לפי הסדר."}
            ${if (page > 0) "זה עמוד ${page + 1} של אותו סיפור. העמודים הקודמים נקראו: ${previous.joinToString(" / ")}. המשיכי את הסיפור, אל תחזרי על מה שכבר נאמר." else ""}
            לכל פאנל: caption = משפט מספר קצר (עד 9 מילים), bubble = משפט דיבור קצר (עד 6 מילים) שמתאים למה שקורה.
            אל תמציאי אנשים או חפצים שלא מופיעים בתיאור. שמות מותר רק מתוך "משתתפים".
            ${Profile.describe(ctx, moments.first().time)}
            כתבי $n ${if (n > 1) "גרסאות שונות מאוד זו מזו (כותרת, זווית ובדיחות אחרות)" else "גרסה"}.
            החזירי רק JSON: {"versions":[{"title":"כותרת של 2 עד 5 מילים","panels":[{"caption":"...","bubble":"..."}]}]} עם בדיוק $panelCount פאנלים בכל גרסה.
        """.trimIndent() + L.t("", "\nWrite the titles, captions and bubbles in ${L.aiLanguage}.")
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", lines))
        val json = extractJson(callMessages(ctx, CHAT_MODEL, system, messages, 600 * n))
        val list = json.optJSONArray("versions") ?: JSONArray().put(json)
        val out = (0 until list.length()).mapNotNull { v ->
            val o = list.optJSONObject(v) ?: return@mapNotNull null
            val arr = o.optJSONArray("panels") ?: JSONArray()
            val panels = (0 until arr.length()).map {
                val p = arr.optJSONObject(it) ?: JSONObject()
                p.optString("caption").trim() to p.optString("bubble").trim()
            }
            ComicScript(o.optString("title").ifBlank { L.t("הסיפור שלנו", "Our story") }, panels)
        }
        if (out.isEmpty()) throw ApiException(L.t("תשובה לא צפויה מה-AI", "Unexpected response from the AI"))
        return out
    }

    // ---------- chat ----------

    class Answer(val text: String, val ids: List<String>)

    fun ask(ctx: Context, question: String, memories: List<Memory>, history: List<Pair<String, String>>): Answer {
        val list = JSONArray()
        for (m in memories) {
            list.put(JSONObject().apply {
                put("id", m.id)
                put("when", describeTime(m.time))
                put("time_source", m.timeSource)
                put("media_type", m.mediaType)
                if (m.place.isNotEmpty()) put("place", m.place)
                put("sound", Labels.he(m.label))
                if (m.description.isNotEmpty()) put("description", m.description)
                if (m.tags.isNotEmpty()) put("tags", m.tags)
                if (m.title.isNotEmpty()) put("title", m.title)
                if (m.category.isNotEmpty()) put("category", m.category)
                if (m.milestone.isNotEmpty()) put("milestone", m.milestone)
                if (m.favorite) put("favorite", true)
                if (m.allPeople.isNotEmpty()) put("people", m.allPeople)
            })
        }
        val system = """
            את "Moments", עוזרת זיכרונות משפחתית חמה. את עונה $inLang, בקצרה ובחום.
            עכשיו: ${describeTime(System.currentTimeMillis())}.
            ${Profile.describe(ctx)}
            "people" ברגע = מי זוהה בזיהוי פנים. אם שואלים על "הבן שלי" או על ילד לפי שם, השתמשי בזה.
            יש לך רק את פרטי הזיכרונות שלמטה, שהם תמונות או סרטונים באורכים שונים. אין לך אודיו, תמליל או רצף וידאו מלא. אל תמציאי רגעים שלא ברשימה.
            time_source=imported אומר שהזמן הוא זמן ההוספה; תאריך הצילום המקורי אינו ידוע. פרופיל המשפחה אינו הוכחה שמישהו נכח בזיכרון.
            אל תצטטי דיבור או תסיקי מה קרה בסוף סרטון מתוך תיאור חלקי. כשאין מידע, אמרי במפורש שאינך יודעת.
            אם שואלים על "הפעם הראשונה" של משהו, מצאי את הרגע המוקדם ביותר שמתאים, ואמרי בעדינות שזה הראשון שתועד.
            אם אין רגע מתאים, אמרי את זה בכנות.
            החזירי רק JSON בפורמט: {"answer":"התשובה","ids":["מזהי הרגעים להצגה, מהמתאים ביותר"]}

            הרגעים:
            $list
        """.trimIndent() + L.t("", "\n\nWrite the answer in ${L.aiLanguage}.")

        val messages = JSONArray()
        for ((role, text) in history.takeLast(6)) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val text = callMessages(ctx, CHAT_MODEL, system, messages, 700)
        return try {
            val json = extractJson(text)
            val ids = json.optJSONArray("ids")
            Answer(
                json.optString("answer").ifBlank { text },
                if (ids != null) (0 until ids.length()).map { ids.optString(it) } else emptyList(),
            )
        } catch (_: Exception) {
            Answer(text, emptyList())
        }
    }

    /**
     * "שאל את הזיכרון": answers a question about one moment, looking at its frames,
     * and can point at other moments like it ("find more moments like this").
     */
    fun askMoment(ctx: Context, m: Memory, question: String, others: List<Memory>): Answer {
        val frames = extractFrames(ctx, m)
        val list = JSONArray()
        for (o in others.filter { it.id != m.id }.take(150)) {
            list.put(JSONObject().apply {
                put("id", o.id)
                put("when", describeTime(o.time))
                if (o.title.isNotEmpty()) put("title", o.title)
                if (o.description.isNotEmpty()) put("description", o.description.take(160))
                if (o.category.isNotEmpty()) put("category", o.category)
                if (o.allPeople.isNotEmpty()) put("people", o.allPeople)
            })
        }
        val about = JSONObject().apply {
            put("when", describeTime(m.time))
            put("time_source", m.timeSource)
            put("media_type", m.mediaType)
            if (m.place.isNotEmpty()) put("place", m.place)
            put("trigger", Labels.he(m.label))
            if (m.title.isNotEmpty()) put("title", m.title)
            if (m.description.isNotEmpty()) put("description", m.description)
            if (m.reason.isNotEmpty()) put("why_it_matters", m.reason)
            if (m.allPeople.isNotEmpty()) put("people_recognized", m.allPeople)
            if (m.tags.isNotEmpty()) put("tags", m.tags)
        }
        val system = """
            את "Moments", עוזרת זיכרונות משפחתית חמה. ההורה צופה עכשיו ברגע אחד ושואל עליו שאלה.
            ענו $inLang, בקצרה (1 עד 3 משפטים), בחום ובכנות, לפי התמונות מהרגע והפרטים עליו.
            אם אי אפשר לדעת מהתמונות או מהפרטים, אמרי במפורש שאינך יודעת ואל תמציאי.
            אין אודיו, אין תמליל ואין רצף וידאו מלא. אי אפשר לדעת מה נאמר, מי דיבר או מה קרה בסוף הסרטון מהדגימות בלבד.
            שמות מותר רק מתוך people_recognized; פרופיל המשפחה אינו הוכחה לנוכחות. אין לשייך פעולה לפנים בשם מסוים בלי התאמה מזוהה.
            time_source=imported אומר שזה זמן הוספה, לא תאריך צילום ידוע. אין לקבוע אירוע ראשון בחיים מתוך תיעוד חלקי.
            ${Profile.describe(ctx, m.time)}
            אם מבקשים רגעים דומים או קשורים, בחרי עד 6 מתוך הרשימה "רגעים אחרים" והחזירי את ה-id שלהם.
            החזירי רק JSON: {"answer":"התשובה","ids":["..."]}
        """.trimIndent() + L.t("", "\nWrite the answer in ${L.aiLanguage}.")
        val content = JSONArray()
        for (f in frames) {
            content.put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64").put("media_type", "image/jpeg").put("data", f)))
        }
        content.put(JSONObject().put("type", "text").put("text", "הרגע: $about\n\nרגעים אחרים: $list\n\nהשאלה: $question"))
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        val text = callMessages(ctx, VISION_MODEL, system, messages, 500)
        return try {
            val json = extractJson(text)
            val ids = json.optJSONArray("ids")
            Answer(json.optString("answer").ifBlank { text }, if (ids != null) (0 until ids.length()).map { ids.optString(it) } else emptyList())
        } catch (_: Exception) {
            Answer(text, emptyList())
        }
    }

    // ---------- helpers ----------

    private val HE_DAYS = arrayOf("", "ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת")
    private val EN_DAYS = arrayOf("", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    /** "בעברית" in Hebrew mode; tells the AI to write in English in English mode. */
    private val inLang: String get() = L.t("בעברית", "באנגלית (in English)")

    /** e.g. "יום שני 05.10.2026 17:42" — gives the model enough to answer "yesterday" or "last week". */
    fun describeTime(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        if (L.isEn) return EN_DAYS[c.get(Calendar.DAY_OF_WEEK)] + " " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(t))
        val day = HE_DAYS[c.get(Calendar.DAY_OF_WEEK)]
        return "יום $day " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(t))
    }

    private fun extractJson(text: String): JSONObject {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) throw ApiException(L.t("תשובה לא צפויה מה-AI", "Unexpected response from the AI"))
        return JSONObject(text.substring(start, end + 1))
    }

    private fun call(ctx: Context, model: String, system: String?, content: JSONArray, maxTokens: Int): String {
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        return callMessages(ctx, model, system, messages, maxTokens)
    }

    private fun callMessages(ctx: Context, model: String, system: String?, messages: JSONArray, maxTokens: Int): String {
        val key = apiKey(ctx)
        if (key.isEmpty()) throw ApiException(L.t("חסר מפתח API", "API key is missing"))
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", maxTokens)
            if (system != null) put("system", system)
            put("messages", messages)
        }
        val conn = (URL(URL_MESSAGES).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw
                } catch (_: Exception) {
                    raw
                }
                throw ApiException(
                    when (code) {
                        401 -> L.t("מפתח ה-API לא תקין", "The API key isn't valid")
                        429 -> L.t("יותר מדי בקשות, נסה שוב בעוד רגע", "Too many requests. Try again in a moment")
                        else -> L.t("שגיאה מה-AI ($code): ${msg.take(150)}", "AI error ($code): ${msg.take(150)}")
                    }
                )
            }
            val arr = JSONObject(raw).optJSONArray("content") ?: JSONArray()
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val block = arr.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
