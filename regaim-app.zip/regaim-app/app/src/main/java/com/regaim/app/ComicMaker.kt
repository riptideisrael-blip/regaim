package com.regaim.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Turns moments into a comic story (1080x1920, story format):
 * frames are drawn in a comic style on the phone, and Claude writes the captions and speech bubbles.
 */
object ComicMaker {

    class Panel(val frame: Bitmap, val caption: String, val bubble: String, val illustrated: Boolean = false)

    /** Just fits a ready illustration into the panel (center crop), no filter. */
    private fun fit(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val m = Matrix().apply {
            postScale(scale, scale)
            postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private const val W = 1080
    private const val H = 1920
    private val INK = Color.parseColor("#1F1D2B")
    private val PAPER = Color.parseColor("#FBF8F1")
    private val CAPTION_BG = Color.parseColor("#FFE9A8")
    private val ACCENT = Color.parseColor("#5B4FE0")

    // ---------- frames ----------

    /** Grabs [count] frames spread over one clip. */
    fun framesFromClip(ctx: Context, m: Memory, count: Int): List<Bitmap> {
        val mmr = MediaMetadataRetriever()
        return try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: max(m.durationMs, 1L)
            val spots = when (count) {
                1 -> listOf(0.5)
                2 -> listOf(0.35, 0.65)
                3 -> listOf(0.3, 0.5, 0.7)
                else -> (0 until count).map { 0.15 + 0.7 * it / (count - 1) }
            }
            spots.mapNotNull { p -> mmr.getFrameAtTime((dur * p * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC) }
        } catch (_: Exception) {
            emptyList()
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    // ---------- comic style ----------

    /** Center-crops to the panel shape, then posterizes colors and draws ink outlines on the edges. */
    fun comicify(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val m = Matrix().apply {
            postScale(scale, scale)
            postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        }
        val base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(base).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))

        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        val gray = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            gray[i] = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
        }
        val out = IntArray(w * h)
        val levels = 5
        val step = 255f / (levels - 1)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val c = px[i]
                // Posterize + a bit more saturation, for the flat "printed" look.
                var r = Color.red(c).toFloat()
                var g = Color.green(c).toFloat()
                var b = Color.blue(c).toFloat()
                val l = gray[i]
                r = l + (r - l) * 1.35f
                g = l + (g - l) * 1.35f
                b = l + (b - l) * 1.35f
                var rr = (Math.round(r.coerceIn(0f, 255f) / step) * step).toInt()
                var gg = (Math.round(g.coerceIn(0f, 255f) / step) * step).toInt()
                var bb = (Math.round(b.coerceIn(0f, 255f) / step) * step).toInt()
                // Sobel edge strength -> ink line.
                if (x in 1 until w - 1 && y in 1 until h - 1) {
                    val gx = -gray[i - w - 1] - 2 * gray[i - 1] - gray[i + w - 1] + gray[i - w + 1] + 2 * gray[i + 1] + gray[i + w + 1]
                    val gy = -gray[i - w - 1] - 2 * gray[i - w] - gray[i - w + 1] + gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1]
                    val mag = sqrt(gx * gx + gy * gy)
                    if (mag > 150f) {
                        val k = min(1f, (mag - 150f) / 160f)
                        rr = (rr * (1 - k) + 31 * k).toInt()
                        gg = (gg * (1 - k) + 29 * k).toInt()
                        bb = (bb * (1 - k) + 43 * k).toInt()
                    }
                }
                out[i] = Color.rgb(rr.coerceIn(0, 255), gg.coerceIn(0, 255), bb.coerceIn(0, 255))
            }
        }
        base.setPixels(out, 0, w, 0, 0, w, h)
        // Soft halftone dots over the darker areas, like old print.
        val c = Canvas(base)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(28, 31, 29, 43) }
        var yy = 6
        while (yy < h) {
            var xx = if ((yy / 12) % 2 == 0) 6 else 12
            while (xx < w) {
                if (gray[yy * w + xx] < 110f) c.drawCircle(xx.toFloat(), yy.toFloat(), 2.2f, dot)
                xx += 12
            }
            yy += 12
        }
        return base
    }

    // ---------- page ----------

    fun render(title: String, dateLine: String, panels: List<Panel>): Bitmap {
        val page = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(page)
        c.drawColor(PAPER)

        // Header
        val margin = 48f
        val titlePaint = textPaint(64f, INK, bold = true)
        val datePaint = textPaint(32f, ACCENT, bold = true)
        drawRtl(c, "Moments · $dateLine", datePaint, margin, 60f, W - 2 * margin)
        val titleLayout = layout(title, titlePaint, (W - 2 * margin).toInt(), 2)
        c.save(); c.translate(margin, 110f); titleLayout.draw(c); c.restore()
        val top = 110f + titleLayout.height + 30f

        // Panels stacked, with gutters
        val n = panels.size.coerceIn(1, 4)
        val gutter = 26f
        val panelH = (H - top - margin - gutter * (n - 1)) / n
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 9f
            color = INK
        }
        for (i in 0 until n) {
            val p = panels[i]
            val rect = RectF(margin, top + i * (panelH + gutter), W - margin, top + i * (panelH + gutter) + panelH)
            val art = if (p.illustrated) fit(p.frame, rect.width().toInt(), rect.height().toInt())
            else comicify(p.frame, rect.width().toInt(), rect.height().toInt())
            c.drawBitmap(art, rect.left, rect.top, null)
            c.drawRect(rect, border)
            if (p.caption.isNotBlank()) drawCaption(c, p.caption, rect)
            if (p.bubble.isNotBlank()) drawBubble(c, p.bubble, rect, i % 2 == 0)
        }
        return page
    }

    private fun drawCaption(c: Canvas, text: String, panel: RectF) {
        val paint = textPaint(34f, INK, bold = true)
        val maxW = (panel.width() * 0.62f).toInt()
        val l = layout(text, paint, maxW, 3)
        val pad = 18f
        val boxW = l.width.toFloat().coerceAtMost(maxW.toFloat()) + pad * 2
        val box = RectF(panel.right - boxW - 4.5f, panel.top + 4.5f, panel.right - 4.5f, panel.top + 4.5f + l.height + pad * 2)
        c.drawRect(box, Paint().apply { color = CAPTION_BG })
        c.drawRect(box, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = INK })
        c.save(); c.translate(box.left + pad, box.top + pad); l.draw(c); c.restore()
    }

    private fun drawBubble(c: Canvas, text: String, panel: RectF, left: Boolean) {
        val paint = textPaint(38f, INK, bold = true)
        val maxW = (panel.width() * 0.48f).toInt()
        val l = layout(text, paint, maxW, 3)
        val padX = 34f
        val padY = 26f
        val bw = l.width + padX * 2
        val bh = l.height + padY * 2
        val bx = if (left) panel.left + 30f else panel.right - 30f - bw
        val by = panel.bottom - bh - 60f
        val oval = RectF(bx, by, bx + bw, by + bh)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = INK }
        // Tail pointing down into the scene.
        val tailX = if (left) oval.left + bw * 0.3f else oval.right - bw * 0.3f
        val tail = Path().apply {
            moveTo(tailX - 22f, oval.bottom - 12f)
            lineTo(tailX + (if (left) 10f else -10f), oval.bottom + 46f)
            lineTo(tailX + 22f, oval.bottom - 12f)
            close()
        }
        c.drawPath(tail, fill)
        c.drawPath(tail, stroke)
        c.drawOval(oval, fill)
        c.drawOval(oval, stroke)
        // Cover the tail's join line.
        c.drawRect(tailX - 18f, oval.bottom - 14f, tailX + 18f, oval.bottom - 2f, fill)
        c.save(); c.translate(oval.left + padX, oval.top + padY); l.draw(c); c.restore()
    }

    private fun textPaint(size: Float, color: Int, bold: Boolean) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun layout(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout {
        val w = max(1, min(width, paint.measureText(text).toInt() + 2))
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()
    }

    private fun drawRtl(c: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Float) {
        val l = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt())
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setMaxLines(1)
            .build()
        c.save(); c.translate(x, y - paint.textSize); l.draw(c); c.restore()
    }

    // ---------- whole flow ----------

    /** Builds the comic for these moments. Background thread only. Returns the saved file. */
    fun make(ctx: Context, moments: List<Memory>, onProgress: ((String) -> Unit)? = null): File {
        val chosen = moments.sortedBy { it.time }
        val frames: List<Pair<Memory, Bitmap>> = if (chosen.size == 1) {
            framesFromClip(ctx, chosen[0], 3).map { chosen[0] to it }
        } else {
            // Up to 4 moments, favorites and milestones first.
            val pick = chosen.sortedByDescending { (if (it.milestone.isNotEmpty()) 2 else 0) + (if (it.favorite) 1 else 0) }
                .take(4).sortedBy { it.time }
            pick.mapNotNull { m -> framesFromClip(ctx, m, 1).firstOrNull()?.let { m to it } }
        }
        if (frames.isEmpty()) throw IllegalStateException("לא הצלחתי לקרוא תמונות מהקליפים")

        val script = try {
            if (ClaudeClient.hasKey(ctx)) ClaudeClient.comicScript(ctx, frames.map { it.first }, frames.size) else null
        } catch (_: Exception) {
            null
        }
        val title = script?.title ?: (if (chosen.size == 1) chosen[0].displayTitle else "הסיפור של היום")
        val useAi = GeminiClient.hasKey(ctx)
        val panels = frames.mapIndexed { i, (m, bmp) ->
            val s = script?.panels?.getOrNull(i)
            // With a Gemini key, each panel is redrawn as a real illustration; otherwise the on-phone comic filter.
            val drawn = if (useAi) {
                onProgress?.invoke("מצייר פאנל ${i + 1} מתוך ${frames.size}...")
                try { GeminiClient.illustrate(ctx, bmp, m.description.ifEmpty { m.displayTitle }) } catch (_: Exception) { null }
            } else null
            Panel(drawn ?: bmp, s?.first?.ifBlank { null } ?: m.displayTitle, s?.second ?: "", illustrated = drawn != null)
        }
        val date = SimpleDateFormat("d.M.yyyy", Locale.US).format(Date(chosen.first().time))
        val page = render(title, date, panels)

        val dir = File(ctx.filesDir, "comics").apply { mkdirs() }
        val file = File(dir, "comic_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { page.compress(Bitmap.CompressFormat.PNG, 100, it) }
        saveToGallery(ctx, file)
        return file
    }

    private fun saveToGallery(ctx: Context, file: File) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Moments")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
                ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Moments")
                dir.mkdirs()
                val dest = File(dir, file.name)
                file.copyTo(dest, overwrite = true)
                MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf("image/png"), null)
            }
        } catch (_: Exception) {
        }
    }

    @Suppress("unused")
    private fun near(a: Float, b: Float) = abs(a - b) < 0.001f
}
