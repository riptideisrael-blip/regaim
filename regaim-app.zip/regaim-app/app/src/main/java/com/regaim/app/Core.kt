package com.regaim.app

import android.media.MediaCodec

/** Monotonic clock in microseconds, shared by the video and audio streams. */
fun nowUs(): Long = System.nanoTime() / 1000

/** One encoded frame (video) or packet (audio) kept in memory. */
class EncodedSample(val data: ByteArray, val ptsUs: Long, val flags: Int) {
    val isKey: Boolean get() = (flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
}

/**
 * Rolling in-memory buffer: keeps only the last [keepUs] of encoded samples.
 * Nothing is written to disk unless a moment is detected.
 */
class SampleRing(private val keepUs: Long) {
    private val queue = ArrayDeque<EncodedSample>()

    @Synchronized
    fun add(sample: EncodedSample) {
        queue.addLast(sample)
        val cutoff = sample.ptsUs - keepUs
        while (queue.isNotEmpty() && queue.first().ptsUs < cutoff) queue.removeFirst()
    }

    @Synchronized
    fun snapshot(): List<EncodedSample> = queue.toList()

    @Synchronized
    fun clear() = queue.clear()
}

/** Live state shared between the capture service and the screen. */
object Status {
    @Volatile var running = false
    @Volatile var startedAt = 0L
    @Volatile var lastScore = 0f
    @Volatile var lastLabel = ""
    @Volatile var topLabel = ""
    @Volatile var clips = 0
    @Volatile var pending = false
    @Volatile var lastClipLabel = ""
    @Volatile var lastClipAt = 0L
    @Volatile var error: String? = null
    @Volatile var threshold = 0.3f
    @Volatile var preview: android.graphics.Bitmap? = null
    @Volatile var uiVisible = false
    @Volatile var videoFrames = 0L
    @Volatile var videoSize = ""

    fun reset() {
        running = false
        startedAt = 0L
        lastScore = 0f
        lastLabel = ""
        topLabel = ""
        clips = 0
        pending = false
        lastClipLabel = ""
        lastClipAt = 0L
        error = null
        preview = null
        videoFrames = 0L
    }
}

/** YAMNet sound classes that count as a "moment", with Hebrew names. */
object Labels {
    val TRIGGERS: Map<String, String> = mapOf(
        "Laughter" to "צחוק",
        "Baby laughter" to "צחוק תינוק",
        "Giggle" to "צחקוק",
        "Belly laugh" to "צחוק מתגלגל",
        "Chuckle, chortle" to "צחקוק",
        "Snicker" to "גיחוך",
        "Children shouting" to "צעקות שמחה",
        "Cheering" to "תשואות",
        "Whoop" to "קריאת התלהבות",
    )

    private val EXTRA: Map<String, String> = mapOf(
        "manual" to "שמירה ידנית",
        "Speech" to "דיבור",
        "Child speech, kid speaking" to "ילד מדבר",
        "Silence" to "שקט",
        "Crying, sobbing" to "בכי",
        "Baby cry, infant cry" to "בכי תינוק",
        "Music" to "מוזיקה",
        "Television" to "טלוויזיה",
    )

    fun he(label: String): String = TRIGGERS[label] ?: EXTRA[label] ?: label
}

/** Fixed moment categories (Hebrew), with a color for chips and dots. */
object Categories {
    val ALL = listOf("צחוק", "משחק", "אוכל", "בחוץ", "אמבטיה", "שינה", "משפחה", "אבן דרך", "אחר")

    fun color(c: String): Int = android.graphics.Color.parseColor(
        when (c) {
            "צחוק" -> "#F2A93B"
            "משחק" -> "#E8743B"
            "אוכל" -> "#D9825B"
            "בחוץ" -> "#7FA36B"
            "אמבטיה" -> "#5B9BB5"
            "שינה" -> "#8C7FB8"
            "משפחה" -> "#C9667A"
            "אבן דרך" -> "#4E8F6A"
            else -> "#A8998B"
        }
    )
}
