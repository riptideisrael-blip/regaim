package com.regaim.app

/**
 * The games world (motor skills and understanding, ages ~3–5). The first game: "taking the animals home" — the
 * child drags each animal with a finger to its home (its dark shape), in the farmyard where the child and Pitzki
 * stand (the child's own animated scene). Three rounds: matching the shape; listening ("only the cat!"); big and
 * small. Each animal makes its sound when it gets home.
 */
object PlayWorld {
    const val ID = "play"
    const val INTRO = "play_intro"

    val KEYS = listOf("song", "play_intro", "play_yard", "play_end")
    /** The scenes the child is in (all of them: the child plays in them). */
    val CHILD_KEYS = listOf("play_intro", "play_yard", "play_end")

    private fun a(id: String) = FarmWorld.ANIMALS.first { it.id == id }.let { Choice(it.emoji, it.he, 1f) }

    /** Levels: 1) two animals home and one to listen for, 2) three, and big / small, 3) four, and listening among three. */
    const val LEVELS = 3

    fun lesson(kid: PitzkiKid, level: Int = PitzkiScript.level): List<PitzkiScene> {
        val lv = level.coerceIn(1, LEVELS)
        val name = kid.name.trim()
        val nm = kid.named
        val p = nm
        fun g(b: String, gi: String, all: String) = kid.g(b, gi, all)
        val s = ArrayList<PitzkiScene>()
        fun add(key: String, title: String, vararg beats: Beat) { s.add(PitzkiScene(s.size + 1, key, title, null, beats.toList())) }
        add("song", "השיר של פיצקי", Beat.Song(0, 0, PitzkiScript.SONG.zip(PitzkiScript.SONG_AT).map { it.second to it.first }), Beat.Wait(500))
        add(INTRO, "החיות ברחו!",
            Beat.Say("p_come", (if (nm) "$name, " else "") + g("בוא! בוא לשחק איתי!", "בואי! בואי לשחק איתי!", "בואו! בואו לשחק איתי!"), personal = p),
            Beat.Say("p_oops", "אוי! כל החיות ברחו מהבתים שלהן!"),
            Beat.Say("p_help", g("תעזור לי להחזיר אותן הביתה?", "תעזרי לי להחזיר אותן הביתה?", "תעזרו לי להחזיר אותן הביתה?"), personal = p),
            Beat.Hear("p_ready", listOf("כן", "בטח", "יאללה", "מוכן", "מוכנה"), ok = "יאללה, מתחילים!", hint = "יאללה, מתחילים!"))
        add("play_yard", "מחזירים את החיות הביתה",
            // 1) Every animal to its own shape.
            Beat.Say("p_r1", g("גרור כל חיה באצבע אל הבית שלה, הצל שנראה בדיוק כמוה.", "גררי כל חיה באצבע אל הבית שלה, הצל שנראה בדיוק כמוה.", "גררו כל חיה באצבע אל הבית שלה, הצל שנראה בדיוק כמוה."), personal = p),
            when (lv) {
                1 -> Beat.Drag("p_drag1a", listOf(a("cow"), a("dog")))
                2 -> Beat.Drag("p_drag1", listOf(a("cow"), a("dog"), a("rooster")))
                else -> Beat.Drag("p_drag1c", listOf(a("cow"), a("dog"), a("rooster"), a("horse")))
            },
            Beat.Say("p_r1_ok$lv", when (lv) { 1 -> "כל הכבוד! הפרה והכלב בבית!"; 2 -> "כל הכבוד! הפרה, הכלב והתרנגול בבית!"; else -> "כל הכבוד! הפרה, הכלב, התרנגול והסוס בבית!" }),
            // 2) Listening: only the one Pitzki says.
            Beat.Say("p_r2", g("עכשיו תקשיב טוב: תחזיר הביתה רק את החתול!", "עכשיו תקשיבי טוב: תחזירי הביתה רק את החתול!", "עכשיו תקשיבו טוב: תחזירו הביתה רק את החתול!"), personal = p),
            if (lv >= 3) Beat.Drag("p_drag2c", listOf(a("sheep"), a("donkey"), a("cat")), only = 2) else Beat.Drag("p_drag2", listOf(a("sheep"), a("cat")), only = 1),
            Beat.Say("p_r2b", g("ועכשיו את הכבשה!", "ועכשיו את הכבשה!", "ועכשיו את הכבשה!")),
            Beat.Drag("p_drag2b", listOf(a("sheep")), only = 0),
            // 3) Big and small.
            *(if (lv >= 2) arrayOf<Beat>(
                Beat.Say("p_r3", "הסוס הגדול לבית הגדול, והסוס הקטן לבית הקטן!"),
                Beat.Drag("p_drag3", listOf(Choice("🐴", "גדול", 1.5f), Choice("🐴", "קטן", 0.75f)))) else emptyArray()))
        add("play_end", "כולם בבית!",
            Beat.Celebrate,
            Beat.Say("p_bravo", (if (nm) "כל הכבוד, $name! " else "כל הכבוד! ") + "החזרנו את כל החיות הביתה!", personal = p),
            Beat.Say("p_bye", if (nm) "נשחק שוב בפעם הבאה, $name!" else "נשחק שוב בפעם הבאה!", personal = p))
        return s
    }

    const val SETTING = "a cozy, sunny storybook farmyard with a red barn, a wooden dog house, a little chicken coop and green grass, warm golden light"

    fun childAction(key: String): String = when (key) {
        INTRO -> "In a sunny farmyard, Pitzki and the child stand side by side, looking surprised and laughing, hands on their cheeks; behind them the barn door, the dog house and the coop are open and empty."
        "play_yard" -> "In a sunny farmyard, the child and Pitzki crouch side by side on the grass, smiling and ready to help, the child holding out a hand as if calling a little animal; the barn, the dog house and the coop behind them, open and empty."
        else -> "In a sunny farmyard, the child and Pitzki jump with joy and high-five; behind them a happy cow looks out of the barn, a puppy out of the dog house and a rooster on the coop."
    }

    fun childMotion(key: String): String = when (key) {
        INTRO -> "The child and Pitzki look around the farmyard in surprise, then laugh and nod to each other, ready to help."
        "play_yard" -> "The child and Pitzki look around happily and wave gently as if calling the animals home; calm, slow camera."
        else -> "The child and Pitzki jump with joy and high-five; the animals behind them look out happily."
    }

    const val INTRO_FROM_START =
        "Pitzki stands in the farmyard, smiles and beckons with his hand in a 'come with me' gesture toward the right edge of the frame; " +
            "the child walks in from the right and stops next to him. Nobody talks. The child's face, hair and clothes are exactly as in the last frame."
}
