package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * "מה Moments למד": every insight with the moments it was learned from, and your corrections:
 * fix it, delete it (and it won't come back), add your own rule, or exclude a moment from learning.
 */
class LearnedActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, LearnedActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var learning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = "מה Moments למד"
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun render() {
        val y = findViewById<View>(R.id.screenScroll).scrollY
        content.removeAllViews()
        val all = MemoryStore.all(this)
        val byId = all.associateBy { it.id }
        val items = Learning.items(this)
        basisCard(all, items.isEmpty())
        insightList("✓ מה חשוב לך לשמור", items.filter { it.like }, byId, true)
        insightList("✗ מה פחות מעניין אותך", items.filter { !it.like }, byId, false)
        otherKnowledge(all)
        content.post { findViewById<View>(R.id.screenScroll).scrollTo(0, y) }
    }

    // ---------- what it learned from ----------

    private fun basisCard(all: List<Memory>, empty: Boolean) {
        val card = ui.card(top = 8)
        val chosen = all.count { it.chosen && !it.noLearn }
        val fav = all.count { it.favorite && !it.noLearn }
        val ms = all.count { it.milestone.isNotEmpty() && !it.noLearn }
        val deleted = Learning.rejected(this).size
        card.addView(ui.text("על מה הלמידה מבוססת", 15f, bold = true))
        card.addView(ui.text("♥ $chosen רגעים ששמרת בעצמך\n★ $fav מועדפים · $ms אבני דרך\n🗑 $deleted רגעים שנשמרו לבד ומחקת", 14f, top = 6))
        val updated = Learning.updatedAt(this)
        if (updated > 0) card.addView(ui.hint("עודכן לאחרונה: ${ClaudeClient.describeTime(updated)}", top = 8))
        card.addView(ui.hint("Moments משתמש בזה כשה-AI מתאר כל רגע, כותב \"למה זה רגע שלך\" ונותן לו ציון. כל דבר שתתקן כאן נשמר כמו שכתבת, וה-AI לא ישנה אותו.", top = 6))
        if (empty) card.addView(ui.hint("עוד אין מספיק דוגמאות. שמור כמה רגעים בעצמך (♥ או ״שמור רגע״), סמן מועדפים או מחק רגעים לא מעניינים, ואז לחץ ״למד עכשיו״.", top = 6))
        card.addView(ui.button(if (learning) "לומד..." else "למד עכשיו מהרגעים שלי", primary = true) {
            if (learning) return@button
            if (!ClaudeClient.hasKey(this)) {
                toast("צריך מפתח Claude (בהגדרות)")
                return@button
            }
            learning = true
            render()
            worker.execute {
                val ok = Learning.refresh(applicationContext, force = true)
                learning = false
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    if (!ok) toast("לא הצלחתי ללמוד. צריך לפחות רגע אחד ששמרת, אהבת או מחקת אחרי שתואר.")
                    render()
                }
            }
        })
        content.addView(card)
    }

    // ---------- the insights ----------

    private fun insightList(title: String, list: List<Insight>, byId: Map<String, Memory>, like: Boolean) {
        content.addView(ui.section(title))
        if (list.isEmpty()) content.addView(ui.hint(if (like) "עוד לא נלמד כלום כאן." else "עוד לא ידוע מה לא מעניין אותך."))
        for (i in list) content.addView(insightCard(i, byId))
        content.addView(ui.button(if (like) "+ הוסף משהו שחשוב לי" else "+ הוסף משהו שלא מעניין אותי") { edit(null, like) })
    }

    private fun insightCard(i: Insight, byId: Map<String, Memory>): View {
        val card = ui.card()
        card.addView(ui.text(i.text, 16f, bold = true))
        val moments = i.evidence.mapNotNull { byId[it] }
        val source = when {
            i.byUser && moments.isEmpty() -> "✎ כתבת את זה בעצמך"
            i.byUser -> "✎ תיקנת בעצמך · במקור נלמד מ-${moments.size} רגעים"
            moments.isEmpty() && i.deleted.isEmpty() -> "נלמד בגרסה קודמת, בלי פירוט רגעים. לחץ ״למד עכשיו״ לעדכון."
            else -> "נלמד מ-" + listOfNotNull(
                if (moments.isNotEmpty()) "${moments.size} רגעים ששמרת" else null,
                if (i.deleted.isNotEmpty()) "${i.deleted.size} שמחקת" else null,
            ).joinToString(" ו-")
        }
        card.addView(ui.hint(source))
        if (moments.isNotEmpty()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in moments) {
                val b = ui.bubble(m.thumb, 52)
                b.setOnClickListener { MomentActivity.open(this, m.id) }
                b.setOnLongClickListener { excludeMoment(m); true }
                row.addView(b)
            }
            card.addView(ui.scrollRow(row))
            card.addView(ui.hint("לחץ על רגע כדי לראות אותו · לחיצה ארוכה: לא ללמוד ממנו", top = 2))
        }
        for (d in i.deleted) {
            val r = ui.horizontal(top = 6)
            r.addView(ui.text("🗑 מחקת: $d", 13f, R.color.ink_soft).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                maxLines = 2
            })
            r.addView(ui.action("לא בגלל זה", R.color.ink_soft) {
                Learning.forgetRejected(this, d)
                render()
            })
            card.addView(r)
        }
        val actions = ui.horizontal(top = 6)
        actions.addView(ui.action("✎ תקן") { edit(i, i.like) })
        actions.addView(ui.action("✕ זה לא נכון", R.color.danger) {
            Learning.remove(this, i.id)
            toast(if (i.byUser) "נמחק" else "נמחק, ו-Moments לא ילמד את זה שוב")
            render()
        })
        card.addView(actions)
        return card
    }

    private fun edit(item: Insight?, like: Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val field = ui.field(if (like) "מה הופך רגע למשמעותי בשבילך?" else "איזה סוג רגעים פחות חשוב לך לשמור?", item?.text ?: "", multiline = true)
        box.addView(field)
        val yes = RadioButton(this).apply { id = View.generateViewId(); text = "✓ חשוב לי לשמור רגעים כאלה" }
        val no = RadioButton(this).apply { id = View.generateViewId(); text = "✗ פחות מעניין אותי" }
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(yes)
            addView(no)
            check(if (like) yes.id else no.id)
            setPadding(0, ui.dp(8), 0, 0)
        }
        box.addView(group)
        AlertDialog.Builder(this)
            .setTitle(if (item == null) "כלל משלך" else "תיקון")
            .setView(box)
            .setPositiveButton("שמור") { _, _ ->
                val text = field.text.toString()
                val isLike = group.checkedRadioButtonId == yes.id
                if (item == null) Learning.add(this, text, isLike) else Learning.edit(this, item.id, text, isLike)
                render()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    private fun excludeMoment(m: Memory) {
        AlertDialog.Builder(this)
            .setTitle("לא ללמוד מהרגע הזה?")
            .setMessage("\"${m.displayTitle}\" יישאר בזיכרונות, אבל Moments לא ילמד ממנו מה חשוב לך. בלמידה הבאה התובנות יתעדכנו.")
            .setPositiveButton("אל תלמד ממנו") { _, _ ->
                MemoryStore.get(this, m.id)?.let { MemoryStore.update(this, it.copy(noLearn = true)) }
                render()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    // ---------- other things Moments knows ----------

    private fun otherKnowledge(all: List<Memory>) {
        content.addView(ui.section("עוד דברים ש-Moments יודע"))
        val card = ui.card()

        val family = Profile.describe(this)
        card.addView(ui.row("המשפחה", if (family.isEmpty()) "הוסף" else "ערוך", top = 0) { SettingsActivity.open(this) })
        card.addView(ui.hint(family.ifEmpty { "עוד לא מילאת פרופיל. עם שמות וגילאים ה-AI מזהה אבני דרך מתאימות." }, top = 0))

        card.addView(ui.divider())
        val people = PeopleStore.people(this)
        card.addView(ui.row("אנשים שמזוהים בפנים", if (people.isEmpty()) "הוסף" else "${people.size}") { PeopleActivity.open(this) })
        card.addView(ui.hint(
            if (people.isEmpty()) "תן שמות לפנים, ו-Moments יכתוב מי היה בכל רגע."
            else people.joinToString(" · ") { "${it.name}: ${PeopleStore.countFor(this, it.name)} רגעים" } +
                "\nזיהוי שגוי? במסך אנשים אפשר לשנות שם או לשכוח אדם.",
            top = 0,
        ))

        card.addView(ui.divider())
        card.addView(ui.text("מה תופס את הרגעים שלך", 15f, top = 4))
        val kinds = linkedMapOf<String, List<Memory>>()
        kinds["♥ שמרת ידנית"] = all.filter { it.label == "manual" }
        kinds["🗣 מילים"] = all.filter { it.label.startsWith("״") }
        kinds["😄 חיוך / ריצה אליך"] = all.filter { it.label in Labels.VISUAL }
        kinds["🔊 צחוק וקולות"] = all.filter { it.label != "manual" && !it.label.startsWith("״") && it.label !in Labels.VISUAL }
        val lines = kinds.filter { it.value.isNotEmpty() }.map { (k, v) ->
            val fav = v.count { it.favorite }
            "$k: ${v.size}" + if (fav > 0) " (♥ $fav אהבת)" else ""
        }
        card.addView(ui.hint(lines.joinToString("\n").ifEmpty { "עוד אין רגעים." }, top = 2))
        val words = all.filter { it.label.startsWith("״") }.groupingBy { it.label }.eachCount().entries.sortedByDescending { it.value }.take(4)
        if (words.isNotEmpty()) card.addView(ui.hint("המילים שהכי תופסות: " + words.joinToString(", ") { "${it.key} ${it.value}" }, top = 4))
        card.addView(ui.row("לשנות מה שומר רגע", "הגדרות") { SettingsActivity.open(this) })

        val cats = all.filter { it.category.isNotEmpty() }.groupingBy { it.category }.eachCount().entries.sortedByDescending { it.value }.take(5)
        if (cats.isNotEmpty()) {
            card.addView(ui.divider())
            card.addView(ui.text("סוגי הרגעים הכי נפוצים", 15f, top = 4))
            card.addView(ui.hint(cats.joinToString(" · ") { "${it.key} ${it.value}" }, top = 2))
            card.addView(ui.hint("קטגוריה שגויה? פתח את הרגע ולחץ ״תקן״.", top = 2))
        }

        val excluded = all.filter { it.noLearn }
        if (excluded.isNotEmpty()) {
            card.addView(ui.divider())
            card.addView(ui.row("רגעים שביקשת לא ללמוד מהם", "${excluded.size}"))
            card.addView(ui.action("החזר את כולם ללמידה") {
                for (m in excluded) MemoryStore.update(this, m.copy(noLearn = false))
                render()
            })
        }

        val dismissed = Learning.dismissed(this)
        if (dismissed.isNotEmpty()) {
            card.addView(ui.divider())
            card.addView(ui.row("תובנות שמחקת ולא יחזרו", "${dismissed.size}"))
            card.addView(ui.hint(dismissed.takeLast(5).joinToString("\n") { "✕ $it" }, top = 0))
            card.addView(ui.action("אפס, ותן ל-Moments ללמוד אותן שוב") {
                Learning.clearDismissed(this)
                render()
            })
        }
        content.addView(card)
    }
}
