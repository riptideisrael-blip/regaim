package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.Executors

/** Draws a comic story from one moment or a whole day, then lets you share it. */
class ComicActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_MOMENT = "moment"
        private const val EXTRA_DAY = "day"

        fun forMoment(ctx: Context, id: String) =
            ctx.startActivity(Intent(ctx, ComicActivity::class.java).putExtra(EXTRA_MOMENT, id))

        fun forDay(ctx: Context, dayKey: String) =
            ctx.startActivity(Intent(ctx, ComicActivity::class.java).putExtra(EXTRA_DAY, dayKey))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private var file: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comic)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnShare).setOnClickListener { share() }
        findViewById<View>(R.id.btnAgain).setOnClickListener { build() }
        build()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun moments(): List<Memory> {
        val all = MemoryStore.all(this)
        intent.getStringExtra(EXTRA_MOMENT)?.let { id -> return all.filter { it.id == id } }
        val day = intent.getStringExtra(EXTRA_DAY) ?: return emptyList()
        return all.filter { it.dayKey == day }
    }

    private fun build() {
        val status = findViewById<TextView>(R.id.comicStatus)
        val image = findViewById<ImageView>(R.id.comicImage)
        val actions = findViewById<View>(R.id.comicActions)
        status.visibility = View.VISIBLE
        status.text = "מצייר את הקומיקס...\nזה לוקח כמה שניות"
        actions.visibility = View.GONE
        val items = moments()
        if (items.isEmpty()) {
            status.text = "לא נמצאו רגעים לקומיקס"
            return
        }
        worker.execute {
            val result = try {
                Result.success(ComicMaker.make(applicationContext, items))
            } catch (e: Exception) {
                Result.failure(e)
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                result.onSuccess { f ->
                    file = f
                    image.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
                    status.visibility = View.GONE
                    actions.visibility = View.VISIBLE
                    if (!ClaudeClient.hasKey(this)) {
                        Toast.makeText(this, "עם מפתח AI הקומיקס יקבל גם טקסטים מצחיקים", Toast.LENGTH_LONG).show()
                    }
                }.onFailure { e ->
                    status.text = "לא הצלחתי לצייר: ${e.message}"
                }
            }
        }
    }

    private fun share() {
        val f = file ?: return
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND)
                .setType("image/png")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "לשתף את הקומיקס עם..."))
        } catch (e: Exception) {
            Toast.makeText(this, "הקומיקס נשמר בגלריה, בתיקייה Moments", Toast.LENGTH_LONG).show()
        }
    }
}
