package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.util.concurrent.Executors

/** "סרטון תקופתי": a video of the week or month, built from the best moments, with music. */
@OptIn(markerClass = [UnstableApi::class])
class PeriodVideoActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, PeriodVideoActivity::class.java))
        private const val MUSIC_KEY = "period_music"
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private var period = PeriodVideo.Period.THIS_WEEK
    private var mood: Music.Mood? = Music.Mood.WARM
    private var handle: PeriodVideo.Handle? = null
    private var progress: ProgressBar? = null
    private var result: File? = null
    private var building = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("סרטון תקופתי", "Period video")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        mv = MemoryViews(this)
        val prefs = Settings.prefs(this)
        if (prefs.contains(MUSIC_KEY)) mood = Music.choice(this, MUSIC_KEY)
        render()
    }

    override fun onDestroy() {
        if (building) handle?.cancel?.invoke()
        Music.stop()
        super.onDestroy()
    }

    private fun render() {
        content.removeAllViews()
        progress = null
        content.addView(ui.hint(L.t("בוחרים תקופה, ואנחנו מחברים את הרגעים הכי טובים שלה לסרטון אחד עם מוזיקה. מתאים לשיתוף.", "Pick a period and we'll put its best moments into one video with music, ready to share."), top = 14))
        val periods = PeriodVideo.Period.values().toList()
        content.addView(ui.chips(periods.map { it.title }, periods.indexOf(period), top = 12) { i ->
            if (building) return@chips
            period = periods[i]; result = null; render()
        })

        val all = PeriodVideo.moments(this, period)
        val picks = PeriodVideo.pick(all)
        if (picks.size < 2) {
            content.addView(ui.text(L.t("אין מספיק רגעים בתקופה הזאת", "Not enough moments in this period"), 17f, bold = true, top = 24))
            content.addView(ui.hint(L.t("צריך לפחות שני רגעים. אפשר לבחור תקופה אחרת.", "You need at least two moments. Try another period."), top = 4))
            return
        }
        content.addView(ui.text(L.t("${picks.size} הרגעים הכי טובים מתוך ${all.size}", "The best ${picks.size} of ${all.size} moments"), 16f, bold = true, top = 18))
        content.addView(ui.hint(L.t("אורך הסרטון: כ-${PeriodVideo.seconds(picks)} שניות. נבחרו מועדפים, אבני דרך ורגעים שנשמרו על ידיכם קודם.", "About ${PeriodVideo.seconds(picks)} seconds. Favorites, milestones and moments you saved come first."), top = 2))
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        picks.forEach { strip.addView(mv.mini(it) { }) }
        content.addView(ui.scrollRow(strip, top = 10))

        val musicRow = ui.action("") { }
        musicRow.text = L.t("🎵 מוזיקה: ${mood?.title ?: "ללא"} ›", "🎵 Music: ${mood?.title ?: "none"} ›")
        musicRow.setOnClickListener {
            if (building) return@setOnClickListener
            Music.chooser(this, mood) { m -> mood = m; Music.setChoice(this, m, MUSIC_KEY); render() }
        }
        content.addView(musicRow.apply { setPadding(0, ui.dp(16), 0, ui.dp(4)) })

        val done = result
        if (done != null && done.exists()) { showResult(done); return }
        if (building) {
            content.addView(ui.text(L.t("מכינים את הסרטון... זה לוקח כדקה, אפשר להישאר כאן.", "Making your video… about a minute. Stay on this screen."), 15f, top = 14))
            progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; isIndeterminate = true
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(10) }
            }
            content.addView(progress)
            return
        }
        content.addView(ui.button(L.t("🎬 צרו את הסרטון", "🎬 Create the video"), primary = true, top = 18) { start(picks) })
    }

    private fun start(picks: List<Memory>) {
        building = true
        render()
        handle = PeriodVideo.make(applicationContext, period, picks, mood,
            onProgress = { p -> progress?.let { it.isIndeterminate = false; it.progress = p } },
            onDone = { file, err ->
                building = false
                if (isFinishing || isDestroyed) return@make
                if (file == null) Toast.makeText(this, err ?: L.t("משהו השתבש", "Something went wrong"), Toast.LENGTH_LONG).show()
                result = file
                render()
            })
    }

    private fun showResult(file: File) {
        content.addView(ui.text(L.t("הסרטון מוכן ❤️", "Your video is ready ❤️"), 18f, bold = true, top = 16))
        val box = FrameLayout(this).apply {
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5f).toInt()).apply { topMargin = ui.dp(10) }
        }
        val video = VideoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setVideoPath(file.absolutePath)
            setOnPreparedListener { it.isLooping = true; start() }
        }
        box.addView(video)
        content.addView(box)
        content.addView(ui.button(L.t("שתף", "Share"), primary = true, top = 14) { share(file) })
        content.addView(ui.button(L.t("שמור בגלריה", "Save to gallery"), top = 6) { save(file) })
        content.addView(ui.action(L.t("יצירה מחדש", "Make another")) { result = null; render() }.apply { setPadding(0, ui.dp(14), 0, 0) })
    }

    private fun share(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val send = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, period.videoTitle + L.t("\n\nנעשה עם Moments 💜", "\n\nMade with Moments 💜"))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, L.t("לשתף עם...", "Share with...")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, L.t("לא הצלחנו לפתוח את השיתוף", "Couldn't open sharing"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun save(file: File) {
        Executors.newSingleThreadExecutor().execute {
            val ok = try { ReelMaker.publish(applicationContext, file); true } catch (_: Exception) { false }
            runOnUiThread {
                Toast.makeText(this, if (ok) L.t("נשמר בגלריה, בתיקייה Movies/Moments", "Saved to your gallery, in Movies/Moments") else L.t("לא הצלחנו לשמור", "Couldn't save"), Toast.LENGTH_LONG).show()
            }
        }
    }
}
