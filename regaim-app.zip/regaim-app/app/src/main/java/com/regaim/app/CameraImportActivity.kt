package com.regaim.app

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Moments from an external camera (GoPro, Insta360, DJI, Ray-Ban Meta glasses...).
 * The camera's own app moves the videos to the phone; here we listen to each video's sound, find the laughs with the
 * same on-phone model as the live recorder, and cut each one into a ~30 second moment. The original video is untouched.
 */
object CameraImport {
    private const val RATE = 16_000
    private const val HOP = RATE / 4 // a window every quarter second: short giggles aren't missed
    /** Videos up to this long are kept whole (no cutting needed). */
    private const val KEEP_WHOLE_MS = 45_000L
    private const val BEFORE_MS = 15_000L
    private const val AFTER_MS = 15_000L
    /** Two moments from the same video are at least this far apart. */
    private const val MIN_APART_MS = 45_000L
    private const val MAX_PER_VIDEO = 10

    class Peak(val ms: Long, val score: Float, val label: String)
    class Found(val name: String, val uri: Uri, val durationMs: Long, val moments: List<Memory>, val error: String? = null, val best: Float = 0f)
    class Listen(val peaks: List<Peak>, val best: Float)

    /** Background thread only. [progress] gets 0..100 for this video. */
    fun process(ctx: Context, uri: Uri, cancelled: AtomicBoolean, progress: (Int) -> Unit): Found {
        Settings.load(ctx)
        val name = displayName(ctx, uri)
        val info = info(ctx, uri)
        if (info.durationMs <= 0) return Found(name, uri, 0, emptyList(), L.t("לא הצלחנו לקרוא את הסרטון", "Couldn't read this video"))
        val heard = try {
            var last = -1
            findLaughs(ctx, uri, info.durationMs, cancelled) { p ->
                val v = (p * 80).toInt()
                if (v != last) { last = v; progress(v) }
            }
        } catch (_: Exception) {
            return Found(name, uri, info.durationMs, emptyList(), L.t("לא הצלחנו לשמוע את הסרטון", "Couldn't listen to this video"))
        }
        val peaks = heard.peaks
        val saved = ArrayList<Memory>()
        try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        /** The whole video as one moment, marked at the laugh (short videos, or when cutting fails). */
        fun keepWhole(p: Peak): Memory? = try {
            val m = MediaImporter.add(ctx, uri)
            MemoryStore.modify(ctx, m.id) { it.copy(label = p.label, highlightMs = p.ms, origin = "camera", chosen = false) }
            MemoryStore.get(ctx, m.id)
        } catch (_: Exception) { null }
        if (peaks.isNotEmpty() && info.durationMs <= KEEP_WHOLE_MS) {
            keepWhole(peaks.maxByOrNull { it.score }!!)?.let { saved.add(it) }
            progress(100)
            return Found(name, uri, info.durationMs, saved, best = heard.best)
        }
        peaks.forEachIndexed { i, p ->
            if (cancelled.get()) return@forEachIndexed
            try {
                val start = (p.ms - BEFORE_MS).coerceAtLeast(0L)
                val end = (p.ms + AFTER_MS).coerceAtMost(info.durationMs)
                val id = UUID.randomUUID().toString()
                val source = Memory(
                    id = id, uri = uri.toString(), name = name, time = info.takenAt + p.ms, label = p.label,
                    lat = null, lon = null, place = "", thumb = "", durationMs = info.durationMs,
                    highlightMs = p.ms, mediaType = "video", origin = "import",
                )
                val cut = ClipTrimmer.trim(ctx, source, start, end)
                val m = cut.copy(
                    origin = "camera",
                    time = info.takenAt + start,
                    timeSource = if (info.dated) "captured" else "imported",
                )
                MemoryStore.add(ctx, m)
                saved.add(m)
            } catch (_: Exception) {
                // Couldn't cut this video (unusual format): keep it whole rather than lose the laugh.
                if (saved.isEmpty()) keepWhole(p)?.let { saved.add(it) }
            }
            progress(80 + (i + 1) * 20 / peaks.size.coerceAtLeast(1))
        }
        progress(100)
        return Found(name, uri, info.durationMs, saved, best = heard.best)
    }

    // ---------- listening ----------

    /** The strongest laughs (or singing, by the user's settings) in the video, at least [MIN_APART_MS] apart. */
    fun findLaughs(ctx: Context, uri: Uri, durationMs: Long, cancelled: AtomicBoolean, progress: (Float) -> Unit): Listen {
        val detector = LaughDetector(ctx)
        val need = detector.requiredSamples
        val times = ArrayList<Long>()
        val scores = ArrayList<Float>()
        val labels = ArrayList<String>()
        try {
            var buf = FloatArray(0)
            var consumedSamples = 0L // samples dropped from the start of buf
            var next = 0L // the next window starts here (in 16 kHz samples)
            decodeMono16k(ctx, uri, cancelled, { ms -> if (durationMs > 0) progress((ms.toFloat() / durationMs).coerceIn(0f, 1f)) }) { chunk ->
                buf = buf + chunk
                while (next + need <= consumedSamples + buf.size) {
                    val from = (next - consumedSamples).toInt()
                    val r = detector.classify(buf.copyOfRange(from, from + need))
                    times.add((next + need / 2) * 1000L / RATE)
                    scores.add(r.score)
                    labels.add(r.label)
                    next += HOP
                }
                // Keep only what the next window still needs.
                val drop = (next - consumedSamples).toInt().coerceIn(0, buf.size)
                if (drop > 0) { buf = buf.copyOfRange(drop, buf.size); consumedSamples += drop }
            }
        } finally {
            detector.close()
        }
        // The same rule as the live recorder: two hits out of three windows, or one very clear laugh.
        // A video is checked calmly afterwards (and the family can delete a miss), so a little more
        // sensitive than live: a laugh counts with a supporting neighbour window, or on its own when clear.
        val thr = Status.threshold * 0.85f
        val strong = maxOf(0.45f, thr * 1.5f)
        val confirmed = scores.indices.filter { i ->
            val s = scores[i]
            if (s < thr || labels[i].isEmpty()) false
            else s >= strong || (maxOf(0, i - 2)..minOf(scores.size - 1, i + 2)).count { it != i && scores[it] >= thr * 0.6f } >= 1
        }
        val chosen = ArrayList<Peak>()
        for (i in confirmed.sortedByDescending { scores[it] }) {
            if (chosen.size >= MAX_PER_VIDEO) break
            if (chosen.all { abs(it.ms - times[i]) >= MIN_APART_MS }) chosen.add(Peak(times[i], scores[i], labels[i]))
        }
        val best = scores.indices.filter { labels[it].isNotEmpty() }.maxOfOrNull { scores[it] } ?: 0f
        return Listen(chosen.sortedBy { it.ms }, best)
    }

    /** Decodes the video's sound to 16 kHz mono floats, chunk by chunk. */
    private fun decodeMono16k(ctx: Context, uri: Uri, cancelled: AtomicBoolean, onTime: (Long) -> Unit, onChunk: (FloatArray) -> Unit) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            val track = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                ?: throw IllegalStateException("no audio")
            ex.selectTrack(track)
            val format = ex.getTrackFormat(track)
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var isFloat = false
            val c = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(format, null, null, 0)
            c.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var resampler = Resampler(rate)
            while (!outputDone && !cancelled.get()) {
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuf = c.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(inBuf, 0)
                        if (size < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            onTime(ex.sampleTime / 1000)
                            ex.advance()
                        }
                    }
                }
                val outIdx = c.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = c.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        isFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) && f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        resampler = Resampler(rate)
                    }
                    outIdx >= 0 -> {
                        if (info.size > 0) {
                            val out = c.getOutputBuffer(outIdx)!!
                            out.position(info.offset); out.limit(info.offset + info.size)
                            val ch = channels.coerceAtLeast(1)
                            val mono: FloatArray = if (isFloat) {
                                val fb = out.order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
                                val frames = fb.remaining() / ch
                                FloatArray(frames) { i -> var s = 0f; for (k in 0 until ch) s += fb.get(i * ch + k); s / ch }
                            } else {
                                val sb = out.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                                val frames = sb.remaining() / ch
                                FloatArray(frames) { i -> var s = 0f; for (k in 0 until ch) s += sb.get(i * ch + k); s / ch / 32768f }
                            }
                            val res = resampler.push(mono)
                            if (res.isNotEmpty()) onChunk(res)
                        }
                        c.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                }
            }
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    /** Any rate → 16 kHz: a gentle low-pass (moving average) then linear interpolation, streaming. */
    private class Resampler(private val from: Int) {
        private val step = from.toDouble() / RATE
        private val avg = (from / RATE).coerceIn(1, 6)
        private var pos = 0.0
        private var tail = FloatArray(0)

        fun push(input: FloatArray): FloatArray {
            if (from == RATE) return input
            val x = tail + input
            // Smooth over [avg] samples so high pitches don't fold into the speech band.
            val smooth = if (avg <= 1) x else FloatArray(x.size) { i ->
                var s = 0f; var n = 0
                for (k in maxOf(0, i - avg + 1)..i) { s += x[k]; n++ }
                s / n
            }
            val out = ArrayList<Float>((x.size / step).toInt() + 2)
            while (pos + 1 < smooth.size) {
                val i = pos.toInt()
                val f = (pos - i).toFloat()
                out.add(smooth[i] * (1 - f) + smooth[i + 1] * f)
                pos += step
            }
            val keepFrom = maxOf(0, pos.toInt() - avg)
            tail = x.copyOfRange(keepFrom, x.size)
            pos -= keepFrom
            return out.toFloatArray()
        }
    }

    // ---------- file details ----------

    private class Info(val durationMs: Long, val takenAt: Long, val dated: Boolean)

    private fun info(ctx: Context, uri: Uri): Info {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val date = parseDate(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE))
            Info(dur, date ?: (System.currentTimeMillis() - dur), date != null)
        } catch (_: Exception) {
            Info(0L, System.currentTimeMillis(), false)
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    /** "20261005T101010.000Z" (the video's own recording time). Cameras without a clock say 1970 or 1904: ignored. */
    internal fun parseDate(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        for (p in listOf("yyyyMMdd'T'HHmmss.SSS'Z'", "yyyyMMdd'T'HHmmss'Z'", "yyyyMMdd'T'HHmmss")) {
            try {
                val f = SimpleDateFormat(p, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                val t = f.parse(s)?.time ?: continue
                return if (t > 946_684_800_000L && t < System.currentTimeMillis() + 86_400_000L) t else null
            } catch (_: Exception) { }
        }
        return null
    }

    private fun displayName(ctx: Context, uri: Uri): String = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
        } ?: uri.lastPathSegment.orEmpty()
    } catch (_: Exception) { uri.lastPathSegment.orEmpty() }
}

/** "ממצלמה חיצונית": pick the camera's videos, and Moments finds the laughs in them. */
class CameraImportActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, CameraImportActivity::class.java))
        private const val MAX_PICK = 20
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val cancelled = AtomicBoolean(false)
    private var running = false
    private var status: TextView? = null
    private var bar: ProgressBar? = null
    private var results: List<CameraImport.Found>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_PICK)) { uris ->
        if (!uris.isNullOrEmpty()) scan(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("ממצלמה חיצונית", "From an external camera")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        mv = MemoryViews(this)
        render()
    }

    override fun onDestroy() {
        cancelled.set(true)
        worker.shutdown()
        super.onDestroy()
    }

    private fun render() {
        content.removeAllViews()
        status = null; bar = null
        val done = results
        if (running) { working(); return }
        if (done != null) { showResults(done); return }

        content.addView(ui.text(L.t(
            "מצלמת אקסטרים או משקפיים מצלמות הרבה. Moments מקשיב לסרטונים, מוצא את הצחוקים ושומר רק אותם כרגעים קצרים.",
            "Action cams and glasses record a lot. Moments listens to the videos, finds the laughs and keeps only those as short moments.",
        ), 16f, top = 16))

        val how = ui.card(top = 16)
        how.addView(ui.text(L.t("איך זה עובד", "How it works"), 16f, bold = true))
        how.addView(ui.text(L.t("1. מעבירים את הסרטונים מהמצלמה לגלריה של הטלפון, דרך האפליקציה של המצלמה.", "1. Move the videos from the camera to your phone's gallery with the camera's own app."), 14f, top = 8))
        how.addView(ui.text(L.t("2. בוחרים כאן את הסרטונים.", "2. Pick the videos here."), 14f, top = 6))
        how.addView(ui.text(L.t("3. Moments מוצא את הצחוקים וגוזר מכל אחד רגע של כחצי דקה. הסרטון המקורי לא משתנה.", "3. Moments finds the laughs and cuts each into a ~30-second moment. The original stays as it is."), 14f, top = 6))
        content.addView(how)

        val cams = ui.card(top = 12)
        cams.addView(ui.text(L.t("מעבירים לטלפון מ:", "Getting the videos to your phone:"), 16f, bold = true))
        fun cam(n: String, he: String, en: String) {
            cams.addView(ui.text(n, 14f, bold = true, top = 10))
            cams.addView(ui.hint(L.t(he, en), top = 2))
        }
        cam("GoPro", "באפליקציית GoPro Quik: מתחברים למצלמה ומורידים את הסרטונים לטלפון. אפשר להפעיל שם העברה אוטומטית.", "In the GoPro Quik app: connect to the camera and download the videos. You can turn on automatic transfer there.")
        cam("Insta360 / DJI", "באפליקציה של המצלמה (Insta360 / DJI Mimo): מורידים או מייצאים את הסרטון לגלריה.", "In the camera's app (Insta360 / DJI Mimo): download or export the video to the gallery.")
        cam("Ray-Ban Meta", "באפליקציית Meta AI: מייבאים את הסרטונים מהמשקפיים ושומרים לגלריה.", "In the Meta AI app: import the videos from the glasses and save them to the gallery.")
        cams.addView(ui.hint(L.t("כל מצלמה אחרת שהסרטונים שלה מגיעים לגלריה עובדת אותו דבר.", "Any other camera whose videos reach your gallery works the same way."), top = 10))
        content.addView(cams)

        content.addView(ui.button(L.t("בחרו סרטונים מהמצלמה", "Choose camera videos"), primary = true, top = 18) {
            try { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) } catch (_: Exception) { }
        })
        content.addView(ui.hint(L.t(
            "עד $MAX_PICK סרטונים בכל פעם. סרטון של 10 דקות לוקח בערך חצי דקה. רגישות הצחוק לפי ההגדרות שלכם.",
            "Up to $MAX_PICK videos at a time. A 10-minute video takes about half a minute. Laugh sensitivity follows your settings.",
        ), top = 6))
    }

    private fun working() {
        status = ui.text(L.t("מקשיבים לסרטונים...", "Listening to the videos…"), 16f, bold = true, top = 24)
        content.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(12) }
        }
        content.addView(bar)
        content.addView(ui.hint(L.t("אפשר להשאיר את המסך פתוח. אם יוצאים, מה שכבר נמצא נשמר.", "Keep this screen open. If you leave, what was found so far is kept."), top = 10))
        content.addView(ui.button(L.t("עצור", "Stop"), top = 18) { cancelled.set(true) })
    }

    private fun scan(uris: List<Uri>) {
        if (running) return
        running = true
        cancelled.set(false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
        worker.execute {
            val found = ArrayList<CameraImport.Found>()
            uris.forEachIndexed { i, uri ->
                if (cancelled.get()) return@forEachIndexed
                val f = CameraImport.process(applicationContext, uri, cancelled) { p ->
                    runOnUiThread {
                        status?.text = if (uris.size == 1) L.t("מקשיבים לסרטון... $p%", "Listening… $p%")
                        else L.t("סרטון ${i + 1} מתוך ${uris.size} · $p%", "Video ${i + 1} of ${uris.size} · $p%")
                        bar?.progress = (i * 100 + p) / uris.size
                    }
                }
                found.add(f)
            }
            runOnUiThread {
                running = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (isFinishing || isDestroyed) return@runOnUiThread
                results = found
                render()
            }
        }
    }

    private fun showResults(found: List<CameraImport.Found>) {
        val moments = found.flatMap { it.moments }
        content.addView(ui.heading(
            when (moments.size) {
                0 -> L.t("לא מצאנו צחוקים", "No laughs found")
                1 -> L.t("מצאנו רגע אחד ❤️", "We found 1 moment ❤️")
                else -> L.t("מצאנו ${moments.size} רגעים ❤️", "We found ${moments.size} moments ❤️")
            }, 24f, top = 20,
        ))
        if (moments.isNotEmpty()) {
            content.addView(ui.hint(L.t("הם כבר בזיכרונות, עם הסרטון המקורי במקום.", "They're already in your memories; the original videos are untouched."), top = 4))
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            moments.forEach { m -> strip.addView(mv.mini(m, 96, 128) { MomentActivity.open(this, m.id) }) }
            content.addView(ui.scrollRow(strip, top = 12))
            content.addView(ui.button(L.t("לזיכרונות", "Open memories"), primary = true, top = 16) {
                startActivity(Intent(this, MemoriesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)); finish()
            })
        }
        val empty = found.filter { it.moments.isEmpty() }
        if (empty.isNotEmpty()) {
            content.addView(ui.section(L.t("סרטונים בלי צחוק", "Videos with no laugh")))
            for (f in empty) {
                val card = ui.card(top = 8)
                card.addView(ui.text(f.name.ifEmpty { L.t("סרטון", "Video") }, 15f, bold = true))
                val pct = (f.best * 100).toInt()
                val need = (Status.threshold * 85).toInt()
                card.addView(ui.hint(f.error ?: (L.t("לא שמענו צחוק ברור", "We didn't hear a clear laugh") +
                    (if (pct > 0) L.t(" (הצחוק הכי חזק: $pct%, צריך $need%)", " (strongest laugh: $pct%, needs $need%)") else "") +
                    L.t(". אפשר להוסיף אותו בכל זאת, או להעלות את רגישות הצחוק בהגדרות.", ". You can still add it, or raise the laugh sensitivity in Settings.")), top = 2))
                if (f.durationMs > 0) card.addView(ui.action(L.t("הוסיפו בכל זאת ›", "Add it anyway ›")) {
                    worker.execute {
                        try { contentResolver.takePersistableUriPermission(f.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                        val m = try { MediaImporter.add(applicationContext, f.uri) } catch (_: Exception) { null }
                        runOnUiThread {
                            if (m == null) android.widget.Toast.makeText(this, L.t("לא הצלחנו להוסיף", "Couldn't add it"), android.widget.Toast.LENGTH_SHORT).show()
                            else if (m.durationMs > NewMemory.MAX_STORY_MS) TrimActivity.open(this, m.id) else MomentActivity.open(this, m.id)
                        }
                    }
                })
                content.addView(card)
            }
        }
        content.addView(ui.button(L.t("עוד סרטונים", "More videos"), top = 18) { results = null; render() })
    }
}
