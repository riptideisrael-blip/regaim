package com.regaim.app

import kotlin.math.sqrt

/**
 * Pure math on face prints (no Android), so it can be tested on any computer.
 * A face print is a length-1 vector; two prints of the same person are close (distance near 0, at most 2).
 */
object FacePrints {
    /** "Not comparable": farther than any two real prints can be, so it never matches anyone. */
    const val FAR = 9f

    fun valid(a: FloatArray): Boolean = a.isNotEmpty() && a.all { it.isFinite() }

    /**
     * Distance between two prints. A damaged print (empty, wrong length, NaN) used to compare as 0 = "the same
     * person as everyone"; now it is [FAR] and never matches.
     */
    fun dist(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return FAR
        var s = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            s += d * d
        }
        return if (s.isFinite()) sqrt(s) else FAR
    }

    /** Length 1, or null when the model gave nothing usable. */
    fun normalize(v: FloatArray): FloatArray? {
        if (!valid(v)) return null
        var n = 0f
        for (x in v) n += x * x
        n = sqrt(n)
        if (!n.isFinite() || n < 1e-6f) return null
        return FloatArray(v.size) { v[it] / n }
    }

    /**
     * The [n] most typical prints of a group (smallest median distance to the rest of the group). When the
     * family names a "Who's this?" group, these are the ones the person is remembered by, so one odd face in the
     * group (a sibling that slipped in, a blurry frame) doesn't teach the app the wrong face.
     */
    fun typical(prints: List<FloatArray>, n: Int): List<FloatArray> {
        val ok = prints.filter { valid(it) }
        if (ok.size <= 3) return ok.take(n) // too few to tell which one is odd
        val scored = ok.map { p ->
            val ds = ok.filter { it !== p }.map { dist(p, it) }.sorted()
            p to ds[ds.size / 2]
        }
        // A print far from the rest of its group (beyond the usual spread) is left out even if there's room.
        val medians = scored.map { it.second }.sorted()
        val usual = medians[medians.size / 2]
        return scored.filter { it.second <= usual * 1.35f + 0.02f }.sortedBy { it.second }.take(n).map { it.first }
    }

    /** Lowercase hex of bytes (for the model's SHA-256). */
    fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }
}

/**
 * When a moment couldn't be scanned for faces (the clip isn't on the phone yet, the phone ran out of memory...),
 * it's tried again on later runs instead of being skipped forever. It's given up on only after [MAX] failed runs.
 */
object ScanTries {
    const val MAX = 3

    fun giveUp(failedRuns: Int): Boolean = failedRuns >= MAX

    /** Which moments to scan now: not tried in this run yet, fewest failures first, then newest. */
    fun order(ids: List<Pair<String, Long>>, tries: Map<String, Int>, triedThisRun: Set<String>): List<String> =
        ids.filter { it.first !in triedThisRun && !giveUp(tries[it.first] ?: 0) }
            .sortedWith(compareBy<Pair<String, Long>> { tries[it.first] ?: 0 }.thenByDescending { it.second })
            .map { it.first }
}
