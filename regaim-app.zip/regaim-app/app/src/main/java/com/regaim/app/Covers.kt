package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Rectangular cover images for the big memory cards (the round bubbles are too small for them).
 * Taken from the middle of the clip (the moment itself), cached on disk and in memory.
 */
object Covers {
    private val mem = object : LruCache<String, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private const val PLACEHOLDER = 0xFFEFEFEF.toInt()

    private fun key(m: Memory) = "${m.id}_${m.uri.hashCode()}_${m.mediaType}_${m.durationMs}_${m.previewWindow?.startMs}_${m.previewWindow?.endMs}"
    private fun file(ctx: Context, m: Memory) = File(File(ctx.filesDir, "covers").apply { mkdirs() }, key(m) + ".jpg")

    /** Background thread only. */
    fun get(ctx: Context, m: Memory): Bitmap? {
        mem.get(key(m))?.let { return it }
        val f = file(ctx, m)
        val cached: Bitmap? = if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        val bmp: Bitmap? = cached ?: extract(ctx, m)?.also { fresh ->
            try { FileOutputStream(f).use { out -> fresh.compress(Bitmap.CompressFormat.JPEG, 84, out) } } catch (_: Exception) {}
        } ?: (if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb) else null)
        bmp?.let { mem.put(key(m), it) }
        return bmp
    }

    private fun extract(ctx: Context, m: Memory): Bitmap? {
        if (!m.isVideo) return MediaImages.decode(ctx, m.uri, 720)
        val mmr = MediaMetadataRetriever()
        return try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: m.durationMs
            val window = m.previewWindow
            val atMs = if (window != null) window.startMs + (window.endMs - window.startMs) / 2 else dur / 2
            val frame = mmr.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: return null
            val w = 720
            if (frame.width <= w) frame
            else Bitmap.createScaledBitmap(frame, w, (frame.height * w.toFloat() / frame.width).toInt(), true)
        } catch (_: Throwable) {
            null
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    /** Shows the cover in [iv] (placeholder first, soft fade in when ready). */
    fun load(iv: ImageView, m: Memory, onReady: ((Bitmap) -> Unit)? = null) {
        val k = key(m)
        iv.tag = k
        mem.get(k)?.let {
            iv.setImageBitmap(it)
            onReady?.invoke(it)
            return
        }
        iv.setImageDrawable(ColorDrawable(PLACEHOLDER))
        val ctx = iv.context.applicationContext
        pool.execute {
            val b = try { get(ctx, m) } catch (_: Throwable) { null }
            main.post {
                if (b != null && iv.tag == k && !Motion.isPlaying(iv)) {
                    iv.alpha = 0f
                    iv.setImageBitmap(b)
                    iv.animate().alpha(1f).setDuration(220).start()
                    onReady?.invoke(b)
                }
            }
        }
    }
}
