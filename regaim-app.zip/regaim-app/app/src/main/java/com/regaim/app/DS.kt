package com.regaim.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import androidx.core.content.ContextCompat

/**
 * The Moments design system in code (Minimal Luxury). Every screen takes its colors, type, radii and depth from here
 * (values live in res/values/colors.xml and dimens.xml). No screen defines a color of its own.
 */
object DS {
    // ---------- colors ----------
    fun bg(c: Context) = col(c, R.color.ds_bg)
    fun card(c: Context) = col(c, R.color.ds_card)
    fun cardAlt(c: Context) = col(c, R.color.ds_card_alt)
    fun line(c: Context) = col(c, R.color.ds_line)
    fun primary(c: Context) = col(c, R.color.ds_primary)
    fun button(c: Context) = col(c, R.color.ds_button)
    fun buttonPressed(c: Context) = col(c, R.color.ds_button_pressed)
    fun buttonSecondary(c: Context) = col(c, R.color.ds_button_secondary)
    fun buttonSecondaryPressed(c: Context) = col(c, R.color.ds_button_secondary_pressed)
    fun onButton(c: Context) = col(c, R.color.ds_on_button)
    fun ink(c: Context) = col(c, R.color.ds_ink)
    fun inkSoft(c: Context) = col(c, R.color.ds_ink_soft)
    fun onPhoto(c: Context) = col(c, R.color.ds_on_photo)
    fun selected(c: Context) = col(c, R.color.ds_selected_bg)
    fun error(c: Context) = col(c, R.color.ds_error)
    fun errorBg(c: Context) = col(c, R.color.ds_error_bg)
    fun heart(c: Context) = col(c, R.color.ds_heart)
    fun star(c: Context) = col(c, R.color.ds_star)
    fun scrim(c: Context) = col(c, R.color.ds_scrim)
    fun scrimSoft(c: Context) = col(c, R.color.ds_scrim_soft)
    fun disabledBg(c: Context) = col(c, R.color.ds_disabled_bg)
    fun disabledInk(c: Context) = col(c, R.color.ds_disabled_ink)
    fun ripple(c: Context, onDark: Boolean = false) = col(c, if (onDark) R.color.ds_ripple_on_dark else R.color.ds_ripple)

    private fun col(c: Context, id: Int) = ContextCompat.getColor(c, id)

    // ---------- shape and depth ----------
    fun radiusCard(c: Context) = c.resources.getDimension(R.dimen.ds_radius_card)
    fun radiusButton(c: Context) = c.resources.getDimension(R.dimen.ds_radius_button)
    fun radiusMedia(c: Context) = c.resources.getDimension(R.dimen.ds_radius_media)
    fun radiusChip(c: Context) = c.resources.getDimension(R.dimen.ds_radius_chip)
    fun padCard(c: Context) = c.resources.getDimensionPixelSize(R.dimen.ds_pad_card)
    fun buttonHeight(c: Context) = c.resources.getDimensionPixelSize(R.dimen.ds_button_height)
    fun elevationCard(c: Context) = c.resources.getDimension(R.dimen.ds_elevation_card)

    /** A rounded fill, optionally with a hairline border. */
    fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        cornerRadius = radius
        setColor(color)
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    /** A pill / circle fill. */
    fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    /** A card: warm beige, large rounded corners, a whisper of shadow. */
    fun cardBackground(v: View, color: Int = card(v.context)) {
        v.background = rounded(color, radiusCard(v.context))
        v.elevation = elevationCard(v.context)
        v.outlineAmbientShadowColorCompat(col(v.context, R.color.ds_shadow))
    }

    /** Touch feedback in the brand's soft tone, on top of [content]. */
    fun pressable(c: Context, content: GradientDrawable, onDark: Boolean = false) =
        RippleDrawable(ColorStateList.valueOf(ripple(c, onDark)), content, null)

    // ---------- type ----------
    /** Hebrew headings: Heebo Bold. */
    val heading: Typeface get() = Fonts.display
    /** Body text: Heebo Regular. */
    val body: Typeface get() = Fonts.regularFace
    /** Buttons and emphasis: Heebo SemiBold. */
    val emphasis: Typeface get() = Fonts.strongFace
    /** The English wordmark: an elegant serif (Gelasio, metric-compatible with Georgia). */
    val logo: Typeface get() = Fonts.serif

    private fun View.outlineAmbientShadowColorCompat(color: Int) {
        if (android.os.Build.VERSION.SDK_INT >= 28) { outlineAmbientShadowColor = color; outlineSpotShadowColor = color }
    }
}
