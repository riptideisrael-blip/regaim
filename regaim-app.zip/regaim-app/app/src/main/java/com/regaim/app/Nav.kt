package com.regaim.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Bottom tab bar shared by the four main screens. */
object Nav {
    enum class Tab { TODAY, MEMORIES, MILESTONES, ASK }

    private val ids = mapOf(
        Tab.TODAY to R.id.tabToday,
        Tab.MEMORIES to R.id.tabMemories,
        Tab.MILESTONES to R.id.tabMilestones,
        Tab.ASK to R.id.tabAsk,
    )

    private val targets: Map<Tab, Class<out Activity>> = mapOf(
        Tab.TODAY to MainActivity::class.java,
        Tab.MEMORIES to MemoriesActivity::class.java,
        Tab.MILESTONES to MilestonesActivity::class.java,
        Tab.ASK to ChatActivity::class.java,
    )

    fun setup(a: Activity, current: Tab) {
        val on = ContextCompat.getColor(a, R.color.accent)
        val off = ContextCompat.getColor(a, R.color.ink_soft)
        for ((tab, id) in ids) {
            val v = a.findViewById<LinearLayout>(id) ?: continue
            val selected = tab == current
            val color = if (selected) on else off
            (v.getChildAt(0) as? ImageView)?.setColorFilter(color)
            (v.getChildAt(1) as? TextView)?.apply {
                setTextColor(color)
                typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            v.setOnClickListener {
                if (!selected) {
                    a.startActivity(Intent(a, targets.getValue(tab)).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                    @Suppress("DEPRECATION")
                    a.overridePendingTransition(0, 0)
                }
            }
        }
    }
}
