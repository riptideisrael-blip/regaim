package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/**
 * "ספר אישי": choose a child and a theme; the app picks the photos, writes the story, draws the child as the
 * book's hero for the parent to approve, then draws the book.
 */
class BookActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, BookActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private var child: FamilyMember? = null
    private var theme: BookTheme = BookThemes.ALL.first()
    private var details: android.widget.EditText? = null

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) BookMaker.current?.usePhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("ספר אישי", "Personal book")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        child = Profile.members(this).firstOrNull { it.isChild }
    }

    override fun onResume() {
        super.onResume()
        BookService.screenOpen = true
        BookService.clearNotice(this)
        Refunds.flushAsync(applicationContext) // a refund that couldn't be sent earlier (no connection)
        BookMaker.current?.listener = { render() }
        render()
    }

    override fun onPause() {
        BookService.screenOpen = false
        BookMaker.current?.listener = null
        super.onPause()
    }

    private fun render() {
        content.removeAllViews()
        val s = BookMaker.current
        if (s == null) { setup(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        when (s.state) {
            BookMaker.State.PHOTOS, BookMaker.State.WRITING, BookMaker.State.CHARACTER -> working(s)
            BookMaker.State.NEED_PHOTO -> needPhoto(s)
            BookMaker.State.CONFIRM_PHOTOS -> confirmPhotos(s)
            BookMaker.State.APPROVE -> approve(s)
            BookMaker.State.PAGES -> pages(s)
            BookMaker.State.PAUSED -> paused(s)
            BookMaker.State.NEED_CREDIT -> needCredit(s)
            BookMaker.State.DONE -> done(s)
            BookMaker.State.FAILED -> failed(s)
        }
    }

    private fun setup() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t(
            "ספר קצר שהילד שלכם הוא הגיבור שלו. בוחרים ילד ונושא, ו-Moments בוחר לבד את התמונות הכי טובות, כותב את הסיפור ומצייר אותו.",
            "A short book where your child is the hero. Pick a child and a theme; Moments picks the best photos, writes the story and illustrates it.",
        ), 16f, top = 14))
        val kids = Profile.members(this).filter { it.isChild }
        if (kids.isEmpty()) {
            content.addView(ui.text(L.t("עוד אין ילדים בפרופיל המשפחה", "There are no children in the family profile yet"), 16f, bold = true, top = 20))
            content.addView(ui.button(L.t("לפרופיל המשפחה", "Family profile"), primary = true, top = 12) { startActivity(Intent(this, FamilyActivity::class.java)) })
            return
        }
        content.addView(ui.text(L.t("מי הגיבור?", "Who's the hero?"), 16f, bold = true, top = 20))
        val sel = kids.indexOfFirst { it.id == child?.id }.coerceAtLeast(0)
        child = kids[sel]
        content.addView(ui.chips(kids.map { it.name }, sel, top = 8) { i -> child = kids[i]; render() })

        content.addView(ui.text(L.t("על מה הספר?", "What's it about?"), 16f, bold = true, top = 20))
        val themes = BookThemes.ALL
        content.addView(ui.chips(themes.map { it.title }, themes.indexOf(theme), top = 8) { i -> theme = themes[i]; render() })

        val field = ui.field(L.t("פרטים שיעזרו לסיפור (לא חובה): שם המוצץ, צעצוע אהוב, שם האח...", "Details for the story (optional): the pacifier's name, a favorite toy, a sibling's name..."), details?.text?.toString().orEmpty(), multiline = true, top = 16)
        details = field
        content.addView(field)

        content.addView(ui.button(L.t("צרו את הספר", "Create the book"), primary = true, top = 18) { consent() })
        content.addView(ui.hint(L.t("ספר של ${BookMaker.PAGES} עמודים וכריכה. עולה קרדיט אחד (כמו סרט מצויר). לפני שמציירים את הספר, תראו את הדמות ותאשרו אותה.", "${BookMaker.PAGES} pages and a cover. Uses one credit (like an animated film). Before the book is drawn, you'll see the character and approve it."), top = 8))

        // A book that stopped in the middle (no connection, or the phone closed the app): continue it from where it was.
        BookMaker.unfinished(this)?.let { u ->
            val card = ui.card(top = 18)
            card.addView(ui.text(L.t("ספר שלא הסתיים: ${u.title}", "An unfinished book: ${u.title}"), 16f, bold = true, top = 0))
            card.addView(ui.hint(L.t("ממשיכים מהשלב שבו הוא נעצר. בתוך 30 דקות מההתחלה זה לא עולה קרדיט נוסף.", "It continues from where it stopped. Within 30 minutes of the start it costs no extra credit."), top = 4))
            card.addView(ui.button(L.t("המשיכו", "Continue"), primary = true, top = 10) { BookMaker.resume(this, u).listener = { render() }; render() })
            card.addView(ui.action(L.t("ביטול הספר", "Cancel the book")) {
                Thread { BookMaker.abandon(applicationContext, u); runOnUiThread { if (!isFinishing) render() } }.start()
            }.apply { setPadding(0, ui.dp(12), 0, 0) })
            content.addView(card)
        }

        val books = BookStore.all(this).filter { it.done }
        if (books.isNotEmpty()) {
            content.addView(ui.section(L.t("הספרים שלכם", "Your books")))
            for (b in books) content.addView(ui.row(b.title, b.child) { BookViewerActivity.open(this, b.id) })
        }
    }

    /** Exactly what leaves the phone, and where it goes (checked against the providers' published terms). */
    private fun consent() {
        val c = child ?: return
        if (!Account.signedIn(this)) { WelcomeActivity.open(this); return }
        AlertDialog.Builder(this)
            .setTitle(L.t("לפני שמתחילים: מה נשלח", "Before we start: what is sent"))
            .setMessage(L.t(
                "• לכתיבת הסיפור, ל-Claude של Anthropic: השם ${c.name}, הגיל, הנושא והפרטים שכתבתם. בלי תמונות. לפי Anthropic, מידע שנשלח דרך ה-API נמחק תוך 30 יום (למעט חריגים, כמו בדיקת שימוש לרעה).\n\n" +
                    "• לציור, ל-fal.ai: עד 3 תמונות פנים של ${c.name} שנבחרו מהרגעים שלכם, לציור הדמות (במודל GPT Image של OpenAI), ואחר כך הדמות המצוירת ותמונת פנים אחת לכל עמוד (במודל nano-banana של Google).\n" +
                    "אצל fal התוצאות נשמרות כקישורים ציבוריים (כל מי שיש לו את הקישור) עד שנמחקות. אנחנו מורידים כל ציור מיד, קובעים לו תפוגה של שעה, ומבקשים מ-fal למחוק את הבקשה ואת הקבצים. fal לא מפרסמת איך OpenAI ו-Google מעבדות את המידע.\n\n" +
                    "• השרת של Moments מעביר את התמונות ולא שומר אותן. הספר נשמר רק בטלפון.\n\n" +
                    "• עלות: קרדיט אחד. אם לא תאשרו את הדמות, הקרדיט יוחזר.",
                "• To write the story, to Anthropic's Claude: the name ${c.name}, the age, the theme and your details. No photos. Anthropic says data sent through its API is deleted within 30 days (except e.g. abuse checks).\n\n" +
                    "• To draw, to fal.ai: up to 3 face photos of ${c.name} chosen from your moments, to draw the character (with OpenAI's GPT Image model), then the drawn character and one face photo for each page (with Google's nano-banana model).\n" +
                    "At fal, results are public links (anyone with the link) until deleted. We download each drawing at once, set it to expire in an hour, and ask fal to delete the request and its files. fal doesn't publish how OpenAI and Google process the data.\n\n" +
                    "• Moments' server passes the photos on and doesn't keep them. The book is saved only on your phone.\n\n" +
                    "• Cost: one credit. If you don't approve the character, the credit is returned.",
            ))
            .setPositiveButton(L.t("מסכימים, צרו את הספר", "I agree, create the book")) { _, _ ->
                BookMaker.start(this, c, theme, details?.text?.toString().orEmpty()).listener = { render() }
                render()
            }
            .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
            .show()
    }

    private fun working(s: BookMaker.Session) {
        content.addView(ui.text(s.message, 17f, bold = true, top = 24))
        content.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = s.state != BookMaker.State.PHOTOS
            max = 100; progress = s.progress
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(12) }
        })
        if (s.waiting) content.addView(ui.text(L.t("אין חיבור לאינטרנט כרגע. ממשיכים לבד כשהחיבור יחזור.", "No internet connection right now. We'll carry on by ourselves when it's back."), 15f, R.color.accent, top = 12))
        content.addView(ui.hint(L.t("זה לוקח דקה-שתיים. אפשר לצאת מהאפליקציה: הספר ממשיך ברקע ונשלח התראה.", "This takes a minute or two. You can leave the app: the book carries on and we'll notify you."), top = 10))
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(18), 0, 0) })
    }

    /** Face recognition can mix up siblings: the parent removes any photo that isn't this child. Nothing is sent yet. */
    private fun confirmPhotos(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val name = s.childName
        content.addView(ui.text(L.t("אלה תמונות של $name?", "Are these photos of $name?"), 20f, bold = true, top = 16))
        content.addView(ui.hint(L.t(
            "לחצו על כל תמונה שאינה של $name (למשל אח או אחות) כדי להסיר אותה. הדמות תצויר מ-3 התמונות הראשונות. עוד לא נשלח כלום ולא ירד קרדיט.",
            "Tap any photo that isn't $name (a brother or sister, say) to remove it. The character is drawn from the first 3. Nothing has been sent and no credit used yet.",
        ), top = 4))
        val list = s.candidates.toList()
        list.chunked(3).forEachIndexed { r, chunk ->
            val row = ui.horizontal(top = if (r == 0) 12 else 8)
            chunk.forEachIndexed { k, c ->
                val used = r * 3 + k < 3
                row.addView(android.widget.FrameLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ui.dp(104), 1f).apply { if (k > 0) marginStart = ui.dp(8) }
                    addView(ImageView(this@BookActivity).apply {
                        setImageBitmap(c.crop)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundResource(R.drawable.rounded_media)
                        clipToOutline = true
                        alpha = if (used) 1f else 0.55f
                    }, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    addView(TextView(this@BookActivity).apply {
                        text = "✕"
                        textSize = 16f
                        setTextColor(android.graphics.Color.WHITE)
                        setBackgroundColor(0x88000000.toInt())
                        setPadding(ui.dp(8), ui.dp(2), ui.dp(8), ui.dp(4))
                    }, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.TOP or android.view.Gravity.END))
                    setOnClickListener { s.removeCandidate(c); render() }
                })
            }
            content.addView(row)
        }
        if (list.isEmpty()) content.addView(ui.hint(L.t("לא נשארו תמונות. הוסיפו תמונה ברורה של $name.", "No photos left. Add a clear photo of $name."), top = 12))
        content.addView(ui.button(L.t("כן, אלה תמונות של $name", "Yes, these are $name"), primary = true, top = 16) { s.confirmPhotos(); render() }.apply { isEnabled = list.isNotEmpty() })
        content.addView(ui.button(L.t("הוסיפו תמונה מהגלריה", "Add a photo from the gallery"), top = 8) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        })
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun needPhoto(s: BookMaker.Session) {
        content.addView(ui.text(L.t("צריך תמונה אחת ברורה", "We need one clear photo"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("בחרו תמונה של ${s.childName}", "Pick a photo of ${s.childName}"), primary = true, top = 16) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        })
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun approve(s: BookMaker.Session) {
        val b = s.book ?: return
        content.addView(ui.text(L.t("זה ${s.childName} בספר?", "Is this ${s.childName} in the book?"), 20f, bold = true, top = 16))
        content.addView(ui.hint(L.t("כך ${s.childName} ייראה/תיראה בכל העמודים. כדאי לאשר רק אם זה באמת דומה.", "This is how ${s.childName} will look on every page. Approve only if it really looks right."), top = 4))
        val f = BookStore.image(this, b, b.character)
        content.addView(ImageView(this).apply {
            adjustViewBounds = true
            setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(12) }
        })
        // The photos the character was drawn from: if it doesn't look right, the parent can see whether the photos were the problem.
        val faces = (0 until 3).map { BookStore.image(this, b, "face_$it.jpg") }.filter { it.exists() }
        if (faces.isNotEmpty()) {
            content.addView(ui.hint(L.t("צויר מהתמונות האלה:", "Drawn from these photos:"), top = 10))
            val row = ui.horizontal(top = 6)
            for (f in faces) row.addView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundResource(R.drawable.rounded_media)
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(ui.dp(72), ui.dp(72)).apply { marginEnd = ui.dp(8) }
            })
            content.addView(row)
        }
        content.addView(ui.text(b.title, 16f, bold = true, top = 12))
        content.addView(ui.button(L.t("מאשרים, ציירו את הספר", "Approve, draw the book"), primary = true, top = 14) { s.approve() })
        if (s.triesLeft > 0) content.addView(ui.button(L.t("ציור מחדש (נותרו ${s.triesLeft})", "Draw again (${s.triesLeft} left)"), top = 8) { s.redrawCharacter() })
        content.addView(ui.action(L.t("לא דומה, בטלו (הקרדיט יוחזר)", "Doesn't look right, cancel (credit returned)")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun pages(s: BookMaker.Session) {
        content.addView(ui.text(L.t("מציירים את הספר... ${s.progress}%", "Drawing the book... ${s.progress}%"), 17f, bold = true, top = 24))
        content.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = s.progress
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(12) }
        })
        if (s.waiting) content.addView(ui.text(L.t("אין חיבור לאינטרנט כרגע. ממשיכים לבד כשהחיבור יחזור.", "No internet connection right now. We'll carry on by ourselves when it's back."), 15f, R.color.accent, top = 12))
        content.addView(ui.hint(L.t("כמה דקות. אפשר לצאת מהאפליקציה: הספר ממשיך ברקע ונשלח התראה כשהוא מוכן.", "A few minutes. You can leave the app: the book carries on and we'll notify you when it's ready."), top = 10))
    }

    private fun done(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val b = s.book ?: return
        content.addView(ui.text(L.t("הספר מוכן 📖", "The book is ready 📖"), 20f, bold = true, top = 20))
        if (s.message.isNotEmpty()) content.addView(ui.hint(s.message, top = 4))
        content.addView(ui.button(L.t("פתחו את הספר", "Open the book"), primary = true, top = 16) { BookViewerActivity.open(this, b.id) })
        content.addView(ui.action(L.t("ספר חדש", "A new book")) { BookMaker.clear(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    /** No connection for a few minutes: the book is saved as it is. */
    private fun paused(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("הספר נשמר", "The book is saved"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("המשיכו את הספר", "Continue the book"), primary = true, top = 16) { s.retry(); render() })
        content.addView(ui.action(L.t("ביטול הספר", "Cancel the book")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    /** The credit's window is over: continuing needs the parent's OK for one more credit. */
    private fun needCredit(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("להמשיך את הספר?", "Continue the book?"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("כן, להמשיך (קרדיט אחד)", "Yes, continue (one credit)"), primary = true, top = 16) { s.continueWithNewCredit(); render() })
        content.addView(ui.action(L.t("לא, לבטל את הספר", "No, cancel the book")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun failed(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("הספר לא נוצר", "The book wasn't created"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("חזרה", "Back"), primary = true, top = 16) { BookMaker.clear(); render() })
    }
}

/** A finished book: page by page (cover first), right to left, with "draw this page again". */
class BookViewerActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_ID = "book"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, BookViewerActivity::class.java).putExtra(EXTRA_ID, id))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private var index = 0
    private var busy = false
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        render()
    }

    override fun onDestroy() { worker.shutdown(); super.onDestroy() }

    private fun render() {
        content.removeAllViews()
        val b = BookStore.load(this, intent.getStringExtra(EXTRA_ID).orEmpty()) ?: run { finish(); return }
        findViewById<TextView>(R.id.screenTitle).text = b.title
        val pages = b.allPages
        index = index.coerceIn(0, pages.size - 1)
        val p = pages[index]
        val f = if (p.image.isNotEmpty()) File(BookStore.dir(this, b.id), p.image) else null
        if (f != null && f.exists()) content.addView(ImageView(this).apply {
            adjustViewBounds = true
            setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(12) }
        }) else content.addView(ui.hint(L.t("העמוד הזה עוד לא צויר.", "This page isn't drawn yet."), top = 16))
        content.addView(TextView(this).apply {
            text = p.text
            textSize = if (index == 0) 26f else 20f
            if (index == 0) typeface = Fonts.display
            setLineSpacing(ui.dp(4).toFloat(), 1f)
            setTextColor(ui.color(R.color.ink))
            gravity = android.view.Gravity.CENTER
            setPadding(ui.dp(8), ui.dp(18), ui.dp(8), ui.dp(8))
        })
        content.addView(ui.hint(if (index == 0) L.t("כריכה", "Cover") else L.t("עמוד $index מתוך ${pages.size - 1}", "Page $index of ${pages.size - 1}"), top = 4).apply { gravity = android.view.Gravity.CENTER })

        val nav = ui.horizontal(top = 14)
        nav.addView(ui.button(L.t("הבא ›", "Next ›"), primary = true, top = 0) { if (index < pages.size - 1) { index++; render() } }.apply {
            isEnabled = index < pages.size - 1
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        nav.addView(ui.button(L.t("‹ הקודם", "‹ Back"), top = 0) { if (index > 0) { index--; render() } }.apply {
            isEnabled = index > 0
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = ui.dp(8) }
        })
        content.addView(nav)
        content.addView(ui.action(if (busy) L.t("מציירים מחדש...", "Redrawing...") else L.t("לצייר את העמוד הזה מחדש", "Draw this page again")) { redraw(b, index, false) }.apply { setPadding(0, ui.dp(18), 0, 0) })
    }

    private fun redraw(b: Book, i: Int, newCredit: Boolean) {
        if (busy) return
        busy = true
        render()
        worker.execute {
            val err = try { BookMaker.Pages.redraw(applicationContext, b.id, i, newCredit); null } catch (e: BookMaker.NeedCredit) { "credit" } catch (e: Exception) { e.message ?: "" }
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                when (err) {
                    null -> render()
                    "credit" -> AlertDialog.Builder(this)
                        .setMessage(L.t("עברו 30 דקות מאז שהספר צויר, אז ציור מחדש משתמש בקרדיט נוסף (שמאפשר עוד תיקונים בחצי השעה הקרובה). להמשיך?", "It's been over 30 minutes since the book was drawn, so redrawing uses another credit (good for more fixes in the next half hour). Continue?"))
                        .setPositiveButton(L.t("כן", "Yes")) { _, _ -> redraw(b, i, true) }
                        .setNegativeButton(L.t("לא", "No"), null).show()
                    else -> { render(); android.widget.Toast.makeText(this, err, android.widget.Toast.LENGTH_LONG).show() }
                }
            }
        }
    }
}
