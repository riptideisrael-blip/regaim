package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/**
 * "ספר אישי": choose a child and a theme; the app picks the photos, writes the story, draws the child as the
 * book's hero for the parent to approve, then draws the book.
 */
class BookActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, BookActivity::class.java))
    }

    private lateinit var ui: Ui
    private lateinit var content: LinearLayout
    private var child: FamilyMember? = null
    private var theme: BookTheme = BookThemes.ALL.first()
    private var details: android.widget.EditText? = null

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) BookMaker.current?.usePhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = L.t("ספר אישי", "Personal book")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        content = findViewById(R.id.screenContent)
        ui = Ui(this)
        child = Profile.members(this).firstOrNull { it.isChild }
    }

    override fun onResume() {
        super.onResume()
        BookService.screenOpen = true
        BookService.clearNotice(this)
        Refunds.flushAsync(applicationContext) // a refund that couldn't be sent earlier (no connection)
        BookMaker.current?.listener = { render() }
        render()
    }

    override fun onPause() {
        BookService.screenOpen = false
        BookMaker.current?.listener = null
        super.onPause()
    }

    private fun render() {
        content.removeAllViews()
        val s = BookMaker.current
        if (s == null) { setup(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        when (s.state) {
            BookMaker.State.PHOTOS, BookMaker.State.WRITING, BookMaker.State.CHARACTER -> working(s)
            BookMaker.State.NEED_PHOTO -> needPhoto(s)
            BookMaker.State.CONFIRM_PHOTOS -> confirmPhotos(s)
            BookMaker.State.CAST -> if (s.castChoices.isEmpty()) working(s) else cast(s)
            BookMaker.State.APPROVE -> approve(s)
            BookMaker.State.PAGES -> pages(s)
            BookMaker.State.PAUSED -> paused(s)
            BookMaker.State.NEED_CREDIT -> needCredit(s)
            BookMaker.State.DONE -> done(s)
            BookMaker.State.FAILED -> failed(s)
        }
    }

    private fun setup() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t(
            "ספר קצר שהילד שלכם הוא הגיבור שלו. בוחרים ילד ונושא, ו-Moments בוחר לבד את התמונות הכי טובות, כותב את הסיפור ומצייר אותו.",
            "A short book where your child is the hero. Pick a child and a theme; Moments picks the best photos, writes the story and illustrates it.",
        ), 16f, top = 14))
        val kids = Profile.members(this).filter { it.isChild }
        if (kids.isEmpty()) {
            content.addView(ui.text(L.t("עוד אין ילדים בפרופיל המשפחה", "There are no children in the family profile yet"), 16f, bold = true, top = 20))
            content.addView(ui.button(L.t("לפרופיל המשפחה", "Family profile"), primary = true, top = 12) { startActivity(Intent(this, FamilyActivity::class.java)) })
            return
        }
        content.addView(ui.text(L.t("מי הגיבור?", "Who's the hero?"), 16f, bold = true, top = 20))
        val sel = kids.indexOfFirst { it.id == child?.id }.coerceAtLeast(0)
        child = kids[sel]
        content.addView(ui.chips(kids.map { it.name }, sel, top = 8) { i -> child = kids[i]; render() })

        content.addView(ui.text(L.t("על מה הספר?", "What's it about?"), 16f, bold = true, top = 20))
        val themes = BookThemes.ALL
        content.addView(ui.chips(themes.map { it.title }, themes.indexOf(theme), top = 8) { i -> theme = themes[i]; render() })

        val field = ui.field(L.t("פרטים שיעזרו לסיפור (לא חובה): שם המוצץ, צעצוע אהוב, שם האח...", "Details for the story (optional): the pacifier's name, a favorite toy, a sibling's name..."), details?.text?.toString().orEmpty(), multiline = true, top = 16)
        details = field
        content.addView(field)

        content.addView(ui.button(L.t("צרו את הספר", "Create the book"), primary = true, top = 18) { consent() })
        content.addView(ui.hint(L.t("ספר של ${BookMaker.PAGES} עמודים, כריכה והקדשה. עולה קרדיט אחד. לפני שמציירים את הספר, תבחרו מאילו תמונות לצייר כל דמות ותאשרו את הדמויות.", "${BookMaker.PAGES} pages, a cover and a dedication. Uses one credit. Before the book is drawn, you choose the photos to draw each character from and approve the characters."), top = 8))

        // A book that stopped in the middle (no connection, or the phone closed the app): continue it from where it was.
        BookMaker.unfinished(this)?.let { u ->
            val card = ui.card(top = 18)
            card.addView(ui.text(L.t("ספר שלא הסתיים: ${u.title}", "An unfinished book: ${u.title}"), 16f, bold = true, top = 0))
            card.addView(ui.hint(L.t("ממשיכים מהשלב שבו הוא נעצר. בתוך שלוש שעות מההתחלה זה לא עולה קרדיט נוסף.", "It continues from where it stopped. Within three hours of the start it costs no extra credit."), top = 4))
            card.addView(ui.button(L.t("המשיכו", "Continue"), primary = true, top = 10) { BookMaker.resume(this, u).listener = { render() }; render() })
            card.addView(ui.action(L.t("ביטול הספר", "Cancel the book")) {
                Thread { BookMaker.abandon(applicationContext, u); runOnUiThread { if (!isFinishing) render() } }.start()
            }.apply { setPadding(0, ui.dp(12), 0, 0) })
            content.addView(card)
        }

        val books = BookStore.all(this).filter { it.done }
        if (books.isNotEmpty()) {
            content.addView(ui.section(L.t("הספרים שלכם", "Your books")))
            for (b in books) content.addView(ui.row(b.title, b.child) { BookViewerActivity.open(this, b.id) })
        }
    }

    /** Exactly what leaves the phone, and where it goes (checked against the providers' published terms). */
    private fun consent() {
        val c = child ?: return
        if (!Account.signedIn(this)) { WelcomeActivity.open(this); return }
        AlertDialog.Builder(this)
            .setTitle(L.t("לפני שמתחילים: מה נשלח", "Before we start: what is sent"))
            .setMessage(L.t(
                "• לכתיבת הסיפור, ל-Claude של Anthropic: השם ${c.name}, הגיל, הנושא, הפרטים שכתבתם, ושמות בני המשפחה והקשר שלהם לילד (מפרופיל המשפחה). בלי תמונות. לפי Anthropic, מידע שנשלח דרך ה-API נמחק תוך 30 יום (למעט חריגים, כמו בדיקת שימוש לרעה).\n\n" +
                    "• לציור, ל-fal.ai, שמריצה את מודל הציור GPT Image של OpenAI: עד 3 תמונות פנים של ${c.name} שאישרתם, ותמונת פנים של כל בן משפחה שתבחרו לצייר לפי תמונה (אפשר לבחור \"בלי תמונה\"). אחר כך הדמויות המצוירות נשלחות לציור כל עמוד.\n" +
                    "אצל fal התוצאות נשמרות כקישורים ציבוריים (כל מי שיש לו את הקישור) עד שנמחקות. אנחנו מורידים כל ציור מיד, קובעים לו תפוגה של שעה, ומבקשים מ-fal למחוק את הבקשה ואת הקבצים. fal לא מפרסמת איך OpenAI מעבדת את המידע.\n\n" +
                    "• השרת של Moments מעביר את התמונות ולא שומר אותן. הספר נשמר רק בטלפון.\n\n" +
                    "• עלות: קרדיט אחד. אם לא תאשרו את הדמויות, הקרדיט יוחזר.",
                "• To write the story, to Anthropic's Claude: the name ${c.name}, the age, the theme, your details, and your family members' names and how they relate to the child (from the family profile). No photos. Anthropic says data sent through its API is deleted within 30 days (except e.g. abuse checks).\n\n" +
                    "• To draw, to fal.ai, which runs OpenAI's GPT Image drawing model: up to 3 face photos of ${c.name} that you approved, and a face photo of each family member you choose to draw from a photo (you can choose \"without a photo\"). Then the drawn characters are sent for drawing each page.\n" +
                    "At fal, results are public links (anyone with the link) until deleted. We download each drawing at once, set it to expire in an hour, and ask fal to delete the request and its files. fal doesn't publish how OpenAI processes the data.\n\n" +
                    "• Moments' server passes the photos on and doesn't keep them. The book is saved only on your phone.\n\n" +
                    "• Cost: one credit. If you don't approve the characters, the credit is returned.",
            ))
            .setPositiveButton(L.t("מסכימים, צרו את הספר", "I agree, create the book")) { _, _ ->
                BookMaker.start(this, c, theme, details?.text?.toString().orEmpty()).listener = { render() }
                render()
            }
            .setNegativeButton(L.t("לא עכשיו", "Not now"), null)
            .show()
    }

    private fun working(s: BookMaker.Session) {
        content.addView(ui.text(s.message, 17f, bold = true, top = 24))
        content.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = s.state != BookMaker.State.PHOTOS
            max = 100; progress = s.progress
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(12) }
        })
        if (s.waiting) content.addView(ui.text(L.t("אין חיבור לאינטרנט כרגע. ממשיכים לבד כשהחיבור יחזור.", "No internet connection right now. We'll carry on by ourselves when it's back."), 15f, R.color.accent, top = 12))
        content.addView(ui.hint(L.t("זה לוקח דקה-שתיים. אפשר לצאת מהאפליקציה: הספר ממשיך ברקע ונשלח התראה.", "This takes a minute or two. You can leave the app: the book carries on and we'll notify you."), top = 10))
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(18), 0, 0) })
    }

    /** Face recognition can mix up siblings: the parent removes any photo that isn't this child. Nothing is sent yet. */
    private fun confirmPhotos(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val name = s.childName
        content.addView(ui.text(L.t("אלה תמונות של $name?", "Are these photos of $name?"), 20f, bold = true, top = 16))
        content.addView(ui.hint(L.t(
            "Moments בחר אותן לבד מהרגעים לפי זיהוי הפנים. אם אחת מהן אינה של $name (למשל אח או אחות), לחצו עליה: היא תוחלף בתמונה אחרת, ונזכור לא להציע אותה שוב. עוד לא נשלח כלום ולא ירד קרדיט.",
            "Moments picked these from your moments by face recognition. If one isn't $name (a brother or sister, say), tap it: it's replaced by another, and we won't offer it again. Nothing has been sent and no credit used yet.",
        ), top = 4))
        val list = s.candidates.toList().take(3)
        list.chunked(3).forEachIndexed { r, chunk ->
            val row = ui.horizontal(top = if (r == 0) 12 else 8)
            chunk.forEachIndexed { k, c ->
                val used = r * 3 + k < 3
                row.addView(android.widget.FrameLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ui.dp(104), 1f).apply { if (k > 0) marginStart = ui.dp(8) }
                    addView(ImageView(this@BookActivity).apply {
                        setImageBitmap(c.crop)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundResource(R.drawable.rounded_media)
                        clipToOutline = true
                        alpha = if (used) 1f else 0.55f
                    }, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    addView(TextView(this@BookActivity).apply {
                        text = "✕"
                        textSize = 16f
                        setTextColor(android.graphics.Color.WHITE)
                        setBackgroundColor(0x88000000.toInt())
                        setPadding(ui.dp(8), ui.dp(2), ui.dp(8), ui.dp(4))
                    }, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.TOP or android.view.Gravity.END))
                    setOnClickListener { s.removeCandidate(c); render() }
                })
            }
            content.addView(row)
        }
        if (list.isEmpty()) content.addView(ui.hint(L.t("לא נשארו תמונות. הוסיפו תמונה ברורה של $name.", "No photos left. Add a clear photo of $name."), top = 12))
        content.addView(ui.button(L.t("כן, אלה תמונות של $name", "Yes, these are $name"), primary = true, top = 16) { s.confirmPhotos(); render() }.apply { isEnabled = list.isNotEmpty() })
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun needPhoto(s: BookMaker.Session) {
        // Photos come only from the family's moments (by face recognition), never from the phone's gallery.
        content.addView(ui.text(L.t("לא מצאנו מספיק תמונות ברורות", "We didn't find enough clear photos"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("לפרופיל המשפחה", "Family profile"), primary = true, top = 16) {
            s.cancel() // nothing was sent or paid yet
            startActivity(Intent(this, FamilyActivity::class.java))
        })
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun approve(s: BookMaker.Session) {
        val b = s.book ?: return
        content.addView(ui.text(L.t("הדמויות של הספר", "The book's characters"), 20f, bold = true, top = 16))
        content.addView(ui.hint(L.t("כך כולם ייראו בכל העמודים. כדאי לאשר רק אם זה באמת דומה. אפשר לצייר כל דמות מחדש.", "This is how everyone will look on every page. Approve only if it really looks right. You can redraw each character."), top = 4))
        content.addView(ui.text(s.childName, 17f, bold = true, top = 12))
        val f = BookStore.image(this, b, b.character)
        content.addView(ImageView(this).apply {
            adjustViewBounds = true
            setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(12) }
        })
        // The photos the character was drawn from: if it doesn't look right, the parent can see whether the photos were the problem.
        val faces = (0 until 3).map { BookStore.image(this, b, "face_$it.jpg") }.filter { it.exists() }
        if (faces.isNotEmpty()) {
            content.addView(ui.hint(L.t("צויר מהתמונות האלה:", "Drawn from these photos:"), top = 10))
            val row = ui.horizontal(top = 6)
            for (f in faces) row.addView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundResource(R.drawable.rounded_media)
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(ui.dp(72), ui.dp(72)).apply { marginEnd = ui.dp(8) }
            })
            content.addView(row)
        }
        // Everyone else in the story, as they'll look on every page.
        for (c in b.cast) {
            content.addView(ui.text(c.name, 17f, bold = true, top = 18))
            val sheet = c.sheet.takeIf { it.isNotEmpty() }?.let { BookStore.image(this, b, it) }?.takeIf { it.exists() }
            if (sheet == null) {
                content.addView(ui.hint(L.t("לא הצלחנו לצייר את ${c.name}. בעמודים יצויר/תצויר לפי התיאור.", "We couldn't draw ${c.name}. The pages will draw them from the description."), top = 4))
            } else {
                content.addView(ImageView(this).apply {
                    adjustViewBounds = true
                    setImageBitmap(BitmapFactory.decodeFile(sheet.absolutePath))
                    setBackgroundResource(R.drawable.rounded_media)
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ui.dp(220), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(8) }
                })
            }
            if (c.tries <= BookMaker.CAST_TRIES) content.addView(ui.action(L.t("לצייר את ${c.name} מחדש", "Draw ${c.name} again")) { s.redrawCast(c.id); render() }.apply { setPadding(0, ui.dp(8), 0, 0) })
        }
        content.addView(ui.text(b.title, 16f, bold = true, top = 18))
        content.addView(ui.button(L.t("מאשרים, ציירו את הספר", "Approve, draw the book"), primary = true, top = 14) { s.approve() })
        if (s.triesLeft > 0) content.addView(ui.button(L.t("לצייר את ${s.childName} מחדש (נותרו ${s.triesLeft})", "Draw ${s.childName} again (${s.triesLeft} left)"), top = 8) { s.redrawCharacter() })
        content.addView(ui.action(L.t("לא דומה, בטלו את הספר (הקרדיט יוחזר אם צוירו עד 5 ציורים)", "Doesn't look right, cancel the book (credit returned if up to 5 drawings were made)")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    /**
     * Who else is in the story: for each family member the story brought in, their best photos from the family's
     * moments. The parent taps the photo to draw them from, or "without a photo". Nothing is sent or paid yet.
     */
    private fun cast(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val b = s.book
        content.addView(ui.text(L.t("מי עוד בסיפור?", "Who else is in the story?"), 20f, bold = true, top = 16))
        b?.let { content.addView(ui.hint(L.t("הסיפור: \"${it.title}\". כדי שכולם ייראו כמו במציאות, בחרו לכל דמות תמונה ממנה נצייר אותה. עוד לא נשלח כלום ולא ירד קרדיט.", "The story: \"${it.title}\". So everyone looks like themselves, choose a photo to draw each character from. Nothing has been sent and no credit used yet."), top = 4)) }
        for (ch in s.castChoices.toList()) {
            content.addView(ui.text(ch.cast.name, 17f, bold = true, top = 18))
            if (ch.options.isEmpty()) content.addView(ui.hint(L.t("לא מצאנו תמונות של ${ch.cast.name} ברגעים.", "We found no photos of ${ch.cast.name} in your moments."), top = 2))
            val row = ui.horizontal(top = 8)
            ch.options.forEachIndexed { k, bmp ->
                row.addView(ImageView(this).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundResource(R.drawable.rounded_media)
                    clipToOutline = true
                    alpha = if (ch.picked == k) 1f else 0.4f
                    layoutParams = LinearLayout.LayoutParams(ui.dp(84), ui.dp(84)).apply { if (k > 0) marginStart = ui.dp(8) }
                    setOnClickListener { s.pickCast(ch.cast.id, k); render() }
                })
            }
            if (ch.options.isNotEmpty()) content.addView(row)
            val links = ui.horizontal(top = 6)
            links.addView(ui.action(if (ch.picked < 0) L.t("✓ בלי תמונה", "✓ Without a photo") else L.t("בלי תמונה", "Without a photo")) { s.pickCast(ch.cast.id, -1); render() })
            links.addView(ui.action(L.t("   מהגלריה", "   From the gallery")) {
                s.galleryFor = ch.cast.id
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            })
            content.addView(links)
        }
        content.addView(ui.button(L.t("המשיכו לציור הדמויות", "Continue to drawing the characters"), primary = true, top = 20) { s.confirmCast(); render() })
        content.addView(ui.hint(L.t("כאן יורד קרדיט אחד לספר. אם לא תאשרו את הדמויות, הוא יוחזר.", "One credit is used for the book here. If you don't approve the characters, it's returned."), top = 6))
        content.addView(ui.action(L.t("ביטול", "Cancel")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun pages(s: BookMaker.Session) {
        content.addView(ui.text(L.t("מציירים את הספר... ${s.progress}%", "Drawing the book... ${s.progress}%"), 17f, bold = true, top = 24))
        content.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = s.progress
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)).apply { topMargin = ui.dp(12) }
        })
        if (s.waiting) content.addView(ui.text(L.t("אין חיבור לאינטרנט כרגע. ממשיכים לבד כשהחיבור יחזור.", "No internet connection right now. We'll carry on by ourselves when it's back."), 15f, R.color.accent, top = 12))
        content.addView(ui.hint(L.t("כמה דקות. אפשר לצאת מהאפליקציה: הספר ממשיך ברקע ונשלח התראה כשהוא מוכן.", "A few minutes. You can leave the app: the book carries on and we'll notify you when it's ready."), top = 10))
    }

    private fun done(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val b = s.book ?: return
        content.addView(ui.text(L.t("הספר מוכן 📖", "The book is ready 📖"), 20f, bold = true, top = 20))
        if (s.message.isNotEmpty()) content.addView(ui.hint(s.message, top = 4))
        content.addView(ui.button(L.t("פתחו את הספר", "Open the book"), primary = true, top = 16) { BookViewerActivity.open(this, b.id) })
        content.addView(ui.action(L.t("ספר חדש", "A new book")) { BookMaker.clear(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    /** No connection for a few minutes: the book is saved as it is. */
    private fun paused(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("הספר נשמר", "The book is saved"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("המשיכו את הספר", "Continue the book"), primary = true, top = 16) { s.retry(); render() })
        content.addView(ui.action(L.t("ביטול הספר", "Cancel the book")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    /** The credit's window is over: continuing needs the parent's OK for one more credit. */
    private fun needCredit(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("להמשיך את הספר?", "Continue the book?"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("כן, להמשיך (קרדיט אחד)", "Yes, continue (one credit)"), primary = true, top = 16) { s.continueWithNewCredit(); render() })
        content.addView(ui.action(L.t("לא, לבטל את הספר", "No, cancel the book")) { s.cancel(); render() }.apply { setPadding(0, ui.dp(16), 0, 0) })
    }

    private fun failed(s: BookMaker.Session) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        content.addView(ui.text(L.t("הספר לא נוצר", "The book wasn't created"), 18f, bold = true, top = 22))
        content.addView(ui.hint(s.message, top = 6))
        content.addView(ui.button(L.t("חזרה", "Back"), primary = true, top = 16) { BookMaker.clear(); render() })
    }
}
