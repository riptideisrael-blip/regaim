package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/** Human family conversation; separate from ChatActivity, which is AI Ask. */
class FamilyChatActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context, postId: String? = null, title: String? = null) = ctx.startActivity(
            Intent(ctx, FamilyChatActivity::class.java).putExtra("post_id", postId).putExtra("title", title))
    }
    private lateinit var ui: Ui
    private lateinit var thread: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: TextView
    private lateinit var status: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var postId: String? = null
    private var loading = false
    private var sending = false
    private var active = false
    private var lastIds = emptyList<String>()
    private var loadedUser = ""
    private var loadedCircle = ""
    private val refresh = object : Runnable {
        override fun run() { if (active) { load(); handler.postDelayed(this, 10_000) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        postId = intent.getStringExtra("post_id")?.takeIf { it.isNotBlank() }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(20), ui.dp(28), ui.dp(20), ui.dp(16))
        }
        root.addView(ui.action("חזרה") { finish() })
        root.addView(ui.text(if (postId == null) Circle.name(this).ifBlank { "שיחה במשפחה" } else "שיחה על הזיכרון", 24f, bold = true))
        intent.getStringExtra("title")?.takeIf { it.isNotBlank() }?.let { root.addView(ui.hint(it, top = 4)) }
        root.addView(ui.hint("רק לחברים המאושרים במעגל · הודעות מהמשפחה", top = 5))
        status = ui.hint("רגע, פותחים את השיחה...", top = 10)
        root.addView(status)
        root.addView(ui.action("רעננו שיחה") { load() })
        thread = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply {
            isFillViewport = true; addView(thread)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(scroll)
        input = ui.field("כתבו למשפחה...", "", multiline = true).apply { maxLines = 4 }
        input.setText(savedInstanceState?.getString("draft").orEmpty())
        root.addView(input)
        send = ui.button("שלחו הודעה", primary = true, top = 8) { sendMessage() }
        root.addView(send)
        setContentView(root)
    }
    override fun onSaveInstanceState(outState: Bundle) { outState.putString("draft", input.text.toString()); super.onSaveInstanceState(outState) }
    override fun onResume() {
        super.onResume()
        if (loadedUser != Account.id(this) || loadedCircle != Circle.circleId(this)) { thread.removeAllViews(); lastIds = emptyList() }
        if (!Circle.joined(this) || !Account.signedIn(this)) { thread.removeAllViews(); lastIds = emptyList(); status.text = "התחברו למעגל כדי לפתוח את השיחה"; send.isEnabled = false; return }
        send.isEnabled = true; active = true; handler.post(refresh)
    }
    override fun onPause() { active = false; handler.removeCallbacks(refresh); super.onPause() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); worker.shutdownNow(); super.onDestroy() }

    private fun load() {
        if (loading || worker.isShutdown || sending) return
        val requestedUser = Account.id(this)
        val requestedCircle = Circle.circleId(this)
        loading = true
        worker.execute {
            val result = try { Result.success(Circle.messages(applicationContext, postId)) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                loading = false
                if (isDestroyed || requestedUser != Account.id(this) || requestedCircle != Circle.circleId(this)) return@runOnUiThread
                result.onSuccess { messages ->
                    loadedUser = requestedUser; loadedCircle = requestedCircle
                    status.text = if (messages.size >= 100) "מוצגות 100 ההודעות האחרונות" else ""
                    if (messages.map { it.id } != lastIds || thread.childCount == 0) {
                        lastIds = messages.map { it.id }; thread.removeAllViews()
                        if (messages.isEmpty()) thread.addView(ui.text("עוד לא התחילה שיחה ❤️\nזה המקום לשאול, להיזכר ולדבר יחד.", 17f, R.color.ink_soft, top = 30))
                        for (message in messages) {
                            val bubble = ui.card(top = 10)
                            bubble.gravity = if (message.authorId == Account.id(this)) Gravity.START else Gravity.END
                            bubble.addView(ui.hint("${message.author} · ${Fmt.dayTime(message.createdAt)}", top = 0))
                            bubble.addView(ui.text(message.body, 16f, top = 4))
                            thread.addView(bubble)
                        }
                        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                    }
                }.onFailure { status.text = it.message ?: "אין חיבור לשיחה כרגע. הטקסט שכתבתם נשאר כאן." }
            }
        }
    }
    private fun sendMessage() {
        val body = input.text.toString().trim()
        if (body.isBlank() || sending || worker.isShutdown) return
        if (body.length > 4000) { Toast.makeText(this, "אפשר לשלוח עד 4,000 תווים", Toast.LENGTH_LONG).show(); return }
        sending = true; send.isEnabled = false; status.text = "שולחים למשפחה..."
        worker.execute {
            val result = try { Circle.sendMessage(applicationContext, body, postId); null } catch (e: Exception) { e.message ?: "ההודעה לא נשלחה. נסו שוב." }
            runOnUiThread {
                sending = false
                if (isDestroyed) return@runOnUiThread
                send.isEnabled = true
                if (result == null) { if (input.text.toString().trim() == body) input.setText(""); status.text = ""; load() }
                else status.text = result
            }
        }
    }
}
