package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Premium: turns one moment (up to ~30 s) into a short Pixar-style animated film.
 * Key frames are extracted from the moment and sent to the server Edge Function which:
 * 1. Stylizes each frame to Pixar look using Flux Pro Kontext
 * 2. Animates the styled frame using Kling video model with different motion prompts
 * The resulting video clips are combined with music into the final film.
 */
@OptIn(markerClass = [UnstableApi::class])
object CartoonFilm {
    private const val SCENE_MS = 3500L
    private val worker = Executors.newSingleThreadExecutor()

    class Handle { @Volatile var cancel: (() -> Unit)? = null }

    fun scenesFor(m: Memory): Int = if (!m.isVideo) 1 else (m.durationMs / 4000L).toInt().coerceIn(4, 8)

    fun seconds(m: Memory): Int = if (!m.isVideo) 5 else (scenesFor(m) * SCENE_MS / 1000L).toInt()

    /** All callbacks run on the main thread. [onStatus] gets (scenes drawn, total). */
    fun make(
        ctx: Context, m: Memory, mood: Music.Mood?,
        onStatus: (Int, Int) -> Unit, onProgress: (Int) -> Unit, onDone: (File?, String?) -> Unit,
    ): Handle {
        val handle = Handle()
        val main = Handler(Looper.getMainLooper())
        val cancelled = AtomicBoolean(false)
        val finished = AtomicBoolean(false)
        handle.cancel = { cancelled.set(true) }
        worker.execute {
            val temp = ArrayList<File>()
            try {
                if (!Account.signedIn(ctx)) throw IllegalStateException(L.t("צריך להתחבר כדי ליצור סרטים", "Sign in to create films"))
                val token = Account.token(ctx) ?: throw IllegalStateException(L.t("בעיה בהתחברות", "Authentication error"))

                val frames = ComicMaker.framesFromClip(ctx, m, scenesFor(m))
                if (frames.isEmpty()) throw IllegalStateException(L.t("לא הצלחנו לקרוא את הרגע", "Couldn't read the moment"))
                val total = frames.size
                val videos = ArrayList<File>()
                for ((i, f) in frames.withIndex()) {
                    if (cancelled.get()) { main.post { }; return@execute }
                    main.post { if (!cancelled.get()) onStatus(i, total) }
                    val video = animateFrameWithFal(ctx, token, f, i)
                    if (video != null) {
                        videos.add(video)
                        temp.add(video)
                    }
                }
                if (videos.isEmpty())
                    throw IllegalStateException(L.t("הציור נכשל. בדקו את חיבור האינטרנט ונסו שוב.", "Drawing failed. Check your connection and try again."))
                main.post { if (!cancelled.get()) onStatus(total, total) }

                val withMark = Settings.prefs(ctx).getBoolean("share_watermark", true)
                val items = ArrayList<EditedMediaItem>()
                for (videoFile in videos) {
                    items.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(videoFile))).build())
                }
                val totalMs = SCENE_MS * items.size
                val wav = if (mood != null) File(ctx.cacheDir, "toon_music_${System.currentTimeMillis()}.wav").also {
                    temp.add(it); Music.renderWav(mood, totalMs, 0.8f, it)
                } else null
                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, "moments_pixar_${System.currentTimeMillis()}.mp4")
                main.post {
                    if (cancelled.get()) { temp.forEach { it.delete() }; return@post }
                    try {
                        val sequences = ArrayList<EditedMediaItemSequence>()
                        sequences.add(EditedMediaItemSequence(items))
                        if (wav != null) sequences.add(EditedMediaItemSequence(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).setRemoveVideo(true).build()))
                        val transformer = Transformer.Builder(ctx)
                            .setVideoMimeType(MimeTypes.VIDEO_H264)
                            .addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    finished.set(true); temp.forEach { it.delete() }; onDone(out, null)
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    finished.set(true); temp.forEach { it.delete() }; out.delete()
                                    onDone(null, L.t("לא הצלחנו להרכיב את הסרט. נסו שוב או בלי מוזיקה.", "Couldn't put the film together. Try again, or without music."))
                                }
                            })
                            .build()
                        transformer.start(Composition.Builder(sequences).build(), out.absolutePath)
                        handle.cancel = { cancelled.set(true); finished.set(true); try { transformer.cancel() } catch (_: Throwable) {}; temp.forEach { it.delete() }; out.delete() }
                        val holder = ProgressHolder()
                        val poll = object : Runnable {
                            override fun run() {
                                if (cancelled.get() || finished.get()) return
                                val state = try { transformer.getProgress(holder) } catch (_: Throwable) { Transformer.PROGRESS_STATE_NOT_STARTED }
                                if (state == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                                main.postDelayed(this, 500)
                            }
                        }
                        main.postDelayed(poll, 500)
                    } catch (t: Throwable) {
                        temp.forEach { it.delete() }
                        onDone(null, L.t("לא הצלחנו להרכיב את הסרט", "Couldn't put the film together"))
                    }
                }
            } catch (e: Throwable) {
                temp.forEach { it.delete() }
                main.post { if (!cancelled.get()) onDone(null, e.message ?: L.t("לא הצלחנו ליצור את הסרט", "Couldn't create the film")) }
            }
        }
        return handle
    }

    private fun animateFrameWithFal(ctx: Context, token: String, frame: Bitmap, sceneIdx: Int): File? {
        return try {
            val edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"

            // Step 1: Stylize the frame to Pixar style using Flux
            val frameBase64 = bitmapToDataUri(frame)
            val styleRes = callEdge(edgeUrl, token, mapOf(
                "action" to "submit",
                "kind" to "style",
                "image" to frameBase64
            ))
            if (styleRes.optString("status_url", "").isEmpty()) return null

            val styledUrl = pollEdge(edgeUrl, token,
                styleRes.optString("status_url", ""),
                styleRes.optString("response_url", ""))
            if (styledUrl.isEmpty()) return null

            // Step 2: Animate the styled image using Kling
            val animRes = callEdge(edgeUrl, token, mapOf(
                "action" to "submit",
                "kind" to "anim",
                "scene" to sceneIdx,
                "image" to styledUrl
            ))
            if (animRes.optString("status_url", "").isEmpty()) return null

            val videoUrl = pollEdge(edgeUrl, token,
                animRes.optString("status_url", ""),
                animRes.optString("response_url", ""))
            if (videoUrl.isEmpty()) return null

            // Download the video
            downloadVideo(ctx, videoUrl)
        } catch (e: Exception) {
            null
        }
    }

    private fun bitmapToDataUri(bmp: Bitmap): String {
        val stream = java.io.ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val data = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
        return "data:image/jpeg;base64,$data"
    }

    private fun callEdge(edgeUrl: String, token: String, body: Map<String, Any>): org.json.JSONObject {
        val conn = java.net.URL(edgeUrl).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.doOutput = true

            val json = org.json.JSONObject()
            body.forEach { (k, v) -> json.put(k, v) }
            conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            return if (text.isBlank()) org.json.JSONObject() else org.json.JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun pollEdge(edgeUrl: String, token: String, statusUrl: String, responseUrl: String): String {
        var attempts = 0
        val maxAttempts = 120  // 10 minutes at 5-second intervals
        while (attempts < maxAttempts) {
            attempts++
            Thread.sleep(5000)

            val res = callEdge(edgeUrl, token, mapOf(
                "action" to "poll",
                "status_url" to statusUrl,
                "response_url" to responseUrl
            ))
            val status = res.optString("status", "PENDING")
            when (status) {
                "DONE" -> return res.optString("url", "")
                "FAILED" -> return ""
                "PENDING" -> { /* continue */ }
            }
        }
        return ""
    }

    private fun downloadVideo(ctx: Context, url: String): File? {
        return try {
            val file = File(ctx.cacheDir, "film_${System.currentTimeMillis()}.mp4")
            val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.inputStream.use { input ->
                file.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            file
        } catch (e: Exception) {
            null
        }
    }
}
