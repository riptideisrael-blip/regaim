package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Premium: one moment as a short 3D animated (Pixar-style) film, about 15 seconds.
 *
 * The flow, in a [Session]:
 *  1. Look: we pick the best 3 scenes of the moment, draw ONE of them as a cartoon (the "anchor"), and show it.
 *     The family approves it (or asks for another drawing) before anything expensive happens.
 *  2. Film: every other scene is drawn like the approved anchor (same face, age, hair, clothes), each drawn scene
 *     is animated into a ~5 s clip, and a failed scene is tried once more.
 *  3. The clips are joined with the moment's own sound (voices, laughs) and soft music, plus the watermark,
 *     then saved to the gallery and to the archive. This keeps going if the screen is closed.
 *
 * All AI runs on our server (Supabase Edge Function "cartoon-film"); the key never lives in the app.
 * One credit opens a window of 12 AI calls; a film uses 5–10 of them.
 */
@OptIn(markerClass = [UnstableApi::class])
object CartoonFilm {
    private const val SCENE_MS = 5000L
    private const val VIDEO_SCENES = 3
    private const val CALL_BUDGET = 12
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** The film being made right now (one at a time), so the screen can come back to it. */
    @Volatile var current: Session? = null
        private set

    fun scenesFor(m: Memory): Int = if (!m.isVideo) 1 else VIDEO_SCENES
    fun seconds(m: Memory): Int = (scenesFor(m) * SCENE_MS / 1000L).toInt()

    /** Starts a new film for [m]: reserves a credit, picks the scenes and draws the first look. */
    fun start(ctx: Context, m: Memory): Session {
        current?.takeIf { it.isActive }?.let { return it }
        val s = Session(ctx.applicationContext, m)
        current = s
        worker.execute { s.prepare() }
        return s
    }

    /** A server answer that means "stop the whole film" (not signed in, no credits, server not set up). */
    private class FatalEdgeError(message: String) : Exception(message)

    class Scene(val bmp: Bitmap, val timeMs: Long, val score: Float)

    class Session internal constructor(private val ctx: Context, val memory: Memory) {
        enum class State { PREPARING, LOOK, FILMING, DONE, FAILED, CANCELLED }

        @Volatile var state = State.PREPARING
            private set
        @Volatile var look: Bitmap? = null
            private set
        @Volatile var status = ""
            private set
        @Volatile var progress = -1
            private set
        @Volatile var result: File? = null
            private set
        @Volatile var savedId: String? = null
            private set
        @Volatile var error: String? = null
            private set
        /** Honest note about the result, e.g. "2 of 3 scenes worked". Empty when everything worked. */
        @Volatile var note = ""
            private set
        @Volatile var redrawsLeft = 2
            private set
        /** Called on the main thread whenever something changes. The screen sets it. */
        var listener: (() -> Unit)? = null

        val isActive get() = state == State.PREPARING || state == State.LOOK || state == State.FILMING

        private val cancelled = AtomicBoolean(false)
        private var edgeUrl = ""
        private var token = ""
        private var reserved = false
        private var calls = 0
        private var scenes: List<Scene> = emptyList()
        private var anchorIdx = 0
        private var anchorUrl = ""
        private var aspect = "9:16"
        private var transformer: Transformer? = null

        private fun changed() = main.post { listener?.invoke() }
        private fun update(st: State, text: String = status) { state = st; status = text; changed() }

        private fun fail(message: String) {
            refundQuietly()
            error = message
            update(State.FAILED)
            if (current === this) current = null
        }

        // ---------- 1. the look ----------

        internal fun prepare() {
            try {
                update(State.PREPARING, L.t("בוחרים את הרגעים הכי טובים מהסרטון...", "Picking the best moments of the clip..."))
                if (!Account.signedIn(ctx)) throw IllegalStateException(L.t("צריך להתחבר כדי ליצור סרטים", "Sign in to create films"))
                token = Account.token(ctx) ?: throw IllegalStateException(L.t("בעיה בהתחברות. התחברו מחדש ונסו שוב.", "Sign-in problem. Sign in again and try again."))
                edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"

                scenes = pickScenes(ctx, memory, scenesFor(memory))
                if (scenes.isEmpty()) throw IllegalStateException(L.t("לא הצלחנו לקרוא את הרגע", "Couldn't read the moment"))
                anchorIdx = scenes.indices.maxByOrNull { scenes[it].score } ?: 0
                aspect = aspectOf(scenes[anchorIdx].bmp)

                val res = callEdge(edgeUrl, token, mapOf("action" to "reserve"))
                if (!res.optBoolean("ok", false))
                    throw IllegalStateException(res.optString("error", "").ifBlank { L.t("לא הצלחנו להתחיל את הסרט. נסו שוב.", "Couldn't start the film. Try again.") })
                reserved = true
                drawLook()
            } catch (e: Exception) {
                if (!cancelled.get()) fail(e.message ?: L.t("לא הצלחנו להתחיל את הסרט", "Couldn't start the film"))
            }
        }

        private fun drawLook() {
            update(State.PREPARING, L.t("מציירים את הדמויות... (כחצי דקה)", "Drawing the characters... (about 30 seconds)"))
            val url = submitAndWait(mapOf("action" to "submit", "kind" to "style", "image" to dataUri(scenes[anchorIdx].bmp), "aspect" to aspect))
            if (cancelled.get()) return
            if (url.isEmpty()) throw IllegalStateException(L.t("הציור לא הצליח הפעם. נסו שוב.", "The drawing didn't work this time. Try again."))
            val bmp = downloadBitmap(url) ?: throw IllegalStateException(L.t("לא הצלחנו להוריד את הציור. בדקו את החיבור.", "Couldn't download the drawing. Check your connection."))
            anchorUrl = url
            look = bmp
            update(State.LOOK, "")
        }

        /** "Draw them again": a new look, up to two times. */
        fun redraw() {
            if (state != State.LOOK || redrawsLeft <= 0) return
            redrawsLeft--
            update(State.PREPARING)
            worker.execute {
                try { drawLook() } catch (e: Exception) { if (!cancelled.get()) fail(e.message ?: L.t("הציור נכשל", "Drawing failed")) }
            }
        }

        fun cancel() {
            if (!isActive) return
            cancelled.set(true)
            try { transformer?.cancel() } catch (_: Throwable) {}
            update(State.CANCELLED)
            if (current === this) current = null
            worker.execute { refundQuietly() }
        }

        // ---------- 2. the film ----------

        fun makeFilm(mood: Music.Mood?, withVoices: Boolean) {
            if (state != State.LOOK) return
            update(State.FILMING, L.t("מתחילים...", "Starting..."))
            worker.execute {
                try { film(mood, withVoices) } catch (e: Exception) {
                    if (!cancelled.get()) fail(e.message ?: L.t("לא הצלחנו ליצור את הסרט", "Couldn't create the film"))
                }
            }
        }

        private fun film(mood: Music.Mood?, withVoices: Boolean) {
            val total = scenes.size
            val clips = arrayOfNulls<File>(total)
            var lastError = ""
            fun attempt(i: Int) {
                try {
                    clips[i] = animateScene(i)
                } catch (e: FatalEdgeError) {
                    throw IllegalStateException(e.message)
                } catch (e: Exception) {
                    lastError = e.message.orEmpty()
                }
            }
            for (i in 0 until total) {
                if (cancelled.get()) return
                update(State.FILMING, L.t("מציירים ומנפישים סצנה ${i + 1} מתוך $total...", "Drawing and animating scene ${i + 1} of $total..."))
                attempt(i)
            }
            // One more try for a scene that failed, while the call budget allows it.
            for (i in 0 until total) {
                if (cancelled.get()) return
                if (clips[i] == null && calls + 2 <= CALL_BUDGET) {
                    update(State.FILMING, L.t("מנסים שוב את סצנה ${i + 1}...", "Trying scene ${i + 1} again..."))
                    attempt(i)
                }
            }
            if (cancelled.get()) return
            val okIdx = (0 until total).filter { clips[it] != null }
            if (okIdx.isEmpty())
                throw IllegalStateException(lastError.ifBlank { L.t("ההנפשה לא הצליחה הפעם. הקרדיט הוחזר, אפשר לנסות שוב.", "The animation didn't work this time. Your credit was returned; you can try again.") })
            note = if (okIdx.size < total) L.t("${okIdx.size} מתוך $total סצנות הצליחו, לכן הסרט קצר יותר.", "${okIdx.size} of $total scenes worked, so the film is shorter.") else ""
            update(State.FILMING, L.t("מרכיבים את הסרט עם הקול והמוזיקה...", "Putting the film together with sound and music..."))
            compose(okIdx.map { clips[it]!! }, okIdx.map { scenes[it].timeMs }, mood, withVoices)
        }

        private fun animateScene(i: Int): File? {
            val drawn = if (i == anchorIdx) anchorUrl else {
                submitAndWait(mapOf("action" to "submit", "kind" to "style_ref", "image" to dataUri(scenes[i].bmp), "ref" to anchorUrl, "aspect" to aspect))
            }
            if (drawn.isEmpty() || cancelled.get()) return null
            val video = submitAndWait(mapOf("action" to "submit", "kind" to "anim", "scene" to i, "image" to drawn, "motion" to actionHint(memory)))
            if (video.isEmpty() || cancelled.get()) return null
            return downloadVideo(ctx, video)
        }

        // ---------- 3. putting it together ----------

        private fun compose(clips: List<File>, times: List<Long>, mood: Music.Mood?, withVoices: Boolean) {
            val (outW, outH) = outSize(aspect)
            val withMark = Settings.prefs(ctx).getBoolean("share_watermark", true)
            val markBitmap = if (withMark) SocialShare.badge(ctx, (minOf(outW, outH) * 0.30f).toInt()) else null
            fun effects(): Effects {
                val list = ArrayList<Effect>()
                list.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
                if (markBitmap != null) {
                    val settings = OverlaySettings.Builder()
                        .setBackgroundFrameAnchor(0.92f, -0.92f)
                        .setOverlayFrameAnchor(1f, -1f)
                        .setAlphaScale(0.92f)
                        .build()
                    list.add(OverlayEffect(ImmutableList.of(BitmapOverlay.createStaticBitmapOverlay(markBitmap, settings))))
                }
                return Effects(emptyList<AudioProcessor>(), list)
            }
            val temp = ArrayList<File>(clips)
            val videoItems = ArrayList<EditedMediaItem>()
            var totalMs = 0L
            for (f in clips) {
                totalMs += durationMs(f)
                videoItems.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(f))).setRemoveAudio(true).setEffects(effects()).build())
            }

            // The moment's own sound (voices, laughs), from just before the first scene, exactly as long as the film.
            val voices: List<EditedMediaItem>? = if (withVoices && memory.isVideo) try {
                originalSound(times.firstOrNull() ?: 0L, totalMs, temp)
            } catch (_: Exception) { null } else null
            val music = if (mood != null) File(ctx.cacheDir, "toon_music_${System.currentTimeMillis()}.wav").also {
                temp.add(it); Music.renderWav(mood, totalMs, if (voices != null) 0.25f else 0.8f, it)
            } else null

            val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
            val out = File(dir, "moments_film_${System.currentTimeMillis()}.mp4")

            fun export(useVoices: Boolean) {
                val sequences = ArrayList<EditedMediaItemSequence>()
                sequences.add(EditedMediaItemSequence(videoItems))
                if (useVoices && voices != null) sequences.add(EditedMediaItemSequence(voices))
                if (music != null) sequences.add(EditedMediaItemSequence(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).setRemoveVideo(true).build()))
                val finished = AtomicBoolean(false)
                val t = Transformer.Builder(ctx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            finished.set(true)
                            worker.execute {
                                temp.forEach { it.delete() }
                                // Keep it for good: the gallery (Movies/Moments) and the archive, next to the moment.
                                savedId = try { keep(ctx, memory, out) } catch (_: Exception) { null }
                                result = out
                                progress = 100
                                update(State.DONE, "")
                                // Stays as `current` so the screen can show the result again; a new film replaces it.
                            }
                        }
                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            finished.set(true)
                            out.delete()
                            if (cancelled.get()) return
                            // The moment's own sound is the one new risk here: try once more without it.
                            if (useVoices && voices != null) { export(false); return }
                            temp.forEach { it.delete() }
                            worker.execute { fail(L.t("לא הצלחנו להרכיב את הסרט. נסו שוב או בלי מוזיקה.", "Couldn't put the film together. Try again, or without music.")) }
                        }
                    })
                    .build()
                transformer = t
                t.start(Composition.Builder(sequences).build(), out.absolutePath)
                val holder = ProgressHolder()
                val poll = object : Runnable {
                    override fun run() {
                        if (cancelled.get() || finished.get()) return
                        val st = try { t.getProgress(holder) } catch (_: Throwable) { Transformer.PROGRESS_STATE_NOT_STARTED }
                        if (st == Transformer.PROGRESS_STATE_AVAILABLE) { progress = holder.progress; listener?.invoke() }
                        main.postDelayed(this, 500)
                    }
                }
                main.postDelayed(poll, 500)
            }
            main.post {
                if (cancelled.get()) { temp.forEach { it.delete() }; return@post }
                try { export(voices != null) } catch (_: Throwable) {
                    try { export(false) } catch (_: Throwable) {
                        temp.forEach { it.delete() }
                        worker.execute { fail(L.t("לא הצלחנו להרכיב את הסרט", "Couldn't put the film together")) }
                    }
                }
            }
        }

        /** The original clip's sound for [lengthMs], padded with silence if the clip is shorter. Null if it has no sound. */
        private fun originalSound(firstSceneMs: Long, lengthMs: Long, temp: MutableList<File>): List<EditedMediaItem>? {
            val r = MediaMetadataRetriever()
            val (hasAudio, dur) = try {
                if (memory.uri.startsWith("content://")) r.setDataSource(ctx, Uri.parse(memory.uri)) else r.setDataSource(memory.uri)
                (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes") to
                    (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: memory.durationMs)
            } finally { try { r.release() } catch (_: Exception) {} }
            if (!hasAudio || dur < 2000) return null
            val start = (firstSceneMs - 500).coerceIn(0L, maxOf(0L, dur - 2000))
            var len = minOf(dur - start, lengthMs)
            var gap = lengthMs - len
            if (gap in 1..999) { len -= (1000 - gap); gap = 1000 } // silence pieces are at least 1 s
            if (len < 2000) return null
            val src = if (memory.uri.startsWith("content://") || memory.uri.startsWith("file://")) Uri.parse(memory.uri) else Uri.fromFile(File(memory.uri))
            val clipped = MediaItem.Builder().setUri(src)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(start + len).build())
                .build()
            val items = arrayListOf(EditedMediaItem.Builder(clipped).setRemoveVideo(true).build())
            if (gap > 0) {
                val silence = File(ctx.cacheDir, "toon_silence_${System.currentTimeMillis()}.wav").also { temp.add(it) }
                Music.renderWav(Music.Mood.CALM, gap, 0f, silence)
                items.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(silence))).setRemoveVideo(true).build())
            }
            return items
        }

        // ---------- server ----------

        /** Sends one AI job and waits for it. Returns the result URL, or "" if this job failed. */
        private fun submitAndWait(body: Map<String, Any>): String {
            if (calls >= CALL_BUDGET) return ""
            calls++
            val res = callEdge(edgeUrl, token, body)
            checkError(res)
            return pollEdge(edgeUrl, token, res.optString("status_url", ""), res.optString("response_url", ""), cancelled)
        }

        private fun refundQuietly() {
            if (!reserved) return
            reserved = false
            try { callEdge(edgeUrl, token, mapOf("action" to "refund")) } catch (_: Exception) {}
        }
    }

    /** English hint for the animation, from what we know about the moment (its category / the sound that saved it). */
    private fun actionHint(m: Memory): String {
        val byCategory = when (m.category) {
            "צחוק" -> "The child is laughing happily."
            "משחק" -> "The child is playing."
            "אוכל" -> "The child is eating."
            "בחוץ" -> "The child is playing outside."
            "אמבטיה" -> "The child is in the bath, splashing gently."
            "שינה" -> "The child is sleeping peacefully, breathing slowly."
            "משפחה" -> "A tender family moment together."
            else -> ""
        }
        if (byCategory.isNotEmpty()) return byCategory
        val l = m.label.lowercase()
        return if ("laugh" in l || "giggle" in l || "chuckle" in l) "The child is laughing happily." else ""
    }

    private fun aspectOf(b: Bitmap): String {
        val r = b.height.toFloat() / b.width
        return when {
            r > 1.5f -> "9:16"
            r > 1.1f -> "3:4"
            r < 0.67f -> "16:9"
            r < 0.9f -> "4:3"
            else -> "1:1"
        }
    }

    private fun outSize(aspect: String): Pair<Int, Int> = when (aspect) {
        "9:16" -> 720 to 1280
        "3:4" -> 720 to 960
        "16:9" -> 1280 to 720
        "4:3" -> 960 to 720
        else -> 720 to 720
    }

    /**
     * Saves a finished film to the gallery and adds it to the archive as its own moment, right next to
     * the moment it was made from (same day, same people). Returns the new memory's id.
     */
    fun keep(ctx: Context, from: Memory, film: File): String {
        val uri = ReelMaker.publish(ctx, film, "Moments_film_${System.currentTimeMillis()}.mp4")
        val id = "film_${System.currentTimeMillis()}"
        val r = MediaMetadataRetriever()
        var dur = SCENE_MS
        var thumb = ""
        try {
            r.setDataSource(film.absolutePath)
            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: dur
            r.getFrameAtTime(1_500_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { thumb = MemoryStore.saveBubble(ctx, id, it) }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        val base = from.title.ifBlank { Fmt.title(from) }
        MemoryStore.add(ctx, Memory(
            id = id, uri = uri, name = film.name, time = from.time + 1, label = "manual",
            lat = from.lat, lon = from.lon, place = from.place, thumb = thumb, durationMs = dur,
            title = L.t("🎬 סרט מצויר: $base", "🎬 Animated film: $base").take(60), titleByUser = true,
            description = L.t("סרט אנימציה בתלת-ממד שנוצר מהרגע \"$base\".", "A 3D animated film made from the moment \"$base\"."),
            descriptionByUser = true, descriptionSource = "user", analyzed = true,
            category = from.category, chosen = true, noLearn = true,
            extraPeople = from.allPeople, facesScanned = true, petsScanned = true,
            origin = "film", timeSource = from.timeSource,
        ))
        return id
    }

    /**
     * Chooses the frames worth drawing (each one costs money): frames where a person is clearly in the
     * picture, at a normal distance. Frames with nobody in them (grass, the parent's legs) are skipped,
     * and extreme close-ups (a wide-angle lens right at the face) score low, since they draw a stretched,
     * creepy face. The film keeps the moment's order: one scene per part of the clip, the best frame in each.
     */
    private fun pickScenes(ctx: Context, m: Memory, count: Int): List<Scene> {
        if (!m.isVideo) return ComicMaker.framesFromClip(ctx, m, 1).map { Scene(it, 0L, 3f) }
        val candidates = ArrayList<Pair<Long, Bitmap>>()
        val mmr = MediaMetadataRetriever()
        try {
            if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: maxOf(m.durationMs, 1L)
            val n = (count * 4).coerceIn(6, 16)
            for (k in 0 until n) {
                val t = (dur * (0.06 + 0.88 * k / (n - 1))).toLong()
                val f = try { mmr.getFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST) } catch (_: Exception) { null } ?: continue
                candidates.add(t to shrink(f, 960))
            }
        } catch (_: Exception) {
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
        if (candidates.isEmpty()) return ComicMaker.framesFromClip(ctx, m, count).map { Scene(it, 0L, 1f) }

        val detector = com.google.mlkit.vision.face.FaceDetection.getClient(
            com.google.mlkit.vision.face.FaceDetectorOptions.Builder()
                .setPerformanceMode(com.google.mlkit.vision.face.FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.05f)
                .build()
        )
        // Score: 0 = nobody there; 3 = a face at a good distance; lower for tiny faces and extreme close-ups.
        val scored = try {
            candidates.map { (t, bmp) ->
                val faces = try {
                    com.google.android.gms.tasks.Tasks.await(detector.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0)))
                } catch (_: Exception) { emptyList<com.google.mlkit.vision.face.Face>() }
                val biggest = faces.maxOfOrNull { it.boundingBox.width().toFloat() * it.boundingBox.height() } ?: 0f
                val share = biggest / (bmp.width.toFloat() * bmp.height)
                val score = when {
                    biggest <= 0f -> 0f
                    share < 0.015f -> 1f
                    share <= 0.18f -> 3f
                    share <= 0.30f -> 2f
                    else -> 0.5f
                }
                Scene(bmp, t, score)
            }
        } finally {
            try { detector.close() } catch (_: Exception) {}
        }
        val withPeople = scored.filter { it.score > 0f }
        if (withPeople.isEmpty()) {
            // No faces found at all (a pet, a back to the camera...): evenly spaced frames.
            return scored.chunked(maxOf(1, scored.size / count)).take(count).map { it[it.size / 2] }
        }
        val buckets = withPeople.chunked(maxOf(1, (withPeople.size + count - 1) / count))
        val best = buckets.mapNotNull { b -> b.maxByOrNull { it.score } }
        val good = best.filter { it.score >= 1f }
        return good.ifEmpty { best }.sortedBy { it.timeMs }.take(count)
    }

    private fun shrink(b: Bitmap, limit: Int): Bitmap {
        val big = maxOf(b.width, b.height)
        if (big <= limit) return b
        val s = limit.toFloat() / big
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    /** Server errors: 401/402/500 stop the film; anything else fails just this job. */
    private fun checkError(res: org.json.JSONObject) {
        val code = res.optInt("_code", 200)
        val err = res.optString("error", "")
        if (code in 200..299 && res.optString("status_url", "").isNotEmpty()) return
        val msg = err.ifBlank { L.t("שירות הציור לא זמין כרגע.", "The drawing service isn't available right now.") }
        if (code == 401 || code == 402 || code == 500) throw FatalEdgeError(msg)
        throw IllegalStateException(msg)
    }

    private fun dataUri(bmp: Bitmap): String {
        // Keep uploads small: the server accepts up to ~4 MB of base64.
        val scaled = shrink(bmp, 1280)
        val stream = java.io.ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val data = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
        return "data:image/jpeg;base64,$data"
    }

    /** POSTs to the edge function. The HTTP status is returned in the JSON as "_code". */
    private fun callEdge(edgeUrl: String, token: String, body: Map<String, Any>): org.json.JSONObject {
        val conn = java.net.URL(edgeUrl).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.doOutput = true

            val json = org.json.JSONObject()
            body.forEach { (k, v) -> json.put(k, v) }
            conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            val out = try { if (text.isBlank()) org.json.JSONObject() else org.json.JSONObject(text) } catch (_: Exception) { org.json.JSONObject() }
            out.put("_code", code)
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun pollEdge(edgeUrl: String, token: String, statusUrl: String, responseUrl: String, cancelled: AtomicBoolean): String {
        if (statusUrl.isEmpty() || responseUrl.isEmpty()) return ""
        repeat(120) { // up to 10 minutes, every 5 seconds
            if (cancelled.get()) return ""
            Thread.sleep(5000)
            if (cancelled.get()) return ""
            val res = try {
                callEdge(edgeUrl, token, mapOf("action" to "poll", "status_url" to statusUrl, "response_url" to responseUrl))
            } catch (_: Exception) { return@repeat } // a network blip: try again next round
            when (res.optString("status", "PENDING")) {
                "DONE" -> return res.optString("url", "")
                "FAILED" -> return ""
            }
        }
        return ""
    }

    private fun durationMs(f: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: SCENE_MS
        } catch (_: Exception) {
            SCENE_MS
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun downloadBitmap(url: String): Bitmap? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 60_000
        conn.inputStream.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    private fun downloadVideo(ctx: Context, url: String): File? {
        return try {
            val file = File(ctx.cacheDir, "film_${System.nanoTime()}.mp4")
            val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            file
        } catch (_: Exception) {
            null
        }
    }
}
