package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Premium: turns one moment (up to ~30 s) into a short 3D animated (Pixar-style) film.
 * Key frames are extracted from the moment and sent to our server (Supabase Edge Function "cartoon-film"), which:
 * 1. stylizes each frame (Flux Pro Kontext), 2. animates the styled frame into a ~5 s clip (Kling).
 * The AI key never lives in the app. The clips are joined here with music and the "Moments app" watermark.
 *
 * Server budget per film: one credit opens a 30-minute window of 12 AI calls. Each scene uses 2 calls,
 * so a film has at most 6 scenes.
 */
@OptIn(markerClass = [UnstableApi::class])
object CartoonFilm {
    private const val SCENE_MS = 5000L
    private const val MAX_SCENES = 6
    private val worker = Executors.newSingleThreadExecutor()

    class Handle { @Volatile var cancel: (() -> Unit)? = null }

    /** A server answer that means "stop the whole film" (not signed in, no credits, server not set up). */
    private class FatalEdgeError(message: String) : Exception(message)

    fun scenesFor(m: Memory): Int = if (!m.isVideo) 1 else (m.durationMs / 5000L).toInt().coerceIn(3, MAX_SCENES)

    fun seconds(m: Memory): Int = (scenesFor(m) * SCENE_MS / 1000L).toInt()

    /** All callbacks run on the main thread. [onStatus] gets (scenes drawn, total). */
    fun make(
        ctx: Context, m: Memory, mood: Music.Mood?,
        onStatus: (Int, Int) -> Unit, onProgress: (Int) -> Unit, onDone: (File?, String?) -> Unit,
    ): Handle {
        val handle = Handle()
        val main = Handler(Looper.getMainLooper())
        val cancelled = AtomicBoolean(false)
        val finished = AtomicBoolean(false)
        handle.cancel = { cancelled.set(true) }
        worker.execute {
            val temp = ArrayList<File>()
            var edgeUrl = ""
            var token = ""
            var reserved = false
            fun refundQuietly() {
                if (!reserved) return
                reserved = false
                try { callEdge(edgeUrl, token, mapOf("action" to "refund")) } catch (_: Exception) {}
            }
            try {
                if (!Account.signedIn(ctx)) throw IllegalStateException(L.t("צריך להתחבר כדי ליצור סרטים", "Sign in to create films"))
                token = Account.token(ctx) ?: throw IllegalStateException(L.t("בעיה בהתחברות. התחברו מחדש ונסו שוב.", "Sign-in problem. Sign in again and try again."))
                edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"

                val frames = ComicMaker.framesFromClip(ctx, m, scenesFor(m))
                if (frames.isEmpty()) throw IllegalStateException(L.t("לא הצלחנו לקרוא את הרגע", "Couldn't read the moment"))

                // One credit for this film. Without it the server refuses every drawing request.
                val res = callEdge(edgeUrl, token, mapOf("action" to "reserve"))
                if (!res.optBoolean("ok", false))
                    throw IllegalStateException(res.optString("error", "").ifBlank { L.t("לא הצלחנו להתחיל את הסרט. נסו שוב.", "Couldn't start the film. Try again.") })
                reserved = true

                val total = frames.size
                val videos = ArrayList<File>()
                var lastError = ""
                for ((i, f) in frames.withIndex()) {
                    if (cancelled.get()) { refundQuietly(); temp.forEach { it.delete() }; return@execute }
                    main.post { if (!cancelled.get()) onStatus(i, total) }
                    try {
                        val video = animateScene(ctx, edgeUrl, token, f, i, cancelled)
                        if (video != null) { videos.add(video); temp.add(video) }
                    } catch (e: FatalEdgeError) {
                        throw IllegalStateException(e.message)
                    } catch (e: Exception) {
                        lastError = e.message.orEmpty()
                    }
                }
                if (cancelled.get()) { refundQuietly(); temp.forEach { it.delete() }; return@execute }
                if (videos.isEmpty())
                    throw IllegalStateException(lastError.ifBlank { L.t("הציור נכשל. בדקו את חיבור האינטרנט ונסו שוב.", "Drawing failed. Check your connection and try again.") })
                main.post { if (!cancelled.get()) onStatus(total, total) }

                // Same frame size for every clip, plus the watermark burned into the picture.
                val portrait = frames[0].height >= frames[0].width
                val outW = if (portrait) 720 else 1280
                val outH = if (portrait) 1280 else 720
                val withMark = Settings.prefs(ctx).getBoolean("share_watermark", true)
                val markBitmap = if (withMark) SocialShare.badge(ctx, (minOf(outW, outH) * 0.30f).toInt()) else null
                fun effects(): Effects {
                    val list = ArrayList<Effect>()
                    list.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
                    if (markBitmap != null) {
                        val settings = OverlaySettings.Builder()
                            .setBackgroundFrameAnchor(0.92f, -0.92f)
                            .setOverlayFrameAnchor(1f, -1f)
                            .setAlphaScale(0.92f)
                            .build()
                        list.add(OverlayEffect(ImmutableList.of(BitmapOverlay.createStaticBitmapOverlay(markBitmap, settings))))
                    }
                    return Effects(emptyList<AudioProcessor>(), list)
                }
                val items = ArrayList<EditedMediaItem>()
                var totalMs = 0L
                for (videoFile in videos) {
                    totalMs += durationMs(videoFile)
                    items.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(videoFile))).setRemoveAudio(true).setEffects(effects()).build())
                }
                val wav = if (mood != null) File(ctx.cacheDir, "toon_music_${System.currentTimeMillis()}.wav").also {
                    temp.add(it); Music.renderWav(mood, totalMs, 0.8f, it)
                } else null
                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, "moments_film_${System.currentTimeMillis()}.mp4")
                main.post {
                    if (cancelled.get()) { temp.forEach { it.delete() }; worker.execute { refundQuietly() }; return@post }
                    try {
                        val sequences = ArrayList<EditedMediaItemSequence>()
                        sequences.add(EditedMediaItemSequence(items))
                        if (wav != null) sequences.add(EditedMediaItemSequence(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).setRemoveVideo(true).build()))
                        val transformer = Transformer.Builder(ctx)
                            .setVideoMimeType(MimeTypes.VIDEO_H264)
                            .addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    finished.set(true); temp.forEach { it.delete() }; onDone(out, null)
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    finished.set(true); temp.forEach { it.delete() }; out.delete()
                                    worker.execute { refundQuietly() }
                                    onDone(null, L.t("לא הצלחנו להרכיב את הסרט. נסו שוב או בלי מוזיקה.", "Couldn't put the film together. Try again, or without music."))
                                }
                            })
                            .build()
                        transformer.start(Composition.Builder(sequences).build(), out.absolutePath)
                        handle.cancel = { cancelled.set(true); finished.set(true); try { transformer.cancel() } catch (_: Throwable) {}; temp.forEach { it.delete() }; out.delete() }
                        val holder = ProgressHolder()
                        val poll = object : Runnable {
                            override fun run() {
                                if (cancelled.get() || finished.get()) return
                                val state = try { transformer.getProgress(holder) } catch (_: Throwable) { Transformer.PROGRESS_STATE_NOT_STARTED }
                                if (state == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                                main.postDelayed(this, 500)
                            }
                        }
                        main.postDelayed(poll, 500)
                    } catch (t: Throwable) {
                        temp.forEach { it.delete() }
                        worker.execute { refundQuietly() }
                        onDone(null, L.t("לא הצלחנו להרכיב את הסרט", "Couldn't put the film together"))
                    }
                }
            } catch (e: Throwable) {
                refundQuietly()
                temp.forEach { it.delete() }
                main.post { if (!cancelled.get()) onDone(null, e.message ?: L.t("לא הצלחנו ליצור את הסרט", "Couldn't create the film")) }
            }
        }
        return handle
    }

    /** One scene: draw it in 3D-cartoon style, then animate it. Returns null when this scene alone failed. */
    private fun animateScene(ctx: Context, edgeUrl: String, token: String, frame: Bitmap, sceneIdx: Int, cancelled: AtomicBoolean): File? {
        val styleRes = callEdge(edgeUrl, token, mapOf("action" to "submit", "kind" to "style", "image" to bitmapToDataUri(frame)))
        checkError(styleRes)
        val styledUrl = pollEdge(edgeUrl, token, styleRes.optString("status_url", ""), styleRes.optString("response_url", ""), cancelled)
        if (styledUrl.isEmpty()) return null

        val animRes = callEdge(edgeUrl, token, mapOf("action" to "submit", "kind" to "anim", "scene" to sceneIdx, "image" to styledUrl))
        checkError(animRes)
        val videoUrl = pollEdge(edgeUrl, token, animRes.optString("status_url", ""), animRes.optString("response_url", ""), cancelled)
        if (videoUrl.isEmpty()) return null
        return downloadVideo(ctx, videoUrl)
    }

    /** Server errors: 401/402/500 stop the film; anything else fails just this scene. */
    private fun checkError(res: org.json.JSONObject) {
        val code = res.optInt("_code", 200)
        val err = res.optString("error", "")
        if (code in 200..299 && res.optString("status_url", "").isNotEmpty()) return
        val msg = err.ifBlank { L.t("שירות הציור לא זמין כרגע.", "The drawing service isn't available right now.") }
        if (code == 401 || code == 402 || code == 500) throw FatalEdgeError(msg)
        throw IllegalStateException(msg)
    }

    private fun bitmapToDataUri(bmp: Bitmap): String {
        // Keep uploads small: the server accepts up to ~4 MB of base64.
        val maxSide = 1280
        val scaled = if (maxOf(bmp.width, bmp.height) > maxSide) {
            val s = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
            Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
        } else bmp
        val stream = java.io.ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val data = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
        return "data:image/jpeg;base64,$data"
    }

    /** POSTs to the edge function. The HTTP status is returned in the JSON as "_code". */
    private fun callEdge(edgeUrl: String, token: String, body: Map<String, Any>): org.json.JSONObject {
        val conn = java.net.URL(edgeUrl).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.doOutput = true

            val json = org.json.JSONObject()
            body.forEach { (k, v) -> json.put(k, v) }
            conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            val out = try { if (text.isBlank()) org.json.JSONObject() else org.json.JSONObject(text) } catch (_: Exception) { org.json.JSONObject() }
            out.put("_code", code)
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun pollEdge(edgeUrl: String, token: String, statusUrl: String, responseUrl: String, cancelled: AtomicBoolean): String {
        if (statusUrl.isEmpty() || responseUrl.isEmpty()) return ""
        repeat(120) { // up to 10 minutes, every 5 seconds
            if (cancelled.get()) return ""
            Thread.sleep(5000)
            if (cancelled.get()) return ""
            val res = try {
                callEdge(edgeUrl, token, mapOf("action" to "poll", "status_url" to statusUrl, "response_url" to responseUrl))
            } catch (_: Exception) { return@repeat } // a network blip: try again next round
            when (res.optString("status", "PENDING")) {
                "DONE" -> return res.optString("url", "")
                "FAILED" -> return ""
            }
        }
        return ""
    }

    private fun durationMs(f: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: SCENE_MS
        } catch (_: Exception) {
            SCENE_MS
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun downloadVideo(ctx: Context, url: String): File? {
        return try {
            val file = File(ctx.cacheDir, "film_${System.nanoTime()}.mp4")
            val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            file
        } catch (_: Exception) {
            null
        }
    }
}
