package com.regaim.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.graphics.Bitmap
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cuts "15 seconds before + 15 seconds after" out of the rolling buffers into an MP4 in the gallery. */
object ClipSaver {
    const val PRE_US = 15_000_000L
    const val POST_US = 15_000_000L

    /** Returns the saved clip, or null if there was nothing to save. */
    fun save(
        ctx: Context,
        video: List<EncodedSample>,
        audio: List<EncodedSample>,
        videoFormat: MediaFormat,
        audioFormat: MediaFormat?,
        rotation: Int,
        triggerUs: Long,
        label: String,
    ): Saved? {
        if (video.isEmpty()) return null
        val from = triggerUs - PRE_US
        val to = triggerUs + POST_US

        // A video clip must start on a key frame: take the last key frame at or before "from".
        var startIdx = -1
        for (i in video.indices) {
            val s = video[i]
            if (s.ptsUs > from) break
            if (s.isKey) startIdx = i
        }
        if (startIdx == -1) startIdx = video.indexOfFirst { it.isKey }
        if (startIdx == -1) return null

        val videoPart = video.subList(startIdx, video.size).filter { it.ptsUs <= to }
        if (videoPart.isEmpty()) return null
        val base = videoPart.first().ptsUs
        val end = videoPart.last().ptsUs
        val audioPart = audio.filter { it.ptsUs in base..end }

        val tmp = File(ctx.cacheDir, "clip_${System.currentTimeMillis()}.mp4")
        val muxer = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            muxer.setOrientationHint(rotation)
            val videoTrack = muxer.addTrack(videoFormat)
            val audioTrack = if (audioFormat != null && audioPart.isNotEmpty()) muxer.addTrack(audioFormat) else -1
            muxer.start()

            val info = MediaCodec.BufferInfo()
            var vi = 0
            var ai = 0
            // Write both tracks interleaved by time.
            while (vi < videoPart.size || (audioTrack >= 0 && ai < audioPart.size)) {
                val takeVideo = when {
                    vi >= videoPart.size -> false
                    audioTrack < 0 || ai >= audioPart.size -> true
                    else -> videoPart[vi].ptsUs <= audioPart[ai].ptsUs
                }
                val s = if (takeVideo) videoPart[vi++] else audioPart[ai++]
                info.set(0, s.data.size, s.ptsUs - base, s.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME)
                muxer.writeSampleData(if (takeVideo) videoTrack else audioTrack, ByteBuffer.wrap(s.data), info)
            }
            muxer.stop()
        } finally {
            try {
                muxer.release()
            } catch (_: Exception) {
            }
        }

        val safeLabel = label.replace(Regex("[^A-Za-z0-9]+"), "-").trim('-').lowercase(Locale.US)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "regaim_${stamp}_$safeLabel.mp4"
        return try {
            // Grab the frame at the moment itself for the memory bubble.
            var durationMs = 0L
            var frame: Bitmap? = null
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(tmp.absolutePath)
                durationMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val atUs = (triggerUs - base).coerceIn(0L, durationMs * 1000L)
                frame = mmr.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                mmr.release()
            } catch (_: Exception) {
            }
            val uri = publish(ctx, tmp, name)
            Saved(name, uri, durationMs, frame)
        } finally {
            tmp.delete()
        }
    }

    class Saved(val name: String, val uri: String, val durationMs: Long, val frame: Bitmap?)

    private fun publish(ctx: Context, file: File, name: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Regaim")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("gallery insert failed")
            val out = resolver.openOutputStream(uri) ?: throw IOException("gallery open failed")
            out.use { o -> file.inputStream().use { it.copyTo(o) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri.toString()
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Regaim")
            dir.mkdirs()
            val dest = File(dir, name)
            file.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf("video/mp4"), null)
            return dest.absolutePath
        }
    }
}
