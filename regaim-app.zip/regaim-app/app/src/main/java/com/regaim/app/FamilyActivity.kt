package com.regaim.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * "משפחה": everyone in the family, each with their own moments.
 * Built from the profile (kids and ages) and from the faces you named — never from guesses.
 */
class FamilyActivity : AppCompatActivity() {

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = "המשפחה שלנו"
        findViewById<View>(R.id.btnClose).visibility = View.GONE
        findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
        Nav.setup(this, Nav.Tab.FAMILY)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private class Member(val name: String, val birth: String, val isKid: Boolean)

    private fun members(): List<Member> {
        val kids = Profile.kids(this)
        val list = kids.map { Member(it.name, it.birth, true) }.toMutableList()
        for (p in PeopleStore.people(this)) if (list.none { it.name == p.name }) list.add(Member(p.name, "", false))
        return list
    }

    private fun openPerson(name: String) {
        startActivity(Intent(this, MemoriesActivity::class.java).putExtra(MemoriesActivity.EXTRA_PERSON, name)
            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private fun render() {
        content.removeAllViews()
        content.addView(ui.hint("כל אחד במשפחה, והרגעים שלו.", top = 0))
        val circle = ui.card(top = 14)
        circle.addView(ui.row("💌 מעגל המשפחה", if (Circle.joined(this)) Circle.name(this) else "פתחו מעגל", top = 0) { CircleActivity.open(this) })
        circle.addView(ui.hint("פיד פרטי לכל המשפחה: סבא וסבתא רואים, מגיבים ומשתפים מהדפדפן.", top = 0))
        content.addView(circle)
        val all = MemoryStore.all(this)
        val people = members()
        if (people.isEmpty()) {
            val card = ui.card(top = 20)
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.setPadding(mv.dp(22), mv.dp(28), mv.dp(22), mv.dp(24))
            card.addView(TextView(this).apply { text = "👨‍👩‍👦"; textSize = 40f; gravity = Gravity.CENTER })
            card.addView(ui.text("בואו נכיר את המשפחה", 20f, bold = true, top = 8).apply { gravity = Gravity.CENTER })
            card.addView(ui.text("הוסיפו את הילדים בפרופיל, ותנו שמות לפנים שזוהו. כך כל אחד יקבל את ציר הזמן שלו.", 15f, R.color.ink_soft, top = 6).apply { gravity = Gravity.CENTER })
            card.addView(ui.button("הוסיפו את המשפחה", primary = true, top = 18) { startActivity(Intent(this, ProfileActivity::class.java)) })
            content.addView(card)
            mv.reveal(card)
        }
        people.forEachIndexed { i, p ->
            val v = memberCard(p, all)
            content.addView(v)
            mv.reveal(v, (i * 50L).coerceAtMost(250L))
        }

        val unknown = try { PeopleStore.unknownGroups(this).size } catch (_: Exception) { 0 }
        val more = ui.card(top = 20)
        if (unknown > 0) more.addView(ui.row("מי זה? $unknown פנים מחכות לשם", "") { PeopleActivity.open(this) })
        more.addView(ui.row("★ אבני דרך", "${all.count { it.milestone.isNotEmpty() }}") {
            startActivity(Intent(this, MilestonesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        })
        more.addView(ui.row("ערוך את המשפחה", "") { startActivity(Intent(this, ProfileActivity::class.java)) })
        content.addView(more)
    }

    private fun memberCard(p: Member, all: List<Memory>): View {
        val mine = all.filter { Fmt.names(it).contains(p.name) }
        val card = ui.card(top = 14)
        val top = ui.horizontal(top = 0)
        top.addView(mv.avatar(p.name, 60))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(14), 0, mv.dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(ui.text(p.name, 19f, bold = true))
        val age = Profile.ageText(p.birth)
        val sub = listOf(
            age,
            when (mine.size) {
                0 -> ""
                1 -> "רגע אחד"
                else -> "${mine.size} רגעים"
            },
            mine.firstOrNull()?.let { "אחרון: ${Fmt.day(it.time)}" }.orEmpty(),
        ).filter { it.isNotEmpty() }.joinToString(" · ")
        texts.addView(ui.hint(sub.ifEmpty { "עוד אין רגעים" }, top = 2))
        top.addView(texts)
        card.addView(top)

        if (mine.isNotEmpty()) {
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in mine.take(8)) strip.addView(mv.mini(m) { MomentActivity.open(this, m.id) })
            card.addView(ui.scrollRow(strip, top = 12))
            card.setOnClickListener { openPerson(p.name) }
            card.addView(ui.action("כל הרגעים של ${p.name} ›") { openPerson(p.name) })
        } else if (p.isKid && PeopleStore.people(this).none { it.name == p.name }) {
            card.addView(ui.hint("כדי למצוא את ${p.name} ברגעים, תנו את השם הזה לפנים שלו במסך \"מי זה?\".", top = 10))
            card.addView(ui.action("מי זה? ›") { PeopleActivity.open(this) })
        }
        return card
    }
}
