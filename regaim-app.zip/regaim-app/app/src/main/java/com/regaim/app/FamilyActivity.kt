package com.regaim.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * "משפחה": everyone in the family, each with their own moments.
 * Built from the profile (kids and ages) and from the faces you named — never from guesses.
 */
class FamilyActivity : AppCompatActivity() {

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private lateinit var sharedViews: SharedMemoryViews
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var familyFeed: Circle.Feed? = null
    private var circleMembers = emptyList<Circle.Member>()
    private var amOwner = false
    private var familyError = ""
    private var loading = false
    private var loadedUser = ""
    private var loadedCircle = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        sharedViews = SharedMemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = Profile.homeTitle(this)
        findViewById<View>(R.id.btnClose).visibility = View.GONE
        findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
        Nav.setup(this, Nav.Tab.FAMILY)
        Nav.addProfileButton(this, findViewById<View>(R.id.screenTitle).parent as android.view.ViewGroup)
    }

    override fun onResume() {
        super.onResume()
        if (!Circle.joined(this) || !Account.signedIn(this) || loadedUser != Account.id(this) || loadedCircle != Circle.circleId(this)) { familyFeed = null; circleMembers = emptyList(); familyError = "" }
        render()
        loadFamily()
    }

    override fun onDestroy() { worker.shutdownNow(); sharedViews.close(); super.onDestroy() }

    private fun loadFamily() {
        if (!Circle.joined(this) || loading || worker.isShutdown) return
        val requestedUser = Account.id(this)
        val requestedCircle = Circle.circleId(this)
        loading = true
        render()
        worker.execute {
            val result = try { Result.success(Circle.feed(applicationContext) to Circle.members(applicationContext)) } catch (e: Exception) { Result.failure(e) }
            val owner = Circle.isOwner(applicationContext)
            runOnUiThread {
                loading = false
                if (isDestroyed || requestedUser != Account.id(this) || requestedCircle != Circle.circleId(this)) return@runOnUiThread
                amOwner = owner
                result.onSuccess { familyFeed = it.first; circleMembers = it.second; familyError = ""; loadedUser = requestedUser; loadedCircle = requestedCircle }
                    .onFailure { familyError = it.message ?: L.t("לא הצלחנו לפתוח את המשפחה כרגע", "We couldn't load your family right now") }
                render()
            }
        }
    }

    private fun confirmRemove(member: Circle.Member) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(L.t("להוציא את ${member.name} מהמעגל?", "Remove ${member.name} from the circle?"))
            .setMessage(L.t("${member.name} לא יראה יותר את הרגעים והשיחות. קישור ההזמנה יוחלף, כדי שהישן לא יעבוד.", "${member.name} won't see the moments and chats anymore. The invite link changes so the old one stops working."))
            .setPositiveButton(L.t("הוצאה", "Remove")) { _, _ ->
                worker.execute {
                    val err = try { Circle.removeMember(applicationContext, member.userId); null } catch (e: Exception) { e.message ?: L.t("לא הצלחנו", "Something went wrong") }
                    runOnUiThread {
                        if (isDestroyed) return@runOnUiThread
                        android.widget.Toast.makeText(this, err ?: L.t("${member.name} הוצא מהמעגל", "${member.name} was removed"), android.widget.Toast.LENGTH_LONG).show()
                        if (err == null) { circleMembers = circleMembers.filter { it.userId != member.userId }; render() }
                    }
                }
            }
            .setNegativeButton(L.t("ביטול", "Cancel"), null)
            .show()
    }

    private class Member(val name: String, val birth: String, val isKid: Boolean, val relation: String)

    private fun members(): List<Member> = Profile.members(this).map { Member(it.name, it.birth, it.isChild, it.relation) }

    private fun openPerson(name: String) {
        startActivity(Intent(this, MemoriesActivity::class.java).putExtra(MemoriesActivity.EXTRA_PERSON, name)
            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private fun render() {
        content.removeAllViews()
        content.addView(ui.hint(L.t("כאן נפגשים הסיפורים והאנשים שלכם.", "Where your stories and your people come together."), top = 10))
        val circle = ui.card(top = 14)
        circle.addView(ui.row(L.t("מעגל המשפחה", "Family circle"), if (Circle.joined(this)) Circle.name(this) else L.t("פתחו מעגל", "Start a circle"), top = 0) { CircleActivity.open(this) })
        circle.addView(ui.hint(L.t("הזמינו את המשפחה, שתפו זיכרון והתחילו שיחה.", "Invite your family, share a memory and start a conversation."), top = 0))
        if (Circle.joined(this)) circle.addView(ui.action(L.t("שיחה במשפחה", "Family chat")) { FamilyChatActivity.open(this) })
        content.addView(circle)
        if (loading) content.addView(ui.hint(L.t("רגע, פותחים את הזיכרונות של המשפחה...", "Loading your family's memories..."), top = 10))
        if (familyError.isNotBlank()) {
            content.addView(ui.hint(familyError, top = 10))
            content.addView(ui.action(L.t("נסו שוב", "Try again")) { loadFamily() })
            if (!Account.signedIn(this)) content.addView(ui.action(L.t("התחברו למעגל", "Sign in to your circle")) { WelcomeActivity.open(this) })
        }
        if (circleMembers.isNotEmpty()) {
            content.addView(ui.section(L.t("במעגל שלכם", "In your circle")))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (member in circleMembers) row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(ui.dp(10), ui.dp(5), ui.dp(10), ui.dp(5))
                addView(mv.avatar(member.name, 48))
                addView(ui.text(member.name, 14f, bold = true, top = 5))
                addView(ui.hint(Profile.relationLabel(member.relationship), top = 2))
                // The family's owner can take someone out of the circle (long press).
                if (amOwner && member.userId != Account.id(this@FamilyActivity)) setOnLongClickListener { confirmRemove(member); true }
            })
            content.addView(ui.scrollRow(row, top = 4))
            if (amOwner && circleMembers.size > 1) content.addView(ui.hint(L.t("לחיצה ארוכה על בן משפחה מוציאה אותו מהמעגל.", "Long-press someone to remove them from the circle."), top = 2))
        }
        familyFeed?.let { feed ->
            content.addView(ui.section(L.t("מה חדש במשפחה", "What's new in the family")))
            if (feed.posts.isEmpty()) content.addView(ui.hint(L.t("עוד לא שיתפתם זיכרונות במעגל. הזיכרון הבא יכול להתחיל שיחה ❤️", "No memories shared in your circle yet. Your next one could start a conversation ❤️"), top = 8))
            feed.posts.take(3).forEach { content.addView(sharedViews.card(it, feed) { loadFamily() }) }
            if (feed.posts.size > 3) content.addView(ui.action(L.t("כל זיכרונות המשפחה", "All family memories")) { CircleActivity.open(this) })
        }
        content.addView(ui.section(L.t("האנשים בסיפור שלכם", "The people in your story")))
        val all = MemoryStore.all(this)
        val people = members()
        if (people.isEmpty()) {
            val card = ui.card(top = 20)
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.setPadding(mv.dp(22), mv.dp(28), mv.dp(22), mv.dp(24))
            card.addView(android.widget.ImageView(this).apply { setImageResource(R.drawable.ic_tab_family); setColorFilter(androidx.core.content.ContextCompat.getColor(this@FamilyActivity, R.color.ink)); layoutParams = android.widget.LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)).apply { gravity = android.view.Gravity.CENTER_HORIZONTAL } })
            card.addView(ui.text(L.t("בואו נכיר את המשפחה", "Let's meet your family"), 20f, bold = true, top = 8).apply { gravity = Gravity.CENTER })
            card.addView(ui.text(L.t("הוסיפו בני משפחה בפרופיל. תוכלו לחבר שמות לפנים שזוהו ולגלות את הרגעים שלכם יחד.", "Add family members in your profile. Then you can name the faces we find and discover your moments together."), 15f, R.color.ink_soft, top = 6).apply { gravity = Gravity.CENTER })
            card.addView(ui.button(L.t("הוסיפו את המשפחה", "Add your family"), primary = true, top = 18) { startActivity(Intent(this, ProfileActivity::class.java)) })
            content.addView(card)
            mv.reveal(card)
        }
        people.forEachIndexed { i, p ->
            val v = memberCard(p, all)
            content.addView(v)
            mv.reveal(v, (i * 50L).coerceAtMost(250L))
        }

        val unknown = try { PeopleStore.unknownGroups(this).size } catch (_: Exception) { 0 }
        val more = ui.card(top = 20)
        if (unknown > 0) more.addView(ui.row(L.t("מי זה? $unknown פנים מחכות לשם", "Who's this? $unknown faces need a name"), "") { PeopleActivity.open(this) })
        more.addView(ui.row(L.t("אבני דרך", "Milestones"), "${all.count { it.milestone.isNotEmpty() }}") {
            startActivity(Intent(this, MilestonesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        })
        more.addView(ui.row(L.t("ערוך את המשפחה", "Edit family"), "") { startActivity(Intent(this, ProfileActivity::class.java)) })
        content.addView(more)
    }

    private fun memberCard(p: Member, all: List<Memory>): View {
        val mine = all.filter { Fmt.names(it).contains(p.name) }
        val card = ui.card(top = 14)
        val top = ui.horizontal(top = 0)
        top.addView(mv.avatar(p.name, 60))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(14), 0, mv.dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(ui.text(p.name, 19f, bold = true))
        val age = Profile.ageText(p.birth)
        val sub = listOf(
            Profile.relationLabel(p.relation),
            age,
            when (mine.size) {
                0 -> ""
                1 -> L.t("רגע אחד", "1 moment")
                else -> L.t("${mine.size} רגעים", "${mine.size} moments")
            },
            mine.firstOrNull()?.let { L.t("אחרון: ${Fmt.day(it.time)}", "Latest: ${Fmt.day(it.time)}") }.orEmpty(),
        ).filter { it.isNotEmpty() }.joinToString(" · ")
        texts.addView(ui.hint(sub.ifEmpty { L.t("עוד אין רגעים", "No moments yet") }, top = 2))
        top.addView(texts)
        card.addView(top)

        if (mine.isNotEmpty()) {
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in mine.take(8)) strip.addView(mv.mini(m) { MomentActivity.open(this, m.id) })
            card.addView(ui.scrollRow(strip, top = 12))
            card.setOnClickListener { openPerson(p.name) }
            card.addView(ui.action(L.t("כל הרגעים של ${p.name} ›", "All of ${p.name}'s moments ›")) { openPerson(p.name) })
            if (p.isKid) card.addView(ui.action(L.t("ציר הזמן של ${p.name} ›", "${p.name}'s timeline ›")) { TimelineActivity.open(this, p.name) })
        } else if (p.isKid && PeopleStore.people(this).none { it.name == p.name }) {
            card.addView(ui.hint(L.t("כדי למצוא את ${p.name} ברגעים, תנו את השם הזה לפנים שלו במסך \"מי זה?\".", "To find ${p.name} in your moments, give their face this name on the \"Who's this?\" screen."), top = 10))
            card.addView(ui.action(L.t("מי זה? ›", "Who's this? ›")) { PeopleActivity.open(this) })
        }
        return card
    }
}
