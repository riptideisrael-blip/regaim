package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Owner's admin screen: how many people use Moments. The numbers come from the server
 * (function admin_stats in server/admin-stats.sql), which answers only the admin account.
 */
class AdminActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, AdminActivity::class.java))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var ui: Ui
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = "ניהול"
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        load()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun load() {
        content.removeAllViews()
        content.addView(ui.hint("טוענים את המספרים...", top = 8))
        worker.execute {
            val result = try { Result.success(Circle.adminStats(applicationContext)) } catch (e: Exception) { Result.failure<JSONObject>(e) }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                content.removeAllViews()
                result.onSuccess { show(it) }.onFailure { fail(it) }
            }
        }
    }

    private fun fail(e: Throwable) {
        val m = e.message.orEmpty()
        content.addView(ui.text("לא הצלחנו להביא את המספרים", 17f, bold = true, top = 8))
        content.addView(ui.hint(
            when {
                "not allowed" in m || "42501" in m -> "החשבון הזה אינו מנהל. התחברו עם חשבון הבעלים."
                "admin_stats" in m || "404" in m || "PGRST202" in m -> "עוד לא הוספתם את פונקציית הניהול בשרת. הריצו את הקובץ server/admin-stats.sql ב-SQL Editor של Supabase."
                else -> m.ifEmpty { "בדקו חיבור לאינטרנט והתחברות לחשבון." }
            }, top = 6))
        content.addView(ui.button("נסו שוב", primary = true, top = 14) { load() })
    }

    private fun n(o: JSONObject, key: String) = o.optLong(key, 0L).toString()

    private fun stat(card: LinearLayout, label: String, value: String) {
        card.addView(ui.row(label, value))
    }

    private fun show(s: JSONObject) {
        content.addView(ui.hint("מתוך השרת, מתעדכן בכל כניסה למסך", top = 0))

        val users = ui.card(top = 10)
        users.addView(ui.text("משתמשים", 17f, bold = true))
        stat(users, "נרשמו בסך הכל", n(s, "users"))
        stat(users, "נרשמו ב-7 הימים האחרונים", n(s, "users_7d"))
        stat(users, "נרשמו ב-30 הימים האחרונים", n(s, "users_30d"))
        stat(users, "פעילים ב-7 הימים האחרונים", n(s, "active_7d"))
        stat(users, "נרשמו עם Google", n(s, "google"))
        stat(users, "אורחים (נכנסו מקישור הזמנה)", n(s, "guests"))
        content.addView(users)

        val fam = ui.card(top = 10)
        fam.addView(ui.text("משפחות ותוכן", 17f, bold = true))
        stat(fam, "מעגלי משפחה", n(s, "circles"))
        stat(fam, "חברים במעגלים", n(s, "members"))
        stat(fam, "רגעים ששותפו", n(s, "posts"))
        stat(fam, "רגעים ששותפו ב-7 ימים", n(s, "posts_7d"))
        stat(fam, "תגובות", n(s, "comments"))
        stat(fam, "תגובות באימוג'י", n(s, "reactions"))
        stat(fam, "הודעות משפחה", n(s, "messages"))
        stat(fam, "רגעים בקהילה", n(s, "community_posts"))
        stat(fam, "רגעים שדווח עליהם", n(s, "community_reported"))
        stat(fam, "אחסון בשימוש (MB)", s.optDouble("storage_mb", 0.0).toString())
        content.addView(fam)

        val signups = s.optJSONArray("signups")
        if (signups != null && signups.length() > 0) {
            val card = ui.card(top = 10)
            card.addView(ui.text("הרשמות ב-14 הימים האחרונים", 17f, bold = true))
            for (i in 0 until signups.length()) {
                val o = signups.getJSONObject(i)
                stat(card, o.optString("day"), o.optLong("n").toString())
            }
            content.addView(card)
        }

        val recent = s.optJSONArray("recent")
        if (recent != null && recent.length() > 0) {
            val card = ui.card(top = 10)
            card.addView(ui.text("נרשמו לאחרונה", 17f, bold = true))
            for (i in 0 until recent.length()) {
                val o = recent.getJSONObject(i)
                val who = o.optString("name").ifEmpty { o.optString("email") }
                stat(card, who, o.optString("created").take(10))
            }
            content.addView(card)
        }
        content.addView(ui.hint("מי שמשתמש באפליקציה בלי חשבון לא נספר כאן, כי הזיכרונות שלו נשארים רק בטלפון.", top = 12))
    }
}
