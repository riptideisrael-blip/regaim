package com.regaim.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Owner's admin screen: how many people use Moments. The numbers come from the server
 * (function admin_stats in server/admin-stats.sql), which answers only the admin account.
 */
class AdminActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, AdminActivity::class.java))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var ui: Ui
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = L.t("ניהול", "Admin")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        load()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun load() {
        content.removeAllViews()
        content.addView(ui.hint(L.t("טוענים את המספרים...", "Loading stats…"), top = 8))
        worker.execute {
            val result = try { Result.success(Circle.adminStats(applicationContext)) } catch (e: Exception) { Result.failure<JSONObject>(e) }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                content.removeAllViews()
                result.onSuccess { show(it) }.onFailure { fail(it) }
            }
        }
    }

    private fun fail(e: Throwable) {
        val m = e.message.orEmpty()
        content.addView(ui.text(L.t("לא הצלחנו להביא את המספרים", "Couldn't load stats"), 17f, bold = true, top = 8))
        content.addView(ui.hint(
            when {
                "not allowed" in m || "42501" in m -> L.t("החשבון הזה אינו מנהל. התחברו עם חשבון הבעלים.", "This account isn't an admin. Sign in with the owner account.")
                "admin_stats" in m || "404" in m || "PGRST202" in m -> L.t("עוד לא הוספתם את פונקציית הניהול בשרת. הריצו את הקובץ server/admin-stats.sql ב-SQL Editor של Supabase.", "The admin function isn't on the server yet. Run server/admin-stats.sql in the Supabase SQL Editor.")
                else -> m.ifEmpty { L.t("בדקו חיבור לאינטרנט והתחברות לחשבון.", "Check your internet connection and that you're signed in.") }
            }, top = 6))
        content.addView(ui.button(L.t("נסו שוב", "Try again"), primary = true, top = 14) { load() })
    }

    private fun n(o: JSONObject, key: String) = o.optLong(key, 0L).toString()

    private fun stat(card: LinearLayout, label: String, value: String) {
        card.addView(ui.row(label, value))
    }

    private fun show(s: JSONObject) {
        content.addView(ui.hint(L.t("מתוך השרת, מתעדכן בכל כניסה למסך", "From the server, refreshed each time you open this screen"), top = 0))

        val users = ui.card(top = 10)
        users.addView(ui.text(L.t("משתמשים", "Users"), 17f, bold = true))
        stat(users, L.t("נרשמו בסך הכל", "Total sign-ups"), n(s, "users"))
        stat(users, L.t("נרשמו ב-7 הימים האחרונים", "Signed up in the last 7 days"), n(s, "users_7d"))
        stat(users, L.t("נרשמו ב-30 הימים האחרונים", "Signed up in the last 30 days"), n(s, "users_30d"))
        stat(users, L.t("פעילים ב-7 הימים האחרונים", "Active in the last 7 days"), n(s, "active_7d"))
        stat(users, L.t("נרשמו עם Google", "Signed up with Google"), n(s, "google"))
        stat(users, L.t("אורחים (נכנסו מקישור הזמנה)", "Guests (joined via invite link)"), n(s, "guests"))
        content.addView(users)

        val fam = ui.card(top = 10)
        fam.addView(ui.text(L.t("משפחות ותוכן", "Families and content"), 17f, bold = true))
        stat(fam, L.t("מעגלי משפחה", "Family circles"), n(s, "circles"))
        stat(fam, L.t("חברים במעגלים", "Circle members"), n(s, "members"))
        stat(fam, L.t("רגעים ששותפו", "Moments shared"), n(s, "posts"))
        stat(fam, L.t("רגעים ששותפו ב-7 ימים", "Moments shared in 7 days"), n(s, "posts_7d"))
        stat(fam, L.t("תגובות", "Comments"), n(s, "comments"))
        stat(fam, L.t("תגובות באימוג'י", "Emoji reactions"), n(s, "reactions"))
        stat(fam, L.t("הודעות משפחה", "Family messages"), n(s, "messages"))
        stat(fam, L.t("רגעים בקהילה", "Community moments"), n(s, "community_posts"))
        stat(fam, L.t("רגעים שדווח עליהם", "Reported moments"), n(s, "community_reported"))
        stat(fam, L.t("אחסון בשימוש (MB)", "Storage used (MB)"), s.optDouble("storage_mb", 0.0).toString())
        content.addView(fam)

        val signups = s.optJSONArray("signups")
        if (signups != null && signups.length() > 0) {
            val card = ui.card(top = 10)
            card.addView(ui.text(L.t("הרשמות ב-14 הימים האחרונים", "Sign-ups in the last 14 days"), 17f, bold = true))
            for (i in 0 until signups.length()) {
                val o = signups.getJSONObject(i)
                stat(card, o.optString("day"), o.optLong("n").toString())
            }
            content.addView(card)
        }

        val recent = s.optJSONArray("recent")
        if (recent != null && recent.length() > 0) {
            val card = ui.card(top = 10)
            card.addView(ui.text(L.t("נרשמו לאחרונה", "Recent sign-ups"), 17f, bold = true))
            for (i in 0 until recent.length()) {
                val o = recent.getJSONObject(i)
                val who = o.optString("name").ifEmpty { o.optString("email") }
                stat(card, who, o.optString("created").take(10))
            }
            content.addView(card)
        }
        content.addView(ui.hint(L.t("מי שמשתמש באפליקציה בלי חשבון לא נספר כאן, כי הזיכרונות שלו נשארים רק בטלפון.", "People using the app without an account aren't counted here, since their memories stay on their phone."), top = 12))
    }
}
