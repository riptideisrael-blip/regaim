package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * On-device face identity (MobileFaceNet, BSD-3 licensed model, downloaded once ~5MB).
 * Turns a face crop into a 192-number "face print". Nothing leaves the phone.
 */
object FaceId {
    private const val MODEL_URL =
        "https://github.com/MCarlomagno/FaceRecognitionAuth/raw/refs/heads/master/assets/mobilefacenet.tflite"
    private var interpreter: Interpreter? = null

    fun modelFile(ctx: Context) = File(ctx.filesDir, "mobilefacenet.tflite")
    fun ready(ctx: Context) = modelFile(ctx).let { it.exists() && it.length() > 1_000_000 }

    /** Downloads the model once. Background thread only. */
    fun ensureModel(ctx: Context): Boolean {
        if (ready(ctx)) return true
        var url = MODEL_URL
        repeat(5) {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
            }
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    url = conn.getHeaderField("Location") ?: return false
                    return@repeat
                }
                if (code != 200) return false
                val tmp = File(ctx.filesDir, "mobilefacenet.tmp")
                conn.inputStream.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                if (tmp.length() < 1_000_000) {
                    tmp.delete()
                    return false
                }
                tmp.renameTo(modelFile(ctx))
                return true
            } catch (_: Exception) {
                return false
            } finally {
                conn.disconnect()
            }
        }
        return false
    }

    @Synchronized
    fun embed(ctx: Context, face: Bitmap): FloatArray? {
        if (!ready(ctx)) return null
        val interp = interpreter ?: Interpreter(modelFile(ctx), Interpreter.Options().setNumThreads(2)).also { interpreter = it }
        val inShape = interp.getInputTensor(0).shape() // [batch, 112, 112, 3]
        val batch = inShape[0]
        val size = inShape[1]
        val outLen = interp.getOutputTensor(0).shape().last()
        val scaled = Bitmap.createScaledBitmap(face, size, size, true)
        val px = IntArray(size * size)
        scaled.getPixels(px, 0, size, 0, 0, size, size)
        val input = ByteBuffer.allocateDirect(batch * size * size * 3 * 4).order(ByteOrder.nativeOrder())
        repeat(batch) {
            for (p in px) {
                input.putFloat((((p shr 16) and 0xff) - 128f) / 128f)
                input.putFloat((((p shr 8) and 0xff) - 128f) / 128f)
                input.putFloat(((p and 0xff) - 128f) / 128f)
            }
        }
        input.rewind()
        val out = Array(batch) { FloatArray(outLen) }
        interp.run(input, out)
        val v = out[0]
        var norm = 0f
        for (x in v) norm += x * x
        norm = sqrt(norm).coerceAtLeast(1e-6f)
        return FloatArray(v.size) { v[it] / norm }
    }

    fun dist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            s += d * d
        }
        return sqrt(s)
    }
}

data class Person(val id: String, val name: String, val photo: String, val prints: List<FloatArray>)

data class FaceShot(
    val id: String,
    val memoryId: String,
    val path: String,
    val print: FloatArray,
    val personId: String?,
    val ignored: Boolean,
    val time: Long,
)

/** People and faces, Google-Photos style: faces are grouped, you name a group once, the app finds them again. */
object PeopleStore {
    /**
     * Two prints closer than this are treated as the same person (prints are length-1 vectors).
     * Was 0.95: too loose for young siblings and small, blurry chest-camera faces, so almost every
     * child ended up tagged as the same kid.
     */
    const val MATCH = 0.82f
    /** "Who's this?" groups: a little looser than MATCH, but no longer lumping different kids together. */
    private const val GROUP = 0.86f
    /** The best person must win clearly over the second best, else the face stays unnamed. */
    private const val MARGIN = 0.06f
    /** Faces smaller than this (pixels) are kept but never named automatically: too little detail. */
    private const val MIN_FACE_PX = 72
    private const val SAME_IN_CLIP = 0.85f

    fun peopleEnabled(ctx: Context) = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).getBoolean("people_on", true)

    private fun peopleFile(ctx: Context) = File(ctx.filesDir, "people.json")
    private fun facesFile(ctx: Context) = File(ctx.filesDir, "faces.json")

    private fun toJson(a: FloatArray) = JSONArray().also { j -> a.forEach { j.put(it.toDouble()) } }
    private fun fromJson(j: JSONArray) = FloatArray(j.length()) { j.optDouble(it).toFloat() }

    @Synchronized
    fun people(ctx: Context): List<Person> = try {
        val arr = JSONArray(peopleFile(ctx).readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val pr = o.optJSONArray("prints") ?: JSONArray()
            Person(o.optString("id"), o.optString("name"), o.optString("photo"),
                (0 until pr.length()).map { k -> fromJson(pr.getJSONArray(k)) })
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun savePeople(ctx: Context, list: List<Person>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("photo", p.photo)
                .put("prints", JSONArray().also { j -> p.prints.forEach { j.put(toJson(it)) } }))
        }
        peopleFile(ctx).writeText(arr.toString())
    }

    @Synchronized
    fun faces(ctx: Context): List<FaceShot> = try {
        val arr = JSONArray(facesFile(ctx).readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            FaceShot(o.optString("id"), o.optString("memoryId"), o.optString("path"),
                fromJson(o.optJSONArray("print") ?: JSONArray()),
                o.optString("personId").ifEmpty { null }, o.optBoolean("ignored"), o.optLong("time"))
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun saveFaces(ctx: Context, list: List<FaceShot>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("id", f.id).put("memoryId", f.memoryId).put("path", f.path)
                .put("print", toJson(f.print)).put("personId", f.personId ?: "")
                .put("ignored", f.ignored).put("time", f.time))
        }
        facesFile(ctx).writeText(arr.toString())
    }

    fun match(people: List<Person>, print: FloatArray): Person? {
        var best: Person? = null
        var bestD = Float.MAX_VALUE
        var second = Float.MAX_VALUE
        for (p in people) {
            val d = p.prints.minOfOrNull { FaceId.dist(print, it) } ?: continue
            if (d < bestD) { second = bestD; bestD = d; best = p } else if (d < second) second = d
        }
        if (best == null || bestD >= MATCH) return null
        // Two family members almost equally close (siblings): don't guess.
        if (bestD > 0.05f && second - bestD < MARGIN) return null
        return best
    }

    /**
     * Once, after the stricter rules: look again at every face that was named automatically.
     * Faces the family named by hand (their print is one of the person's own prints) stay as they are.
     */
    private fun rematchOnce(ctx: Context) {
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        if (prefs.getBoolean("faces_rules_v2", false)) return
        synchronized(this) {
            val people = people(ctx)
            saveFaces(ctx, faces(ctx).map { f ->
                val pid = f.personId ?: return@map f
                val own = people.firstOrNull { it.id == pid }
                val byHand = own?.prints?.any { FaceId.dist(it, f.print) < 0.05f } == true
                if (byHand) f else f.copy(personId = match(people, f.print)?.id)
            })
        }
        refreshMemoryNames(ctx)
        prefs.edit().putBoolean("faces_rules_v2", true).apply()
    }

    // ---------- scanning moments ----------

    private val scanning = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Finds faces in moments that weren't scanned yet. Background thread only. Returns how many were scanned. */
    fun scanPending(ctx: Context, limit: Int = 8): Int {
        if (!scanning.compareAndSet(false, true)) return 0
        try {
            if (!FaceId.ensureModel(ctx)) return 0
            try { enrollFamily(ctx) } catch (_: Exception) {}
            try { rematchOnce(ctx) } catch (_: Exception) {}
            var n = 0
            for (m in MemoryStore.all(ctx).filter { !it.facesScanned }.take(limit)) {
                try { scanMemory(ctx, m) } catch (_: Throwable) {
                    // An unreadable clip (deleted from the gallery...): mark it so we don't try it forever.
                    MemoryStore.modify(ctx, m.id) { it.copy(facesScanned = true) }
                }
                n++
            }
            return n
        } finally {
            scanning.set(false)
        }
    }

    /**
     * Family members with a profile photo become known people right away, so nobody has to name their
     * faces by hand first. Runs once per member photo. Background thread only.
     */
    fun enrollFamily(ctx: Context) {
        if (!FaceId.ready(ctx)) return
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        val done = prefs.getStringSet("enrolled_family", emptySet())?.toMutableSet() ?: mutableSetOf()
        var changed = false
        for (member in Profile.members(ctx)) {
            if (member.photo.isEmpty() || member.isPet) continue
            val key = "${member.name.trim()}|${member.photo}"
            if (key in done) continue
            val bmp = try { android.graphics.BitmapFactory.decodeFile(member.photo)?.let { downscale(it, 1280) } } catch (_: Exception) { null }
            if (bmp == null) { done.add(key); continue }
            val detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setMinFaceSize(0.1f).build()
            )
            val print = try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                val biggest = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                biggest?.let { cropFace(bmp, it.boundingBox) }?.let { FaceId.embed(ctx, it) }
            } catch (_: Exception) { null } finally { detector.close() }
            done.add(key)
            if (print == null) continue
            synchronized(this) {
                val people = people(ctx)
                val name = member.name.trim()
                val existing = people.firstOrNull { it.name == name }
                val person = (existing ?: Person(UUID.randomUUID().toString(), name, member.photo, emptyList()))
                    .let { it.copy(prints = (it.prints + print).takeLast(15)) }
                savePeople(ctx, people.filterNot { it.id == person.id } + person)
                saveFaces(ctx, faces(ctx).map { f ->
                    if (f.personId == null && !f.ignored && FaceId.dist(f.print, print) < MATCH) f.copy(personId = person.id) else f
                })
            }
            changed = true
        }
        prefs.edit().putStringSet("enrolled_family", done).apply()
        if (changed) refreshMemoryNames(ctx)
    }

    private fun downscale(b: Bitmap, limit: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= limit) return b
        val f = limit.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    /** Looks again, more carefully, for the people in one moment, then lets the AI describe it again. */
    fun rescan(ctx: Context, m: Memory) {
        if (!FaceId.ensureModel(ctx)) return
        enrollFamily(ctx)
        synchronized(this) { saveFaces(ctx, faces(ctx).filterNot { it.memoryId == m.id }) }
        scanMemory(ctx, MemoryStore.get(ctx, m.id) ?: m, frames = 8)
    }

    fun scanMemory(ctx: Context, m: Memory, frames: Int = 5) {
        if (!FaceId.ready(ctx)) return
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setMinFaceSize(0.08f)
                .build()
        )
        class Found(val crop: Bitmap, val print: FloatArray, val area: Int, val side: Int)
        val found = mutableListOf<Found>()
        try {
            for (frame in ComicMaker.framesFromClip(ctx, m, frames)) {
                val faces = try { Tasks.await(detector.process(InputImage.fromBitmap(frame, 0))) } catch (_: Exception) { emptyList() }
                for (f in faces) {
                    val crop = cropFace(frame, f.boundingBox) ?: continue
                    val print = FaceId.embed(ctx, crop) ?: continue
                    found.add(Found(crop, print, f.boundingBox.width() * f.boundingBox.height(), minOf(f.boundingBox.width(), f.boundingBox.height())))
                }
            }
        } finally {
            detector.close()
        }
        // The same person usually shows up in all 3 frames: keep the biggest shot of each.
        val unique = mutableListOf<Found>()
        for (f in found.sortedByDescending { it.area }) {
            if (unique.none { FaceId.dist(it.print, f.print) < SAME_IN_CLIP }) unique.add(f)
        }
        val people = people(ctx)
        val dir = File(ctx.filesDir, "faces").apply { mkdirs() }
        val shots = unique.take(6).map { u ->
            val id = UUID.randomUUID().toString()
            val path = File(dir, "$id.jpg").absolutePath
            FileOutputStream(path).use { u.crop.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            FaceShot(id, m.id, path, u.print, if (u.side >= MIN_FACE_PX) match(people, u.print)?.id else null, false, m.time)
        }
        synchronized(this) { saveFaces(ctx, faces(ctx) + shots) }
        val names = shots.mapNotNull { s -> people.firstOrNull { it.id == s.personId }?.name }.distinct()
        val joined = names.joinToString(", ")
        MemoryStore.modify(ctx, m.id) { fresh ->
            // New names mean the old description doesn't know who is in it: describe it again.
            val again = joined.isNotEmpty() && joined != fresh.people && !fresh.descriptionByUser
            fresh.copy(people = joined, facesScanned = true, analyzed = if (again) false else fresh.analyzed)
        }
    }

    /** The crop every face print is made from (the book uses the same one, so prints are comparable). */
    internal fun cropFace(src: Bitmap, box: Rect): Bitmap? {
        if (box.width() < 40 || box.height() < 40) return null
        val pad = (max(box.width(), box.height()) * 0.18f).toInt()
        val l = max(0, box.left - pad)
        val t = max(0, box.top - pad)
        val r = min(src.width, box.right + pad)
        val b = min(src.height, box.bottom + pad)
        if (r - l < 40 || b - t < 40) return null
        val side = min(r - l, b - t)
        return Bitmap.createBitmap(src, l + (r - l - side) / 2, t + (b - t - side) / 2, side, side)
    }

    // ---------- grouping and naming ----------

    /** Unnamed faces grouped by likeness, biggest groups first. */
    fun unknownGroups(ctx: Context): List<List<FaceShot>> {
        val groups = mutableListOf<MutableList<FaceShot>>()
        for (f in faces(ctx).filter { it.personId == null && !it.ignored }.sortedByDescending { it.time }) {
            val g = groups.firstOrNull { grp -> grp.any { FaceId.dist(it.print, f.print) < GROUP } }
            if (g != null) g.add(f) else groups.add(mutableListOf(f))
        }
        return groups.sortedByDescending { it.size }
    }

    /** Names a group of faces; also finds this person in other unnamed faces right away. */
    @Synchronized
    fun assign(ctx: Context, faceIds: Collection<String>, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        var people = people(ctx)
        var faces = faces(ctx)
        val picked = faces.filter { it.id in faceIds }
        val existing = people.firstOrNull { it.name == clean }
        val person = (existing ?: Person(UUID.randomUUID().toString(), clean, picked.firstOrNull()?.path ?: "", emptyList()))
            .let { p -> p.copy(prints = (p.prints + picked.map { it.print }).takeLast(15)) }
        people = people.filterNot { it.id == person.id } + person
        faces = faces.map { f ->
            when {
                f.id in faceIds -> f.copy(personId = person.id, ignored = false)
                f.personId == null && !f.ignored && person.prints.any { FaceId.dist(it, f.print) < MATCH } -> f.copy(personId = person.id)
                else -> f
            }
        }
        savePeople(ctx, people)
        saveFaces(ctx, faces)
        refreshMemoryNames(ctx)
    }

    @Synchronized
    fun ignore(ctx: Context, faceIds: Collection<String>) {
        saveFaces(ctx, faces(ctx).map { if (it.id in faceIds) it.copy(ignored = true, personId = null) else it })
    }

    @Synchronized
    fun rename(ctx: Context, personId: String, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        savePeople(ctx, people(ctx).map { if (it.id == personId) it.copy(name = clean) else it })
        refreshMemoryNames(ctx)
    }

    @Synchronized
    fun forget(ctx: Context, personId: String) {
        savePeople(ctx, people(ctx).filterNot { it.id == personId })
        saveFaces(ctx, faces(ctx).map { if (it.personId == personId) it.copy(personId = null) else it })
        refreshMemoryNames(ctx)
    }

    /** Writes each moment's list of names from its recognized faces. */
    private fun refreshMemoryNames(ctx: Context) {
        val names = people(ctx).associate { it.id to it.name }
        val byMemory = faces(ctx).groupBy { it.memoryId }
        for (m in MemoryStore.all(ctx)) {
            val list = byMemory[m.id].orEmpty().mapNotNull { f -> f.personId?.let { names[it] } }.distinct().joinToString(", ")
            if (list != m.people) MemoryStore.update(ctx, m.copy(people = list, analyzed = if (list.isNotEmpty() && !m.descriptionByUser) false else m.analyzed))
        }
    }

    fun countFor(ctx: Context, name: String) = MemoryStore.kept(ctx).count { m -> Fmt.names(m).contains(name) }
}
