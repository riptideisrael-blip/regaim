package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * On-device face identity (MobileFaceNet, BSD-3 licensed model, downloaded once ~5MB).
 * Turns a face crop into a 192-number "face print". Nothing leaves the phone.
 */
object FaceId {
    private const val MODEL_URL =
        "https://github.com/MCarlomagno/FaceRecognitionAuth/raw/refs/heads/master/assets/mobilefacenet.tflite"
    private var interpreter: Interpreter? = null

    fun modelFile(ctx: Context) = File(ctx.filesDir, "mobilefacenet.tflite")
    fun ready(ctx: Context) = modelFile(ctx).let { it.exists() && it.length() > 1_000_000 }

    /** Downloads the model once. Background thread only. */
    fun ensureModel(ctx: Context): Boolean {
        if (ready(ctx)) return true
        var url = MODEL_URL
        repeat(5) {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
            }
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    url = conn.getHeaderField("Location") ?: return false
                    return@repeat
                }
                if (code != 200) return false
                val tmp = File(ctx.filesDir, "mobilefacenet.tmp")
                conn.inputStream.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                if (tmp.length() < 1_000_000) {
                    tmp.delete()
                    return false
                }
                tmp.renameTo(modelFile(ctx))
                return true
            } catch (_: Exception) {
                return false
            } finally {
                conn.disconnect()
            }
        }
        return false
    }

    @Synchronized
    fun embed(ctx: Context, face: Bitmap): FloatArray? {
        if (!ready(ctx)) return null
        val interp = interpreter ?: Interpreter(modelFile(ctx), Interpreter.Options().setNumThreads(2)).also { interpreter = it }
        val inShape = interp.getInputTensor(0).shape() // [batch, 112, 112, 3]
        val batch = inShape[0]
        val size = inShape[1]
        val outLen = interp.getOutputTensor(0).shape().last()
        val scaled = Bitmap.createScaledBitmap(face, size, size, true)
        val px = IntArray(size * size)
        scaled.getPixels(px, 0, size, 0, 0, size, size)
        val input = ByteBuffer.allocateDirect(batch * size * size * 3 * 4).order(ByteOrder.nativeOrder())
        repeat(batch) {
            for (p in px) {
                input.putFloat((((p shr 16) and 0xff) - 128f) / 128f)
                input.putFloat((((p shr 8) and 0xff) - 128f) / 128f)
                input.putFloat(((p and 0xff) - 128f) / 128f)
            }
        }
        input.rewind()
        val out = Array(batch) { FloatArray(outLen) }
        interp.run(input, out)
        val v = out[0]
        var norm = 0f
        for (x in v) norm += x * x
        norm = sqrt(norm).coerceAtLeast(1e-6f)
        return FloatArray(v.size) { v[it] / norm }
    }

    fun dist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            s += d * d
        }
        return sqrt(s)
    }
}

data class Person(val id: String, val name: String, val photo: String, val prints: List<FloatArray>)

data class FaceShot(
    val id: String,
    val memoryId: String,
    val path: String,
    val print: FloatArray,
    val personId: String?,
    val ignored: Boolean,
    val time: Long,
)

/** People and faces, Google-Photos style: faces are grouped, you name a group once, the app finds them again. */
object PeopleStore {
    /** Two prints closer than this are treated as the same person (prints are length-1 vectors). */
    const val MATCH = 0.95f
    private const val SAME_IN_CLIP = 0.85f

    fun peopleEnabled(ctx: Context) = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).getBoolean("people_on", true)

    private fun peopleFile(ctx: Context) = File(ctx.filesDir, "people.json")
    private fun facesFile(ctx: Context) = File(ctx.filesDir, "faces.json")

    private fun toJson(a: FloatArray) = JSONArray().also { j -> a.forEach { j.put(it.toDouble()) } }
    private fun fromJson(j: JSONArray) = FloatArray(j.length()) { j.optDouble(it).toFloat() }

    @Synchronized
    fun people(ctx: Context): List<Person> = try {
        val arr = JSONArray(peopleFile(ctx).readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val pr = o.optJSONArray("prints") ?: JSONArray()
            Person(o.optString("id"), o.optString("name"), o.optString("photo"),
                (0 until pr.length()).map { k -> fromJson(pr.getJSONArray(k)) })
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun savePeople(ctx: Context, list: List<Person>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("photo", p.photo)
                .put("prints", JSONArray().also { j -> p.prints.forEach { j.put(toJson(it)) } }))
        }
        peopleFile(ctx).writeText(arr.toString())
    }

    @Synchronized
    fun faces(ctx: Context): List<FaceShot> = try {
        val arr = JSONArray(facesFile(ctx).readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            FaceShot(o.optString("id"), o.optString("memoryId"), o.optString("path"),
                fromJson(o.optJSONArray("print") ?: JSONArray()),
                o.optString("personId").ifEmpty { null }, o.optBoolean("ignored"), o.optLong("time"))
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun saveFaces(ctx: Context, list: List<FaceShot>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("id", f.id).put("memoryId", f.memoryId).put("path", f.path)
                .put("print", toJson(f.print)).put("personId", f.personId ?: "")
                .put("ignored", f.ignored).put("time", f.time))
        }
        facesFile(ctx).writeText(arr.toString())
    }

    fun match(people: List<Person>, print: FloatArray): Person? {
        var best: Person? = null
        var bestD = MATCH
        for (p in people) for (q in p.prints) {
            val d = FaceId.dist(print, q)
            if (d < bestD) {
                bestD = d
                best = p
            }
        }
        return best
    }

    // ---------- scanning moments ----------

    private val scanning = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Finds faces in moments that weren't scanned yet. Background thread only. Returns how many were scanned. */
    fun scanPending(ctx: Context, limit: Int = 8): Int {
        if (!scanning.compareAndSet(false, true)) return 0
        try {
            if (!FaceId.ensureModel(ctx)) return 0
            var n = 0
            for (m in MemoryStore.all(ctx).filter { !it.facesScanned }.take(limit)) {
                scanMemory(ctx, m)
                n++
            }
            return n
        } finally {
            scanning.set(false)
        }
    }

    fun scanMemory(ctx: Context, m: Memory) {
        if (!FaceId.ready(ctx)) return
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setMinFaceSize(0.08f)
                .build()
        )
        class Found(val crop: Bitmap, val print: FloatArray, val area: Int)
        val found = mutableListOf<Found>()
        try {
            for (frame in ComicMaker.framesFromClip(ctx, m, 3)) {
                val faces = try { Tasks.await(detector.process(InputImage.fromBitmap(frame, 0))) } catch (_: Exception) { emptyList() }
                for (f in faces) {
                    val crop = cropFace(frame, f.boundingBox) ?: continue
                    val print = FaceId.embed(ctx, crop) ?: continue
                    found.add(Found(crop, print, f.boundingBox.width() * f.boundingBox.height()))
                }
            }
        } finally {
            detector.close()
        }
        // The same person usually shows up in all 3 frames: keep the biggest shot of each.
        val unique = mutableListOf<Found>()
        for (f in found.sortedByDescending { it.area }) {
            if (unique.none { FaceId.dist(it.print, f.print) < SAME_IN_CLIP }) unique.add(f)
        }
        val people = people(ctx)
        val dir = File(ctx.filesDir, "faces").apply { mkdirs() }
        val shots = unique.take(6).map { u ->
            val id = UUID.randomUUID().toString()
            val path = File(dir, "$id.jpg").absolutePath
            FileOutputStream(path).use { u.crop.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            FaceShot(id, m.id, path, u.print, match(people, u.print)?.id, false, m.time)
        }
        synchronized(this) { saveFaces(ctx, faces(ctx) + shots) }
        val names = shots.mapNotNull { s -> people.firstOrNull { it.id == s.personId }?.name }.distinct()
        val fresh = MemoryStore.get(ctx, m.id) ?: return
        MemoryStore.update(ctx, fresh.copy(people = names.joinToString(", "), facesScanned = true))
    }

    private fun cropFace(src: Bitmap, box: Rect): Bitmap? {
        if (box.width() < 48 || box.height() < 48) return null
        val pad = (max(box.width(), box.height()) * 0.18f).toInt()
        val l = max(0, box.left - pad)
        val t = max(0, box.top - pad)
        val r = min(src.width, box.right + pad)
        val b = min(src.height, box.bottom + pad)
        if (r - l < 40 || b - t < 40) return null
        val side = min(r - l, b - t)
        return Bitmap.createBitmap(src, l + (r - l - side) / 2, t + (b - t - side) / 2, side, side)
    }

    // ---------- grouping and naming ----------

    /** Unnamed faces grouped by likeness, biggest groups first. */
    fun unknownGroups(ctx: Context): List<List<FaceShot>> {
        val groups = mutableListOf<MutableList<FaceShot>>()
        for (f in faces(ctx).filter { it.personId == null && !it.ignored }.sortedByDescending { it.time }) {
            val g = groups.firstOrNull { grp -> grp.any { FaceId.dist(it.print, f.print) < MATCH } }
            if (g != null) g.add(f) else groups.add(mutableListOf(f))
        }
        return groups.sortedByDescending { it.size }
    }

    /** Names a group of faces; also finds this person in other unnamed faces right away. */
    @Synchronized
    fun assign(ctx: Context, faceIds: Collection<String>, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        var people = people(ctx)
        var faces = faces(ctx)
        val picked = faces.filter { it.id in faceIds }
        val existing = people.firstOrNull { it.name == clean }
        val person = (existing ?: Person(UUID.randomUUID().toString(), clean, picked.firstOrNull()?.path ?: "", emptyList()))
            .let { p -> p.copy(prints = (p.prints + picked.map { it.print }).takeLast(15)) }
        people = people.filterNot { it.id == person.id } + person
        faces = faces.map { f ->
            when {
                f.id in faceIds -> f.copy(personId = person.id, ignored = false)
                f.personId == null && !f.ignored && person.prints.any { FaceId.dist(it, f.print) < MATCH } -> f.copy(personId = person.id)
                else -> f
            }
        }
        savePeople(ctx, people)
        saveFaces(ctx, faces)
        refreshMemoryNames(ctx)
    }

    @Synchronized
    fun ignore(ctx: Context, faceIds: Collection<String>) {
        saveFaces(ctx, faces(ctx).map { if (it.id in faceIds) it.copy(ignored = true, personId = null) else it })
    }

    @Synchronized
    fun rename(ctx: Context, personId: String, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        savePeople(ctx, people(ctx).map { if (it.id == personId) it.copy(name = clean) else it })
        refreshMemoryNames(ctx)
    }

    @Synchronized
    fun forget(ctx: Context, personId: String) {
        savePeople(ctx, people(ctx).filterNot { it.id == personId })
        saveFaces(ctx, faces(ctx).map { if (it.personId == personId) it.copy(personId = null) else it })
        refreshMemoryNames(ctx)
    }

    /** Writes each moment's list of names from its recognized faces. */
    private fun refreshMemoryNames(ctx: Context) {
        val names = people(ctx).associate { it.id to it.name }
        val byMemory = faces(ctx).groupBy { it.memoryId }
        for (m in MemoryStore.all(ctx)) {
            val list = byMemory[m.id].orEmpty().mapNotNull { f -> f.personId?.let { names[it] } }.distinct().joinToString(", ")
            if (list != m.people) MemoryStore.update(ctx, m.copy(people = list))
        }
    }

    fun countFor(ctx: Context, name: String) = MemoryStore.all(ctx).count { m -> m.people.split(", ").contains(name) }
}
