package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/**
 * On-device face identity (MobileFaceNet, BSD-3 licensed model, downloaded once ~5MB).
 * Turns a face crop into a 192-number "face print". Nothing leaves the phone.
 */
object FaceId {
    /**
     * Pinned to the exact commit and checked by SHA-256: if the file at this address is ever changed or swapped,
     * the app refuses it instead of running an unknown model. The file hasn't changed since 2020 (commit 010f0ee).
     */
    private const val MODEL_URL =
        "https://github.com/MCarlomagno/FaceRecognitionAuth/raw/010f0ee203ddf008665e6ea202118fe9aeb28ad5/assets/mobilefacenet.tflite"
    const val MODEL_SHA256 = "be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854"
    private const val MODEL_BYTES = 5_233_552L
    private var interpreter: Interpreter? = null
    @Volatile private var checked = false

    /** The model failed to load (damaged file): it was deleted and will be downloaded again. */
    class ModelBroken(cause: Throwable) : Exception(cause)

    fun modelFile(ctx: Context) = File(ctx.filesDir, "mobilefacenet.tflite")
    fun ready(ctx: Context) = modelFile(ctx).let { it.exists() && it.length() > 1_000_000 }

    private fun sha256(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return FacePrints.hex(md.digest())
    }

    /** Downloads the model once and checks it's the expected file. Background thread only. */
    @Synchronized
    fun ensureModel(ctx: Context): Boolean {
        val f = modelFile(ctx)
        if (ready(ctx)) {
            if (checked) return true
            if (try { sha256(f) == MODEL_SHA256 } catch (_: Exception) { false }) {
                checked = true
                return true
            }
            // Not the expected model: never use it. Faces read with it must be read again with the right one.
            close()
            f.delete()
            ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).edit().putBoolean("faces_reprint", true).apply()
        }
        var url = MODEL_URL
        repeat(5) {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
            }
            val tmp = File(ctx.filesDir, "mobilefacenet.tmp")
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    url = conn.getHeaderField("Location") ?: return false
                    if (!url.startsWith("https://")) return false
                    return@repeat
                }
                if (code != 200) return false
                conn.inputStream.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                if (tmp.length() != MODEL_BYTES || sha256(tmp) != MODEL_SHA256) {
                    tmp.delete()
                    return false
                }
                if (!tmp.renameTo(f)) {
                    tmp.delete()
                    return false
                }
                checked = true
                return true
            } catch (_: Exception) {
                tmp.delete()
                return false
            } finally {
                conn.disconnect()
            }
        }
        return false
    }

    @Synchronized
    private fun close() {
        try { interpreter?.close() } catch (_: Exception) { }
        interpreter = null
    }

    @Synchronized
    fun embed(ctx: Context, face: Bitmap): FloatArray? {
        if (!ready(ctx)) return null
        val interp = interpreter ?: try {
            Interpreter(modelFile(ctx), Interpreter.Options().setNumThreads(2)).also { interpreter = it }
        } catch (e: Exception) {
            // A damaged model file: delete it, so the next run downloads a good one, instead of every moment failing.
            modelFile(ctx).delete()
            checked = false
            throw ModelBroken(e)
        }
        val inShape = interp.getInputTensor(0).shape() // [batch, 112, 112, 3]
        val batch = inShape[0]
        val size = inShape[1]
        val outLen = interp.getOutputTensor(0).shape().last()
        val scaled = Bitmap.createScaledBitmap(face, size, size, true)
        val px = IntArray(size * size)
        scaled.getPixels(px, 0, size, 0, 0, size, size)
        val input = ByteBuffer.allocateDirect(batch * size * size * 3 * 4).order(ByteOrder.nativeOrder())
        repeat(batch) {
            for (p in px) {
                input.putFloat((((p shr 16) and 0xff) - 128f) / 128f)
                input.putFloat((((p shr 8) and 0xff) - 128f) / 128f)
                input.putFloat(((p and 0xff) - 128f) / 128f)
            }
        }
        input.rewind()
        val out = Array(batch) { FloatArray(outLen) }
        interp.run(input, out)
        return FacePrints.normalize(out[0])
    }

    /** Damaged prints (wrong length, NaN) never count as close. */
    fun dist(a: FloatArray, b: FloatArray): Float = FacePrints.dist(a, b)
}

data class Person(val id: String, val name: String, val photo: String, val prints: List<FloatArray>)

data class FaceShot(
    val id: String,
    val memoryId: String,
    val path: String,
    val print: FloatArray,
    val personId: String?,
    val ignored: Boolean,
    val time: Long,
)

/** People and faces, Google-Photos style: faces are grouped, you name a group once, the app finds them again. */
object PeopleStore {
    /**
     * Two prints closer than this are treated as the same person (prints are length-1 vectors).
     * Was 0.95: too loose for young siblings and small, blurry chest-camera faces, so almost every
     * child ended up tagged as the same kid.
     */
    const val MATCH = 0.82f
    /** "Who's this?" groups: a little looser than MATCH, but no longer lumping different kids together. */
    private const val GROUP = 0.86f
    /** The best person must win clearly over the second best, else the face stays unnamed. */
    private const val MARGIN = 0.06f
    /** Faces smaller than this (pixels) are kept but never named automatically: too little detail. */
    private const val MIN_FACE_PX = 72
    private const val SAME_IN_CLIP = 0.85f

    fun peopleEnabled(ctx: Context) = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE).getBoolean("people_on", true)

    private fun peopleFile(ctx: Context) = File(ctx.filesDir, "people.json")
    private fun facesFile(ctx: Context) = File(ctx.filesDir, "faces.json")

    private fun toJson(a: FloatArray) = JSONArray().also { j -> a.forEach { j.put(it.toDouble()) } }
    private fun fromJson(j: JSONArray) = FloatArray(j.length()) { j.optDouble(it).toFloat() }

    @Synchronized
    fun people(ctx: Context): List<Person> = try {
        val arr = JSONArray(SecureFiles.readText(peopleFile(ctx)) ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val pr = o.optJSONArray("prints") ?: JSONArray()
            Person(o.optString("id"), o.optString("name"), o.optString("photo"),
                (0 until pr.length()).map { k -> fromJson(pr.getJSONArray(k)) })
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun savePeople(ctx: Context, list: List<Person>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("photo", p.photo)
                .put("prints", JSONArray().also { j -> p.prints.forEach { j.put(toJson(it)) } }))
        }
        SecureFiles.writeText(peopleFile(ctx), arr.toString()) // encrypted on the phone
    }

    @Synchronized
    fun faces(ctx: Context): List<FaceShot> = try {
        val arr = JSONArray(SecureFiles.readText(facesFile(ctx)) ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            FaceShot(o.optString("id"), o.optString("memoryId"), o.optString("path"),
                fromJson(o.optJSONArray("print") ?: JSONArray()),
                o.optString("personId").ifEmpty { null }, o.optBoolean("ignored"), o.optLong("time"))
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    private fun saveFaces(ctx: Context, list: List<FaceShot>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("id", f.id).put("memoryId", f.memoryId).put("path", f.path)
                .put("print", toJson(f.print)).put("personId", f.personId ?: "")
                .put("ignored", f.ignored).put("time", f.time))
        }
        SecureFiles.writeText(facesFile(ctx), arr.toString()) // encrypted on the phone
    }

    fun match(people: List<Person>, print: FloatArray): Person? {
        var best: Person? = null
        var bestD = Float.MAX_VALUE
        var second = Float.MAX_VALUE
        for (p in people) {
            val d = p.prints.minOfOrNull { FaceId.dist(print, it) } ?: continue
            if (d < bestD) { second = bestD; bestD = d; best = p } else if (d < second) second = d
        }
        if (best == null || bestD >= MATCH) return null
        // Two family members almost equally close (siblings): don't guess.
        if (bestD > 0.05f && second - bestD < MARGIN) return null
        return best
    }

    /**
     * Once, after the stricter rules: look again at every face that was named automatically.
     * Faces the family named by hand (their print is one of the person's own prints) stay as they are.
     */
    private fun rematchOnce(ctx: Context) {
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        if (prefs.getBoolean("faces_rules_v2", false)) return
        synchronized(this) {
            val people = people(ctx)
            saveFaces(ctx, faces(ctx).map { f ->
                val pid = f.personId ?: return@map f
                val own = people.firstOrNull { it.id == pid }
                val byHand = own?.prints?.any { FaceId.dist(it, f.print) < 0.05f } == true
                if (byHand) f else f.copy(personId = match(people, f.print)?.id)
            })
        }
        refreshMemoryNames(ctx)
        prefs.edit().putBoolean("faces_rules_v2", true).apply()
    }

    // ---------- scanning moments ----------

    private val scanning = java.util.concurrent.atomic.AtomicBoolean(false)
    /** Moments that failed in this run of the app: tried again on a later run, not again and again now. */
    private val failedThisRun = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    private fun triesPrefs(ctx: Context) = ctx.getSharedPreferences("face_scan_tries", Context.MODE_PRIVATE)

    /**
     * Finds faces in moments that weren't scanned yet. Background thread only. Returns how many were scanned.
     * A moment that can't be read right now (not downloaded from Google Photos yet, out of memory...) is tried
     * again on later runs; only after [ScanTries.MAX] failed runs is it marked as done without faces.
     */
    fun scanPending(ctx: Context, limit: Int = 8): Int {
        if (!scanning.compareAndSet(false, true)) return 0
        try {
            if (!FaceId.ensureModel(ctx)) return 0
            try { reprintIfNeeded(ctx) } catch (_: Exception) {}
            try { sealOnce(ctx) } catch (_: Exception) {}
            try { enrollFamily(ctx) } catch (_: Exception) {}
            try { mergeDuplicates(ctx) } catch (_: Exception) {}
            try { rematchOnce(ctx) } catch (_: Exception) {}
            val tp = triesPrefs(ctx)
            val tries = tp.all.mapNotNull { (k, v) -> (v as? Int)?.let { k to it } }.toMap()
            val todo = MemoryStore.all(ctx).filter { !it.facesScanned }
            val order = ScanTries.order(todo.map { it.id to it.time }, tries, failedThisRun.toSet())
            val byId = todo.associateBy { it.id }
            var n = 0
            for (id in order.take(limit)) {
                val m = byId[id] ?: continue
                val ok = try {
                    scanMemory(ctx, m)
                } catch (e: FaceId.ModelBroken) {
                    return n // not this moment's fault: stop, the model is downloaded again next time
                } catch (e: Throwable) {
                    tp.edit().putString("why_$id", (e.javaClass.simpleName + ": " + e.message.orEmpty()).take(200)).apply()
                    false
                }
                if (ok) {
                    if (tries.containsKey(id)) tp.edit().remove(id).remove("why_$id").apply()
                } else {
                    failedThisRun.add(id)
                    val t = (tries[id] ?: 0) + 1
                    if (ScanTries.giveUp(t)) {
                        // Still unreadable after several runs (deleted from the gallery...): stop trying.
                        MemoryStore.modify(ctx, id) { it.copy(facesScanned = true) }
                        tp.edit().remove(id).apply()
                    } else tp.edit().putInt(id, t).apply()
                }
                n++
            }
            return n
        } finally {
            scanning.set(false)
        }
    }

    /** Once: face data saved before encryption existed is saved again, encrypted (see [SecureFiles]). */
    private fun sealOnce(ctx: Context) {
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        if (prefs.getBoolean("faces_sealed", false)) return
        synchronized(this) {
            // Only files that were actually read: an unreadable file is never replaced by an empty one.
            if (peopleFile(ctx).exists()) { val p = people(ctx); if (p.isNotEmpty()) savePeople(ctx, p) }
            if (facesFile(ctx).exists()) { val f = faces(ctx); if (f.isNotEmpty()) saveFaces(ctx, f) }
        }
        prefs.edit().putBoolean("faces_sealed", true).apply()
    }

    /**
     * The face model was replaced (the old file wasn't the expected one): every saved face is read again with the
     * new model, and each person is remembered again from their named faces and their profile photo.
     */
    private fun reprintIfNeeded(ctx: Context) {
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("faces_reprint", false)) return
        synchronized(this) {
            val fresh = faces(ctx).mapNotNull { f ->
                val bmp = try { android.graphics.BitmapFactory.decodeFile(f.path) } catch (_: Throwable) { null } ?: return@mapNotNull null
                FaceId.embed(ctx, bmp)?.let { f.copy(print = it) }
            }
            saveFaces(ctx, fresh)
            val byPerson = fresh.filter { it.personId != null }.groupBy { it.personId }
            savePeople(ctx, people(ctx).map { p -> p.copy(prints = FacePrints.typical(byPerson[p.id].orEmpty().map { it.print }, 15)) })
        }
        prefs.edit().remove("enrolled_family").putBoolean("faces_reprint", false).apply()
    }

    /**
     * Family members with a profile photo become known people right away, so nobody has to name their
     * faces by hand first. Runs once per member photo. Background thread only.
     */
    fun enrollFamily(ctx: Context) {
        if (!FaceId.ready(ctx)) return
        val prefs = ctx.getSharedPreferences("regaim", Context.MODE_PRIVATE)
        val done = prefs.getStringSet("enrolled_family", emptySet())?.toMutableSet() ?: mutableSetOf()
        var changed = false
        for (member in Profile.members(ctx)) {
            if (member.photo.isEmpty() || member.isPet) continue
            val key = "${member.name.trim()}|${member.photo}"
            if (key in done) continue
            val bmp = try { android.graphics.BitmapFactory.decodeFile(member.photo)?.let { downscale(it, 1280) } } catch (_: Exception) { null }
            if (bmp == null) { done.add(key); continue }
            val detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setMinFaceSize(0.1f).build()
            )
            val print = try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                val biggest = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                biggest?.let { cropFace(bmp, it.boundingBox) }?.let { FaceId.embed(ctx, it) }
            } catch (_: Exception) { null } finally { detector.close() }
            done.add(key)
            if (print == null) continue
            synchronized(this) {
                val people = people(ctx)
                val name = member.name.trim()
                val existing = people.firstOrNull { it.name == name }
                val person = (existing ?: Person(UUID.randomUUID().toString(), name, member.photo, emptyList()))
                    .let { it.copy(prints = (it.prints + print).takeLast(15)) }
                val updated = people.filterNot { it.id == person.id } + person
                savePeople(ctx, updated)
                // Same rule as everywhere: a face that is almost as close to a sibling isn't guessed.
                saveFaces(ctx, faces(ctx).map { f ->
                    if (f.personId == null && !f.ignored && match(updated, f.print)?.id == person.id) f.copy(personId = person.id) else f
                })
            }
            changed = true
        }
        prefs.edit().putStringSet("enrolled_family", done).apply()
        if (changed) refreshMemoryNames(ctx)
    }

    private fun downscale(b: Bitmap, limit: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= limit) return b
        val f = limit.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    /** Looks again, more carefully, for the people in one moment, then lets the AI describe it again. */
    fun rescan(ctx: Context, m: Memory) {
        if (!FaceId.ensureModel(ctx)) return
        enrollFamily(ctx)
        synchronized(this) { saveFaces(ctx, faces(ctx).filterNot { it.memoryId == m.id }) }
        scanMemory(ctx, MemoryStore.get(ctx, m.id) ?: m, frames = 8)
    }

    /** Returns false when the moment couldn't be read at all (no frame came out of it): it's tried again later. */
    fun scanMemory(ctx: Context, m: Memory, frames: Int = 5): Boolean {
        if (!FaceId.ready(ctx)) return false
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setMinFaceSize(0.08f)
                .build()
        )
        class Found(val crop: Bitmap, val print: FloatArray, val area: Int, val side: Int)
        val found = mutableListOf<Found>()
        try {
            val pics = ComicMaker.framesFromClip(ctx, m, frames)
            if (pics.isEmpty()) return false
            for (frame in pics) {
                val faces = try { Tasks.await(detector.process(InputImage.fromBitmap(frame, 0))) } catch (_: Exception) { emptyList() }
                for (f in faces) {
                    val crop = cropFace(frame, f.boundingBox) ?: continue
                    val print = FaceId.embed(ctx, crop) ?: continue
                    found.add(Found(crop, print, f.boundingBox.width() * f.boundingBox.height(), minOf(f.boundingBox.width(), f.boundingBox.height())))
                }
            }
        } finally {
            detector.close()
        }
        // The same person usually shows up in all 3 frames: keep the biggest shot of each.
        val unique = mutableListOf<Found>()
        for (f in found.sortedByDescending { it.area }) {
            if (unique.none { FaceId.dist(it.print, f.print) < SAME_IN_CLIP }) unique.add(f)
        }
        val people = people(ctx)
        val dir = File(ctx.filesDir, "faces").apply { mkdirs() }
        val shots = unique.take(6).map { u ->
            val id = UUID.randomUUID().toString()
            val path = File(dir, "$id.jpg").absolutePath
            FileOutputStream(path).use { u.crop.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            FaceShot(id, m.id, path, u.print, if (u.side >= MIN_FACE_PX) match(people, u.print)?.id else null, false, m.time)
        }
        synchronized(this) { saveFaces(ctx, faces(ctx) + shots) }
        val names = shots.mapNotNull { s -> people.firstOrNull { it.id == s.personId }?.name }.distinct()
        val joined = names.joinToString(", ")
        MemoryStore.modify(ctx, m.id) { fresh ->
            // New names mean the old description doesn't know who is in it: describe it again.
            val again = joined.isNotEmpty() && joined != fresh.people && !fresh.descriptionByUser
            fresh.copy(people = joined, facesScanned = true, analyzed = if (again) false else fresh.analyzed)
        }
        return true
    }

    /** The crop every face print is made from (the book uses the same one, so prints are comparable). */
    internal fun cropFace(src: Bitmap, box: Rect): Bitmap? {
        if (box.width() < 40 || box.height() < 40) return null
        val pad = (max(box.width(), box.height()) * 0.18f).toInt()
        val l = max(0, box.left - pad)
        val t = max(0, box.top - pad)
        val r = min(src.width, box.right + pad)
        val b = min(src.height, box.bottom + pad)
        if (r - l < 40 || b - t < 40) return null
        val side = min(r - l, b - t)
        return Bitmap.createBitmap(src, l + (r - l - side) / 2, t + (b - t - side) / 2, side, side)
    }

    // ---------- grouping and naming ----------

    /** Unnamed faces grouped by likeness, biggest groups first. */
    fun unknownGroups(ctx: Context): List<List<FaceShot>> {
        val groups = mutableListOf<MutableList<FaceShot>>()
        for (f in faces(ctx).filter { it.personId == null && !it.ignored }.sortedByDescending { it.time }) {
            // Joins the group it is closest to on average, not any group with one look-alike in it: one
            // in-between face no longer chains two siblings into one group.
            val g = groups.map { grp -> grp to grp.take(12).map { FaceId.dist(it.print, f.print) }.average() }
                .filter { it.second < GROUP }
                .minByOrNull { it.second }?.first
            if (g != null) g.add(f) else groups.add(mutableListOf(f))
        }
        return groups.sortedByDescending { it.size }
    }

    /** Names a group of faces; also finds this person in other unnamed faces right away. */
    @Synchronized
    fun assign(ctx: Context, faceIds: Collection<String>, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        var people = people(ctx)
        var faces = faces(ctx)
        val picked = faces.filter { it.id in faceIds }
        val existing = people.firstOrNull { it.name == clean }
        // All the picked faces get the name; only the most typical of them teach the app the face, and none
        // that looks more like someone else the family already named.
        val others = people.filterNot { it.id == existing?.id }
        val teach = FacePrints.typical(picked.map { it.print }.filter { match(others, it) == null }, 6)
        val person = (existing ?: Person(UUID.randomUUID().toString(), clean, picked.firstOrNull()?.path ?: "", emptyList()))
            .let { p -> p.copy(prints = (p.prints + teach).takeLast(15)) }
        people = people.filterNot { it.id == person.id } + person
        faces = faces.map { f ->
            when {
                f.id in faceIds -> f.copy(personId = person.id, ignored = false)
                f.personId == null && !f.ignored && match(people, f.print)?.id == person.id -> f.copy(personId = person.id)
                else -> f
            }
        }
        savePeople(ctx, people)
        saveFaces(ctx, faces)
        refreshMemoryNames(ctx)
    }

    @Synchronized
    fun ignore(ctx: Context, faceIds: Collection<String>) {
        saveFaces(ctx, faces(ctx).map { if (it.id in faceIds) it.copy(ignored = true, personId = null) else it })
    }

    /** Renames a person; if someone already has that name, the two become one person (no duplicates). */
    @Synchronized
    fun rename(ctx: Context, personId: String, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val other = people(ctx).firstOrNull { it.id != personId && it.name.trim() == clean }
        if (other != null) { merge(ctx, personId, other.id); return }
        savePeople(ctx, people(ctx).map { if (it.id == personId) it.copy(name = clean) else it })
        refreshMemoryNames(ctx)
    }

    /** Two entries that are the same person (e.g. "יוסף" and "אני (יוסף)"): faces and samples move to [intoId]. */
    @Synchronized
    fun merge(ctx: Context, fromId: String, intoId: String) {
        if (fromId == intoId) return
        val people = people(ctx)
        val from = people.firstOrNull { it.id == fromId } ?: return
        val into = people.firstOrNull { it.id == intoId } ?: return
        val joined = into.copy(prints = (into.prints + from.prints).takeLast(15), photo = into.photo.ifBlank { from.photo })
        savePeople(ctx, people.filterNot { it.id == fromId || it.id == intoId } + joined)
        saveFaces(ctx, faces(ctx).map { if (it.personId == fromId) it.copy(personId = intoId) else it })
        refreshMemoryNames(ctx)
    }

    /**
     * Cleans up names that mean the same person: "אני" / "אני (יוסף)" become the parent's own name, and two
     * people with exactly the same name become one. Safe to run any time. Background thread only.
     */
    @Synchronized
    fun mergeDuplicates(ctx: Context) {
        val self = Profile.parentName(ctx).trim()
        val alias = Regex("^(אני|me)\\s*[(（]\\s*(.+?)\\s*[)）]$", RegexOption.IGNORE_CASE)
        var changed = true
        var guard = 0
        while (changed && guard++ < 20) {
            changed = false
            val people = people(ctx)
            for (p in people) {
                val n = p.name.trim()
                val target = alias.find(n)?.groupValues?.get(2)?.trim()
                    ?: if ((n == "אני" || n.equals("me", true)) && self.isNotEmpty()) self else null
                if (target != null && target != n) {
                    val into = people.firstOrNull { it.id != p.id && it.name.trim() == target }
                    if (into != null) merge(ctx, p.id, into.id) else rename(ctx, p.id, target)
                    changed = true; break
                }
                val twin = people.firstOrNull { it.id != p.id && it.name.trim() == n }
                if (twin != null) { merge(ctx, twin.id, p.id); changed = true; break }
            }
        }
    }

    @Synchronized
    fun forget(ctx: Context, personId: String) {
        savePeople(ctx, people(ctx).filterNot { it.id == personId })
        saveFaces(ctx, faces(ctx).map { if (it.personId == personId) it.copy(personId = null) else it })
        refreshMemoryNames(ctx)
    }

    /** Writes each moment's list of names from its recognized faces. */
    private fun refreshMemoryNames(ctx: Context) {
        val names = people(ctx).associate { it.id to it.name }
        val byMemory = faces(ctx).groupBy { it.memoryId }
        fun listFor(id: String) = byMemory[id].orEmpty().mapNotNull { f -> f.personId?.let { names[it] } }.distinct().joinToString(", ")
        val changed = MemoryStore.all(ctx).filter { listFor(it.id) != it.people }.map { it.id }.toSet()
        // One write for all moments (was one full rewrite of the index per moment), on the fresh copy of each.
        MemoryStore.updateMany(ctx, changed) { fresh ->
            val list = listFor(fresh.id)
            if (list == fresh.people) fresh
            else fresh.copy(people = list, analyzed = if (list.isNotEmpty() && !fresh.descriptionByUser) false else fresh.analyzed)
        }
    }

    fun countFor(ctx: Context, name: String) = MemoryStore.kept(ctx).count { m -> Fmt.names(m).contains(name) }
}
