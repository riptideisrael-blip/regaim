package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

/** One saved moment ("memory bubble"). */
data class Memory(
    val id: String,
    val uri: String,
    val name: String,
    val time: Long,
    val label: String,
    val lat: Double?,
    val lon: Double?,
    val place: String,
    val thumb: String,
    val durationMs: Long,
    val description: String = "",
    val tags: String = "",
    val analyzed: Boolean = false,
    val title: String = "",
    val category: String = "",
    val milestone: String = "",
    val favorite: Boolean = false,
    /** Saved on purpose by the user (button / code word). */
    val chosen: Boolean = false,
    /** AI's guess why this moment matters to the user. */
    val reason: String = "",
    /** AI's 1-10 guess how much this fits what the user likes to keep. */
    val score: Int = 0,
    /** Names of recognized people, e.g. "אורי, אמא" (face recognition on the phone). */
    val people: String = "",
    val facesScanned: Boolean = false,
    /** You asked Moments not to learn from this moment. */
    val noLearn: Boolean = false,
    /** Names you added by hand (", "), and names you removed from face recognition. */
    val extraPeople: String = "",
    val hiddenPeople: String = "",
    /** Where in the clip the moment itself happened (the laugh, the word), in ms; -1 = unknown (use the middle). */
    val highlightMs: Long = -1,
) {
    /** Everyone in the moment: recognized faces + names you added − names you removed. */
    val allPeople: String get() {
        fun split(s: String) = s.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val hidden = split(hiddenPeople).toSet()
        return (split(people) + split(extraPeople)).filter { it !in hidden }.distinct().joinToString(", ")
    }

    /** The heart of the clip: the moment of the laugh / word, or the middle. */
    val highlight: Long get() = if (highlightMs in 0..durationMs) highlightMs else durationMs / 2

    /** Day key like 2026-10-05, used to group memories by day. */
    val dayKey: String get() = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(time))

    /** Short title for cards: AI title, else the sound that triggered it. */
    val displayTitle: String get() = title.ifBlank { Labels.he(label) }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("uri", uri); put("name", name); put("time", time); put("label", label)
        if (lat != null) put("lat", lat)
        if (lon != null) put("lon", lon)
        put("place", place); put("thumb", thumb); put("durationMs", durationMs)
        put("description", description); put("tags", tags); put("analyzed", analyzed)
        put("title", title); put("category", category); put("milestone", milestone); put("favorite", favorite)
        put("chosen", chosen); put("reason", reason); put("score", score)
        put("people", people); put("facesScanned", facesScanned); put("noLearn", noLearn)
        put("extraPeople", extraPeople); put("hiddenPeople", hiddenPeople); put("highlightMs", highlightMs)
    }

    companion object {
        fun fromJson(o: JSONObject) = Memory(
            id = o.optString("id"),
            uri = o.optString("uri"),
            name = o.optString("name"),
            time = o.optLong("time"),
            label = o.optString("label"),
            lat = if (o.has("lat")) o.optDouble("lat") else null,
            lon = if (o.has("lon")) o.optDouble("lon") else null,
            place = o.optString("place"),
            thumb = o.optString("thumb"),
            durationMs = o.optLong("durationMs"),
            description = o.optString("description"),
            tags = o.optString("tags"),
            analyzed = o.optBoolean("analyzed"),
            title = o.optString("title"),
            category = o.optString("category"),
            milestone = o.optString("milestone"),
            favorite = o.optBoolean("favorite"),
            chosen = o.optBoolean("chosen"),
            reason = o.optString("reason"),
            score = o.optInt("score"),
            people = o.optString("people"),
            facesScanned = o.optBoolean("facesScanned"),
            noLearn = o.optBoolean("noLearn"),
            extraPeople = o.optString("extraPeople"),
            hiddenPeople = o.optString("hiddenPeople"),
            highlightMs = o.optLong("highlightMs", -1),
        )
    }
}

/** Local index of all moments, stored as JSON inside the app. Nothing leaves the phone. */
object MemoryStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "memories.json")

    @Synchronized
    fun all(ctx: Context): List<Memory> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { Memory.fromJson(arr.getJSONObject(it)) }.sortedByDescending { it.time }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun add(ctx: Context, m: Memory) = write(ctx, all(ctx) + m)

    @Synchronized
    fun update(ctx: Context, m: Memory) = write(ctx, all(ctx).map { if (it.id == m.id) m else it })

    /** Describes every moment that wasn't analyzed yet. Background thread only. Returns how many succeeded. */
    private val analyzing = java.util.concurrent.atomic.AtomicBoolean(false)

    fun analyzePending(ctx: Context): Int {
        // Recognize faces first, so the AI can use the people's names.
        try { if (PeopleStore.peopleEnabled(ctx)) PeopleStore.scanPending(ctx) } catch (_: Exception) {}
        if (!ClaudeClient.hasKey(ctx)) return 0
        if (!analyzing.compareAndSet(false, true)) return 0
        try {
            return analyzeAll(ctx)
        } finally {
            analyzing.set(false)
        }
    }

    private fun analyzeAll(ctx: Context): Int {
        var done = 0
        for (m in all(ctx).filter { !it.analyzed }) {
            try {
                update(ctx, ClaudeClient.analyze(ctx, m))
                done++
            } catch (e: ClaudeClient.ApiException) {
                Status.error = "ניתוח AI: ${e.message}"
                break
            } catch (_: Exception) {
            }
        }
        if (done > 0) refreshTaste(ctx)
        return done
    }

    fun get(ctx: Context, id: String): Memory? = all(ctx).firstOrNull { it.id == id }

    // ---------- day stories ("סיפור היום") ----------

    private fun storiesFile(ctx: Context) = File(ctx.filesDir, "stories.json")

    @Synchronized
    fun story(ctx: Context, dayKey: String): String {
        val f = storiesFile(ctx)
        if (!f.exists()) return ""
        return try { JSONObject(f.readText()).optJSONObject(dayKey)?.optString("text") ?: "" } catch (_: Exception) { "" }
    }

    @Synchronized
    private fun storyCount(ctx: Context, dayKey: String): Int {
        val f = storiesFile(ctx)
        if (!f.exists()) return -1
        return try { JSONObject(f.readText()).optJSONObject(dayKey)?.optInt("count", -1) ?: -1 } catch (_: Exception) { -1 }
    }

    @Synchronized
    private fun saveStory(ctx: Context, dayKey: String, text: String, count: Int) {
        val f = storiesFile(ctx)
        val root = try { if (f.exists()) JSONObject(f.readText()) else JSONObject() } catch (_: Exception) { JSONObject() }
        root.put(dayKey, JSONObject().put("text", text).put("count", count))
        f.writeText(root.toString())
    }

    /** Writes or refreshes the story of each day whose moments changed. Background thread only. */
    fun refreshStories(ctx: Context, maxDays: Int = 7): Boolean {
        if (!ClaudeClient.hasKey(ctx)) return false
        var changed = false
        val byDay = all(ctx).filter { it.analyzed }.groupBy { it.dayKey }.toList().sortedByDescending { it.first }.take(maxDays)
        for ((day, items) in byDay) {
            if (items.size < 2 || storyCount(ctx, day) == items.size) continue
            try {
                saveStory(ctx, day, ClaudeClient.dayStory(ctx, items.sortedBy { it.time }), items.size)
                changed = true
            } catch (_: Exception) {
                break
            }
        }
        return changed
    }

    // ---------- learning what the user likes (see Learning.kt) ----------

    fun taste(ctx: Context): String = Learning.tasteText(ctx)

    fun refreshTaste(ctx: Context, force: Boolean = false): Boolean = Learning.refresh(ctx, force)

    @Synchronized
    fun remove(ctx: Context, id: String) {
        val list = all(ctx)
        list.firstOrNull { it.id == id }?.let { Learning.rememberRejected(ctx, it) }
        list.firstOrNull { it.id == id }?.let { File(it.thumb).delete() }
        write(ctx, list.filterNot { it.id == id })
    }

    private fun write(ctx: Context, list: List<Memory>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(ctx.filesDir, "memories.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file(ctx))
    }

    /** Crops a frame into a round "bubble" and saves it as PNG. Returns the path. */
    fun saveBubble(ctx: Context, id: String, frame: Bitmap, sizePx: Int = 320): String {
        val side = min(frame.width, frame.height)
        val square = Bitmap.createBitmap(frame, (frame.width - side) / 2, (frame.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, sizePx, sizePx, true)
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val r = sizePx / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(r, r, r - 6f, paint)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 8f
            color = Color.parseColor("#5B4FE0")
        }
        canvas.drawCircle(r, r, r - 6f, ring)

        val dir = File(ctx.filesDir, "bubbles").apply { mkdirs() }
        val f = File(dir, "$id.png")
        FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f.absolutePath
    }
}
