package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Pitzki's side of the app: which child, how the child looks (from what the family already has), the family's own
 * photos for each color, and the forest scenes drawn with the child in them (kept on the phone, per child).
 */
object PitzkiStore {
    /** A child from the family profile, with what Pitzki can show of them. */
    class Child(val memberId: String, val kid: PitzkiKid, val look: Look?, val birth: String = "", val photos: List<File> = emptyList())

    /**
     * How the child looks: [file] is a picture on the phone. [drawn] = an approved character from a book
     * (already a drawing); otherwise a real photo (profile picture or the face the app learned).
     */
    class Look(val file: File, val drawn: Boolean) {
        /** Changes when the picture changes, so the scenes are drawn again for the new look. */
        val key: String get() = "${file.absolutePath}:${file.length()}:${file.lastModified()}"
    }

    fun children(ctx: Context): List<Child> = Profile.members(ctx).filter { it.isChild && it.name.isNotBlank() }.map { m ->
        Child(m.id, PitzkiKid(PitzkiScript.firstName(m.name), girl = m.relation == "ילדה"), look(ctx, m), m.birth, photos(ctx, m))
    }

    /** Real photos of the child the family already has (profile picture, the face the app learned), up to 3. */
    private fun photos(ctx: Context, m: FamilyMember): List<File> {
        val out = ArrayList<File>()
        m.photo.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }?.let { out.add(it) }
        PeopleStore.people(ctx).filter { it.name.trim() == m.name.trim() }.mapNotNull { p -> p.photo.takeIf { it.isNotBlank() }?.let { File(it) } }
            .filter { it.exists() && out.none { o -> o.absolutePath == it.absolutePath } }.forEach { out.add(it) }
        return out.take(3)
    }

    private fun look(ctx: Context, m: FamilyMember): Look? {
        CharacterStore.latest(ctx, m.id)?.let { c -> CharacterStore.file(ctx, c).takeIf { it.exists() }?.let { return Look(it, drawn = true) } }
        m.photo.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        PeopleStore.people(ctx).firstOrNull { it.name.trim() == m.name.trim() }?.photo?.takeIf { it.isNotBlank() }
            ?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        return null
    }

    // ---------- bundled art ----------

    /** Pitzki's own art, in the app (assets/pitzki): "pitzki" (whole body), "face", "forest" (the wide scene). */
    fun art(ctx: Context, name: String): Bitmap? = try {
        ctx.assets.open("pitzki/$name.jpg").use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    /** A recorded line, if one was added to the app (assets/pitzki/voice/<id>.mp3). */
    fun hasRecording(ctx: Context, id: String): Boolean = try {
        ctx.assets.openFd("pitzki/voice/$id.mp3").close(); true
    } catch (_: Exception) { false }

    // ---------- progress ----------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("pitzki", Context.MODE_PRIVATE)
    fun stars(ctx: Context, member: String) = prefs(ctx).getInt("stars_$member", 0)
    fun addStars(ctx: Context, member: String, n: Int) = prefs(ctx).edit().putInt("stars_$member", stars(ctx, member) + n).apply()
    /** The parent's choice: Pitzki listens to the child's answers (microphone). On unless the parent turned it off. */
    fun listenOn(ctx: Context) = prefs(ctx).getBoolean("listen_on", true)
    fun setListen(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("listen_on", on).apply()
    /** The little cloud that explains the microphone button: shown once. */
    fun micTipShown(ctx: Context) = prefs(ctx).getBoolean("mic_tip", false)
    fun setMicTipShown(ctx: Context) = prefs(ctx).edit().putBoolean("mic_tip", true).apply()
    fun lessonsDone(ctx: Context, member: String) = prefs(ctx).getInt("done_$member", 0)
    fun markDone(ctx: Context, member: String) = prefs(ctx).edit().putInt("done_$member", lessonsDone(ctx, member) + 1).apply()

    // ---------- forest scenes drawn with the child ----------

    private fun dir(ctx: Context, member: String) = File(File(ctx.filesDir, "pitzki"), member.filter { it.isLetterOrDigit() || it == '-' || it == '_' }).apply { mkdirs() }
    fun sceneFile(ctx: Context, member: String, key: String) = File(dir(ctx, member).also { migrate(it) }, "scene_$key.jpg")
    private fun meta(ctx: Context, member: String) = File(dir(ctx, member), "scenes.json")
    /** A scene come to life (a few seconds of animation of the drawn scene: Pitzki and the child move). */
    fun clipFile(ctx: Context, member: String, key: String) = File(dir(ctx, member).also { migrate(it) }, "clip_$key.mp4")

    /** The first version named scenes by number (1–8); they keep their drawing and animation under their name. */
    private val OLD = listOf("intro", "walk", "green", "brown", "red", "yellow", "gray", "end")
    private fun migrate(d: File) {
        if (!File(d, "scene_1.jpg").exists() && !File(d, "clip_1.mp4").exists()) return
        OLD.forEachIndexed { i, key ->
            for ((from, to) in listOf("scene_${i + 1}.jpg" to "scene_$key.jpg", "clip_${i + 1}.mp4" to "clip_$key.mp4")) {
                val f = File(d, from)
                if (f.exists()) { val t = File(d, to); if (!t.exists()) f.renameTo(t) else f.delete() }
            }
        }
    }

    /** How many scenes of the child's film move (their own, or Pitzki's shared close-ups). */
    fun clips(ctx: Context, c: Child): Int =
        if (!scenesReady(ctx, c)) 0 else PitzkiScript.KEYS.count { clipFor(ctx, c.memberId, it) != null }

    /**
     * The picture of a scene for this child: their own drawing when there is one (the child is in it), otherwise
     * Pitzki's shared close-up (the same for every family). Null: neither yet (the lesson shows the forest).
     */
    fun sceneFor(ctx: Context, member: String?, key: String): File? {
        if (member != null) sceneFile(ctx, member, key).takeIf { it.exists() }?.let { return it }
        return sharedScene(ctx, key).takeIf { it.exists() && it.length() > 0 }
    }

    /** The animation that goes with [sceneFor] (never a shared clip over the family's own drawing). */
    fun clipFor(ctx: Context, member: String?, key: String): File? {
        if (member != null && sceneFile(ctx, member, key).exists()) return clipFile(ctx, member, key).takeIf { it.exists() && it.length() > 0 }
        if (!sharedScene(ctx, key).exists()) return null
        return sharedClip(ctx, key).takeIf { it.exists() && it.length() > 0 }
    }

    /** The look the saved scenes were drawn from, or "". */
    private fun drawnFrom(ctx: Context, member: String): String = when (val r = SafeFiles.readObject(meta(ctx, member))) {
        is SafeFiles.Read.Ok -> r.value.optString("look")
        else -> ""
    }

    /** The parent said this look (the book's character, or a new one) is their child, for the film. */
    fun lookConfirmed(ctx: Context, c: Child): Boolean = c.look != null && prefs(ctx).getString("look_ok_${c.memberId}", "") == c.look.key
    fun confirmLook(ctx: Context, c: Child) { c.look?.let { prefs(ctx).edit().putString("look_ok_${c.memberId}", it.key).apply() } }

    /** Once: the opening scene's animation made before the warmer high-five opening is made again. */
    fun upgrade(ctx: Context) {
        if (prefs(ctx).getInt("intro_motion_v", 1) >= 2) return
        try { File(ctx.filesDir, "pitzki").listFiles()?.filter { it.isDirectory && it.name != "shared" }?.forEach { File(it, "clip_intro.mp4").delete() } } catch (_: Exception) {}
        prefs(ctx).edit().putInt("intro_motion_v", 2).apply()
    }

    /** Scenes of the child's own that are drawn but don't move yet. */
    fun needsAnimation(ctx: Context, c: Child): Boolean =
        scenesReady(ctx, c) && PitzkiScript.KEYS.any { sceneFile(ctx, c.memberId, it).exists() && !clipFile(ctx, c.memberId, it).exists() }

    /** The scenes the child is in are drawn, from the child's current look (the close-ups are Pitzki's, shared). */
    fun scenesReady(ctx: Context, c: Child): Boolean {
        val look = c.look ?: return false
        return drawnFrom(ctx, c.memberId) == look.key && PitzkiScript.CHILD_KEYS.all { sceneFile(ctx, c.memberId, it).exists() }
    }

    /** How many scenes are already drawn from the child's current look (when the lesson grew, some are missing). */
    fun partial(ctx: Context, c: Child): Int {
        val look = c.look ?: return 0
        if (drawnFrom(ctx, c.memberId) != look.key) return 0
        return PitzkiScript.CHILD_KEYS.count { sceneFile(ctx, c.memberId, it).exists() }
    }

    /** Scenes exist but from an older look (a new character was approved since). */
    fun scenesOutdated(ctx: Context, c: Child): Boolean =
        c.look != null && drawnFrom(ctx, c.memberId).isNotEmpty() && drawnFrom(ctx, c.memberId) != c.look.key

    /** Deletes the child's drawn scenes (the lesson goes back to the circle look). */
    fun deleteScenes(ctx: Context, member: String) {
        PitzkiScript.KEYS.forEach { sceneFile(ctx, member, it).delete(); clipFile(ctx, member, it).delete() }
        meta(ctx, member).delete()
        pendingFile(ctx, member).delete()
    }

    /** What's being drawn right now (one child at a time), for the screen to show. */
    class Drawing(val member: String, @Volatile var done: Int = 0, @Volatile var failed: String = "", @Volatile var finished: Boolean = false) {
        /** "draw" (the 8 pictures), then "anim" (bringing them to life). */
        @Volatile var phase = "draw"
        @Volatile var animated = 0
        /** How many scenes this run draws / animates (for the progress bar). */
        @Volatile var total = 0
        /** What's happening right now, when it's worth saying (a retry, an error from the server). */
        @Volatile var note = ""
    }

    @Volatile var drawing: Drawing? = null
        private set
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /**
     * Draws the 8 forest scenes with the child (8 pictures through Moments' server). Keeps going if the screen is
     * left; scenes already drawn from the same look are kept, so a stop in the middle continues where it was.
     * False if a drawing is already running.
     */
    fun drawScenes(ctx: Context, c: Child, animate: Boolean = false): Boolean {
        val look = c.look ?: return false
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing(c.memberId)
        drawing = d
        worker.execute {
            try {
                if (drawnFrom(app, c.memberId) != look.key) {
                    deleteScenes(app, c.memberId)
                    SafeFiles.write(meta(app, c.memberId), JSONObject().put("look", look.key).put("started", System.currentTimeMillis()).toString())
                }
                val pitzki = art(app, "pitzki") ?: throw IllegalStateException(L.t("חסרה התמונה של פיצקי באפליקציה", "Pitzki's picture is missing from the app"))
                val child = BitmapFactory.decodeFile(look.file.absolutePath) ?: throw IllegalStateException(L.t("לא הצלחנו לפתוח את התמונה של ${c.kid.name}", "Couldn't open ${c.kid.name}'s picture"))
                // A drawn character keeps the style; a real photo next to it keeps the face (the likeness).
                val photo: Bitmap? = if (look.drawn) c.photos.firstOrNull()?.let { BitmapFactory.decodeFile(it.absolutePath) } else null
                var first: Bitmap? = if (sceneFile(app, c.memberId, "intro").exists()) BitmapFactory.decodeFile(sceneFile(app, c.memberId, "intro").absolutePath) else null
                d.total = PitzkiScript.CHILD_KEYS.size
                for ((i, n) in PitzkiScript.CHILD_KEYS.withIndex()) {
                    val f = sceneFile(app, c.memberId, n)
                    if (f.exists()) { d.done = i + 1; continue }
                    val useFirst = first != null && n != "intro"
                    val refs = listOfNotNull(pitzki, child, first.takeIf { useFirst }, photo)
                    val img = GeminiClient.scene(app, prompt(n, c, useFirst, photo != null), refs)
                        ?: throw IllegalStateException(L.t("הציור לא הצליח (סצנה $n). אפשר לנסות שוב: מה שכבר צויר נשמר.", "The drawing didn't work (scene $n). Try again: what's drawn is kept."))
                    val out = java.io.ByteArrayOutputStream()
                    img.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    if (!SafeFiles.writeBytes(f, out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
                    if (n == "intro") first = img
                    d.done = i + 1
                }
                if (animate) {
                    d.phase = "anim"
                    animateScenes(app, c, d)
                }
            } catch (e: Exception) {
                d.failed = friendly(e, L.t("הציור לא הצליח", "The drawing didn't work"))
            } finally {
                d.finished = true
            }
        }
        return true
    }

    private class Edge(val url: String, val token: String)

    /**
     * Brings the drawn scenes to life (5 seconds each, through the same service as the 3D films: one film credit
     * for the whole lesson). Scenes already animated are kept. If not a single scene came to life, the credit
     * is given back.
     */
    private fun animateScenes(app: Context, c: Child, d: Drawing) {
        if (c.look == null) return
        // Every scene with the child's own drawing gets its own animation (the close-ups are shared).
        val todo = PitzkiScript.KEYS.filter { sceneFile(app, c.memberId, it).exists() && !clipFile(app, c.memberId, it).exists() }
        animateAll(app, d, todo, creditRef(c), c.memberId, { sceneFile(app, c.memberId, it) }, { clipFile(app, c.memberId, it) }, ::motion)
    }

    /**
     * Brings [todo] scenes to life (one film credit, [ref]): all are sent at once, then collected. [store] names
     * where the ones already sent are remembered (so closing the app doesn't send — and pay — them again).
     */
    private fun animateAll(
        app: Context, d: Drawing, todo: List<String>, ref: String, store: String,
        picture: (String) -> File, clip: (String) -> File, motionOf: (String) -> String,
    ) {
        val ed = edge(app)
        d.animated = 0
        d.total = todo.size
        if (todo.isEmpty()) { pendingFile(app, store).delete(); return }
        // Scenes already sent (the app was closed while they were being animated): collected, not sent (and paid) again.
        val sent = pending(app, store).filterKeys { it in todo }
        if (todo.any { it !in sent }) reserve(app, ed, ref)
        var made = 0
        var lastError = ""
        // "pitzki_anim": lively, 10-second motion (walking, talking, expressions). A server not updated yet doesn't
        // know it: then the gentler 5-second "book_anim" is used, so the film still gets made.
        var kind = "pitzki_anim"
        // All scenes are sent first, so the service animates them at the same time (a few minutes in all, not
        // a few minutes each); then each one is collected as it's ready.
        val jobs = ArrayList<Triple<String, String, String>>()
        sent.forEach { (n, j) -> jobs.add(Triple(n, j.first, j.second)) }
        for (n in todo.filter { it !in sent }) {
            try {
                val bmp = BitmapFactory.decodeFile(picture(n).absolutePath) ?: continue
                val image = CartoonFilm.dataUri(bmp)
                fun submit(k: String) = CartoonFilm.callEdge(ed.url, ed.token, mapOf(
                    "action" to "submit", "kind" to k, "duration" to "10", "image" to image, "scene" to motionOf(n)))
                var job = submit(kind)
                if (kind == "pitzki_anim" && job.optInt("_code", 200) == 400 && job.optString("error").contains("לא מוכרת")) {
                    kind = "book_anim"
                    job = submit(kind)
                }
                // The animation service itself refused (its account ran out of balance, or blocked us): sending the
                // other scenes would only fail the same way, and use up the credit's calls.
                val refusal = (job.optString("error") + " " + job.optString("detail")).lowercase()
                if (job.optInt("_code", 200) == 502 && ("balance" in refusal || "locked" in refusal || ", 403" in refusal || ", 401" in refusal)) {
                    lastError = L.t("שירות ההנפשה (fal) חסום כרגע: נגמרה היתרה בחשבון. צריך להטעין אותו ב-fal.ai ואז ללחוץ שוב.",
                        "The animation service (fal) is blocked right now: its account balance ran out. Top it up at fal.ai, then tap again.")
                    break
                }
                CartoonFilm.checkError(job)
                jobs.add(Triple(n, job.optString("status_url"), job.optString("response_url")))
                savePending(app, store, jobs)
            } catch (e: CartoonFilm.FatalEdgeError) {
                lastError = friendly(e, "")
                break
            } catch (e: Exception) {
                lastError = friendly(e, "")
            }
        }
        // Collected together, every few seconds, with a fresh sign-in each time (a long wait can outlast the old one).
        val left = jobs.toMutableList()
        var errors = 0
        val until = System.currentTimeMillis() + 20 * 60_000L
        while (left.isNotEmpty() && System.currentTimeMillis() < until) {
            Thread.sleep(6000)
            val iter = left.iterator()
            while (iter.hasNext()) {
                val (n, status, response) = iter.next()
                val token = Account.token(app)
                if (token == null) { errors++; d.note = L.t("החיבור לחשבון נותק, מנסים שוב…", "Signed out, trying again…"); continue }
                val res = try {
                    CartoonFilm.callEdge(ed.url, token, mapOf("action" to "poll", "status_url" to status, "response_url" to response))
                } catch (e: Exception) { errors++; d.note = L.t("אין חיבור לרשת, מנסים שוב…", "No connection, trying again…"); continue }
                val code = res.optInt("_code", 200)
                if (code !in 200..299) {
                    errors++
                    d.note = L.t("השרת השיב שגיאה ($code)", "The server answered an error ($code)") + res.optString("error").let { if (it.isBlank()) "" else ": ${it.take(80)}" }
                    if (errors > 30) { lastError = d.note; left.clear(); break }
                    continue
                }
                when (res.optString("status", "PENDING")) {
                    "DONE" -> {
                        iter.remove()
                        if (download(res.optString("url"), clip(n))) { made++; d.animated = d.animated + 1 }
                        else lastError = L.t("ההורדה של סצנה $n נכשלה", "Downloading scene $n failed")
                    }
                    "FAILED" -> { iter.remove(); lastError = res.optString("detail").take(160) }
                    else -> d.note = ""
                }
            }
        }
        if (left.isNotEmpty() && lastError.isBlank()) lastError = L.t("ההנפשה לקחה יותר מדי זמן", "The animation took too long")
        pendingFile(app, store).delete()
        if (made == 0) {
            try { CartoonFilm.callEdge(ed.url, ed.token, mapOf("action" to "refund", "ref" to ref)) } catch (_: Exception) {}
            throw IllegalStateException(if (lastError.startsWith(L.t("אין חיבור", "No internet")) || lastError.startsWith(L.t("שירות ההנפשה", "The animation service"))) lastError
                else L.t("ההנפשה לא הצליחה", "The animation didn't work") + if (lastError.isBlank()) "" else ": ${lastError.take(120)}")
        }
        if (made < todo.size) d.failed = L.t("$made מתוך ${todo.size} סצנות קמו לחיים. אפשר לנסות שוב את השאר.", "$made of ${todo.size} scenes came to life. You can try the rest again.")
    }

    /**
     * The film credit of one making session: the child's character and the film's animation within the same
     * hours share one credit (the server keeps a reserved credit for 3 hours).
     */
    private fun creditRef(c: Child) = "pitzki-" + c.memberId.filter { it.isLetterOrDigit() }.take(24) + "-" +
        java.text.SimpleDateFormat("yyyyMMddHH", java.util.Locale.US).format(java.util.Date()).let { it.dropLast(2) + (it.takeLast(2).toInt() / 3) }

    private fun edge(app: Context) = Edge(Circle.url(app) + "/functions/v1/cartoon-film",
        Account.token(app) ?: throw IllegalStateException(L.t("צריך להתחבר לחשבון", "Please sign in")))

    private fun reserve(app: Context, e: Edge, ref: String) {
        val res = CartoonFilm.callEdge(e.url, e.token, mapOf("action" to "reserve", "ref" to ref, "again" to true))
        if (res.optInt("_code", 200) !in 200..299 || !res.optBoolean("ok", false)) {
            throw IllegalStateException(res.optString("error", "").ifBlank { L.t("אין קרדיט לסרט כרגע", "No film credit right now") }
                .let { if (it == "expired") L.t("נסו שוב", "Try again") else it })
        }
    }

    // ---------- the child's character (for the best likeness) ----------

    /** A character drawn from the child's photos, waiting for the parent's OK. */
    fun candidate(ctx: Context, member: String) = File(dir(ctx, member), "character_candidate.jpg")

    /**
     * Draws the child as an animated character from their real photos, with the same model the children's books use
     * (it keeps likeness best). The parent approves it; then it's the child's character everywhere (books too).
     */
    fun makeCharacter(ctx: Context, c: Child): Boolean {
        if (c.photos.isEmpty()) return false
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing(c.memberId).apply { phase = "character" }
        drawing = d
        worker.execute {
            try {
                val ed = edge(app)
                reserve(app, ed, creditRef(c))
                val uris = c.photos.mapNotNull { f -> BitmapFactory.decodeFile(f.absolutePath)?.let { CartoonFilm.dataUri(it) } }
                if (uris.isEmpty()) throw IllegalStateException(L.t("לא הצלחנו לפתוח את התמונות של ${c.kid.name}", "Couldn't open ${c.kid.name}'s photos"))
                val job = CartoonFilm.callEdge(ed.url, ed.token, mapOf(
                    "action" to "submit", "kind" to "book_character", "image" to uris.first(), "refs" to org.json.JSONArray(uris.drop(1)),
                    "age" to BookJson.ageDesc(Profile.ageMonths(c.birth), c.kid.girl), "aspect" to "3:4",
                    "outfit" to "comfortable everyday clothes in soft, friendly colors"))
                CartoonFilm.checkError(job)
                val url = CartoonFilm.pollEdge(ed.url, ed.token, job.optString("status_url"), job.optString("response_url"), java.util.concurrent.atomic.AtomicBoolean(false))
                val bmp = (if (url.isEmpty()) null else CartoonFilm.downloadBitmap(url))
                    ?: throw IllegalStateException(L.t("הדמות לא צוירה", "The character wasn't drawn") + CartoonFilm.lastJobDetail.let { if (it.isBlank()) "" else ": $it" })
                val out = java.io.ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
                if (!SafeFiles.writeBytes(candidate(app, c.memberId), out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
            } catch (e: Exception) {
                d.failed = friendly(e, L.t("הדמות לא צוירה", "The character wasn't drawn"))
            } finally {
                d.finished = true
            }
        }
        return true
    }

    /** The parent said "that's my child": it becomes the child's character (Pitzki's film and the books use it). */
    fun approveCharacter(ctx: Context, c: Child): Boolean {
        val f = candidate(ctx, c.memberId)
        if (!f.exists()) return false
        val ok = CharacterStore.save(ctx, c.memberId, c.kid.name, f, "pitzki")
        if (ok) f.delete()
        return ok
    }

    // ---------- Pitzki's close-ups: made once, the same for every family ----------

    /** Bump when the close-ups are made again, so phones fetch the new ones. */
    private const val SHARED_V = "v1"
    private fun sharedDir(ctx: Context) = File(File(ctx.filesDir, "pitzki"), "shared").apply { mkdirs() }
    fun sharedScene(ctx: Context, key: String) = File(sharedDir(ctx), "$key.jpg")
    fun sharedClip(ctx: Context, key: String) = File(sharedDir(ctx), "$key.mp4")
    val SHARED_KEYS: List<String> get() = PitzkiScript.KEYS - PitzkiScript.CHILD_KEYS.toSet()
    private fun sharedUrl(ctx: Context, name: String) = Circle.url(ctx) + "/storage/v1/object/public/pitzki-shared/$SHARED_V/$name"

    /** How many close-ups this phone has, and how many of them move. */
    fun sharedReady(ctx: Context): Pair<Int, Int> =
        SHARED_KEYS.count { sharedScene(ctx, it).exists() } to SHARED_KEYS.count { sharedClip(ctx, it).exists() }

    @Volatile private var fetching = false

    /** Background thread only. Downloads the close-ups this phone doesn't have yet (quietly: missing ones stay missing). */
    fun fetchShared(ctx: Context) {
        if (fetching) return
        fetching = true
        try {
            for (key in SHARED_KEYS) for ((name, f) in listOf("$key.jpg" to sharedScene(ctx, key), "$key.mp4" to sharedClip(ctx, key))) {
                if (!f.exists()) download(sharedUrl(ctx, name), f)
            }
        } finally { fetching = false }
    }

    /**
     * The admin makes Pitzki's close-ups once (drawn, animated, and put on the server for every family): only the
     * missing ones, so a stop in the middle continues. Uses one film credit for the animations.
     */
    fun buildShared(ctx: Context): Boolean {
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing("shared")
        drawing = d
        worker.execute {
            try {
                fetchShared(app) // what's on the server already isn't made again
                val pitzki = art(app, "pitzki") ?: throw IllegalStateException(L.t("חסרה התמונה של פיצקי באפליקציה", "Pitzki's picture is missing from the app"))
                var style: Bitmap? = SHARED_KEYS.map { sharedScene(app, it) }.firstOrNull { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
                val missing = SHARED_KEYS.filter { !sharedScene(app, it).exists() }
                d.total = missing.size
                for (key in missing) {
                    val img = GeminiClient.scene(app, sharedPrompt(key, style != null), listOfNotNull(pitzki, style))
                        ?: throw IllegalStateException(L.t("הציור לא הצליח ($key). אפשר לנסות שוב: מה שכבר צויר נשמר.", "The drawing didn't work ($key). Try again: what's drawn is kept."))
                    val out = java.io.ByteArrayOutputStream()
                    img.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    upload(app, "$key.jpg", out.toByteArray(), "image/jpeg")
                    if (!SafeFiles.writeBytes(sharedScene(app, key), out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
                    if (style == null) style = img
                    d.done = d.done + 1
                }
                d.phase = "anim"
                val todo = SHARED_KEYS.filter { sharedScene(app, it).exists() && !sharedClip(app, it).exists() }
                val ref = "pitzki-shared-" + java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
                animateAll(app, d, todo, ref, "shared", { sharedScene(app, it) }, { sharedClip(app, it) }, ::sharedMotion)
                for (key in SHARED_KEYS) {
                    val f = sharedClip(app, key)
                    if (f.exists() && f.length() > 0) upload(app, "$key.mp4", f.readBytes(), "video/mp4")
                }
            } catch (e: Exception) {
                d.failed = friendly(e, L.t("הסצנות המשותפות לא נוצרו", "The shared scenes weren't made"))
            } finally {
                d.finished = true
            }
        }
        return true
    }

    /** Puts one close-up on the server (only the admin may: see server/pitzki-shared-scenes.sql). */
    private fun upload(ctx: Context, name: String, bytes: ByteArray, type: String) {
        val token = Account.token(ctx) ?: throw IllegalStateException(L.t("צריך להתחבר לחשבון", "Please sign in"))
        val conn = java.net.URL(Circle.url(ctx) + "/storage/v1/object/pitzki-shared/$SHARED_V/$name").openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30_000
            conn.readTimeout = 120_000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("apikey", Circle.key(ctx))
            conn.setRequestProperty("Content-Type", type)
            conn.setRequestProperty("x-upsert", "true")
            conn.outputStream.use { it.write(bytes) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val why = try { conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty().take(120) } catch (_: Exception) { "" }
                throw IllegalStateException(L.t("ההעלאה לשרת לא הצליחה ($code). צריך להריץ פעם אחת את pitzki-shared-scenes.sql ב-Supabase.", "Uploading to the server failed ($code). Run pitzki-shared-scenes.sql once in Supabase.") + if (why.isBlank()) "" else " $why")
            }
        } finally { conn.disconnect() }
    }

    /** A close-up: Pitzki alone with the thing, big and in focus. */
    private fun sharedPrompt(key: String, withStyle: Boolean): String {
        if (key == "song2") return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. " +
            (if (withStyle) "The second image is an earlier scene of the same film: same style, same forest, same light. " else "") +
            "Scene: Pitzki dances happily along a flowery forest path, mid-jump with his arms up, singing, fireflies and flowers around him. " +
            "Only Pitzki: no child, no other people. No text, no letters, no music notes, no speech bubbles, no watermark, no borders."
        if (key == "song") return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. " +
            (if (withStyle) "The second image is an earlier scene of the same film: same style, same forest, same light. " else "") +
            "Scene: Pitzki stands on a mossy tree stump in a sunny forest clearing, singing joyfully to the viewer with open arms, " +
            "butterflies and tiny birds around him. Only Pitzki: no child, no other people. " +
            "No text, no letters, no music notes, no speech bubbles, no watermark, no borders."
        val c = PColor.values().first { it.name.lowercase() == key }
        return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition, close-up. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. " +
            (if (withStyle) "The second image is an earlier scene of the same film: same style, same forest, same light. " else "") +
            "Scene: a close-up of ${c.enThing}, big, sharp and in the center, its color vivid and unmistakable; Pitzki is beside it, " +
            "pointing at it with a delighted face. Only Pitzki: no child, no other people. Soft blurred forest background, warm sunlight. " +
            "No text, no letters, no speech bubbles, no watermark, no borders."
    }

    private fun sharedMotion(key: String): String {
        if (key == "song2") return "Pitzki sings and dances along the flowery path: he hops between the flowers, skips, spins around, " +
            "jumps with joy and waves to the camera, mouth moving with the song. Lively, joyful, the camera follows him. Only Pitzki, no other people."
        if (key == "song") return "Pitzki sings happily to the camera, mouth moving with the song, dancing on the tree stump: he sways, " +
            "taps his foot, spreads his arms, tips his hat and bows; butterflies fly around him. Lively, joyful, smooth camera. Only Pitzki, no other people."
        val c = PColor.values().first { it.name.lowercase() == key }
        return "Close-up: ${c.enMotion}. Pitzki points at it, looks at the camera with an excited, delighted face and talks, " +
            "as if telling the child about it. Slow cinematic camera push-in. Only Pitzki, no other people."
    }

    // ---------- scenes being animated (kept on the phone, so closing the app doesn't lose them) ----------

    private fun pendingFile(ctx: Context, member: String) = File(dir(ctx, member), "animating.json")

    /** Scenes sent for animation in the last hour (the service keeps results for an hour): scene → (status, result). */
    private fun pending(ctx: Context, member: String): Map<String, Pair<String, String>> {
        val o = ((SafeFiles.readObject(pendingFile(ctx, member)) as? SafeFiles.Read.Ok<*>)?.value as? JSONObject) ?: return emptyMap()
        if (System.currentTimeMillis() - o.optLong("at") > 55 * 60_000L) return emptyMap()
        val out = HashMap<String, Pair<String, String>>()
        val arr = o.optJSONArray("jobs") ?: return emptyMap()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { j ->
            // "k": the scene's name; "n": its number in the first version.
            val key = j.optString("k").ifEmpty { OLD.getOrNull(j.optInt("n") - 1).orEmpty() }
            if (key.isNotEmpty() && j.optString("status").isNotEmpty()) out[key] = j.optString("status") to j.optString("response")
        }
        return out
    }

    private fun savePending(ctx: Context, member: String, jobs: List<Triple<String, String, String>>) {
        val old = ((SafeFiles.readObject(pendingFile(ctx, member)) as? SafeFiles.Read.Ok<*>)?.value as? JSONObject)?.optLong("at") ?: 0L
        val at = if (old > 0 && System.currentTimeMillis() - old < 55 * 60_000L) old else System.currentTimeMillis()
        val arr = org.json.JSONArray()
        jobs.forEach { (n, st, rs) -> arr.put(JSONObject().put("k", n).put("status", st).put("response", rs)) }
        SafeFiles.write(pendingFile(ctx, member), JSONObject().put("at", at).put("jobs", arr).toString())
    }

    /** Animation was cut off (the app was closed): true if it can be picked up again without paying again. */
    fun interrupted(ctx: Context, c: Child): Boolean =
        drawing?.finished != false && scenesReady(ctx, c) && pending(ctx, c.memberId).isNotEmpty()

    /** Picks up an animation cut off by closing the app (collects what was already sent). */
    fun resume(ctx: Context, c: Child): Boolean = if (interrupted(ctx, c)) drawScenes(ctx, c, animate = true) else false

    private fun download(url: String, to: File): Boolean = try {
        val tmp = File(to.parentFile, to.name + ".part")
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 90_000
        try { conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } } } finally { conn.disconnect() }
        tmp.length() > 0 && tmp.renameTo(to)
    } catch (_: Exception) { false }

    /** What moves in each scene: Pitzki and the child walk and act together, like a film. */
    private fun motion(key: String): String {
        val c = PColor.values().firstOrNull { it.name.lowercase() == key }
        return when {
            key == "intro" -> "Pitzki walks up to the child and stops right in front of them, looking at the child the whole time with a warm smile. " +
                "They wave hello, then give each other a happy high-five, and Pitzki talks to the child warmly; the child laughs and answers. " +
                "Pitzki never turns away or walks past the child."
            key == "walk2" -> "Pitzki and the child walk deeper into the magical forest, hand in hand, laughing and looking around; fireflies glow and the camera follows them."
            key == "walk" -> "Pitzki and the child walk side by side along the forest path, talking and looking around; Pitzki points at the trees and the child turns to look, amazed. The camera tracks with them as they walk."
            c != null -> "Pitzki points at ${c.enThing} and talks to the child about it; the child's face lights up with surprise, the child points at it too and says the word with a happy smile."
            else -> "Pitzki and the child jump with joy and high-five, then wave goodbye together and walk away side by side down the path into warm golden light."
        }
    }

    /** One scene's drawing instructions. Pitzki is the first picture, the child the second, scene 1 the third. */
    private fun prompt(n: String, c: Child, withFirst: Boolean, withPhoto: Boolean = false): String {
        val who = if (c.kid.girl) "a little girl" else "a little boy"
        val childRef = if (c.look?.drawn == true)
            "The second image is the child, $who: an existing animated character. Keep exactly the same face, hair, skin tone, age and clothes."
        else
            "The second image is a real photo of the child, $who. Turn the child into the same soft 3D animated style as Pitzki, keeping them recognizable: same face shape, hair color and style, skin tone and age."
        val color = PColor.values().firstOrNull { it.name.lowercase() == n }
        val action = when {
            n == "intro" -> "Pitzki and the child stand facing each other on a sunny magical forest path, smiling at each other, each raising a hand for a high-five."
            n == "walk" -> "Pitzki and the child walk together along the forest path, looking around with curiosity."
            n == "walk2" -> "Pitzki and the child walk hand in hand deeper into the magical forest, with glowing fireflies and a little pond ahead."
            color != null -> "Pitzki and the child find ${color.enThing}; Pitzki points at it and the child looks at it, delighted. It is clearly visible and its color is vivid."
            else -> "Pitzki and the child wave goodbye together on the forest path in warm golden evening light."
        }
        return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. $childRef " +
            (if (withFirst) "The third image is an earlier scene of the same film: same characters, same style, same forest. " else "") +
            (if (withPhoto) "The last image is a real photo of the same child: use it only for the face, so the drawn child clearly looks like this child " +
                "(face shape, eyes, nose, smile, hair color and curls), still in the animated style. " else "") +
            "Scene: $action Both characters fully visible, the same height scale, gentle happy expressions, slow calm mood, " +
            "soft warm sunlight, lush friendly forest. No text, no letters, no speech bubbles, no watermark, no borders."
    }

    /** Runs [f] on the main thread. */
    fun onMain(f: () -> Unit) = main.post(f)
}
