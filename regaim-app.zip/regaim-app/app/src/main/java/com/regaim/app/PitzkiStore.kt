package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Pitzki's side of the app: which child, how the child looks (from what the family already has), the family's own
 * photos for each color, and the forest scenes drawn with the child in them (kept on the phone, per child).
 */
object PitzkiStore {
    /** A child from the family profile, with what Pitzki can show of them. */
    class Child(val memberId: String, val kid: PitzkiKid, val look: Look?, val birth: String = "", val photos: List<File> = emptyList())

    /**
     * How the child looks: [file] is a picture on the phone. [drawn] = an approved character from a book
     * (already a drawing); otherwise a real photo (profile picture or the face the app learned).
     */
    class Look(val file: File, val drawn: Boolean) {
        /** Changes when the picture changes, so the scenes are drawn again for the new look. */
        val key: String get() = "${file.absolutePath}:${file.length()}:${file.lastModified()}"
    }

    fun children(ctx: Context): List<Child> = Profile.members(ctx).filter { it.isChild && it.name.isNotBlank() }.map { m ->
        Child(m.id, PitzkiKid(m.name.trim(), girl = m.relation == "ילדה"), look(ctx, m), m.birth, photos(ctx, m))
    }

    /** Real photos of the child the family already has (profile picture, the face the app learned), up to 3. */
    private fun photos(ctx: Context, m: FamilyMember): List<File> {
        val out = ArrayList<File>()
        m.photo.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }?.let { out.add(it) }
        PeopleStore.people(ctx).filter { it.name.trim() == m.name.trim() }.mapNotNull { p -> p.photo.takeIf { it.isNotBlank() }?.let { File(it) } }
            .filter { it.exists() && out.none { o -> o.absolutePath == it.absolutePath } }.forEach { out.add(it) }
        return out.take(3)
    }

    private fun look(ctx: Context, m: FamilyMember): Look? {
        CharacterStore.latest(ctx, m.id)?.let { c -> CharacterStore.file(ctx, c).takeIf { it.exists() }?.let { return Look(it, drawn = true) } }
        m.photo.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        PeopleStore.people(ctx).firstOrNull { it.name.trim() == m.name.trim() }?.photo?.takeIf { it.isNotBlank() }
            ?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        return null
    }

    // ---------- bundled art ----------

    /** Pitzki's own art, in the app (assets/pitzki): "pitzki" (whole body), "face", "forest" (the wide scene). */
    fun art(ctx: Context, name: String): Bitmap? = try {
        ctx.assets.open("pitzki/$name.jpg").use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    /** A recorded line, if one was added to the app (assets/pitzki/voice/<id>.mp3). */
    fun hasRecording(ctx: Context, id: String): Boolean = try {
        ctx.assets.openFd("pitzki/voice/$id.mp3").close(); true
    } catch (_: Exception) { false }

    // ---------- progress ----------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("pitzki", Context.MODE_PRIVATE)
    fun stars(ctx: Context, member: String) = prefs(ctx).getInt("stars_$member", 0)
    fun addStars(ctx: Context, member: String, n: Int) = prefs(ctx).edit().putInt("stars_$member", stars(ctx, member) + n).apply()
    fun lessonsDone(ctx: Context, member: String) = prefs(ctx).getInt("done_$member", 0)
    fun markDone(ctx: Context, member: String) = prefs(ctx).edit().putInt("done_$member", lessonsDone(ctx, member) + 1).apply()

    // ---------- forest scenes drawn with the child ----------

    private fun dir(ctx: Context, member: String) = File(File(ctx.filesDir, "pitzki"), member.filter { it.isLetterOrDigit() || it == '-' || it == '_' }).apply { mkdirs() }
    fun sceneFile(ctx: Context, member: String, n: Int) = File(dir(ctx, member), "scene_$n.jpg")
    private fun meta(ctx: Context, member: String) = File(dir(ctx, member), "scenes.json")
    /** A scene come to life (a few seconds of animation of the drawn scene: Pitzki and the child move). */
    fun clipFile(ctx: Context, member: String, n: Int) = File(dir(ctx, member), "clip_$n.mp4")

    /** How many scenes are animated (0 = none: the lesson shows the drawn scenes still, with a slow zoom). */
    fun clips(ctx: Context, c: Child): Int =
        if (!scenesReady(ctx, c)) 0 else (1..PitzkiScript.SCENES).count { clipFile(ctx, c.memberId, it).let { f -> f.exists() && f.length() > 0 } }

    /** The look the saved scenes were drawn from, or "". */
    private fun drawnFrom(ctx: Context, member: String): String = when (val r = SafeFiles.readObject(meta(ctx, member))) {
        is SafeFiles.Read.Ok -> r.value.optString("look")
        else -> ""
    }

    /** All 8 scenes are drawn, from the child's current look. */
    fun scenesReady(ctx: Context, c: Child): Boolean {
        val look = c.look ?: return false
        return drawnFrom(ctx, c.memberId) == look.key && (1..PitzkiScript.SCENES).all { sceneFile(ctx, c.memberId, it).exists() }
    }

    /** Scenes exist but from an older look (a new character was approved since). */
    fun scenesOutdated(ctx: Context, c: Child): Boolean =
        c.look != null && drawnFrom(ctx, c.memberId).isNotEmpty() && drawnFrom(ctx, c.memberId) != c.look.key

    /** Deletes the child's drawn scenes (the lesson goes back to the circle look). */
    fun deleteScenes(ctx: Context, member: String) {
        (1..PitzkiScript.SCENES).forEach { sceneFile(ctx, member, it).delete(); clipFile(ctx, member, it).delete() }
        meta(ctx, member).delete()
    }

    /** What's being drawn right now (one child at a time), for the screen to show. */
    class Drawing(val member: String, @Volatile var done: Int = 0, @Volatile var failed: String = "", @Volatile var finished: Boolean = false) {
        /** "draw" (the 8 pictures), then "anim" (bringing them to life). */
        @Volatile var phase = "draw"
        @Volatile var animated = 0
    }

    @Volatile var drawing: Drawing? = null
        private set
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /**
     * Draws the 8 forest scenes with the child (8 pictures through Moments' server). Keeps going if the screen is
     * left; scenes already drawn from the same look are kept, so a stop in the middle continues where it was.
     * False if a drawing is already running.
     */
    fun drawScenes(ctx: Context, c: Child, animate: Boolean = false): Boolean {
        val look = c.look ?: return false
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing(c.memberId)
        drawing = d
        worker.execute {
            try {
                if (drawnFrom(app, c.memberId) != look.key) {
                    deleteScenes(app, c.memberId)
                    SafeFiles.write(meta(app, c.memberId), JSONObject().put("look", look.key).put("started", System.currentTimeMillis()).toString())
                }
                val pitzki = art(app, "pitzki") ?: throw IllegalStateException(L.t("חסרה התמונה של פיצקי באפליקציה", "Pitzki's picture is missing from the app"))
                val child = BitmapFactory.decodeFile(look.file.absolutePath) ?: throw IllegalStateException(L.t("לא הצלחנו לפתוח את התמונה של ${c.kid.name}", "Couldn't open ${c.kid.name}'s picture"))
                var first: Bitmap? = if (sceneFile(app, c.memberId, 1).exists()) BitmapFactory.decodeFile(sceneFile(app, c.memberId, 1).absolutePath) else null
                for (n in 1..PitzkiScript.SCENES) {
                    val f = sceneFile(app, c.memberId, n)
                    if (f.exists()) { d.done = n; continue }
                    val refs = listOfNotNull(pitzki, child, first.takeIf { n > 1 })
                    val img = GeminiClient.scene(app, prompt(n, c, first != null && n > 1), refs)
                        ?: throw IllegalStateException(L.t("הציור לא הצליח (סצנה $n). אפשר לנסות שוב: מה שכבר צויר נשמר.", "The drawing didn't work (scene $n). Try again: what's drawn is kept."))
                    val out = java.io.ByteArrayOutputStream()
                    img.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    if (!SafeFiles.writeBytes(f, out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
                    if (n == 1) first = img
                    d.done = n
                }
                if (animate) {
                    d.phase = "anim"
                    animateScenes(app, c, d)
                }
            } catch (e: Exception) {
                d.failed = e.message ?: L.t("הציור לא הצליח", "The drawing didn't work")
            } finally {
                d.finished = true
            }
        }
        return true
    }

    private class Edge(val url: String, val token: String)

    /**
     * Brings the drawn scenes to life (5 seconds each, through the same service as the 3D films: one film credit
     * for the whole lesson). Scenes already animated are kept. If not a single scene came to life, the credit
     * is given back.
     */
    private fun animateScenes(app: Context, c: Child, d: Drawing) {
        if (c.look == null) return
        val ed = edge(app)
        val ref = creditRef(c)
        val todo = (1..PitzkiScript.SCENES).filter { !clipFile(app, c.memberId, it).exists() }
        d.animated = PitzkiScript.SCENES - todo.size
        if (todo.isEmpty()) return
        reserve(app, ed, ref)
        var made = 0
        var lastError = ""
        val stop = java.util.concurrent.atomic.AtomicBoolean(false)
        // "pitzki_anim": lively, 10-second motion (walking, talking, expressions). A server not updated yet doesn't
        // know it: then the gentler 5-second "book_anim" is used, so the film still gets made.
        var kind = "pitzki_anim"
        // All scenes are sent first, so the service animates them at the same time (a few minutes in all, not
        // a few minutes each); then each one is collected as it's ready.
        val jobs = ArrayList<Triple<Int, String, String>>()
        for (n in todo) {
            try {
                val bmp = BitmapFactory.decodeFile(sceneFile(app, c.memberId, n).absolutePath) ?: continue
                val image = CartoonFilm.dataUri(bmp)
                fun submit(k: String) = CartoonFilm.callEdge(ed.url, ed.token, mapOf(
                    "action" to "submit", "kind" to k, "duration" to "10", "image" to image, "scene" to motion(n)))
                var job = submit(kind)
                if (kind == "pitzki_anim" && job.optInt("_code", 200) == 400 && job.optString("error").contains("לא מוכרת")) {
                    kind = "book_anim"
                    job = submit(kind)
                }
                CartoonFilm.checkError(job)
                jobs.add(Triple(n, job.optString("status_url"), job.optString("response_url")))
            } catch (e: CartoonFilm.FatalEdgeError) {
                lastError = e.message.orEmpty()
                break
            } catch (e: Exception) {
                lastError = e.message.orEmpty()
            }
        }
        for ((n, status, response) in jobs) {
            try {
                val url = CartoonFilm.pollEdge(ed.url, ed.token, status, response, stop)
                if (url.isEmpty()) { lastError = CartoonFilm.lastJobDetail; continue }
                if (download(url, clipFile(app, c.memberId, n))) { made++; d.animated = d.animated + 1 }
            } catch (e: Exception) {
                lastError = e.message.orEmpty()
            }
        }
        if (made == 0) {
            try { CartoonFilm.callEdge(ed.url, ed.token, mapOf("action" to "refund", "ref" to ref)) } catch (_: Exception) {}
            throw IllegalStateException(L.t("ההנפשה לא הצליחה", "The animation didn't work") + if (lastError.isBlank()) "" else ": ${lastError.take(120)}")
        }
        if (made < todo.size) d.failed = L.t("${d.animated} מתוך ${PitzkiScript.SCENES} סצנות קמו לחיים. אפשר לנסות שוב את השאר.", "${d.animated} of ${PitzkiScript.SCENES} scenes came to life. You can try the rest again.")
    }

    /**
     * The film credit of one making session: the child's character and the film's animation within the same
     * hours share one credit (the server keeps a reserved credit for 3 hours).
     */
    private fun creditRef(c: Child) = "pitzki-" + c.memberId.filter { it.isLetterOrDigit() }.take(24) + "-" +
        java.text.SimpleDateFormat("yyyyMMddHH", java.util.Locale.US).format(java.util.Date()).let { it.dropLast(2) + (it.takeLast(2).toInt() / 3) }

    private fun edge(app: Context) = Edge(Circle.url(app) + "/functions/v1/cartoon-film",
        Account.token(app) ?: throw IllegalStateException(L.t("צריך להתחבר לחשבון", "Please sign in")))

    private fun reserve(app: Context, e: Edge, ref: String) {
        val res = CartoonFilm.callEdge(e.url, e.token, mapOf("action" to "reserve", "ref" to ref, "again" to true))
        if (res.optInt("_code", 200) !in 200..299 || !res.optBoolean("ok", false)) {
            throw IllegalStateException(res.optString("error", "").ifBlank { L.t("אין קרדיט לסרט כרגע", "No film credit right now") }
                .let { if (it == "expired") L.t("נסו שוב", "Try again") else it })
        }
    }

    // ---------- the child's character (for the best likeness) ----------

    /** A character drawn from the child's photos, waiting for the parent's OK. */
    fun candidate(ctx: Context, member: String) = File(dir(ctx, member), "character_candidate.jpg")

    /**
     * Draws the child as an animated character from their real photos, with the same model the children's books use
     * (it keeps likeness best). The parent approves it; then it's the child's character everywhere (books too).
     */
    fun makeCharacter(ctx: Context, c: Child): Boolean {
        if (c.photos.isEmpty()) return false
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing(c.memberId).apply { phase = "character" }
        drawing = d
        worker.execute {
            try {
                val ed = edge(app)
                reserve(app, ed, creditRef(c))
                val uris = c.photos.mapNotNull { f -> BitmapFactory.decodeFile(f.absolutePath)?.let { CartoonFilm.dataUri(it) } }
                if (uris.isEmpty()) throw IllegalStateException(L.t("לא הצלחנו לפתוח את התמונות של ${c.kid.name}", "Couldn't open ${c.kid.name}'s photos"))
                val job = CartoonFilm.callEdge(ed.url, ed.token, mapOf(
                    "action" to "submit", "kind" to "book_character", "image" to uris.first(), "refs" to org.json.JSONArray(uris.drop(1)),
                    "age" to BookJson.ageDesc(Profile.ageMonths(c.birth), c.kid.girl), "aspect" to "3:4",
                    "outfit" to "comfortable everyday clothes in soft, friendly colors"))
                CartoonFilm.checkError(job)
                val url = CartoonFilm.pollEdge(ed.url, ed.token, job.optString("status_url"), job.optString("response_url"), java.util.concurrent.atomic.AtomicBoolean(false))
                val bmp = (if (url.isEmpty()) null else CartoonFilm.downloadBitmap(url))
                    ?: throw IllegalStateException(L.t("הדמות לא צוירה", "The character wasn't drawn") + CartoonFilm.lastJobDetail.let { if (it.isBlank()) "" else ": $it" })
                val out = java.io.ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
                if (!SafeFiles.writeBytes(candidate(app, c.memberId), out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
            } catch (e: Exception) {
                d.failed = e.message ?: L.t("הדמות לא צוירה", "The character wasn't drawn")
            } finally {
                d.finished = true
            }
        }
        return true
    }

    /** The parent said "that's my child": it becomes the child's character (Pitzki's film and the books use it). */
    fun approveCharacter(ctx: Context, c: Child): Boolean {
        val f = candidate(ctx, c.memberId)
        if (!f.exists()) return false
        val ok = CharacterStore.save(ctx, c.memberId, c.kid.name, f, "pitzki")
        if (ok) f.delete()
        return ok
    }

    private fun download(url: String, to: File): Boolean = try {
        val tmp = File(to.parentFile, to.name + ".part")
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 90_000
        try { conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } } } finally { conn.disconnect() }
        tmp.length() > 0 && tmp.renameTo(to)
    } catch (_: Exception) { false }

    /** What moves in each scene: Pitzki and the child walk and act together, like a film. */
    private fun motion(n: Int): String = when (n) {
        1 -> "Pitzki the little forest elf walks in along the sunny forest path toward the child, stops, waves hello and talks to the child with a big smile; the child laughs, waves back and answers excitedly."
        2 -> "Pitzki and the child walk side by side along the forest path, talking and looking around; Pitzki points at the trees and the child turns to look, amazed. The camera tracks with them as they walk."
        3 -> "Pitzki lifts the big green heart-shaped leaf and shows it to the child while talking; the child's face lights up with surprise, the child points at the leaf and says the word with a happy smile."
        4 -> "Pitzki and the child walk up to the huge tree, pat its brown bark and look up together; Pitzki talks and the child laughs."
        5 -> "Pitzki reaches up, picks the shiny red apple from the branch and hands it to the child, talking; the child takes it with a delighted expression and holds it up proudly."
        6 -> "Pitzki and the child crouch by the bright yellow flower, which sways in the breeze; Pitzki talks, the child leans in to smell it and giggles."
        7 -> "Pitzki picks up the smooth gray stone from the path and shows it to the child while talking; the child touches it curiously, then looks up at Pitzki and smiles."
        else -> "Pitzki and the child jump with joy and high-five, then wave goodbye together and walk away side by side down the path into warm golden light."
    }

    /** One scene's drawing instructions. Pitzki is the first picture, the child the second, scene 1 the third. */
    private fun prompt(n: Int, c: Child, withFirst: Boolean): String {
        val who = if (c.kid.girl) "a little girl" else "a little boy"
        val childRef = if (c.look?.drawn == true)
            "The second image is the child, $who: an existing animated character. Keep exactly the same face, hair, skin tone, age and clothes."
        else
            "The second image is a real photo of the child, $who. Turn the child into the same soft 3D animated style as Pitzki, keeping them recognizable: same face shape, hair color and style, skin tone and age."
        val action = when (n) {
            1 -> "Pitzki enters a sunny magical forest path and waves hello to the child, who smiles and waves back."
            2 -> "Pitzki and the child walk together along the forest path, looking around with curiosity."
            3 -> "Pitzki holds up a large green heart-shaped leaf; the child points at it, excited."
            4 -> "Pitzki and the child stand by a huge tree, both touching the brown bark of its trunk."
            5 -> "Pitzki holds a shiny red apple from a low branch; the child looks at it happily."
            6 -> "Pitzki and the child look at a small bright yellow sunflower growing by the path."
            7 -> "Pitzki holds a smooth gray stone; the child looks at it curiously."
            else -> "Pitzki and the child wave goodbye together on the forest path in warm golden evening light."
        }
        return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. $childRef " +
            (if (withFirst) "The third image is an earlier scene of the same film: same characters, same style, same forest. " else "") +
            "Scene: $action Both characters fully visible, the same height scale, gentle happy expressions, slow calm mood, " +
            "soft warm sunlight, lush friendly forest. No text, no letters, no speech bubbles, no watermark, no borders."
    }

    /** Runs [f] on the main thread. */
    fun onMain(f: () -> Unit) = main.post(f)
}
