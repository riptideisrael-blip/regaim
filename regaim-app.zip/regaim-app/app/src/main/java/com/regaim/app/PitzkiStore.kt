package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Pitzki's side of the app: which child, how the child looks (from what the family already has), the family's own
 * photos for each color, and the forest scenes drawn with the child in them (kept on the phone, per child).
 */
object PitzkiStore {
    /** A child from the family profile, with what Pitzki can show of them. */
    class Child(val memberId: String, val kid: PitzkiKid, val look: Look?)

    /**
     * How the child looks: [file] is a picture on the phone. [drawn] = an approved character from a book
     * (already a drawing); otherwise a real photo (profile picture or the face the app learned).
     */
    class Look(val file: File, val drawn: Boolean) {
        /** Changes when the picture changes, so the scenes are drawn again for the new look. */
        val key: String get() = "${file.absolutePath}:${file.length()}:${file.lastModified()}"
    }

    fun children(ctx: Context): List<Child> = Profile.members(ctx).filter { it.isChild && it.name.isNotBlank() }.map { m ->
        Child(m.id, PitzkiKid(m.name.trim(), girl = m.relation == "ילדה"), look(ctx, m))
    }

    private fun look(ctx: Context, m: FamilyMember): Look? {
        CharacterStore.latest(ctx, m.id)?.let { c -> CharacterStore.file(ctx, c).takeIf { it.exists() }?.let { return Look(it, drawn = true) } }
        m.photo.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        PeopleStore.people(ctx).firstOrNull { it.name.trim() == m.name.trim() }?.photo?.takeIf { it.isNotBlank() }
            ?.let { File(it) }?.takeIf { it.exists() }?.let { return Look(it, drawn = false) }
        return null
    }

    // ---------- bundled art ----------

    /** Pitzki's own art, in the app (assets/pitzki): "pitzki" (whole body), "face", "forest" (the wide scene). */
    fun art(ctx: Context, name: String): Bitmap? = try {
        ctx.assets.open("pitzki/$name.jpg").use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    /** A recorded line, if one was added to the app (assets/pitzki/voice/<id>.mp3). */
    fun hasRecording(ctx: Context, id: String): Boolean = try {
        ctx.assets.openFd("pitzki/voice/$id.mp3").close(); true
    } catch (_: Exception) { false }

    // ---------- progress ----------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("pitzki", Context.MODE_PRIVATE)
    fun stars(ctx: Context, member: String) = prefs(ctx).getInt("stars_$member", 0)
    fun addStars(ctx: Context, member: String, n: Int) = prefs(ctx).edit().putInt("stars_$member", stars(ctx, member) + n).apply()
    fun lessonsDone(ctx: Context, member: String) = prefs(ctx).getInt("done_$member", 0)
    fun markDone(ctx: Context, member: String) = prefs(ctx).edit().putInt("done_$member", lessonsDone(ctx, member) + 1).apply()

    // ---------- the family's photos, one per color ----------

    /**
     * Background thread only. One moment per color whose picture has a lot of it, preferring moments with the
     * child in them. Looks at a limited number of pictures (at most [budgetMs]), so it's quick; may find none.
     */
    fun familyPhotos(ctx: Context, childName: String, budgetMs: Long = 7000): Map<PColor, Memory> {
        val started = System.currentTimeMillis()
        val all = MemoryStore.kept(ctx)
        val withChild = all.filter { m -> Fmt.names(m).any { it.trim() == childName.trim() } }
        val candidates = (withChild + all.filter { it !in withChild }).take(60)
        val measured = ArrayList<Pair<String, Map<PColor, Float>>>()
        for (m in candidates) {
            if (System.currentTimeMillis() - started > budgetMs) break
            val b = try { Covers.get(ctx, m) } catch (_: Throwable) { null } ?: continue
            val small = Bitmap.createScaledBitmap(b, 24, 24, true)
            val px = IntArray(24 * 24)
            small.getPixels(px, 0, 24, 0, 0, 24, 24)
            if (small !== b) small.recycle()
            measured.add(m.id to PitzkiColors.shares(px))
        }
        val byId = candidates.associateBy { it.id }
        return PitzkiColors.pick(measured).mapNotNull { (c, id) -> byId[id]?.let { c to it } }.toMap()
    }

    // ---------- forest scenes drawn with the child ----------

    private fun dir(ctx: Context, member: String) = File(File(ctx.filesDir, "pitzki"), member.filter { it.isLetterOrDigit() || it == '-' || it == '_' }).apply { mkdirs() }
    fun sceneFile(ctx: Context, member: String, n: Int) = File(dir(ctx, member), "scene_$n.jpg")
    private fun meta(ctx: Context, member: String) = File(dir(ctx, member), "scenes.json")

    /** The look the saved scenes were drawn from, or "". */
    private fun drawnFrom(ctx: Context, member: String): String = when (val r = SafeFiles.readObject(meta(ctx, member))) {
        is SafeFiles.Read.Ok -> r.value.optString("look")
        else -> ""
    }

    /** All 8 scenes are drawn, from the child's current look. */
    fun scenesReady(ctx: Context, c: Child): Boolean {
        val look = c.look ?: return false
        return drawnFrom(ctx, c.memberId) == look.key && (1..PitzkiScript.SCENES).all { sceneFile(ctx, c.memberId, it).exists() }
    }

    /** Scenes exist but from an older look (a new character was approved since). */
    fun scenesOutdated(ctx: Context, c: Child): Boolean =
        c.look != null && drawnFrom(ctx, c.memberId).isNotEmpty() && drawnFrom(ctx, c.memberId) != c.look.key

    /** Deletes the child's drawn scenes (the lesson goes back to the circle look). */
    fun deleteScenes(ctx: Context, member: String) {
        (1..PitzkiScript.SCENES).forEach { sceneFile(ctx, member, it).delete() }
        meta(ctx, member).delete()
    }

    /** What's being drawn right now (one child at a time), for the screen to show. */
    class Drawing(val member: String, @Volatile var done: Int = 0, @Volatile var failed: String = "", @Volatile var finished: Boolean = false)

    @Volatile var drawing: Drawing? = null
        private set
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /**
     * Draws the 8 forest scenes with the child (8 pictures through Moments' server). Keeps going if the screen is
     * left; scenes already drawn from the same look are kept, so a stop in the middle continues where it was.
     * False if a drawing is already running.
     */
    fun drawScenes(ctx: Context, c: Child): Boolean {
        val look = c.look ?: return false
        if (drawing?.finished == false) return false
        val app = ctx.applicationContext
        val d = Drawing(c.memberId)
        drawing = d
        worker.execute {
            try {
                if (drawnFrom(app, c.memberId) != look.key) {
                    deleteScenes(app, c.memberId)
                    SafeFiles.write(meta(app, c.memberId), JSONObject().put("look", look.key).put("started", System.currentTimeMillis()).toString())
                }
                val pitzki = art(app, "pitzki") ?: throw IllegalStateException(L.t("חסרה התמונה של פיצקי באפליקציה", "Pitzki's picture is missing from the app"))
                val child = BitmapFactory.decodeFile(look.file.absolutePath) ?: throw IllegalStateException(L.t("לא הצלחנו לפתוח את התמונה של ${c.kid.name}", "Couldn't open ${c.kid.name}'s picture"))
                var first: Bitmap? = if (sceneFile(app, c.memberId, 1).exists()) BitmapFactory.decodeFile(sceneFile(app, c.memberId, 1).absolutePath) else null
                for (n in 1..PitzkiScript.SCENES) {
                    val f = sceneFile(app, c.memberId, n)
                    if (f.exists()) { d.done = n; continue }
                    val refs = listOfNotNull(pitzki, child, first.takeIf { n > 1 })
                    val img = GeminiClient.scene(app, prompt(n, c, first != null && n > 1), refs)
                        ?: throw IllegalStateException(L.t("הציור לא הצליח (סצנה $n). אפשר לנסות שוב: מה שכבר צויר נשמר.", "The drawing didn't work (scene $n). Try again: what's drawn is kept."))
                    val out = java.io.ByteArrayOutputStream()
                    img.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    if (!SafeFiles.writeBytes(f, out.toByteArray())) throw IllegalStateException(L.t("אין מספיק מקום בטלפון", "Not enough space on the phone"))
                    if (n == 1) first = img
                    d.done = n
                }
            } catch (e: Exception) {
                d.failed = e.message ?: L.t("הציור לא הצליח", "The drawing didn't work")
            } finally {
                d.finished = true
            }
        }
        return true
    }

    /** One scene's drawing instructions. Pitzki is the first picture, the child the second, scene 1 the third. */
    private fun prompt(n: Int, c: Child, withFirst: Boolean): String {
        val who = if (c.kid.girl) "a little girl" else "a little boy"
        val childRef = if (c.look?.drawn == true)
            "The second image is the child, $who: an existing animated character. Keep exactly the same face, hair, skin tone, age and clothes."
        else
            "The second image is a real photo of the child, $who. Turn the child into the same soft 3D animated style as Pitzki, keeping them recognizable: same face shape, hair color and style, skin tone and age."
        val action = when (n) {
            1 -> "Pitzki enters a sunny magical forest path and waves hello to the child, who smiles and waves back."
            2 -> "Pitzki and the child walk together along the forest path, looking around with curiosity."
            3 -> "Pitzki holds up a large green heart-shaped leaf; the child points at it, excited."
            4 -> "Pitzki and the child stand by a huge tree, both touching the brown bark of its trunk."
            5 -> "Pitzki holds a shiny red apple from a low branch; the child looks at it happily."
            6 -> "Pitzki and the child look at a small bright yellow sunflower growing by the path."
            7 -> "Pitzki holds a smooth gray stone; the child looks at it curiously."
            else -> "Pitzki and the child wave goodbye together on the forest path in warm golden evening light."
        }
        return "A single frame from a high-end soft 3D animated children's film for ages 3 to 5. Wide landscape composition. " +
            "The first image is Pitzki, a small forest elf: keep his face, curly chestnut hair, green pointed hat with a leaf, " +
            "leaf-green clothes, brown shoes and proportions exactly the same. $childRef " +
            (if (withFirst) "The third image is an earlier scene of the same film: same characters, same style, same forest. " else "") +
            "Scene: $action Both characters fully visible, the same height scale, gentle happy expressions, slow calm mood, " +
            "soft warm sunlight, lush friendly forest. No text, no letters, no speech bubbles, no watermark, no borders."
    }

    /** Runs [f] on the main thread. */
    fun onMain(f: () -> Unit) = main.post(f)
}
