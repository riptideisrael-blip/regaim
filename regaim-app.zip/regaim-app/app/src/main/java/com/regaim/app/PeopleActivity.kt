package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * "אנשים", like in Google Photos: your named people, and groups of faces waiting for a name.
 * Name a face once and Moments finds that person in all moments, on the phone only.
 */
class PeopleActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, PeopleActivity::class.java))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var known: LinearLayout
    private lateinit var unknown: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_people)
        known = findViewById(R.id.knownPeople)
        unknown = findViewById(R.id.unknownFaces)
        status = findViewById(R.id.peopleStatus)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        render()
        scan()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun scan() {
        val pending = MemoryStore.all(this).count { !it.facesScanned }
        if (pending == 0 && FaceId.ready(this)) {
            status.visibility = View.GONE
            return
        }
        status.visibility = View.VISIBLE
        status.text = if (!FaceId.ready(this)) "מוריד את מודל זיהוי הפנים (פעם אחת, כ-5MB)..." else "מחפש פנים ב-$pending רגעים..."
        worker.execute {
            var total = 0
            while (true) {
                val n = PeopleStore.scanPending(applicationContext, 4)
                total += n
                runOnUiThread { if (!isFinishing) render() }
                if (n == 0) break
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (!FaceId.ready(this)) status.text = "לא הצלחתי להוריד את המודל. בדוק חיבור לאינטרנט ונסה שוב."
                else status.visibility = View.GONE
            }
        }
    }

    private fun render() {
        val d = resources.displayMetrics.density
        // Named people
        known.removeAllViews()
        val people = PeopleStore.people(this)
        findViewById<View>(R.id.knownEmpty).visibility = if (people.isEmpty()) View.VISIBLE else View.GONE
        for (row in people.chunked(4)) {
            val line = rowLayout()
            for (p in row) {
                val count = PeopleStore.countFor(this, p.name)
                line.addView(faceCell(p.photo, p.name, if (count == 1) "רגע אחד" else "$count רגעים") { personMenu(p) })
            }
            known.addView(line)
        }
        // Faces waiting for a name
        unknown.removeAllViews()
        val groups = PeopleStore.unknownGroups(this)
        findViewById<View>(R.id.unknownEmpty).visibility = if (groups.isEmpty()) View.VISIBLE else View.GONE
        for (row in groups.take(24).chunked(4)) {
            val line = rowLayout()
            for (g in row) {
                line.addView(faceCell(g.first().path, "מי זה?", if (g.size > 1) "${g.size} פעמים" else "") { nameGroup(g) })
            }
            unknown.addView(line)
        }
        known.setPadding(0, (4 * d).toInt(), 0, 0)
    }

    private fun rowLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun faceCell(path: String, title: String, sub: String, onClick: () -> Unit): View {
        val d = resources.displayMetrics.density
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding((4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { onClick() }
        }
        val img = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams((68 * d).toInt(), (68 * d).toInt())
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bubble_placeholder)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) = outline.setOval(0, 0, view.width, view.height)
            }
            clipToOutline = true
            BitmapFactory.decodeFile(path)?.let { setImageBitmap(it) }
        }
        cell.addView(img)
        cell.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@PeopleActivity, R.color.ink))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, (6 * d).toInt(), 0, 0)
        })
        if (sub.isNotEmpty()) cell.addView(TextView(this).apply {
            text = sub
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@PeopleActivity, R.color.ink_soft))
            gravity = Gravity.CENTER
        })
        return cell
    }

    private fun nameGroup(group: List<FaceShot>) {
        val names = PeopleStore.people(this).map { it.name }
        val field = EditText(this).apply {
            hint = "השם שבו תרצו שיופיע בזיכרונות"
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, p / 2)
        }
        val b = AlertDialog.Builder(this)
            .setTitle("מי זה?")
            .setView(field)
            .setPositiveButton("שמור") { _, _ -> assign(group, field.text.toString()) }
            .setNeutralButton("לא חשוב") { _, _ ->
                worker.execute { PeopleStore.ignore(applicationContext, group.map { it.id }); runOnUiThread { render() } }
            }
            .setNegativeButton("ביטול", null)
        if (names.isNotEmpty()) {
            // Existing people as one-tap choices.
            b.setItems(names.toTypedArray()) { _, i -> assign(group, names[i]) }
        }
        b.show()
    }

    private fun assign(group: List<FaceShot>, name: String) {
        if (name.isBlank()) return
        worker.execute {
            PeopleStore.assign(applicationContext, group.map { it.id }, name)
            runOnUiThread { if (!isFinishing) render() }
        }
    }

    private fun personMenu(p: Person) {
        AlertDialog.Builder(this)
            .setTitle(p.name)
            .setItems(arrayOf("הצג את הרגעים של ${p.name}", "שנה שם", "שכח את האדם הזה")) { _, i ->
                when (i) {
                    0 -> startActivity(Intent(this, MemoriesActivity::class.java)
                        .putExtra(MemoriesActivity.EXTRA_PERSON, p.name)
                        .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                    1 -> {
                        val field = EditText(this).apply { setText(p.name) }
                        AlertDialog.Builder(this).setTitle("שם חדש").setView(field)
                            .setPositiveButton("שמור") { _, _ ->
                                worker.execute { PeopleStore.rename(applicationContext, p.id, field.text.toString()); runOnUiThread { render() } }
                            }
                            .setNegativeButton("ביטול", null).show()
                    }
                    2 -> worker.execute { PeopleStore.forget(applicationContext, p.id); runOnUiThread { render() } }
                }
            }
            .show()
    }
}
