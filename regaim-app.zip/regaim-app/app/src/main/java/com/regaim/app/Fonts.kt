package com.regaim.app

import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * One typography for the whole app. Headings use a medium weight instead of heavy bold (softer on the eye).
 * To use your own font, put `regular.ttf` and `bold.ttf` (e.g. Heebo or Assistant) in app/src/main/assets/fonts/ —
 * they are picked up automatically; without them the phone's own font is used.
 */
object Fonts {
    private var regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private var strong: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    fun init(ctx: Context) {
        try { regular = Typeface.createFromAsset(ctx.assets, "fonts/regular.ttf") } catch (_: Exception) { }
        try { strong = Typeface.createFromAsset(ctx.assets, "fonts/bold.ttf") } catch (_: Exception) { }
    }

    /** Applies the app font to every text in [root] (once per view; later bold requests are honoured). */
    fun apply(root: View) {
        if (root is TextView) {
            val current = root.typeface
            if (current === Typeface.SERIF || current === Typeface.MONOSPACE) return
            if (root.getTag(R.id.fontApplied) !== current) {
                val wantsBold = current != null && current.isBold
                val face = if (wantsBold) strong else regular
                root.typeface = face
                root.setTag(R.id.fontApplied, root.typeface)
            }
        }
        if (root is ViewGroup) for (i in 0 until root.childCount) apply(root.getChildAt(i))
    }

    fun install(app: Application) {
        init(app)
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: Activity, b: Bundle?) {
                val decor = a.window.decorView
                var pending = false
                decor.viewTreeObserver.addOnGlobalLayoutListener {
                    if (!pending) {
                        pending = true
                        decor.postDelayed({ pending = false; apply(decor) }, 60)
                    }
                }
            }
            override fun onActivityResumed(a: Activity) { apply(a.window.decorView) }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}
