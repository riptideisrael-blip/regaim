package com.regaim.app

/**
 * "The magic forest with Pitzki": the colors lesson, as data (pure Kotlin, tested on the computer).
 * Pitzki the forest elf and the child walk through the forest and meet five colors, in Hebrew and in English.
 * The screen plays the beats one after another; it never decides the words itself.
 */
enum class PColor(val en: String, val he: String, val emoji: String, val thing: String, val found: String, private val adj: String = "") {
    GREEN("Green", "ירוק", "🍃", "עלה", "עלה בצורת לב!"),
    BROWN("Brown", "חום", "🪵", "גזע", "עץ גדול! תראו את הגזע שלו."),
    RED("Red", "אדום", "🍎", "תפוח", "תפוח על הענף!"),
    YELLOW("Yellow", "צהוב", "🌻", "פרח", "פרח שמש קטן!"),
    GRAY("Gray", "אפור", "🪨", "אבן", "אבן ליד הרגליים שלנו!", adj = "אפורה"),
    ;

    /** The color describing its thing ("the gray stone" is feminine in Hebrew: אבן אפורה). */
    val heAdj: String get() = adj.ifEmpty { he }
}

/** The child the lesson is for. An empty name: Pitzki talks to "friends" (plural). */
data class PitzkiKid(val name: String, val girl: Boolean) {
    val named: Boolean get() = name.isNotBlank()
    /** Picks the Hebrew form: to a boy, to a girl, or to everyone. */
    fun g(boy: String, girl: String, all: String) = if (!named) all else if (this.girl) girl else boy
}

sealed class Beat {
    /**
     * Pitzki says [text] (Hebrew). [id] names a recorded line (assets/pitzki/voice/[id].mp3) that may replace the
     * phone's voice; [personal] lines carry the child's name or form, so a recording can't stand in for them.
     */
    data class Say(val id: String, val text: String, val personal: Boolean = false) : Beat()
    /** The English word, said clearly, with the big colored word bubble. */
    data class Word(val color: PColor) : Beat()
    /** A pause for the child to answer out loud. */
    data class Wait(val ms: Long) : Beat()
    /** Waits for the child to tap the right thing in the row below. */
    data class Ask(val color: PColor) : Beat()
    /** A photo from the family's own moments with this color, if one was found ("and at home too!"). */
    data class Family(val color: PColor, val text: String) : Beat()
    /** Stars and a cheer. */
    object Celebrate : Beat()
}

data class PitzkiScene(val n: Int, val title: String, val color: PColor?, val beats: List<Beat>)

object PitzkiScript {
    const val SCENES = 8
    /** The order the colors are met in the forest. */
    val ORDER = listOf(PColor.GREEN, PColor.BROWN, PColor.RED, PColor.YELLOW, PColor.GRAY)
    /** The order of the questions in the review (mixed, so it's not just repeating). */
    val REVIEW = listOf(PColor.RED, PColor.GREEN, PColor.YELLOW, PColor.GRAY, PColor.BROWN)

    fun lesson(kid: PitzkiKid): List<PitzkiScene> {
        val name = kid.name.trim()
        val hi = if (kid.named) "שלום $name!" else "שלום חברים!"
        val scenes = ArrayList<PitzkiScene>()
        scenes.add(PitzkiScene(1, "פתיח", null, listOf(
            Beat.Say("s1_hello", "$hi אני פיצקי, שדון היער.", personal = kid.named),
            Beat.Say("s1_trip", "היום נצא יחד לטיול ביער, ונלמד צבעים באנגלית."),
            Beat.Say("s1_ready", kid.g("מוכן?", "מוכנה?", "מוכנים?"), personal = kid.named),
            Beat.Wait(1500),
            Beat.Say("s1_go", kid.g("בוא!", "בואי!", "בואו!"), personal = kid.named),
        )))
        scenes.add(PitzkiScene(2, "הליכה ביער", null, listOf(
            Beat.Say("s2_pretty", "איזה יער יפה! נסתכל מסביב ונמצא צבעים."),
            Beat.Say("s2_point", "אפשר להצביע יחד איתי."),
            Beat.Wait(800),
        )))
        ORDER.forEachIndexed { i, c ->
            val n = 3 + i
            val key = c.name.lowercase()
            scenes.add(PitzkiScene(n, c.he, c, listOf(
                Beat.Say("s${n}_${key}_found", "וואו, תראו! ${c.found}"),
                Beat.Say("s${n}_${key}_which", "איזה צבע יש ל${c.thing}?"),
                Beat.Wait(2500),
                Beat.Say("s${n}_${key}_he", "${c.he}!"),
                Beat.Say("s${n}_${key}_en", "באנגלית אומרים"),
                Beat.Word(c),
                Beat.Say("s${n}_${key}_together", (if (kid.named) "$name, " else "") + kid.g("תגיד איתי:", "תגידי איתי:", "תגידו איתי:"), personal = kid.named),
                Beat.Word(c),
                Beat.Wait(1800),
                Beat.Family(c, "וגם אצלנו בבית יש ${c.he}!"),
                Beat.Say("s${n}_${key}_tap", kid.g("תלחץ על ה${c.thing}", "תלחצי על ה${c.thing}", "תלחצו על ה${c.thing}") + " ה${c.heAdj}.", personal = kid.named),
                Beat.Ask(c),
            )))
        }
        val review = ArrayList<Beat>()
        review.add(Beat.Say("s8_check", kid.g("עכשיו בוא נבדוק מה זכרנו!", "עכשיו בואי נבדוק מה זכרנו!", "עכשיו בואו נבדוק מה זכרנו!"), personal = kid.named))
        for (c in REVIEW) {
            review.add(Beat.Say("s8_where_${c.name.lowercase()}", "איפה ה${c.he}?"))
            review.add(Beat.Ask(c))
        }
        review.add(Beat.Celebrate)
        review.add(Beat.Say("s8_wonderful", "איזה טיול נפלא! היום למדנו:"))
        ORDER.forEach { review.add(Beat.Word(it)) }
        review.add(Beat.Say("s8_bye", if (kid.named) "נתראה בהרפתקה הבאה, $name!" else "נתראה בהרפתקה הבאה!", personal = kid.named))
        scenes.add(PitzkiScene(8, "חזרה וסיום", null, review))
        return scenes
    }

    /** A cheer after a right answer (a different one each time, by [i]). */
    fun praise(kid: PitzkiKid, i: Int): String {
        val all = listOf(
            kid.g("כל הכבוד!", "כל הכבוד!", "כל הכבוד!"),
            kid.g("נכון מאוד! אתה אלוף!", "נכון מאוד! את אלופה!", "נכון מאוד! אתם אלופים!"),
            kid.g("יופי! מצאת!", "יופי! מצאת!", "יופי! מצאתם!"),
            "וואו, איזה יופי!",
        )
        return all[Math.floorMod(i, all.size)]
    }

    /** After a wrong tap: gentle, says what it was and asks again. */
    fun tryAgain(kid: PitzkiKid, tapped: PColor, wanted: PColor) =
        "כמעט! זה ${tapped.he}. " + kid.g("נסה שוב:", "נסי שוב:", "נסו שוב:") + " איפה ה${wanted.he}?"

    /** After two misses or a long wait: shows the answer, no score lost. */
    fun showAnswer(wanted: PColor) = "הנה ה${wanted.he}! ${wanted.en}!"
}
