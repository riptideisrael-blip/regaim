package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * "מעגל המשפחה" (prototype): one private feed for the whole family.
 * Parents share moments from the app; grandparents and relatives join from a web link, react and comment.
 */
class CircleActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context, postId: String? = null) = ctx.startActivity(Intent(ctx, CircleActivity::class.java).putExtra("post_id", postId))
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(2)
    private var feed: Circle.Feed? = null
    private var loading = false
    private var error = ""
    private var busyText = ""
    private var loadedUser = ""
    private var loadedCircle = ""

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) askTitleAndShare(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = L.t("מעגל המשפחה", "Family circle")
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        if (loadedUser != Account.id(this) || loadedCircle != Circle.circleId(this) || !Account.signedIn(this)) { feed = null; error = "" }
        render()
        load()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        images.shutdownNow()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun load() {
        if (isFinishing || isDestroyed || worker.isShutdown) return
        if (!Circle.joined(this) || loading) return
        val requestedUser = Account.id(this)
        val requestedCircle = Circle.circleId(this)
        loading = true
        render()
        worker.execute {
            val r = try {
                var loaded = Circle.feed(applicationContext)
                intent.getStringExtra("post_id")?.let { id ->
                    val selected = loaded.posts.find { it.id == id } ?: Circle.postById(applicationContext, id)
                    loaded = Circle.Feed(listOfNotNull(selected), if (selected != null) Circle.reactionsForPost(applicationContext, id) else emptyList(), if (selected != null) Circle.commentsForPost(applicationContext, id) else emptyList())
                }
                Result.success(loaded)
            } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                loading = false
                if (isFinishing || requestedUser != Account.id(this) || requestedCircle != Circle.circleId(this)) return@runOnUiThread
                r.onSuccess { feed = it; error = ""; loadedUser = requestedUser; loadedCircle = requestedCircle }.onFailure { error = it.message ?: L.t("אין חיבור כרגע", "You're offline right now") }
                render()
            }
        }
    }

    private fun render() {
        content.removeAllViews()
        content.addView(ui.hint(L.t("רגעים ששיתפתם ושיחות עם החברים המאושרים במעגל.", "Moments you've shared and chats with approved circle members."), top = 0))
        when {
            !Circle.configured(this) -> serverSetup()
            !Circle.joined(this) -> createOrJoin()
            else -> circleHome()
        }
    }

    // ---------- step 1: the family's server ----------

    private fun serverSetup() {
        val card = ui.card(top = 16)
        card.addView(ui.text(L.t("חיבור לשרת של המשפחה", "Connect your family server"), 18f, bold = true))
        card.addView(ui.hint(L.t("מ-Supabase: Project Settings ← API. מעתיקים את ה-Project URL ואת המפתח הציבורי (anon / publishable).", "In Supabase: Project Settings → API. Copy the Project URL and the public key (anon / publishable)."), top = 4))
        val url = ui.field("https://xxxx.supabase.co", Circle.url(this))
        val key = ui.field(L.t("המפתח הציבורי", "Public key"), Circle.key(this))
        card.addView(url)
        card.addView(key)
        card.addView(ui.text(L.t("כתובת דף המשפחה (לסבא וסבתא)", "Family page link (for grandparents)"), 14f, R.color.ink_soft, top = 12))
        val web = ui.field(Circle.DEFAULT_WEB, Circle.web(this), top = 4)
        card.addView(web)
        card.addView(ui.hint(L.t("אם העלית את index.html ל-GitHub Pages של הריפו, השאר כמו שזה.", "If you uploaded index.html to the repo's GitHub Pages, leave this as is."), top = 4))
        card.addView(ui.button(L.t("שמור והמשך", "Save and continue"), primary = true, top = 14) {
            Circle.setServer(this, url.text.toString(), key.text.toString(), web.text.toString())
            if (key.text.toString().trim().startsWith("sb_secret")) {
                Circle.setServer(this, url.text.toString(), "", web.text.toString())
                toast(L.t("זה המפתח הסודי. צריך את המפתח הציבורי שמתחיל ב-sb_publishable", "That's the secret key. Use the public key that starts with sb_publishable"))
            } else if (!Circle.configured(this)) toast(L.t("הכתובת צריכה להתחיל ב-https:// ולהגיע עם מפתח מלא", "The URL must start with https:// and include a full key"))
            render()
        })
        content.addView(card)
    }

    // ---------- step 2: create or join ----------

    private fun createOrJoin() {
        if (!Account.signedIn(this)) {
            content.addView(ui.text(L.t("המשפחה שלכם, יחד בזיכרונות", "Your family, together in memories"), 22f, bold = true, top = 22))
            content.addView(ui.hint(L.t("התחברו כדי לפתוח מעגל או לקבל הזמנה. הזיכרונות בטלפון זמינים גם בלי חשבון.", "Sign in to start a circle or accept an invite. Memories on your phone work without an account."), top = 8))
            content.addView(ui.button(L.t("התחברות למשפחה", "Sign in to family"), primary = true, top = 16) { WelcomeActivity.open(this) })
            return
        }
        val card = ui.card(top = 16)
        card.addView(ui.text(L.t("פתחו מעגל משפחה", "Start a family circle"), 18f, bold = true))
        val name = ui.field(L.t("שם המעגל", "Circle name"), Profile.homeTitle(this))
        card.addView(name)
        card.addView(ui.button(L.t("צור מעגל", "Create circle"), primary = true, top = 12) {
            run(L.t("פותחים את המעגל...", "Creating your circle...")) {
                Circle.create(applicationContext, name.text.toString().ifBlank { Profile.homeTitle(this) })
                L.t("המעגל שלכם נפתח ❤️", "Your circle is ready ❤️")
            }
        })
        card.addView(ui.divider())
        card.addView(ui.text(L.t("או הצטרפו למעגל קיים", "Or join an existing circle"), 16f, bold = true, top = 6))
        val code = ui.field(L.t("קישור הזמנה או קוד הזמנה מאובטח", "Invite link or secure invite code"), "")
        card.addView(code)
        card.addView(ui.button(L.t("הצטרף", "Join"), top = 10) {
            run(L.t("מצטרפים...", "Joining...")) {
                val input = code.text.toString().trim()
                val token = if (input.startsWith("https://")) Uri.parse(input).getQueryParameter("c") ?: "" else input
                Circle.join(applicationContext, token)
                L.t("הצטרפתם ל${Circle.name(applicationContext)}", "You joined ${Circle.name(applicationContext)}")
            }
        })
        card.addView(ui.action(L.t("שינוי פרטי השרת", "Change server details"), R.color.ink_soft) {
            Circle.setServer(this, "", "", Circle.web(this))
            render()
        })
        content.addView(card)
        if (error.isNotEmpty()) content.addView(ui.hint(error, top = 10))
    }

    private fun run(busy: String, work: () -> String) {
        if (worker.isShutdown || busyText.isNotEmpty()) return
        busyText = busy
        toast(busy)
        render()
        worker.execute {
            val r = try { Result.success(work()) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                busyText = ""
                if (isFinishing) return@runOnUiThread
                r.onSuccess { toast(it) }.onFailure { error = it.message ?: L.t("משהו השתבש", "Something went wrong"); toast(error) }
                render()
                load()
            }
        }
    }

    // ---------- the circle ----------

    private fun circleHome() {
        val head = ui.card(top = 14)
        head.addView(ui.text(Circle.name(this), 20f, bold = true))
        head.addView(ui.hint(L.t("הזיכרונות משותפים לכל החברים המאושרים במעגל", "Memories are shared with all approved circle members"), top = 2))
        head.addView(ui.button(L.t("שיחה במשפחה", "Family chat"), top = 8) { FamilyChatActivity.open(this) })
        head.addView(ui.button(L.t("הזמינו את המשפחה", "Invite your family"), primary = true, top = 12) { invite() })
        head.addView(ui.button(L.t("שתפו רגע ששמרתם", "Share a saved moment"), top = 8) { pickMoment() })
        val row = ui.horizontal(top = 4)
        row.addView(ui.action(L.t("תמונה או סרטון", "Photo or video")) { AlertDialog.Builder(this).setItems(arrayOf(L.t("תמונה", "Photo"), L.t("סרטון", "Video"))) { _, i -> pick.launch(if (i == 0) "image/*" else "video/*") }.show() })
        row.addView(ui.action(L.t("השם שלי", "My name")) { editMe() })
        row.addView(ui.action(L.t("רענון", "Refresh")) { load(); toast(L.t("מרענן...", "Refreshing...")) })
        head.addView(row)
        head.addView(ui.action(L.t("החליפו קישור הזמנה", "Reset invite link"), R.color.ink_soft) {
            AlertDialog.Builder(this).setTitle(L.t("ליצור קישור חדש?", "Create a new link?"))
                .setMessage(L.t("הקישור הישן יפסיק לצרף אנשים. החברים שכבר הצטרפו נשארים במעגל. הפעולה זמינה למנהל המשפחה.", "The old link will stop working. People who already joined stay in the circle. Only the family admin can do this."))
                .setPositiveButton(L.t("צור קישור", "Create link")) { _, _ -> run(L.t("יוצרים הזמנה חדשה...", "Creating a new invite...")) { Circle.renewInvite(applicationContext); L.t("קישור ההזמנה עודכן", "Invite link updated") } }
                .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
        })
        content.addView(head)
        if (busyText.isNotEmpty()) content.addView(ui.hint(busyText, top = 10).also { mv.pulse(it) })
        if (error.isNotEmpty()) content.addView(ui.hint(error, top = 10))

        val f = feed
        if (f == null) {
            content.addView(ui.hint(if (loading) L.t("רגע, טוענים את הרגעים של המשפחה...", "Loading your family's moments...") else "", top = 18))
            return
        }
        if (f.posts.isEmpty()) {
            val e = ui.card(top = 18)
            e.gravity = Gravity.CENTER_HORIZONTAL
            e.addView(android.widget.ImageView(this).apply { setImageResource(R.drawable.ic_heart_outline); setColorFilter(androidx.core.content.ContextCompat.getColor(this@CircleActivity, R.color.ink)); layoutParams = android.widget.LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { gravity = android.view.Gravity.CENTER_HORIZONTAL } })
            e.addView(ui.text(L.t("עדיין אין כאן רגעים", "No moments here yet"), 19f, bold = true, top = 6).apply { gravity = Gravity.CENTER })
            e.addView(ui.text(L.t("פתחו רגע ולחצו \"שתף למעגל המשפחה\", או שתפו תמונה מהגלריה.", "Open a moment and tap \"Share to family circle\", or share a photo from your gallery."), 15f, R.color.ink_soft, top = 6).apply { gravity = Gravity.CENTER })
            content.addView(e)
            return
        }
        f.posts.forEachIndexed { i, p ->
            val v = postCard(p, f)
            content.addView(v)
            if (i < 6) mv.reveal(v, i * 40L)
        }
        content.addView(ui.action(L.t("יציאה מהמעגל", "Leave circle"), R.color.ink_soft) {
            AlertDialog.Builder(this).setTitle(L.t("לצאת מהמעגל?", "Leave the circle?"))
                .setMessage(L.t("לא תראו יותר את הרגעים והשיחות של המעגל. כדי לחזור תצטרכו הזמנה חדשה.", "You won't see the circle's moments and chats anymore. To come back you'll need a new invite."))
                .setPositiveButton(L.t("יציאה", "Leave")) { _, _ ->
                    Thread { Circle.leaveForGood(applicationContext); runOnUiThread { if (!isDestroyed) { feed = null; render() } } }.start()
                }
                .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
        })
    }

    private fun postCard(p: Circle.Post, f: Circle.Feed): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_bg)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = mv.dp(16) }
        }
        val media = FrameLayout(this).apply {
            setBackgroundColor(0xFFEFEFEF.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(320))
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        media.addView(img)
        img.colorFilter = Circle.styleFilter(p.style)
        if (p.style == "party") media.foreground = android.graphics.drawable.GradientDrawable().apply {
            setStroke(mv.dp(5), 0xFFFFC94D.toInt())
        }
        val cover = p.cover.ifEmpty { if (p.kind == "photo") p.video else "" }
        img.tag = cover
        if (cover.isNotEmpty()) images.execute {
            val bmp = Circle.image(applicationContext, cover)
            runOnUiThread {
                if (bmp != null && img.tag == cover) {
                    img.alpha = 0f
                    img.setImageBitmap(bmp)
                    img.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
        if (p.kind != "photo") media.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            setColorFilter(ContextCompat.getColor(this@CircleActivity, R.color.white))
            setBackgroundResource(R.drawable.play_circle)
            val pad = mv.dp(18)
            setPadding(pad, pad, pad, pad)
            layoutParams = FrameLayout.LayoutParams(mv.dp(64), mv.dp(64), Gravity.CENTER)
        })
        media.setOnClickListener { openMedia(p) }
        box.addView(media)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(16), mv.dp(12), mv.dp(16), mv.dp(14))
        }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = (if (p.style == "party") "🎉 " else "") + p.title
            textSize = 18f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (p.authorId.isNotEmpty() && p.authorId == Account.id(this)) titleRow.addView(TextView(this).apply {
            text = "⋯"
            textSize = 22f
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink_soft))
            setPadding(mv.dp(12), 0, mv.dp(4), mv.dp(4))
            setOnClickListener { v -> postMenu(v, p) }
        })
        body.addView(titleRow)
        if (p.caption.isNotEmpty()) body.addView(TextView(this).apply {
            text = p.caption
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            setPadding(0, mv.dp(6), 0, 0)
        })
        val whenT = p.takenAt.takeIf { it > 0 } ?: p.createdAt
        body.addView(ui.hint(listOf(p.author, if (whenT > 0) (if (p.takenAt > 0) "" else L.t("שותף: ", "Shared: ")) + Fmt.dayTime(whenT) else "", p.people, p.place).filter { it.isNotEmpty() }.joinToString(" · "), top = 2))
        if (p.story.isNotEmpty()) body.addView(TextView(this).apply {
            text = p.story
            textSize = 16f
            typeface = Typeface.SERIF
            setLineSpacing(mv.dp(3).toFloat(), 1f)
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            setPadding(0, mv.dp(8), 0, 0)
        })

        val reacts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (e in Circle.EMOJIS) {
            val all = f.reactions.filter { it.postId == p.id && it.emoji == e }
            val mine = all.any { it.authorId.isNotEmpty() && it.authorId == Account.id(this) }
            reacts.addView(mv.tag(e + if (all.isNotEmpty()) " ${all.size}" else "").apply {
                if (mine) background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = mv.dp(18).toFloat(); setColor(0xFFEFEFEF.toInt())
                }
                setOnClickListener {
                    scaleX = 0.8f; scaleY = 0.8f
                    animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                    worker.execute {
                        val failure = try { Circle.react(applicationContext, p.id, e, mine); null } catch (e: Exception) { e.message ?: L.t("התגובה לא נשמרה", "Reaction wasn't saved") }
                        runOnUiThread { if (!isDestroyed) { if (failure != null) toast(failure); load() } }
                    }
                }
                setOnLongClickListener { if (all.isNotEmpty()) toast(all.joinToString(", ") { r -> r.member }); true }
            })
        }
        val cs = f.comments.filter { it.postId == p.id }
        reacts.addView(mv.tag(if (cs.isEmpty()) L.t("תגובה", "Comment") else L.t("${cs.size} תגובות", "${cs.size} comments")).apply { setOnClickListener { addComment(p) } })
        body.addView(ui.scrollRow(reacts, top = 12))
        for (c in cs.takeLast(5)) body.addView(ui.text("${c.member}: ${c.body}", 15f, top = 6))
        if (cs.size > 5) body.addView(ui.action(L.t("כל ${cs.size} התגובות", "All ${cs.size} comments")) { showComments(p, cs) })
        body.addView(ui.action(L.t("שיחה על הזיכרון", "Chat about this memory")) { FamilyChatActivity.open(this, p.id, p.title) })
        box.addView(body)
        if (p.authorId.isNotEmpty() && p.authorId == Account.id(this)) box.setOnLongClickListener { postMenu(it, p); true }
        return box
    }

    /** Your own shared moment: edit (cut again, words, style) or delete. */
    private fun postMenu(anchor: View, p: Circle.Post) {
        val menu = android.widget.PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, L.t("עריכה: קטע, מילים ועיצוב", "Edit: clip, text and style"))
        menu.menu.add(0, 2, 1, L.t("מחיקה מהמעגל", "Remove from circle"))
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> ShareActivity.edit(this, p)
                2 -> AlertDialog.Builder(this).setTitle(L.t("למחוק את הרגע מהמעגל?", "Remove this moment from the circle?"))
                    .setMessage(L.t("הוא יימחק מהמעגל לכולם. הרגע עצמו נשאר אצלך בטלפון.", "It will be removed for everyone. The moment stays on your phone."))
                    .setPositiveButton(L.t("מחק", "Remove")) { _, _ ->
                        worker.execute {
                            val failure = try { Circle.deletePost(applicationContext, p); null } catch (e: Exception) { e.message ?: L.t("הזיכרון לא נמחק", "Couldn't remove the memory") }
                            runOnUiThread { if (!isFinishing) { if (failure != null) toast(failure); load() } }
                        }
                    }.setNegativeButton(L.t("ביטול", "Cancel"), null).show()
            }
            true
        }
        menu.show()
    }

    /** Pick one of your saved moments to share (newest first; shared ones are marked). */
    private fun pickMoment() {
        val all = MemoryStore.all(this).take(40)
        if (all.isEmpty()) {
            toast(L.t("עוד אין רגעים שמורים", "No saved moments yet"))
            return
        }
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(16), mv.dp(8), mv.dp(16), mv.dp(8))
        }
        val dialog = AlertDialog.Builder(this).setTitle(L.t("איזה רגע לשתף?", "Which moment to share?"))
            .setView(android.widget.ScrollView(this).apply { addView(grid) })
            .setNegativeButton(L.t("ביטול", "Cancel"), null).create()
        val cards = all.map { m ->
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val frame = FrameLayout(this@CircleActivity).apply {
                    setBackgroundResource(R.drawable.rounded_media)
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(120))
                }
                val iv = ImageView(this@CircleActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                }
                frame.addView(iv)
                Covers.load(iv, m)
                if (Circle.wasShared(this@CircleActivity, m)) {
                    frame.addView(TextView(this@CircleActivity).apply {
                    text = L.t("שותף", "Shared")
                    textSize = 11f
                    setTextColor(0xFFFFFFFF.toInt())
                    setBackgroundResource(R.drawable.pill_dark)
                    setPadding(mv.dp(8), mv.dp(3), mv.dp(8), mv.dp(3))
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                        setMargins(mv.dp(6), mv.dp(6), mv.dp(6), mv.dp(6))
                    }
                    })
                }
                addView(frame)
                addView(TextView(this@CircleActivity).apply {
                    text = Fmt.title(m)
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
                    setPadding(mv.dp(2), mv.dp(4), mv.dp(2), 0)
                })
                addView(TextView(this@CircleActivity).apply {
                    text = Fmt.dayTime(m.time)
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink_soft))
                    setPadding(mv.dp(2), 0, mv.dp(2), 0)
                })
                setOnClickListener {
                    dialog.dismiss()
                    ShareActivity.share(this@CircleActivity, m.id)
                }
            } as View
        }
        grid.addView(mv.grid(cards, 10))
        dialog.show()
    }

    private fun openMedia(p: Circle.Post) {
        try {
            val type = if (p.kind == "photo") "image/*" else "video/*"
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(p.video), type))
        } catch (_: Exception) {
            toast(L.t("אין באפליקציה נגן מתאים", "No compatible player found"))
        }
    }

    private fun addComment(p: Circle.Post) {
        val field = ui.field(L.t("כתבו משהו...", "Write something..."), "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle(p.title.ifEmpty { L.t("תגובה", "Comment") }).setView(box)
            .setPositiveButton(L.t("שלח", "Send")) { _, _ ->
                val text = field.text.toString().trim()
                if (text.isEmpty()) return@setPositiveButton
                worker.execute {
                    val failure = try { Circle.comment(applicationContext, p.id, text); null } catch (e: Exception) { e.message ?: L.t("התגובה לא נשלחה", "Comment wasn't sent") }
                    runOnUiThread { if (!isDestroyed) { if (failure != null) toast(failure); load() } }
                }
            }
            .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }

    private fun showComments(post: Circle.Post, comments: List<Circle.Comment>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(20), ui.dp(12), ui.dp(20), ui.dp(12)) }
        comments.forEach { box.addView(ui.text("${it.member}: ${it.body}", 15f, top = 8)) }
        AlertDialog.Builder(this).setTitle(post.title.ifBlank { L.t("תגובות המשפחה", "Family comments") })
            .setView(android.widget.ScrollView(this).apply { addView(box) }).setPositiveButton(L.t("סגור", "Close"), null).show()
    }

    private fun editMe() {
        val field = ui.field(L.t("איך תרצו להופיע למשפחה?", "How should your family see your name?"), Circle.me(this))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle(L.t("איך המשפחה תראה אותך?", "How your family sees you")).setView(box)
            .setPositiveButton(L.t("שמור", "Save")) { _, _ -> Circle.setMe(this, field.text.toString()); render() }
            .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }

    private fun invite() {
        if (worker.isShutdown) {
            return
        }
        worker.execute {
            val result = try { Circle.secureReady(applicationContext); Result.success(Circle.inviteLink(applicationContext)) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                result.onSuccess { link ->
                    val text = L.t("הצטרפו ל${Circle.name(this)} ❤️\nכאן נשתף יחד זיכרונות משפחתיים:\n$link", "Join ${Circle.name(this)} on Moments ❤️\nLet's share our family memories here:\n$link")
                    try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), L.t("להזמין את המשפחה", "Invite your family"))) }
                    catch (_: Exception) { toast(L.t("לא נמצאה אפליקציה לשליחת ההזמנה", "No app found to send the invite")) }
                }.onFailure { toast(it.message ?: L.t("לא הצלחנו להכין הזמנה", "Couldn't create the invite")) }
            }
        }
    }

    private fun askTitleAndShare(uri: Uri) {
        val field = ui.field(L.t("מה קורה כאן? (לא חובה)", "What's happening here? (optional)"), "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle(L.t("לשתף עם המשפחה", "Share with family")).setView(box)
            .setPositiveButton(L.t("שתף", "Share")) { _, _ ->
                val title = field.text.toString()
                run(L.t("רגע, אנחנו שומרים את הזיכרון הזה...", "Saving this memory...")) {
                    Circle.shareFromGallery(applicationContext, uri, title) { msg -> runOnUiThread { busyText = msg; if (!isFinishing) render() } }
                    L.t("שותף עם המשפחה ❤️", "Shared with your family ❤️")
                }
            }
            .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }
}
