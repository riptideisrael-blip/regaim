package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * "מעגל המשפחה" (prototype): one private feed for the whole family.
 * Parents share moments from the app; grandparents and relatives join from a web link, react and comment.
 */
class CircleActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context, postId: String? = null) = ctx.startActivity(Intent(ctx, CircleActivity::class.java).putExtra("post_id", postId))
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(2)
    private var feed: Circle.Feed? = null
    private var loading = false
    private var error = ""
    private var busyText = ""
    private var loadedUser = ""
    private var loadedCircle = ""

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) askTitleAndShare(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = "מעגל המשפחה"
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        if (loadedUser != Account.id(this) || loadedCircle != Circle.circleId(this) || !Account.signedIn(this)) { feed = null; error = "" }
        render()
        load()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        images.shutdownNow()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun load() {
        if (isFinishing || isDestroyed || worker.isShutdown) return
        if (!Circle.joined(this) || loading) return
        val requestedUser = Account.id(this)
        val requestedCircle = Circle.circleId(this)
        loading = true
        render()
        worker.execute {
            val r = try {
                var loaded = Circle.feed(applicationContext)
                intent.getStringExtra("post_id")?.let { id ->
                    val selected = loaded.posts.find { it.id == id } ?: Circle.postById(applicationContext, id)
                    loaded = Circle.Feed(listOfNotNull(selected), if (selected != null) Circle.reactionsForPost(applicationContext, id) else emptyList(), if (selected != null) Circle.commentsForPost(applicationContext, id) else emptyList())
                }
                Result.success(loaded)
            } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                loading = false
                if (isFinishing || requestedUser != Account.id(this) || requestedCircle != Circle.circleId(this)) return@runOnUiThread
                r.onSuccess { feed = it; error = ""; loadedUser = requestedUser; loadedCircle = requestedCircle }.onFailure { error = it.message ?: "אין חיבור כרגע" }
                render()
            }
        }
    }

    private fun render() {
        content.removeAllViews()
        content.addView(ui.hint("רגעים ששיתפתם ושיחות עם החברים המאושרים במעגל.", top = 0))
        when {
            !Circle.configured(this) -> serverSetup()
            !Circle.joined(this) -> createOrJoin()
            else -> circleHome()
        }
    }

    // ---------- step 1: the family's server ----------

    private fun serverSetup() {
        val card = ui.card(top = 16)
        card.addView(ui.text("חיבור לשרת של המשפחה", 18f, bold = true))
        card.addView(ui.hint("מ-Supabase: Project Settings ← API. מעתיקים את ה-Project URL ואת המפתח הציבורי (anon / publishable).", top = 4))
        val url = ui.field("https://xxxx.supabase.co", Circle.url(this))
        val key = ui.field("המפתח הציבורי", Circle.key(this))
        card.addView(url)
        card.addView(key)
        card.addView(ui.text("כתובת דף המשפחה (לסבא וסבתא)", 14f, R.color.ink_soft, top = 12))
        val web = ui.field(Circle.DEFAULT_WEB, Circle.web(this), top = 4)
        card.addView(web)
        card.addView(ui.hint("אם העלית את index.html ל-GitHub Pages של הריפו, השאר כמו שזה.", top = 4))
        card.addView(ui.button("שמור והמשך", primary = true, top = 14) {
            Circle.setServer(this, url.text.toString(), key.text.toString(), web.text.toString())
            if (key.text.toString().trim().startsWith("sb_secret")) {
                Circle.setServer(this, url.text.toString(), "", web.text.toString())
                toast("זה המפתח הסודי. צריך את המפתח הציבורי שמתחיל ב-sb_publishable")
            } else if (!Circle.configured(this)) toast("הכתובת צריכה להתחיל ב-https:// ולהגיע עם מפתח מלא")
            render()
        })
        content.addView(card)
    }

    // ---------- step 2: create or join ----------

    private fun createOrJoin() {
        if (!Account.signedIn(this)) {
            content.addView(ui.text("המשפחה שלכם, יחד בזיכרונות", 22f, bold = true, top = 22))
            content.addView(ui.hint("התחברו כדי לפתוח מעגל או לקבל הזמנה. הזיכרונות בטלפון זמינים גם בלי חשבון.", top = 8))
            content.addView(ui.button("התחברות למשפחה", primary = true, top = 16) { WelcomeActivity.open(this) })
            return
        }
        val card = ui.card(top = 16)
        card.addView(ui.text("פתחו מעגל משפחה", 18f, bold = true))
        val name = ui.field("שם המעגל", Profile.homeTitle(this))
        card.addView(name)
        card.addView(ui.button("צור מעגל", primary = true, top = 12) {
            run("פותחים את המעגל...") {
                Circle.create(applicationContext, name.text.toString().ifBlank { Profile.homeTitle(this) })
                "המעגל שלכם נפתח ❤️"
            }
        })
        card.addView(ui.divider())
        card.addView(ui.text("או הצטרפו למעגל קיים", 16f, bold = true, top = 6))
        val code = ui.field("קישור הזמנה או קוד הזמנה מאובטח", "")
        card.addView(code)
        card.addView(ui.button("הצטרף", top = 10) {
            run("מצטרפים...") {
                val input = code.text.toString().trim()
                val token = if (input.startsWith("https://")) Uri.parse(input).getQueryParameter("c") ?: "" else input
                Circle.join(applicationContext, token)
                "הצטרפתם ל${Circle.name(applicationContext)}"
            }
        })
        card.addView(ui.action("שינוי פרטי השרת", R.color.ink_soft) {
            Circle.setServer(this, "", "", Circle.web(this))
            render()
        })
        content.addView(card)
        if (error.isNotEmpty()) content.addView(ui.hint(error, top = 10))
    }

    private fun run(busy: String, work: () -> String) {
        if (worker.isShutdown || busyText.isNotEmpty()) return
        busyText = busy
        toast(busy)
        render()
        worker.execute {
            val r = try { Result.success(work()) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                busyText = ""
                if (isFinishing) return@runOnUiThread
                r.onSuccess { toast(it) }.onFailure { error = it.message ?: "משהו השתבש"; toast(error) }
                render()
                load()
            }
        }
    }

    // ---------- the circle ----------

    private fun circleHome() {
        val head = ui.card(top = 14)
        head.addView(ui.text(Circle.name(this), 20f, bold = true))
        head.addView(ui.hint("הזיכרונות משותפים לכל החברים המאושרים במעגל", top = 2))
        head.addView(ui.button("שיחה במשפחה", top = 8) { FamilyChatActivity.open(this) })
        head.addView(ui.button("💌 הזמינו את המשפחה", primary = true, top = 12) { invite() })
        head.addView(ui.button("＋ שתפו רגע ששמרתם", top = 8) { pickMoment() })
        val row = ui.horizontal(top = 4)
        row.addView(ui.action("＋ תמונה או סרטון") { AlertDialog.Builder(this).setItems(arrayOf("תמונה", "סרטון")) { _, i -> pick.launch(if (i == 0) "image/*" else "video/*") }.show() })
        row.addView(ui.action("✎ השם שלי") { editMe() })
        row.addView(ui.action("↻ רענן") { load(); toast("מרענן...") })
        head.addView(row)
        head.addView(ui.action("החליפו קישור הזמנה", R.color.ink_soft) {
            AlertDialog.Builder(this).setTitle("ליצור קישור חדש?")
                .setMessage("הקישור הישן יפסיק לצרף אנשים. החברים שכבר הצטרפו נשארים במעגל. הפעולה זמינה למנהל המשפחה.")
                .setPositiveButton("צור קישור") { _, _ -> run("יוצרים הזמנה חדשה...") { Circle.renewInvite(applicationContext); "קישור ההזמנה עודכן" } }
                .setNegativeButton("ביטול", null).show()
        })
        content.addView(head)
        if (busyText.isNotEmpty()) content.addView(ui.hint(busyText, top = 10).also { mv.pulse(it) })
        if (error.isNotEmpty()) content.addView(ui.hint(error, top = 10))

        val f = feed
        if (f == null) {
            content.addView(ui.hint(if (loading) "רגע, טוענים את הרגעים של המשפחה..." else "", top = 18))
            return
        }
        if (f.posts.isEmpty()) {
            val e = ui.card(top = 18)
            e.gravity = Gravity.CENTER_HORIZONTAL
            e.addView(TextView(this).apply { text = "❤️"; textSize = 40f; gravity = Gravity.CENTER })
            e.addView(ui.text("עדיין אין כאן רגעים", 19f, bold = true, top = 6).apply { gravity = Gravity.CENTER })
            e.addView(ui.text("פתחו רגע ולחצו \"שתף למעגל המשפחה\", או שתפו תמונה מהגלריה.", 15f, R.color.ink_soft, top = 6).apply { gravity = Gravity.CENTER })
            content.addView(e)
            return
        }
        f.posts.forEachIndexed { i, p ->
            val v = postCard(p, f)
            content.addView(v)
            if (i < 6) mv.reveal(v, i * 40L)
        }
        content.addView(ui.action("יציאה מהמעגל", R.color.ink_soft) {
            AlertDialog.Builder(this).setTitle("לצאת מהמעגל?")
                .setMessage("הרגעים במעגל נשארים. אפשר להצטרף שוב עם הקוד ${Circle.code(this)}.")
                .setPositiveButton("צא") { _, _ -> Circle.leave(this); feed = null; render() }
                .setNegativeButton("ביטול", null).show()
        })
    }

    private fun postCard(p: Circle.Post, f: Circle.Feed): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_bg)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = mv.dp(16) }
        }
        val media = FrameLayout(this).apply {
            setBackgroundColor(0xFFECE7E1.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(320))
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        media.addView(img)
        img.colorFilter = Circle.styleFilter(p.style)
        if (p.style == "party") media.foreground = android.graphics.drawable.GradientDrawable().apply {
            setStroke(mv.dp(5), 0xFFFFC94D.toInt())
        }
        val cover = p.cover.ifEmpty { if (p.kind == "photo") p.video else "" }
        img.tag = cover
        if (cover.isNotEmpty()) images.execute {
            val bmp = Circle.image(applicationContext, cover)
            runOnUiThread {
                if (bmp != null && img.tag == cover) {
                    img.alpha = 0f
                    img.setImageBitmap(bmp)
                    img.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
        if (p.kind != "photo") media.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            setColorFilter(ContextCompat.getColor(this@CircleActivity, R.color.white))
            setBackgroundResource(R.drawable.play_circle)
            val pad = mv.dp(18)
            setPadding(pad, pad, pad, pad)
            layoutParams = FrameLayout.LayoutParams(mv.dp(64), mv.dp(64), Gravity.CENTER)
        })
        media.setOnClickListener { openMedia(p) }
        box.addView(media)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(16), mv.dp(12), mv.dp(16), mv.dp(14))
        }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = (if (p.style == "party") "🎉 " else "") + p.title
            textSize = 18f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (p.authorId.isNotEmpty() && p.authorId == Account.id(this)) titleRow.addView(TextView(this).apply {
            text = "⋯"
            textSize = 22f
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink_soft))
            setPadding(mv.dp(12), 0, mv.dp(4), mv.dp(4))
            setOnClickListener { v -> postMenu(v, p) }
        })
        body.addView(titleRow)
        if (p.caption.isNotEmpty()) body.addView(TextView(this).apply {
            text = p.caption
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            setPadding(0, mv.dp(6), 0, 0)
        })
        val whenT = p.takenAt.takeIf { it > 0 } ?: p.createdAt
        body.addView(ui.hint(listOf(p.author, if (whenT > 0) (if (p.takenAt > 0) "" else "שותף: ") + Fmt.dayTime(whenT) else "", p.people, p.place).filter { it.isNotEmpty() }.joinToString(" · "), top = 2))
        if (p.story.isNotEmpty()) body.addView(TextView(this).apply {
            text = p.story
            textSize = 16f
            typeface = Typeface.SERIF
            setLineSpacing(mv.dp(3).toFloat(), 1f)
            setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
            setPadding(0, mv.dp(8), 0, 0)
        })

        val reacts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (e in Circle.EMOJIS) {
            val all = f.reactions.filter { it.postId == p.id && it.emoji == e }
            val mine = all.any { it.authorId.isNotEmpty() && it.authorId == Account.id(this) }
            reacts.addView(mv.tag(e + if (all.isNotEmpty()) " ${all.size}" else "").apply {
                if (mine) background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = mv.dp(18).toFloat(); setColor(0xFFE9E7FB.toInt())
                }
                setOnClickListener {
                    scaleX = 0.8f; scaleY = 0.8f
                    animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                    worker.execute {
                        val failure = try { Circle.react(applicationContext, p.id, e, mine); null } catch (e: Exception) { e.message ?: "התגובה לא נשמרה" }
                        runOnUiThread { if (!isDestroyed) { if (failure != null) toast(failure); load() } }
                    }
                }
                setOnLongClickListener { if (all.isNotEmpty()) toast(all.joinToString(", ") { r -> r.member }); true }
            })
        }
        val cs = f.comments.filter { it.postId == p.id }
        reacts.addView(mv.tag("💬 ${if (cs.isEmpty()) "" else cs.size}").apply { setOnClickListener { addComment(p) } })
        body.addView(ui.scrollRow(reacts, top = 12))
        for (c in cs.takeLast(5)) body.addView(ui.text("${c.member}: ${c.body}", 15f, top = 6))
        if (cs.size > 5) body.addView(ui.action("כל ${cs.size} התגובות") { showComments(p, cs) })
        body.addView(ui.action("שיחה על הזיכרון") { FamilyChatActivity.open(this, p.id, p.title) })
        box.addView(body)
        if (p.authorId.isNotEmpty() && p.authorId == Account.id(this)) box.setOnLongClickListener { postMenu(it, p); true }
        return box
    }

    /** Your own shared moment: edit (cut again, words, style) or delete. */
    private fun postMenu(anchor: View, p: Circle.Post) {
        val menu = android.widget.PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "✎ עריכה: קטע, מילים ועיצוב")
        menu.menu.add(0, 2, 1, "🗑 מחיקה מהמעגל")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> ShareActivity.edit(this, p)
                2 -> AlertDialog.Builder(this).setTitle("למחוק את הרגע מהמעגל?")
                    .setMessage("הוא יימחק מהמעגל לכולם. הרגע עצמו נשאר אצלך בטלפון.")
                    .setPositiveButton("מחק") { _, _ ->
                        worker.execute {
                            val failure = try { Circle.deletePost(applicationContext, p); null } catch (e: Exception) { e.message ?: "הזיכרון לא נמחק" }
                            runOnUiThread { if (!isFinishing) { if (failure != null) toast(failure); load() } }
                        }
                    }.setNegativeButton("ביטול", null).show()
            }
            true
        }
        menu.show()
    }

    /** Pick one of your saved moments to share (newest first; shared ones are marked). */
    private fun pickMoment() {
        val all = MemoryStore.all(this).take(40)
        if (all.isEmpty()) {
            toast("עוד אין רגעים שמורים")
            return
        }
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(16), mv.dp(8), mv.dp(16), mv.dp(8))
        }
        val dialog = AlertDialog.Builder(this).setTitle("איזה רגע לשתף?")
            .setView(android.widget.ScrollView(this).apply { addView(grid) })
            .setNegativeButton("ביטול", null).create()
        val cards = all.map { m ->
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val frame = FrameLayout(this@CircleActivity).apply {
                    setBackgroundResource(R.drawable.rounded_media)
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(120))
                }
                val iv = ImageView(this@CircleActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                }
                frame.addView(iv)
                Covers.load(iv, m)
                if (Circle.wasShared(this@CircleActivity, m)) {
                    frame.addView(TextView(this@CircleActivity).apply {
                    text = "💌 שותף"
                    textSize = 11f
                    setTextColor(0xFFFFFFFF.toInt())
                    setBackgroundResource(R.drawable.pill_dark)
                    setPadding(mv.dp(8), mv.dp(3), mv.dp(8), mv.dp(3))
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT).apply {
                        setMargins(mv.dp(6), mv.dp(6), mv.dp(6), mv.dp(6))
                    }
                    })
                }
                addView(frame)
                addView(TextView(this@CircleActivity).apply {
                    text = Fmt.title(m)
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink))
                    setPadding(mv.dp(2), mv.dp(4), mv.dp(2), 0)
                })
                addView(TextView(this@CircleActivity).apply {
                    text = Fmt.dayTime(m.time)
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@CircleActivity, R.color.ink_soft))
                    setPadding(mv.dp(2), 0, mv.dp(2), 0)
                })
                setOnClickListener {
                    dialog.dismiss()
                    ShareActivity.share(this@CircleActivity, m.id)
                }
            } as View
        }
        grid.addView(mv.grid(cards, 10))
        dialog.show()
    }

    private fun openMedia(p: Circle.Post) {
        try {
            val type = if (p.kind == "photo") "image/*" else "video/*"
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(p.video), type))
        } catch (_: Exception) {
            toast("אין באפליקציה נגן מתאים")
        }
    }

    private fun addComment(p: Circle.Post) {
        val field = ui.field("כתבו משהו...", "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle(p.title.ifEmpty { "תגובה" }).setView(box)
            .setPositiveButton("שלח") { _, _ ->
                val text = field.text.toString().trim()
                if (text.isEmpty()) return@setPositiveButton
                worker.execute {
                    val failure = try { Circle.comment(applicationContext, p.id, text); null } catch (e: Exception) { e.message ?: "התגובה לא נשלחה" }
                    runOnUiThread { if (!isDestroyed) { if (failure != null) toast(failure); load() } }
                }
            }
            .setNegativeButton("ביטול", null).show()
    }

    private fun showComments(post: Circle.Post, comments: List<Circle.Comment>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(20), ui.dp(12), ui.dp(20), ui.dp(12)) }
        comments.forEach { box.addView(ui.text("${it.member}: ${it.body}", 15f, top = 8)) }
        AlertDialog.Builder(this).setTitle(post.title.ifBlank { "תגובות המשפחה" })
            .setView(android.widget.ScrollView(this).apply { addView(box) }).setPositiveButton("סגור", null).show()
    }

    private fun editMe() {
        val field = ui.field("איך תרצו להופיע למשפחה?", Circle.me(this))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle("איך המשפחה תראה אותך?").setView(box)
            .setPositiveButton("שמור") { _, _ -> Circle.setMe(this, field.text.toString()); render() }
            .setNegativeButton("ביטול", null).show()
    }

    private fun invite() {
        if (worker.isShutdown) {
            return
        }
        worker.execute {
            val result = try { Circle.secureReady(applicationContext); Result.success(Circle.inviteLink(applicationContext)) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                result.onSuccess { link ->
                    val text = "הצטרפו ל${Circle.name(this)} ❤️\nכאן נשתף יחד זיכרונות משפחתיים:\n$link"
                    try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "להזמין את המשפחה")) }
                    catch (_: Exception) { toast("לא נמצאה אפליקציה לשליחת ההזמנה") }
                }.onFailure { toast(it.message ?: "לא הצלחנו להכין הזמנה") }
            }
        }
    }

    private fun askTitleAndShare(uri: Uri) {
        val field = ui.field("מה קורה כאן? (לא חובה)", "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(20), mv.dp(8), mv.dp(20), 0)
            addView(field)
        }
        AlertDialog.Builder(this).setTitle("לשתף עם המשפחה").setView(box)
            .setPositiveButton("שתף") { _, _ ->
                val title = field.text.toString()
                run("רגע, אנחנו שומרים את הזיכרון הזה...") {
                    Circle.shareFromGallery(applicationContext, uri, title) { msg -> runOnUiThread { busyText = msg; if (!isFinishing) render() } }
                    "שותף עם המשפחה ❤️"
                }
            }
            .setNegativeButton("ביטול", null).show()
    }
}
