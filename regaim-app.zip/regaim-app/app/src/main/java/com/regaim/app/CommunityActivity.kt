package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.format.DateUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.util.concurrent.Executors

/**
 * "הקהילה": the public feed. Only moments that people deliberately published here.
 * Like (also with a double tap), comment, report, block. Needs the server file community-v4.sql.
 */
class CommunityActivity : AppCompatActivity() {

    companion object {
        /** Set after publishing, so the feed reloads when it comes back on screen. */
        @Volatile var dirty = false
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, CommunityActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(3)
    private val posts = mutableListOf<Community.Post>()
    private var more = false
    private var loading = false
    private var loaded = false
    private var error = ""
    private var playing: VideoView? = null
    private var termsOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = "הקהילה"
        findViewById<View>(R.id.btnClose).visibility = View.GONE
        findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
        Nav.setup(this, Nav.Tab.FAMILY)
    }

    override fun onResume() {
        super.onResume()
        if (Community.available(this) && !Community.termsAccepted(this)) {
            render()
            if (!termsOpen) showTerms()
            return
        }
        if (dirty || (!loaded && !loading)) { dirty = false; reload() } else render()
    }

    override fun onPause() {
        super.onPause()
        stopVideo()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        images.shutdownNow()
        super.onDestroy()
    }

    // ---------- data ----------

    private fun reload() {
        if (!Community.available(this)) { render(); return }
        posts.clear(); more = false; error = ""
        fetch(0L)
    }

    private fun fetch(before: Long) {
        if (loading || worker.isShutdown) return
        loading = true
        render()
        worker.execute {
            val r = try { Result.success(Community.feed(applicationContext, before)) } catch (e: Exception) { Result.failure<Community.Page>(e) }
            runOnUiThread {
                loading = false
                loaded = true
                if (isFinishing || isDestroyed) return@runOnUiThread
                r.onSuccess { posts.addAll(it.posts); more = it.more; error = "" }
                    .onFailure { error = it.message ?: "לא הצלחנו לפתוח את הקהילה" }
                render()
            }
        }
    }

    private fun showTerms() {
        termsOpen = true
        AlertDialog.Builder(this)
            .setTitle("כללי הקהילה")
            .setMessage(
                "• מפרסמים רק רגעים שיש לכם זכות לפרסם.\n" +
                "• בלי תוכן פוגעני, ובלי פרטים מזהים של ילדים (כתובת, בית ספר, שם מלא).\n" +
                "• רק השם הפרטי שלכם מוצג, ומיקום לא מתפרסם.\n" +
                "• אפשר למחוק את מה שפרסמתם בכל רגע.\n" +
                "• אפשר לדווח על רגע או לחסום משתמש. רגע שדווח עליו שלוש פעמים מוסתר עד שנבדוק אותו."
            )
            .setPositiveButton("הבנתי, ממשיכים") { _, _ -> termsOpen = false; Community.acceptTerms(this); reload() }
            .setNegativeButton("לא עכשיו") { _, _ -> termsOpen = false; startActivity(Intent(this, FamilyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)); finish() }
            .setCancelable(false)
            .show()
    }

    // ---------- page ----------

    private fun segmented() {
        content.addView(ui.chips(listOf("המשפחה", "הקהילה"), 1, top = 6) { i ->
            if (i == 0) {
                startActivity(Intent(this, FamilyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                @Suppress("DEPRECATION") overridePendingTransition(0, 0)
                finish()
            }
        })
    }

    private fun render() {
        stopVideo()
        content.removeAllViews()
        segmented()
        if (!Community.available(this)) {
            val card = ui.card(top = 16)
            card.addView(ui.text("🌍 הקהילה של Moments", 20f, bold = true))
            card.addView(ui.hint("רגעים שמשתמשים בחרו לפרסם לכולם. כדי לראות ולפרסם צריך חשבון.", top = 6))
            card.addView(ui.button("התחברות או הרשמה", primary = true, top = 14) { WelcomeActivity.open(this) })
            content.addView(card)
            return
        }
        content.addView(composer())
        if (error.isNotEmpty()) {
            val card = ui.card(top = 14)
            card.addView(ui.text(error, 15f))
            card.addView(ui.button("נסו שוב", primary = true, top = 12) { reload() })
            content.addView(card)
        }
        for ((i, p) in posts.toList().withIndex()) {
            val v = postCard(p)
            content.addView(v)
            if (i < 3) mv.reveal(v, i * 50L)
        }
        if (loading) content.addView(ui.hint("טוענים...", top = 16).apply { gravity = Gravity.CENTER })
        if (!loading && error.isEmpty() && posts.isEmpty()) {
            val box = ui.card(top = 16)
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.addView(TextView(this).apply { text = "🌱"; textSize = 40f; gravity = Gravity.CENTER })
            box.addView(ui.text("הקהילה רק מתחילה", 19f, bold = true, top = 8).apply { gravity = Gravity.CENTER })
            box.addView(ui.hint("היו הראשונים לפרסם רגע טוב. רק מה שתבחרו מתפרסם.", top = 6).apply { gravity = Gravity.CENTER })
            content.addView(box)
        }
        if (more && !loading) content.addView(ui.button("עוד רגעים", top = 16) { fetch(posts.last().createdAt) })
        if (loaded && !loading) content.addView(ui.action("רענון") { reload() }.apply { gravity = Gravity.CENTER })
    }

    /** "What's your moment today?" Opens the picker of your memories, then the publish sheet. */
    private fun composer(): View {
        val card = ui.card(top = 14)
        val row = ui.horizontal(top = 0)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(mv.avatar(Community.displayName(this), 40))
        row.addView(TextView(this).apply {
            text = "איזה רגע תרצו לפרסם?"
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.ink_soft))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            background = GradientDrawable().apply { cornerRadius = ui.dp(22).toFloat(); setColor(0xFFF1EEE9.toInt()) }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = ui.dp(12) }
        })
        card.addView(row)
        card.setOnClickListener { pickMemory() }
        return card
    }

    private fun pickMemory() {
        val all = MemoryStore.all(this).take(24)
        if (all.isEmpty()) {
            Toast.makeText(this, "עוד אין לכם רגעים לפרסם. צלמו או הוסיפו רגע ונחזור לפה.", Toast.LENGTH_LONG).show()
            return
        }
        val dialog = BottomSheetDialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(24))
        }
        box.addView(ui.text("בחרו רגע לפרסום", 18f, bold = true))
        val views = all.map { m ->
            mv.gridCard(m) { dialog.dismiss(); PublishSheet.show(this, m, Community.lastAudience(this).let { if (it == "family") "community" else it }) { dirty = true; reload() } }
        }
        box.addView(mv.grid(views, 10))
        dialog.setContentView(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    // ---------- a post ----------

    private class State(var liked: Boolean, var likes: Int, var comments: Int)

    private fun postCard(p: Community.Post): View {
        val me = Account.id(this)
        val st = State(p.liked, p.likes, p.comments)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_white)
            elevation = ui.dp(2).toFloat()
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(16) }
        }

        // header
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(14), ui.dp(12), ui.dp(6), ui.dp(10))
        }
        head.addView(mv.avatar(p.author, 40))
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(12), 0, ui.dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        names.addView(ui.text(p.author, 15f, bold = true))
        val sub = DateUtils.getRelativeTimeSpanString(p.createdAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString() +
            (if (p.hidden) " · מוסתר" else "") + (if (p.reports > 0) " · 🚩 ${p.reports}" else "")
        names.addView(ui.hint(sub, top = 1))
        head.addView(names)
        head.addView(TextView(this).apply {
            text = "⋯"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.ink_soft))
            setPadding(ui.dp(12), 0, ui.dp(12), 0)
            contentDescription = "עוד אפשרויות"
            setOnClickListener { menu(it, p, me) }
        })
        box.addView(head)

        // media (4:5), double tap = like
        val width = resources.displayMetrics.widthPixels - ui.dp(40)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(0xFFECE7E1.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (width * 1.25f).toInt())
        }
        val pic = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            tag = p.image
        }
        frame.addView(pic)
        loadImage(pic, p.image)
        val badge = TextView(this).apply {
            text = "▶"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
            layoutParams = FrameLayout.LayoutParams(ui.dp(64), ui.dp(64), Gravity.CENTER)
            visibility = if (p.isVideo) View.VISIBLE else View.GONE
        }
        frame.addView(badge)
        val pop = TextView(this).apply {
            text = "❤️"
            textSize = 84f
            gravity = Gravity.CENTER
            alpha = 0f
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        }
        frame.addView(pop)
        box.addView(frame)

        // actions
        val heart = ImageView(this)
        val likeCount = TextView(this)
        val commentCount = TextView(this)
        fun paintLike() {
            heart.setImageResource(if (st.liked) R.drawable.ic_heart else R.drawable.ic_heart_outline)
            heart.setColorFilter(ContextCompat.getColor(this, if (st.liked) R.color.heart else R.color.ink))
            likeCount.text = if (st.likes > 0) st.likes.toString() else ""
            commentCount.text = if (st.comments > 0) st.comments.toString() else ""
        }
        fun toggleLike(on: Boolean? = null) {
            val want = on ?: !st.liked
            if (want == st.liked) return
            st.liked = want
            st.likes += if (want) 1 else -1
            paintLike()
            heart.animate().scaleX(1.3f).scaleY(1.3f).setDuration(110).withEndAction { heart.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start()
            worker.execute {
                try { Community.setLike(applicationContext, p.id, want) } catch (e: Exception) {
                    runOnUiThread {
                        st.liked = !want; st.likes += if (want) -1 else 1; paintLike()
                        Toast.makeText(this, e.message ?: "לא הצלחנו", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleLike(true)
                pop.scaleX = 0.5f; pop.scaleY = 0.5f; pop.alpha = 1f
                pop.animate().scaleX(1.1f).scaleY(1.1f).setDuration(260).withEndAction { pop.animate().alpha(0f).setDuration(220).start() }.start()
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (p.isVideo) playVideo(frame, pic, badge, p)
                return true
            }
        })
        frame.setOnTouchListener { _, e -> gesture.onTouchEvent(e) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(10), ui.dp(6), ui.dp(14), ui.dp(2))
        }
        fun tap(icon: View, label: TextView, onClick: () -> Unit) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(6), ui.dp(8), ui.dp(12), ui.dp(8))
                setOnClickListener { onClick() }
            }
            icon.layoutParams = LinearLayout.LayoutParams(ui.dp(26), ui.dp(26))
            label.textSize = 14f
            label.setTextColor(ContextCompat.getColor(this, R.color.ink))
            label.setPadding(ui.dp(6), 0, 0, 0)
            cell.addView(icon); cell.addView(label)
            bar.addView(cell)
        }
        tap(heart, likeCount) { toggleLike() }
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.ic_comment)
            setColorFilter(ContextCompat.getColor(this@CommunityActivity, R.color.ink))
        }
        tap(bubble, commentCount) { openComments(p, st) { c -> st.comments = c; paintLike() } }
        paintLike()
        box.addView(bar)

        // words
        if (p.title.isNotBlank() || p.caption.isNotBlank()) {
            val words = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ui.dp(16), ui.dp(2), ui.dp(16), ui.dp(14))
            }
            if (p.title.isNotBlank()) words.addView(ui.text(p.title, 16f, bold = true))
            if (p.caption.isNotBlank()) words.addView(ui.text(p.caption, 15f, top = if (p.title.isNotBlank()) 4 else 0))
            box.addView(words)
        } else {
            box.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, ui.dp(10)) })
        }
        return box
    }

    private fun loadImage(iv: ImageView, url: String) {
        if (url.isEmpty()) return
        iv.setImageDrawable(ColorDrawable(0xFFECE7E1.toInt()))
        if (images.isShutdown) return
        images.execute {
            val bmp = Community.image(applicationContext, url)
            runOnUiThread {
                if (bmp != null && iv.tag == url && !isDestroyed) {
                    iv.alpha = 0f
                    iv.setImageBitmap(bmp)
                    iv.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
    }

    // ---------- video ----------

    private fun stopVideo() {
        playing?.let { v ->
            try { v.stopPlayback() } catch (_: Exception) {}
            (v.parent as? ViewGroup)?.let { parent ->
                parent.removeView(v)
                for (i in 0 until parent.childCount) {
                    val c = parent.getChildAt(i)
                    if (c is TextView && c.text == "▶") c.visibility = View.VISIBLE
                    if (c is ImageView) c.visibility = View.VISIBLE
                }
            }
        }
        playing = null
    }

    private fun playVideo(frame: FrameLayout, pic: ImageView, badge: View, p: Community.Post) {
        val current = playing
        if (current != null && current.parent === frame) {
            if (current.isPlaying) current.pause() else current.start()
            return
        }
        stopVideo()
        val v = VideoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        }
        frame.addView(v, 1)
        badge.visibility = View.GONE
        v.setOnPreparedListener { mp ->
            mp.isLooping = true
            v.start()
            pic.visibility = View.GONE
        }
        v.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "לא הצלחנו לנגן את הסרטון", Toast.LENGTH_SHORT).show()
            stopVideo()
            true
        }
        v.setVideoURI(Uri.parse(p.mediaUrl))
        playing = v
    }

    // ---------- menu, report, block ----------

    private fun menu(anchor: View, p: Community.Post, me: String) {
        val m = PopupMenu(this, anchor)
        val own = p.authorId == me
        if (own) m.menu.add(0, 1, 0, "מחיקת הרגע")
        else {
            m.menu.add(0, 2, 0, "דיווח על הרגע")
            m.menu.add(0, 3, 1, "חסימת ${p.author}")
        }
        if (Account.isAdmin(this)) {
            m.menu.add(0, 4, 2, if (p.hidden) "ביטול הסתרה (מנהל)" else "הסתרה (מנהל)")
            if (!own) m.menu.add(0, 5, 3, "מחיקה (מנהל)")
        }
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1, 5 -> confirmDelete(p)
                2 -> reportDialog(p)
                3 -> confirmBlock(p)
                4 -> background("מעדכנים...") { Community.setHidden(applicationContext, p.id, !p.hidden) }
            }
            true
        }
        m.show()
    }

    private fun background(msg: String, done: String = "", work: () -> Unit) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        worker.execute {
            val err = try { work(); null } catch (e: Exception) { e.message ?: "משהו השתבש" }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                else { if (done.isNotEmpty()) Toast.makeText(this, done, Toast.LENGTH_SHORT).show(); reload() }
            }
        }
    }

    private fun confirmDelete(p: Community.Post) {
        AlertDialog.Builder(this).setTitle("למחוק את הרגע מהקהילה?")
            .setMessage("הוא יימחק לכולם. הרגע המקורי נשאר אצלכם בטלפון.")
            .setPositiveButton("מחיקה") { _, _ -> background("מוחקים...", "נמחק") { Community.delete(applicationContext, p) } }
            .setNegativeButton("ביטול", null).show()
    }

    private fun reportDialog(p: Community.Post) {
        AlertDialog.Builder(this).setTitle("מה הבעיה ברגע הזה?")
            .setItems(Community.REPORT_REASONS.toTypedArray()) { _, i ->
                worker.execute {
                    val err = try { Community.report(applicationContext, p.id, Community.REPORT_REASONS[i]); null } catch (e: Exception) { e.message }
                    runOnUiThread { Toast.makeText(this, err ?: "תודה, הדיווח התקבל", Toast.LENGTH_LONG).show() }
                }
            }.setNegativeButton("ביטול", null).show()
    }

    private fun confirmBlock(p: Community.Post) {
        AlertDialog.Builder(this).setTitle("לחסום את ${p.author}?")
            .setMessage("לא תראו יותר רגעים מהמשתמש הזה.")
            .setPositiveButton("חסימה") { _, _ -> background("חוסמים...", "נחסם") { Community.block(applicationContext, p.authorId) } }
            .setNegativeButton("ביטול", null).show()
    }

    // ---------- comments ----------

    private fun openComments(p: Community.Post, st: State, onCount: (Int) -> Unit) {
        val dialog = BottomSheetDialog(this)
        val me = Account.id(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(16))
        }
        root.addView(ui.text("תגובות", 18f, bold = true))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(300)).apply { topMargin = ui.dp(8) }
            addView(list)
        }
        root.addView(scroll)
        val input = EditText(this).apply {
            hint = "כתבו תגובה..."
            textSize = 15f
            maxLines = 3
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            background = GradientDrawable().apply { cornerRadius = ui.dp(22).toFloat(); setColor(0xFFF1EEE9.toInt()) }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val send = TextView(this).apply {
            text = "שליחה"
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.accent))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(4), ui.dp(10))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(input); row.addView(send)
        root.addView(row)

        var shown = emptyList<Community.Comment>()
        fun draw() {
            list.removeAllViews()
            if (shown.isEmpty()) list.addView(ui.hint("עוד אין תגובות. היו הראשונים.", top = 12))
            for (c in shown) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, ui.dp(10), 0, ui.dp(2))
                }
                line.addView(mv.avatar(c.author, 32))
                val texts = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(ui.dp(10), 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                texts.addView(ui.text(c.author, 13f, bold = true))
                texts.addView(ui.text(c.body, 15f, top = 1))
                line.addView(texts)
                if (c.authorId == me || p.authorId == me || Account.isAdmin(this)) {
                    line.setOnLongClickListener {
                        AlertDialog.Builder(this).setTitle("למחוק את התגובה?")
                            .setPositiveButton("מחיקה") { _, _ ->
                                worker.execute {
                                    try { Community.deleteComment(applicationContext, c.id) } catch (_: Exception) {}
                                    runOnUiThread { shown = shown.filter { it.id != c.id }; onCount(shown.size); draw() }
                                }
                            }.setNegativeButton("ביטול", null).show()
                        true
                    }
                }
                list.addView(line)
            }
        }
        fun load() {
            worker.execute {
                val r = try { Community.comments(applicationContext, p.id) } catch (_: Exception) { null }
                runOnUiThread {
                    if (r != null) { shown = r; onCount(r.size) }
                    if (!isDestroyed) draw()
                }
            }
        }
        send.setOnClickListener {
            val body = input.text.toString().trim()
            if (body.isEmpty()) return@setOnClickListener
            input.setText("")
            worker.execute {
                val err = try { Community.addComment(applicationContext, p.id, body); null } catch (e: Exception) { e.message }
                runOnUiThread { if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show() else load() }
            }
        }
        draw()
        load()
        dialog.setContentView(root)
        dialog.show()
    }
}
