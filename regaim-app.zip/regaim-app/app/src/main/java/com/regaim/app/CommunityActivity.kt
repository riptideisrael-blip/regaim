package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.format.DateUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.util.concurrent.Executors

/**
 * "הקהילה": the public feed. Only moments that people deliberately published here.
 * Like (also with a double tap), comment, report, block. Needs the server file community-v4.sql.
 */
class CommunityActivity : AppCompatActivity() {

    companion object {
        /** Set after publishing, so the feed reloads when it comes back on screen. */
        @Volatile var dirty = false
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, CommunityActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private lateinit var ui: Ui
    private lateinit var mv: MemoryViews
    private lateinit var content: LinearLayout
    private val worker = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(3)
    private val posts = mutableListOf<Community.Post>()
    private var more = false
    private var loading = false
    private var loaded = false
    private var error = ""
    private var playing: FillVideoView? = null
    private var termsOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        ui = Ui(this)
        mv = MemoryViews(this)
        content = findViewById(R.id.screenContent)
        findViewById<TextView>(R.id.screenTitle).text = L.t("הקהילה", "Community")
        findViewById<View>(R.id.btnClose).visibility = View.GONE
        findViewById<View>(R.id.bottomNav).visibility = View.VISIBLE
        Nav.setup(this, Nav.Tab.COMMUNITY)
        Nav.addProfileButton(this, findViewById<View>(R.id.screenTitle).parent as android.view.ViewGroup)
    }

    override fun onResume() {
        super.onResume()
        if (Community.available(this) && !Community.termsAccepted(this)) {
            render()
            if (!termsOpen) showTerms()
            return
        }
        if (dirty || (!loaded && !loading)) { dirty = false; reload() } else render()
    }

    override fun onPause() {
        super.onPause()
        stopVideo()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        images.shutdownNow()
        super.onDestroy()
    }

    // ---------- data ----------

    private fun reload() {
        if (!Community.available(this)) { render(); return }
        posts.clear(); more = false; error = ""
        fetch(0L)
    }

    private fun fetch(before: Long) {
        if (loading || worker.isShutdown) return
        loading = true
        render()
        worker.execute {
            val r = try { Result.success(Community.feed(applicationContext, before)) } catch (e: Exception) { Result.failure<Community.Page>(e) }
            runOnUiThread {
                loading = false
                loaded = true
                if (isFinishing || isDestroyed) return@runOnUiThread
                r.onSuccess { posts.addAll(it.posts); more = it.more; error = "" }
                    .onFailure { error = it.message ?: L.t("לא הצלחנו לפתוח את הקהילה", "Couldn't open the community") }
                render()
            }
        }
    }

    private fun showTerms() {
        termsOpen = true
        AlertDialog.Builder(this)
            .setTitle(L.t("כללי הקהילה", "Community guidelines"))
            .setMessage(
                L.t(
                    "• מפרסמים רק רגעים שיש לכם זכות לפרסם.\n" +
                    "• בלי תוכן פוגעני, ובלי פרטים מזהים של ילדים (כתובת, בית ספר, שם מלא).\n" +
                    "• רק השם הפרטי שלכם מוצג, ומיקום לא מתפרסם.\n" +
                    "• אפשר למחוק את מה שפרסמתם בכל רגע.\n" +
                    "• אפשר לדווח על רגע או לחסום משתמש. רגע שדווח עליו שלוש פעמים מוסתר עד שנבדוק אותו.",
                    "• Only share moments you have the right to share.\n" +
                    "• No offensive content, and no identifying details about children (address, school, full name).\n" +
                    "• Only your first name is shown, and location is never shared.\n" +
                    "• You can delete anything you've shared at any time.\n" +
                    "• You can report a moment or block someone. A moment reported three times is hidden until we review it.",
                )
            )
            .setPositiveButton(L.t("הבנתי, ממשיכים", "Got it, continue")) { _, _ -> termsOpen = false; Community.acceptTerms(this); reload() }
            .setNegativeButton(L.t("לא עכשיו", "Not now")) { _, _ -> termsOpen = false; startActivity(Intent(this, FamilyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)); finish() }
            .setCancelable(false)
            .show()
    }

    // ---------- page ----------

    private fun segmented() {
        content.addView(ui.chips(listOf(L.t("המשפחה", "Family"), L.t("הקהילה", "Community")), 1, top = 6) { i ->
            if (i == 0) {
                startActivity(Intent(this, FamilyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                @Suppress("DEPRECATION") overridePendingTransition(0, 0)
                finish()
            }
        })
    }

    private fun render() {
        stopVideo()
        content.removeAllViews()
        segmented()
        if (!Community.available(this)) {
            val card = ui.card(top = 16)
            card.addView(ui.text(L.t("🌍 הקהילה של Moments", "🌍 The Moments community"), 20f, bold = true))
            card.addView(ui.hint(L.t("רגעים שמשתמשים בחרו לפרסם לכולם. כדי לראות ולפרסם צריך חשבון.", "Moments people chose to share with everyone. You'll need an account to view and share."), top = 6))
            card.addView(ui.button(L.t("התחברות או הרשמה", "Sign in or sign up"), primary = true, top = 14) { WelcomeActivity.open(this) })
            content.addView(card)
            return
        }
        content.addView(composer())
        if (error.isNotEmpty()) {
            val card = ui.card(top = 14)
            card.addView(ui.text(error, 15f))
            card.addView(ui.button(L.t("נסו שוב", "Try again"), primary = true, top = 12) { reload() })
            content.addView(card)
        }
        for ((i, p) in posts.toList().withIndex()) {
            val v = postCard(p)
            content.addView(v)
            if (i < 3) mv.reveal(v, i * 50L)
        }
        if (loading) content.addView(ui.hint(L.t("טוענים...", "Loading…"), top = 16).apply { gravity = Gravity.CENTER })
        if (!loading && error.isEmpty() && posts.isEmpty()) {
            val box = ui.card(top = 16)
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.addView(TextView(this).apply { text = "🌱"; textSize = 40f; gravity = Gravity.CENTER })
            box.addView(ui.text(L.t("הקהילה רק מתחילה", "The community is just getting started"), 19f, bold = true, top = 8).apply { gravity = Gravity.CENTER })
            box.addView(ui.hint(L.t("היו הראשונים לפרסם רגע טוב. רק מה שתבחרו מתפרסם.", "Be the first to share a great moment. Only what you choose gets shared."), top = 6).apply { gravity = Gravity.CENTER })
            content.addView(box)
        }
        if (more && !loading) content.addView(ui.button(L.t("עוד רגעים", "More moments"), top = 16) { fetch(posts.last().createdAt) })
        if (loaded && !loading) content.addView(ui.action(L.t("רענון", "Refresh")) { reload() }.apply { gravity = Gravity.CENTER })
    }

    /** "What's your moment today?" Opens the picker of your memories, then the publish sheet. */
    private fun composer(): View {
        val card = ui.card(top = 14)
        val row = ui.horizontal(top = 0)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(mv.avatar(Community.displayName(this), 40))
        row.addView(TextView(this).apply {
            text = L.t("איזה רגע תרצו לפרסם?", "Which moment would you like to share?")
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.ink_soft))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            background = GradientDrawable().apply { cornerRadius = ui.dp(22).toFloat(); setColor(0xFFF1EEE9.toInt()) }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = ui.dp(12) }
        })
        card.addView(row)
        card.setOnClickListener { pickMemory() }
        return card
    }

    private fun pickMemory() {
        val all = MemoryStore.all(this).take(24)
        if (all.isEmpty()) {
            Toast.makeText(this, L.t("עוד אין לכם רגעים לפרסם. צלמו או הוסיפו רגע ונחזור לפה.", "You don't have any moments to share yet. Capture or add one, then come back."), Toast.LENGTH_LONG).show()
            return
        }
        val dialog = BottomSheetDialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
            setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(24))
        }
        box.addView(ui.text(L.t("בחרו רגע לפרסום", "Choose a moment to share"), 18f, bold = true))
        val views = all.map { m ->
            mv.gridCard(m) { dialog.dismiss(); PublishSheet.show(this, m, Community.lastAudience(this).let { if (it == "family") "community" else it }) { dirty = true; reload() } }
        }
        box.addView(mv.grid(views, 10))
        dialog.setContentView(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    // ---------- a post ----------

    private class State(var liked: Boolean, var likes: Int, var comments: Int)

    private fun postCard(p: Community.Post): View {
        val me = Account.id(this)
        val st = State(p.liked, p.likes, p.comments)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_white)
            elevation = ui.dp(2).toFloat()
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(16) }
        }

        // header
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(14), ui.dp(12), ui.dp(6), ui.dp(10))
        }
        head.addView(mv.avatar(p.author, 40))
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(12), 0, ui.dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        names.addView(ui.text(p.author, 15f, bold = true))
        val sub = DateUtils.getRelativeTimeSpanString(p.createdAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString() +
            (if (p.hidden) L.t(" · מוסתר", " · Hidden") else "") + (if (p.reports > 0) " · 🚩 ${p.reports}" else "")
        names.addView(ui.hint(sub, top = 1))
        head.addView(names)
        head.addView(TextView(this).apply {
            text = "⋯"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.ink_soft))
            setPadding(ui.dp(12), 0, ui.dp(12), 0)
            contentDescription = L.t("עוד אפשרויות", "More options")
            setOnClickListener { menu(it, p, me) }
        })
        box.addView(head)

        // media fills the frame edge to edge (photo 4:5, video taller), double tap = like
        val width = resources.displayMetrics.widthPixels - ui.dp(40)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(0xFF1B1830.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (width * (if (p.isVideo) 1.45f else 1.25f)).toInt())
        }
        val pic = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            tag = p.image
        }
        frame.addView(pic)
        loadImage(pic, p.image)
        val badge = TextView(this).apply {
            text = "▶"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
            layoutParams = FrameLayout.LayoutParams(ui.dp(64), ui.dp(64), Gravity.CENTER)
            visibility = if (p.isVideo) View.VISIBLE else View.GONE
        }
        frame.addView(badge)
        val pop = TextView(this).apply {
            text = "❤️"
            textSize = 84f
            gravity = Gravity.CENTER
            alpha = 0f
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        }
        frame.addView(pop)
        box.addView(frame)

        // actions
        val heart = ImageView(this)
        val likeCount = TextView(this)
        val commentCount = TextView(this)
        fun paintLike() {
            heart.setImageResource(if (st.liked) R.drawable.ic_heart else R.drawable.ic_heart_outline)
            heart.setColorFilter(ContextCompat.getColor(this, if (st.liked) R.color.heart else R.color.ink))
            likeCount.text = if (st.likes > 0) st.likes.toString() else ""
            commentCount.text = if (st.comments > 0) st.comments.toString() else ""
        }
        fun toggleLike(on: Boolean? = null) {
            val want = on ?: !st.liked
            if (want == st.liked) return
            st.liked = want
            st.likes += if (want) 1 else -1
            paintLike()
            heart.animate().scaleX(1.3f).scaleY(1.3f).setDuration(110).withEndAction { heart.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start()
            worker.execute {
                try { Community.setLike(applicationContext, p.id, want) } catch (e: Exception) {
                    runOnUiThread {
                        st.liked = !want; st.likes += if (want) -1 else 1; paintLike()
                        Toast.makeText(this, e.message ?: L.t("לא הצלחנו", "Something went wrong"), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleLike(true)
                pop.scaleX = 0.5f; pop.scaleY = 0.5f; pop.alpha = 1f
                pop.animate().scaleX(1.1f).scaleY(1.1f).setDuration(260).withEndAction { pop.animate().alpha(0f).setDuration(220).start() }.start()
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (p.isVideo) playVideo(frame, pic, badge, p)
                return true
            }
        })
        frame.setOnTouchListener { _, e -> gesture.onTouchEvent(e) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(10), ui.dp(6), ui.dp(14), ui.dp(2))
        }
        fun tap(icon: View, label: TextView, onClick: () -> Unit) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(6), ui.dp(8), ui.dp(12), ui.dp(8))
                setOnClickListener { onClick() }
            }
            icon.layoutParams = LinearLayout.LayoutParams(ui.dp(26), ui.dp(26))
            label.textSize = 14f
            label.setTextColor(ContextCompat.getColor(this, R.color.ink))
            label.setPadding(ui.dp(6), 0, 0, 0)
            cell.addView(icon); cell.addView(label)
            bar.addView(cell)
        }
        tap(heart, likeCount) { toggleLike() }
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.ic_comment)
            setColorFilter(ContextCompat.getColor(this@CommunityActivity, R.color.ink))
        }
        tap(bubble, commentCount) { openComments(p, st) { c -> st.comments = c; paintLike() } }
        paintLike()
        box.addView(bar)

        // words
        if (p.title.isNotBlank() || p.caption.isNotBlank()) {
            val words = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ui.dp(16), ui.dp(2), ui.dp(16), ui.dp(14))
            }
            if (p.title.isNotBlank()) words.addView(ui.text(p.title, 16f, bold = true))
            if (p.caption.isNotBlank()) words.addView(ui.text(p.caption, 15f, top = if (p.title.isNotBlank()) 4 else 0))
            box.addView(words)
        } else {
            box.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, ui.dp(10)) })
        }
        return box
    }

    private fun loadImage(iv: ImageView, url: String) {
        if (url.isEmpty()) return
        iv.setImageDrawable(ColorDrawable(0xFFECE7E1.toInt()))
        if (images.isShutdown) return
        images.execute {
            val bmp = Community.image(applicationContext, url)
            runOnUiThread {
                if (bmp != null && iv.tag == url && !isDestroyed) {
                    iv.alpha = 0f
                    iv.setImageBitmap(bmp)
                    iv.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
    }

    // ---------- video ----------

    private fun stopVideo() {
        playing?.let { v ->
            v.release()
            (v.parent as? ViewGroup)?.let { parent ->
                parent.removeView(v)
                for (i in 0 until parent.childCount) {
                    val c = parent.getChildAt(i)
                    if (c is TextView && c.text == "▶") c.visibility = View.VISIBLE
                    if (c is ImageView) c.visibility = View.VISIBLE
                }
            }
        }
        playing = null
    }

    private fun playVideo(frame: FrameLayout, pic: ImageView, badge: View, p: Community.Post) {
        val current = playing
        if (current != null && current.parent === frame) {
            if (current.isPlaying) current.pause() else current.start()
            return
        }
        stopVideo()
        val v = FillVideoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        }
        frame.addView(v, 1)
        badge.visibility = View.GONE
        v.onReady = { runOnUiThread { pic.visibility = View.GONE } }
        v.onFailed = {
            runOnUiThread {
                Toast.makeText(this, L.t("לא הצלחנו לנגן את הסרטון", "Couldn't play this video"), Toast.LENGTH_SHORT).show()
                stopVideo()
            }
        }
        v.play(p.mediaUrl)
        playing = v
    }

    // ---------- menu, report, block ----------

    private fun menu(anchor: View, p: Community.Post, me: String) {
        val m = PopupMenu(this, anchor)
        val own = p.authorId == me
        if (own) m.menu.add(0, 1, 0, L.t("מחיקת הרגע", "Delete moment"))
        else {
            m.menu.add(0, 2, 0, L.t("דיווח על הרגע", "Report moment"))
            m.menu.add(0, 3, 1, L.t("חסימת ${p.author}", "Block ${p.author}"))
        }
        if (Account.isAdmin(this)) {
            m.menu.add(0, 4, 2, if (p.hidden) L.t("ביטול הסתרה (מנהל)", "Unhide (admin)") else L.t("הסתרה (מנהל)", "Hide (admin)"))
            if (!own) m.menu.add(0, 5, 3, L.t("מחיקה (מנהל)", "Delete (admin)"))
        }
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1, 5 -> confirmDelete(p)
                2 -> reportDialog(p)
                3 -> confirmBlock(p)
                4 -> background(L.t("מעדכנים...", "Updating…")) { Community.setHidden(applicationContext, p.id, !p.hidden) }
            }
            true
        }
        m.show()
    }

    private fun background(msg: String, done: String = "", work: () -> Unit) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        worker.execute {
            val err = try { work(); null } catch (e: Exception) { e.message ?: L.t("משהו השתבש", "Something went wrong") }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                else { if (done.isNotEmpty()) Toast.makeText(this, done, Toast.LENGTH_SHORT).show(); reload() }
            }
        }
    }

    private fun confirmDelete(p: Community.Post) {
        AlertDialog.Builder(this).setTitle(L.t("למחוק את הרגע מהקהילה?", "Delete this moment from the community?"))
            .setMessage(L.t("הוא יימחק לכולם. הרגע המקורי נשאר אצלכם בטלפון.", "It will be removed for everyone. The original stays on your phone."))
            .setPositiveButton(L.t("מחיקה", "Delete")) { _, _ -> background(L.t("מוחקים...", "Deleting…"), L.t("נמחק", "Deleted")) { Community.delete(applicationContext, p) } }
            .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }

    private fun reportDialog(p: Community.Post) {
        AlertDialog.Builder(this).setTitle(L.t("מה הבעיה ברגע הזה?", "What's wrong with this moment?"))
            .setItems(Community.REPORT_REASON_LABELS.toTypedArray()) { _, i ->
                worker.execute {
                    val err = try { Community.report(applicationContext, p.id, Community.REPORT_REASONS[i]); null } catch (e: Exception) { e.message }
                    runOnUiThread { Toast.makeText(this, err ?: L.t("תודה, הדיווח התקבל", "Thanks, we got your report"), Toast.LENGTH_LONG).show() }
                }
            }.setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }

    private fun confirmBlock(p: Community.Post) {
        AlertDialog.Builder(this).setTitle(L.t("לחסום את ${p.author}?", "Block ${p.author}?"))
            .setMessage(L.t("לא תראו יותר רגעים מהמשתמש הזה.", "You won't see moments from this person anymore."))
            .setPositiveButton(L.t("חסימה", "Block")) { _, _ -> background(L.t("חוסמים...", "Blocking…"), L.t("נחסם", "Blocked")) { Community.block(applicationContext, p.authorId) } }
            .setNegativeButton(L.t("ביטול", "Cancel"), null).show()
    }

    // ---------- comments ----------

    private fun openComments(p: Community.Post, st: State, onCount: (Int) -> Unit) {
        val dialog = BottomSheetDialog(this)
        val me = Account.id(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
            setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(16))
        }
        root.addView(ui.text(L.t("תגובות", "Comments"), 18f, bold = true))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(300)).apply { topMargin = ui.dp(8) }
            addView(list)
        }
        root.addView(scroll)
        val input = EditText(this).apply {
            hint = L.t("כתבו תגובה...", "Add a comment…")
            textSize = 15f
            maxLines = 3
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            background = GradientDrawable().apply { cornerRadius = ui.dp(22).toFloat(); setColor(0xFFF1EEE9.toInt()) }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val send = TextView(this).apply {
            text = L.t("שליחה", "Send")
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@CommunityActivity, R.color.accent))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(4), ui.dp(10))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(input); row.addView(send)
        root.addView(row)

        var shown = emptyList<Community.Comment>()
        fun draw() {
            list.removeAllViews()
            if (shown.isEmpty()) list.addView(ui.hint(L.t("עוד אין תגובות. היו הראשונים.", "No comments yet. Be the first."), top = 12))
            for (c in shown) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, ui.dp(10), 0, ui.dp(2))
                }
                line.addView(mv.avatar(c.author, 32))
                val texts = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(ui.dp(10), 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                texts.addView(ui.text(c.author, 13f, bold = true))
                texts.addView(ui.text(c.body, 15f, top = 1))
                line.addView(texts)
                if (c.authorId == me || p.authorId == me || Account.isAdmin(this)) {
                    line.setOnLongClickListener {
                        AlertDialog.Builder(this).setTitle(L.t("למחוק את התגובה?", "Delete this comment?"))
                            .setPositiveButton(L.t("מחיקה", "Delete")) { _, _ ->
                                worker.execute {
                                    try { Community.deleteComment(applicationContext, c.id) } catch (_: Exception) {}
                                    runOnUiThread { shown = shown.filter { it.id != c.id }; onCount(shown.size); draw() }
                                }
                            }.setNegativeButton(L.t("ביטול", "Cancel"), null).show()
                        true
                    }
                }
                list.addView(line)
            }
        }
        fun load() {
            worker.execute {
                val r = try { Community.comments(applicationContext, p.id) } catch (_: Exception) { null }
                runOnUiThread {
                    if (r != null) { shown = r; onCount(r.size) }
                    if (!isDestroyed) draw()
                }
            }
        }
        send.setOnClickListener {
            val body = input.text.toString().trim()
            if (body.isEmpty()) return@setOnClickListener
            input.setText("")
            worker.execute {
                val err = try { Community.addComment(applicationContext, p.id, body); null } catch (e: Exception) { e.message }
                runOnUiThread { if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show() else load() }
            }
        }
        draw()
        load()
        dialog.setContentView(root)
        dialog.show()
    }
}
