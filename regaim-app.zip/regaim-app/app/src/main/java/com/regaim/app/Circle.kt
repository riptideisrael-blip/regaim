package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * "מעגל המשפחה" — PROTOTYPE for ~10 people.
 * A private family feed on the family's own Supabase project (database + file storage):
 * share a moment (its best ~10 seconds), react ❤️😂😍🥹, comment. Grandparents join from a web link.
 * Security is prototype-level: whoever has the circle link can see and post.
 */
object Circle {
    private const val BUCKET = "moments"
    const val DEFAULT_WEB = "https://riptideisrael-blip.github.io/regaim/"
    /** The family's prototype server (public address and public key only; the secret key never goes in the app). */
    private const val DEFAULT_URL = "https://acqgmcmvxijyijhgivnt.supabase.co"
    private const val DEFAULT_KEY = "sb_publishable_MLvfYGP3BD_liOe_8g-TEg_MN3ZU1bm"
    val EMOJIS = listOf("❤️", "😂", "😍", "🥹")
    private const val SHARE_SECONDS = 10

    class Post(
        val id: String, val author: String, val title: String, val story: String, val people: String,
        val place: String, val kind: String, val takenAt: Long, val video: String, val cover: String, val createdAt: Long,
    )
    class Reaction(val postId: String, val member: String, val emoji: String)
    class Comment(val postId: String, val member: String, val body: String, val createdAt: Long)
    class Feed(val posts: List<Post>, val reactions: List<Reaction>, val comments: List<Comment>)

    // ---------- settings ----------

    private fun p(ctx: Context) = Settings.prefs(ctx)
    fun url(ctx: Context) = clean((p(ctx).getString("circle_url", "") ?: "").ifBlank { DEFAULT_URL })
    fun key(ctx: Context) = (p(ctx).getString("circle_key", "") ?: "").trim().ifEmpty { DEFAULT_KEY }

    /** Accepts the address however it was copied: "https://x.supabase.co/rest/v1/" → "https://x.supabase.co". */
    private fun clean(raw: String): String {
        var u = raw.trim()
        if (u.isNotEmpty() && !u.startsWith("http")) u = "https://$u"
        val i = u.indexOf(".supabase.co")
        if (i > 0) u = u.substring(0, i + ".supabase.co".length)
        return u.trimEnd('/')
    }
    fun web(ctx: Context) = (p(ctx).getString("circle_web", "") ?: "").trim().ifEmpty { DEFAULT_WEB }
    fun circleId(ctx: Context) = p(ctx).getString("circle_id", "") ?: ""
    fun code(ctx: Context) = p(ctx).getString("circle_code", "") ?: ""
    fun name(ctx: Context) = p(ctx).getString("circle_name", "") ?: ""
    fun me(ctx: Context) = (p(ctx).getString("circle_me", "") ?: "").ifEmpty {
        Profile.parentName(ctx).ifEmpty { Profile.role(ctx) }.ifEmpty { "אני" }
    }

    fun configured(ctx: Context) = url(ctx).startsWith("https://") && key(ctx).length > 20 && !key(ctx).startsWith("sb_secret")
    fun joined(ctx: Context) = configured(ctx) && circleId(ctx).isNotEmpty()

    fun setServer(ctx: Context, url: String, key: String, web: String) =
        p(ctx).edit().putString("circle_url", url.trim()).putString("circle_key", key.trim()).putString("circle_web", web.trim()).apply()

    fun setMe(ctx: Context, name: String) = p(ctx).edit().putString("circle_me", name.trim()).apply()

    fun leave(ctx: Context) = p(ctx).edit().remove("circle_id").remove("circle_code").remove("circle_name").apply()

    /** The link to send on WhatsApp: opens the family feed in any browser. */
    fun inviteLink(ctx: Context): String {
        val server = Base64.encodeToString("${url(ctx)}|${key(ctx)}".toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val base = web(ctx).let { if (it.endsWith("/") || it.endsWith(".html")) it else "$it/" }
        return "$base?c=${code(ctx)}&s=$server"
    }

    // ---------- http ----------

    private fun open(ctx: Context, method: String, path: String): HttpURLConnection {
        val conn = URL(url(ctx) + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 20_000
        conn.readTimeout = 120_000
        val k = key(ctx)
        conn.setRequestProperty("apikey", k)
        if (k.startsWith("eyJ")) conn.setRequestProperty("Authorization", "Bearer $k")
        return conn
    }

    private fun read(conn: HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            throw IllegalStateException(
                when (code) {
                    401, 403 -> "השרת דחה את המפתח. בדוק את הכתובת והמפתח בפרופיל."
                    404 -> "לא נמצא בשרת. הרצת את קובץ ההקמה ב-SQL Editor?"
                    else -> "שגיאת שרת ($code): ${text.take(140)}"
                }
            )
        }
        return text
    }

    private fun rest(ctx: Context, method: String, path: String, body: String? = null): JSONArray {
        val conn = open(ctx, method, "/rest/v1/$path")
        try {
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Prefer", "return=representation")
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val text = read(conn).trim()
            if (text.isEmpty()) return JSONArray()
            return if (text.startsWith("[")) JSONArray(text) else JSONArray().put(JSONObject(text))
        } finally {
            conn.disconnect()
        }
    }

    private fun upload(ctx: Context, path: String, file: File, type: String): String {
        val conn = open(ctx, "POST", "/storage/v1/object/$BUCKET/$path")
        try {
            conn.setRequestProperty("Content-Type", type)
            conn.setRequestProperty("x-upsert", "true")
            conn.doOutput = true
            conn.setFixedLengthStreamingMode(file.length())
            conn.outputStream.use { o -> file.inputStream().use { it.copyTo(o) } }
            read(conn)
            return "${url(ctx)}/storage/v1/object/public/$BUCKET/$path"
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    private fun isoOf(t: Long) = synchronized(iso) { iso.format(Date(t)) }
    private fun timeOf(s: String): Long {
        if (s.isEmpty()) return 0L
        // Postgres sends e.g. 2026-10-06T05:57:12.345678+00:00
        val core = s.replace(Regex("(\\.\\d{3})\\d*"), "$1").replace("+00:00", "Z")
        val fmts = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        for (f in fmts) {
            try {
                return SimpleDateFormat(f, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(core)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // ---------- circles ----------

    /** Creates a new family circle and joins it. Background thread only. */
    fun create(ctx: Context, circleName: String): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val code = (1..6).map { alphabet.random() }.joinToString("")
        val row = rest(ctx, "POST", "circles", JSONObject().put("code", code).put("name", circleName.trim()).toString()).getJSONObject(0)
        save(ctx, row)
        return code
    }

    /** Joins an existing circle by its code. Background thread only. */
    fun join(ctx: Context, code: String) {
        val rows = rest(ctx, "GET", "circles?code=eq.${enc(code.trim().uppercase())}&select=*")
        if (rows.length() == 0) throw IllegalStateException("לא מצאתי מעגל עם הקוד הזה")
        save(ctx, rows.getJSONObject(0))
    }

    private fun save(ctx: Context, o: JSONObject) {
        p(ctx).edit().putString("circle_id", o.optString("id")).putString("circle_code", o.optString("code"))
            .putString("circle_name", o.optString("name")).apply()
    }

    // ---------- feed ----------

    fun feed(ctx: Context): Feed {
        val id = circleId(ctx)
        val rows = rest(ctx, "GET", "posts?circle_id=eq.$id&order=created_at.desc&limit=60&select=*")
        val posts = (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            Post(
                o.optString("id"), o.optString("author"), o.optString("title").nullless(), o.optString("story").nullless(),
                o.optString("people").nullless(), o.optString("place").nullless(), o.optString("kind", "video"),
                timeOf(o.optString("taken_at").nullless()), o.optString("video").nullless(), o.optString("cover").nullless(),
                timeOf(o.optString("created_at").nullless()),
            )
        }
        if (posts.isEmpty()) return Feed(posts, emptyList(), emptyList())
        val ids = posts.joinToString(",") { it.id }
        val r = rest(ctx, "GET", "reactions?post_id=in.($ids)&select=*")
        val reactions = (0 until r.length()).map { i ->
            val o = r.getJSONObject(i)
            Reaction(o.optString("post_id"), o.optString("member"), o.optString("emoji"))
        }
        val c = rest(ctx, "GET", "comments?post_id=in.($ids)&order=created_at.asc&select=*")
        val comments = (0 until c.length()).map { i ->
            val o = c.getJSONObject(i)
            Comment(o.optString("post_id"), o.optString("member"), o.optString("body"), timeOf(o.optString("created_at").nullless()))
        }
        return Feed(posts, reactions, comments)
    }

    private fun String.nullless() = if (this == "null") "" else this

    fun react(ctx: Context, postId: String, emoji: String, remove: Boolean) {
        val me = me(ctx)
        if (remove) rest(ctx, "DELETE", "reactions?post_id=eq.$postId&member=eq.${enc(me)}&emoji=eq.${enc(emoji)}")
        else rest(ctx, "POST", "reactions", JSONObject().put("post_id", postId).put("member", me).put("emoji", emoji).toString())
    }

    fun comment(ctx: Context, postId: String, body: String) {
        rest(ctx, "POST", "comments", JSONObject().put("post_id", postId).put("member", me(ctx)).put("body", body.trim()).toString())
    }

    fun deletePost(ctx: Context, postId: String) {
        rest(ctx, "DELETE", "posts?id=eq.$postId")
    }

    // ---------- sharing ----------

    /** Shares a moment: its best ~10 seconds, a cover, and the AI title and story. Background thread only. */
    fun shareMoment(ctx: Context, m: Memory, onProgress: (String) -> Unit) {
        onProgress("רגע, אנחנו מכינים את הרגע למשפחה...")
        val clip = cutHeart(ctx, m, SHARE_SECONDS)
        val base = "${circleId(ctx)}/${m.id}_${System.currentTimeMillis()}"
        try {
            onProgress("שולחים למעגל המשפחה...")
            val video = upload(ctx, "$base.mp4", clip, "video/mp4")
            val coverUrl = Covers.get(ctx, m)?.let { bmp -> uploadJpeg(ctx, "${base}_cover.jpg", bmp) } ?: ""
            val post = JSONObject()
                .put("circle_id", circleId(ctx)).put("author", me(ctx)).put("title", Fmt.title(m))
                .put("story", m.description).put("people", Fmt.names(m).joinToString(" · ")).put("place", Fmt.place(m))
                .put("kind", "video").put("taken_at", isoOf(m.time)).put("video", video).put("cover", coverUrl)
            rest(ctx, "POST", "posts", post.toString())
            Settings.prefs(ctx).edit().putBoolean("circle_shared_${m.id}", true).apply()
        } finally {
            clip.delete()
        }
    }

    fun wasShared(ctx: Context, m: Memory) = Settings.prefs(ctx).getBoolean("circle_shared_${m.id}", false)

    /** Shares a photo or video from the phone's gallery. Background thread only. */
    fun shareFromGallery(ctx: Context, uri: Uri, title: String, onProgress: (String) -> Unit) {
        val type = ctx.contentResolver.getType(uri) ?: "video/mp4"
        val isVideo = type.startsWith("video/")
        val tmp = File(ctx.cacheDir, "circle_upload_${System.currentTimeMillis()}")
        try {
            onProgress("רגע, אנחנו שומרים את הזיכרון הזה...")
            ctx.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                ?: throw IllegalStateException("לא הצלחתי לקרוא את הקובץ")
            if (tmp.length() > 45L * 1024 * 1024) throw IllegalStateException("הקובץ גדול מדי (עד 45MB). אפשר לקצר אותו קודם.")
            val ext = if (isVideo) "mp4" else "jpg"
            val base = "${circleId(ctx)}/app_${System.currentTimeMillis()}"
            onProgress("שולחים למעגל המשפחה...")
            val fileUrl = upload(ctx, "$base.$ext", tmp, type)
            val coverUrl = if (isVideo) {
                val frame = try {
                    val mmr = MediaMetadataRetriever()
                    mmr.setDataSource(tmp.absolutePath)
                    val f = mmr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    mmr.release()
                    f
                } catch (_: Exception) {
                    null
                }
                frame?.let { uploadJpeg(ctx, "${base}_cover.jpg", it) } ?: ""
            } else fileUrl
            val post = JSONObject()
                .put("circle_id", circleId(ctx)).put("author", me(ctx)).put("title", title.trim())
                .put("kind", if (isVideo) "video" else "photo").put("taken_at", isoOf(System.currentTimeMillis()))
                .put("video", fileUrl).put("cover", coverUrl)
            rest(ctx, "POST", "posts", post.toString())
        } finally {
            tmp.delete()
        }
    }

    private fun uploadJpeg(ctx: Context, path: String, bmp: Bitmap): String {
        val f = File(ctx.cacheDir, "cover_${System.currentTimeMillis()}.jpg")
        try {
            val w = 720
            val scaled = if (bmp.width > w) Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true) else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            f.writeBytes(out.toByteArray())
            return upload(ctx, path, f, "image/jpeg")
        } finally {
            f.delete()
        }
    }

    /** Copies the [seconds] around the middle of a clip (the moment itself) into a small MP4, without re-encoding. */
    private fun cutHeart(ctx: Context, m: Memory, seconds: Int): File {
        val src = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.fromFile(File(m.uri))
        val ex = MediaExtractor()
        ex.setDataSource(ctx, src, null)
        val rotation = try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(ctx, src)
            val r = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            mmr.release()
            r
        } catch (_: Exception) {
            0
        }
        val out = File(ctx.cacheDir, "circle_${System.currentTimeMillis()}.mp4")
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        val map = HashMap<Int, Int>()
        var durUs = m.durationMs * 1000
        var videoTrack = -1
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                ex.selectTrack(i)
                map[i] = muxer.addTrack(f)
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    if (f.containsKey(MediaFormat.KEY_DURATION)) durUs = f.getLong(MediaFormat.KEY_DURATION)
                }
            }
        }
        if (videoTrack < 0) {
            ex.release()
            muxer.release()
            out.delete()
            throw IllegalStateException("לא מצאתי וידאו ברגע הזה")
        }
        muxer.start()
        val half = seconds * 500_000L
        val startUs = (durUs / 2 - half).coerceAtLeast(0)
        val endUs = (durUs / 2 + half).coerceAtMost(durUs)
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var base = -1L
        try {
            while (true) {
                val track = ex.sampleTrackIndex
                if (track < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                if (base < 0) {
                    if (track != videoTrack || (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) == 0) { ex.advance(); continue }
                    base = t
                }
                val o = map[track]
                if (o != null && t >= base) {
                    val sync = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                    info.set(0, size, t - base, if (sync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(o, buf, info)
                }
                ex.advance()
            }
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release()
            ex.release()
        }
        return out
    }

    // ---------- images from the web ----------

    private val imgCache = object : android.util.LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /** Downloads a cover (cached on disk and in memory). Background thread only. */
    fun image(ctx: Context, url: String): Bitmap? {
        if (url.isEmpty()) return null
        imgCache.get(url)?.let { return it }
        val f = File(File(ctx.cacheDir, "circle_img").apply { mkdirs() }, url.hashCode().toString() + ".img")
        if (!f.exists()) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                try {
                    if (conn.responseCode != 200) return null
                    conn.inputStream.use { input -> f.outputStream().use { input.copyTo(it) } }
                } finally {
                    conn.disconnect()
                }
            } catch (_: Exception) {
                f.delete()
                return null
            }
        }
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, opts)
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 720) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        imgCache.put(url, bmp)
        return bmp
    }
}
