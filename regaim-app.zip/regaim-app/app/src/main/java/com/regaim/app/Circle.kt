package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Family sharing over authenticated membership RLS and private Storage.
 * Requires the explicit v3 server migration; never falls back to prototype access.
 */
object Circle {
    private const val BUCKET = "moments"
    const val DEFAULT_WEB = "https://riptideisrael-blip.github.io/regaim/"
    /** The family's prototype server (public address and public key only; the secret key never goes in the app). */
    private const val DEFAULT_URL = "https://acqgmcmvxijyijhgivnt.supabase.co"
    private const val DEFAULT_KEY = "sb_publishable_MLvfYGP3BD_liOe_8g-TEg_MN3ZU1bm"
    val EMOJIS = listOf("❤️", "😂", "😍", "🥹")
    private const val SHARE_SECONDS = 10

    class Post(
        val id: String, val author: String, val title: String, val story: String, val people: String,
        val place: String, val kind: String, val takenAt: Long, val video: String, val cover: String, val createdAt: Long,
        val caption: String = "", val style: String = "plain", val memoryId: String = "",
        val authorId: String = "", val videoPath: String = "", val coverPath: String = "",
    )

    /** What you chose on the share screen. startMs/endMs < 0 = the default ~10 seconds around the highlight. */
    class Draft(
        val title: String, val caption: String, val withStory: Boolean, val style: String,
        val startMs: Long = -1, val endMs: Long = -1,
    )

    /** Styles for a shared moment: id to Hebrew name. The same ids are used by the web page. */
    val STYLES: List<Pair<String, String>> get() = listOf("plain" to L.t("רגיל", "Plain"), "warm" to L.t("חם", "Warm"), "bw" to L.t("שחור-לבן", "B&W"), "vintage" to L.t("נוסטלגי", "Vintage"), "party" to L.t("חגיגי", "Festive"))

    /** A color filter for the cover in this style (null = as is). */
    fun styleFilter(style: String): android.graphics.ColorMatrixColorFilter? {
        val cm = android.graphics.ColorMatrix()
        when (style) {
            "bw" -> cm.setSaturation(0f)
            "vintage" -> {
                cm.setSaturation(0.35f)
                cm.postConcat(android.graphics.ColorMatrix(floatArrayOf(
                    1.08f, 0f, 0f, 0f, 14f,
                    0f, 1.0f, 0f, 0f, 6f,
                    0f, 0f, 0.82f, 0f, -6f,
                    0f, 0f, 0f, 1f, 0f,
                )))
            }
            "warm" -> cm.set(floatArrayOf(
                1.08f, 0f, 0f, 0f, 10f,
                0f, 1.02f, 0f, 0f, 4f,
                0f, 0f, 0.92f, 0f, -4f,
                0f, 0f, 0f, 1f, 0f,
            ))
            else -> return null
        }
        return android.graphics.ColorMatrixColorFilter(cm)
    }
    class Reaction(val postId: String, val member: String, val emoji: String, val authorId: String = "")
    class Comment(val postId: String, val member: String, val body: String, val createdAt: Long, val authorId: String = "", val id: String = "")
    class Member(val userId: String, val name: String, val relationship: String, val avatar: String)
    class Message(val id: String, val authorId: String, val author: String, val body: String, val createdAt: Long)
    class Feed(val posts: List<Post>, val reactions: List<Reaction>, val comments: List<Comment>)

    // ---------- settings ----------

    private fun p(ctx: Context) = Settings.prefs(ctx)
    fun url(ctx: Context) = clean((p(ctx).getString("circle_url", "") ?: "").ifBlank { DEFAULT_URL })
    fun key(ctx: Context) = (p(ctx).getString("circle_key", "") ?: "").trim().ifEmpty { DEFAULT_KEY }

    /** Accepts the address however it was copied: "https://x.supabase.co/rest/v1/" → "https://x.supabase.co". */
    private fun clean(raw: String): String {
        var u = raw.trim()
        if (u.isNotEmpty() && !u.startsWith("http")) u = "https://$u"
        val i = u.indexOf(".supabase.co")
        if (i > 0) u = u.substring(0, i + ".supabase.co".length)
        return u.trimEnd('/')
    }
    fun web(ctx: Context) = (p(ctx).getString("circle_web", "") ?: "").trim().ifEmpty { DEFAULT_WEB }
    fun circleId(ctx: Context) = p(ctx).getString("circle_id", "") ?: ""
    fun code(ctx: Context) = p(ctx).getString("circle_code", "") ?: ""
    fun name(ctx: Context) = p(ctx).getString("circle_name", "") ?: ""
    fun me(ctx: Context) = (p(ctx).getString("circle_me", "") ?: "").ifEmpty {
        Profile.parentName(ctx).ifEmpty { Profile.relationLabel(Profile.role(ctx)) }.ifEmpty { L.t("אני", "Me") }
    }

    fun configured(ctx: Context): Boolean {
        val k = key(ctx)
        val isPublic = k.startsWith("sb_publishable_") || try {
            k.startsWith("eyJ") && JSONObject(String(Base64.decode(k.split('.')[1], Base64.URL_SAFE))).optString("role") == "anon"
        } catch (_: Exception) { false }
        return url(ctx).startsWith("https://") && isPublic
    }
    fun joined(ctx: Context) = configured(ctx) && circleId(ctx).isNotEmpty()

    fun setServer(ctx: Context, url: String, key: String, web: String) =
        p(ctx).edit().putString("circle_url", url.trim()).putString("circle_key", key.trim()).putString("circle_web", web.trim()).apply()

    fun setMe(ctx: Context, name: String) = p(ctx).edit().putString("circle_me", name.trim()).apply()

    fun leave(ctx: Context) {
        p(ctx).edit().remove("circle_id").remove("circle_code").remove("circle_name").apply()
        clearMediaCache(ctx)
    }

    /**
     * Really leaves: the server removes your membership (not only this phone forgetting the circle).
     * Background thread only. If the server isn't updated yet, at least this phone leaves.
     */
    fun leaveForGood(ctx: Context) {
        val id = circleId(ctx)
        if (id.isNotEmpty()) try { rpcRaw(ctx, "leave_family", JSONObject().put("p_circle_id", id)) } catch (_: Exception) { }
        leave(ctx)
    }

    /** Is this account the family's owner (the one who can remove members)? Background thread only. */
    fun isOwner(ctx: Context): Boolean = try {
        circleId(ctx).isNotEmpty() && rpcRaw(ctx, "family_is_owner", JSONObject().put("p_circle_id", circleId(ctx))).trim() == "true"
    } catch (_: Exception) { false }

    /** The owner removes someone: they lose access at once, and the invite link changes. Background thread only. */
    fun removeMember(ctx: Context, userId: String) {
        rpcRaw(ctx, "remove_family_member", JSONObject().put("p_circle_id", circleId(ctx)).put("p_user_id", userId))
        try { renewInvite(ctx) } catch (_: Exception) { }
    }

    /** An RPC whose answer may be a plain value (true/false) or nothing. */
    private fun rpcRaw(ctx: Context, name: String, body: JSONObject): String {
        val conn = open(ctx, "POST", "/rest/v1/rpc/$name")
        try {
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            return read(conn)
        } finally { conn.disconnect() }
    }

    fun clearSession(ctx: Context) {
        leave(ctx)
        val editor = p(ctx).edit().remove("circle_me")
        p(ctx).all.keys.filter { it.startsWith("circle_shared_") }.forEach { editor.remove(it) }
        editor.apply()
    }

    private fun clearMediaCache(ctx: Context) {
        imgCache.evictAll()
        File(ctx.cacheDir, "circle_img").deleteRecursively()
    }

    /** The link to send on WhatsApp: opens the family feed in any browser. */
    fun inviteLink(ctx: Context): String {
        val server = Base64.encodeToString("${url(ctx)}|${key(ctx)}".toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val base = web(ctx).let { if (it.endsWith("/") || it.endsWith(".html")) it else "$it/" }
        check(code(ctx).matches(Regex("[A-Fa-f0-9]{32}"))) { L.t("צריך לחדש את קישור ההזמנה באמצעות מנהל המשפחה", "The invite link needs to be renewed by the family admin") }
        return "$base?c=${code(ctx)}&s=$server"
    }

    // ---------- http ----------

    private fun open(ctx: Context, method: String, path: String): HttpURLConnection {
        val conn = URL(url(ctx) + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 20_000
        conn.readTimeout = 120_000
        val k = key(ctx)
        conn.setRequestProperty("apikey", k)
        val token = Account.token(ctx) ?: throw IllegalStateException(L.t("כדי לשתף עם המשפחה צריך להתחבר לחשבון. הזיכרונות בטלפון זמינים גם בלי התחברות.", "Sign in to share with your family. Memories on your phone are available without an account."))
        conn.setRequestProperty("Authorization", "Bearer $token")
        return conn
    }

    private fun read(conn: HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            throw IllegalStateException(
                when (code) {
                    401, 403 -> L.t("אין הרשאה למעגל הזה. התחברו לחשבון ובקשו הזמנה חדשה.", "You don't have access to this circle. Sign in and ask for a new invite.")
                    404 -> L.t("שיתוף משפחתי מאובטח עדיין לא הופעל בשרת. נדרש עדכון השרת לגרסה 3.", "Secure family sharing isn't enabled on the server yet. A server update to version 3 is needed.")
                    else -> L.t("שגיאת שרת ($code): ${text.take(140)}", "Server error ($code): ${text.take(140)}")
                }
            )
        }
        return text
    }

    private fun rest(ctx: Context, method: String, path: String, body: String? = null): JSONArray {
        val conn = open(ctx, method, "/rest/v1/$path")
        try {
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Prefer", "return=representation")
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val text = read(conn).trim()
            if (text.isEmpty()) return JSONArray()
            return if (text.startsWith("[")) JSONArray(text) else JSONArray().put(JSONObject(text))
        } finally {
            conn.disconnect()
        }
    }

    private fun upload(ctx: Context, path: String, file: File, type: String): String {
        val conn = open(ctx, "POST", "/storage/v1/object/$BUCKET/$path")
        try {
            conn.setRequestProperty("Content-Type", type)
            conn.setRequestProperty("x-upsert", "false")
            conn.doOutput = true
            conn.setFixedLengthStreamingMode(file.length())
            conn.outputStream.use { o -> file.inputStream().use { it.copyTo(o) } }
            read(conn)
            return path
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    private fun isoOf(t: Long) = synchronized(iso) { iso.format(Date(t)) }
    private fun timeOf(s: String): Long {
        if (s.isEmpty()) return 0L
        // Postgres sends e.g. 2026-10-06T05:57:12.345678+00:00
        val core = s.replace(Regex("(\\.\\d{3})\\d*"), "$1").replace("+00:00", "Z")
        val fmts = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        for (f in fmts) {
            try {
                return SimpleDateFormat(f, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(core)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // ---------- circles ----------

    private fun rpc(ctx: Context, name: String, body: JSONObject = JSONObject()) =
        rest(ctx, "POST", "rpc/$name", body.toString())

    /** Numbers for the owner's admin screen (the server allows only the admin account). Background thread only. */
    fun adminStats(ctx: Context): JSONObject = rpc(ctx, "admin_stats").getJSONObject(0)

    /** Does not trust local configuration: a real authenticated server check is required. */
    fun secureReady(ctx: Context): Boolean {
        val version = rpc(ctx, "family_circle_version").optJSONObject(0)?.optInt("version", 0)
        if (version != 3) throw IllegalStateException(L.t("שיתוף משפחתי מאובטח עדיין לא הופעל בשרת. נדרש עדכון השרת לגרסה 3.", "Secure family sharing isn't enabled on the server yet. A server update to version 3 is needed."))
        if (circleId(ctx).isNotEmpty()) {
            val rows = rpc(ctx, "family_circle_status", JSONObject().put("p_circle_id", circleId(ctx)))
            if (rows.length() == 0) throw IllegalStateException(L.t("אין חברות מאושרת במעגל הזה. בקשו הזמנה חדשה ממנהל המשפחה.", "You're not an approved member of this circle. Ask the family admin for a new invite."))
            save(ctx, rows.getJSONObject(0))
        }
        return true
    }

    fun create(ctx: Context, circleName: String): String {
        secureReady(ctx)
        val row = rpc(ctx, "create_family_circle", JSONObject().put("p_name", circleName.trim()).put("p_display_name", me(ctx))).getJSONObject(0)
        save(ctx, row)
        return row.getString("code")
    }

    fun join(ctx: Context, code: String) {
        // Old six-character codes are deliberately not treated as access credentials.
        if (!code.trim().matches(Regex("[A-Fa-f0-9]{32}"))) throw IllegalStateException(L.t("צריך קישור הזמנה חדש ומאובטח מהמשפחה. קודים ישנים אינם מעניקים גישה.", "You need a new secure invite link from your family. Old codes no longer give access."))
        val row = rpc(ctx, "redeem_family_invite", JSONObject().put("p_token", code.trim()).put("p_display_name", me(ctx))).getJSONObject(0)
        save(ctx, row)
    }

    fun renewInvite(ctx: Context) {
        val row = rpc(ctx, "create_family_invite", JSONObject().put("p_circle_id", circleId(ctx))).getJSONObject(0)
        save(ctx, row)
    }

    fun members(ctx: Context): List<Member> {
        secureReady(ctx)
        val rows = rpc(ctx, "get_family_members", JSONObject().put("p_circle_id", circleId(ctx)))
        return (0 until rows.length()).map { i -> rows.getJSONObject(i).let {
            Member(it.optString("user_id"), it.optString("display_name"), it.optString("relationship"), it.optString("avatar_url"))
        } }
    }

    private fun save(ctx: Context, o: JSONObject) {
        p(ctx).edit().putString("circle_id", o.optString("id")).putString("circle_code", o.optString("code"))
            .putString("circle_name", o.optString("name")).apply()
    }

    // ---------- feed ----------

    private fun post(ctx: Context, o: JSONObject): Post {
        val videoPath = mediaPath(ctx, o.optString("video").nullless())
        val coverPath = mediaPath(ctx, o.optString("cover").nullless())
        return Post(o.optString("id"), o.optString("author"), o.optString("title").nullless(), o.optString("story").nullless(),
            o.optString("people").nullless(), o.optString("place").nullless(), o.optString("kind", "video"),
            timeOf(o.optString("taken_at").nullless()), signedUrl(ctx, videoPath), signedUrl(ctx, coverPath), timeOf(o.optString("created_at").nullless()),
            o.optString("caption").nullless(), o.optString("style").nullless().ifEmpty { "plain" }, o.optString("memory_id").nullless(),
            o.optString("author_id").nullless(), videoPath, coverPath)
    }

    fun feed(ctx: Context): Feed {
        secureReady(ctx)
        val rows = rest(ctx, "GET", "posts?circle_id=eq.${circleId(ctx)}&order=created_at.desc&limit=60&select=*")
        val posts = (0 until rows.length()).map { post(ctx, rows.getJSONObject(it)) }
        if (posts.isEmpty()) return Feed(posts, emptyList(), emptyList())
        val ids = posts.joinToString(",") { it.id }
        return Feed(posts, reactions(ctx, "post_id=in.($ids)"), comments(ctx, "post_id=in.($ids)"))
    }

    fun postById(ctx: Context, postId: String): Post? {
        secureReady(ctx)
        val rows = rest(ctx, "GET", "posts?circle_id=eq.${circleId(ctx)}&id=eq.${enc(postId)}&limit=1&select=*")
        return if (rows.length() == 0) null else post(ctx, rows.getJSONObject(0))
    }

    fun postForMemory(ctx: Context, memoryId: String): Post? {
        secureReady(ctx)
        val rows = rest(ctx, "GET", "posts?circle_id=eq.${circleId(ctx)}&memory_id=eq.${enc(memoryId)}&order=created_at.desc&limit=1&select=*")
        return if (rows.length() == 0) null else post(ctx, rows.getJSONObject(0))
    }

    private fun reactions(ctx: Context, filter: String): List<Reaction> {
        val rows = rest(ctx, "GET", "reactions?$filter&select=*")
        return (0 until rows.length()).map { i -> rows.getJSONObject(i).let {
            Reaction(it.optString("post_id"), it.optString("member"), it.optString("emoji"), it.optString("author_id").nullless())
        } }
    }
    private fun comments(ctx: Context, filter: String): List<Comment> {
        val rows = rest(ctx, "GET", "comments?$filter&order=created_at.asc&select=*")
        return (0 until rows.length()).map { i -> rows.getJSONObject(i).let {
            Comment(it.optString("post_id"), it.optString("member"), it.optString("body"), timeOf(it.optString("created_at").nullless()), it.optString("author_id").nullless(), it.optString("id"))
        } }
    }
    fun reactionsForPost(ctx: Context, postId: String) = reactions(ctx, "post_id=eq.${enc(postId)}")
    fun commentsForPost(ctx: Context, postId: String) = comments(ctx, "post_id=eq.${enc(postId)}")

    fun messages(ctx: Context, postId: String? = null): List<Message> {
        secureReady(ctx)
        val filter = if (postId == null) "post_id=is.null" else "post_id=eq.${enc(postId)}"
        val rows = rest(ctx, "GET", "family_messages?circle_id=eq.${circleId(ctx)}&$filter&order=created_at.desc&limit=100&select=*")
        return (0 until rows.length()).map { i -> rows.getJSONObject(i).let {
            Message(it.optString("id"), it.optString("author_id"), it.optString("author"), it.optString("body"), timeOf(it.optString("created_at")))
        } }.reversed()
    }
    fun sendMessage(ctx: Context, body: String, postId: String? = null) {
        secureReady(ctx)
        val text = body.trim()
        require(text.length in 1..4000) { L.t("הודעה צריכה לכלול בין 1 ל־4,000 תווים", "Messages must be 1 to 4,000 characters") }
        val row = JSONObject().put("circle_id", circleId(ctx)).put("author_id", Account.id(ctx)).put("author", me(ctx)).put("body", text)
        if (postId != null) row.put("post_id", postId)
        rest(ctx, "POST", "family_messages", row.toString())
    }

    private fun mediaPath(ctx: Context, value: String): String {
        if (value.isEmpty()) return ""
        if (!value.contains("://")) return value
        if (!value.startsWith(url(ctx) + "/storage/v1/object/")) throw IllegalStateException(L.t("קישור המדיה אינו שייך לשרת המשפחה", "This media link doesn't belong to the family server"))
        val marker = "/$BUCKET/"
        val index = value.indexOf(marker, value.indexOf("/storage/v1/object/"))
        return if (index >= 0) value.substring(index + marker.length).substringBefore('?') else ""
    }

    private fun signedUrl(ctx: Context, path: String): String {
        if (path.isEmpty()) return ""
        val conn = open(ctx, "POST", "/storage/v1/object/sign/$BUCKET/$path")
        try {
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(JSONObject().put("expiresIn", 900).toString().toByteArray(Charsets.UTF_8)) }
            val signed = JSONObject(read(conn)).optString("signedURL")
            if (signed.isBlank()) throw IllegalStateException(L.t("לא הצלחנו לפתוח את המדיה המשפחתית", "Couldn't open the family media"))
            return if (signed.startsWith("https://")) signed else "${url(ctx)}/storage/v1$signed"
        } finally { conn.disconnect() }
    }

    private fun String.nullless() = if (this == "null") "" else this

    fun react(ctx: Context, postId: String, emoji: String, remove: Boolean) {
        val me = me(ctx)
        if (remove) rest(ctx, "DELETE", "reactions?post_id=eq.$postId&author_id=eq.${Account.id(ctx)}&emoji=eq.${enc(emoji)}")
        else rest(ctx, "POST", "reactions", JSONObject().put("post_id", postId).put("author_id", Account.id(ctx)).put("member", me).put("emoji", emoji).toString())
    }

    fun comment(ctx: Context, postId: String, body: String) {
        rest(ctx, "POST", "comments", JSONObject().put("post_id", postId).put("author_id", Account.id(ctx)).put("member", me(ctx)).put("body", body.trim()).toString())
    }

    /** Deletes the post and its files. Background thread only. */
    fun deletePost(ctx: Context, post: Post) {
        rest(ctx, "DELETE", "posts?id=eq.${post.id}")
        removeFile(ctx, post.video)
        if (post.cover != post.video) removeFile(ctx, post.cover)
        if (post.memoryId.isNotEmpty()) Settings.prefs(ctx).edit().remove(sharedKey(ctx, post.memoryId)).apply()
    }

    private fun removeFile(ctx: Context, publicUrl: String) {
        if (publicUrl.isEmpty()) return
        try {
            val conn = open(ctx, "DELETE", "/storage/v1/object/$BUCKET")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(JSONObject().put("prefixes", JSONArray().put(mediaPath(ctx, publicUrl))).toString().toByteArray(Charsets.UTF_8)) }
            try { read(conn) } finally { conn.disconnect() }
        } catch (_: Exception) {
        }
    }

    /** True when the server still needs the small update (caption/style columns). */
    fun needsServerUpdate(ctx: Context) = Settings.prefs(ctx).getBoolean("circle_old_schema", false)

    /** Insert or update a post; if the server doesn't know the new columns yet, save without them. */
    private fun writePost(ctx: Context, method: String, path: String, post: JSONObject) {
        try {
            rest(ctx, method, path, post.toString())
            Settings.prefs(ctx).edit().putBoolean("circle_old_schema", false).apply()
        } catch (e: Exception) {
            throw e // No insecure or data-loss fallback to the prototype schema.
        }
    }

    // ---------- sharing ----------

    /** Shares a moment: the chosen part of the clip, a cover, a title, your words and a style. Background thread only. */
    fun shareMoment(ctx: Context, m: Memory, d: Draft = Draft(Fmt.title(m), "", true, "plain"), onProgress: (String) -> Unit) {
        secureReady(ctx)
        if (!m.isVideo) { shareImage(ctx, m, d, onProgress); return }
        onProgress(L.t("רגע, אנחנו מכינים את הרגע למשפחה...", "Getting this moment ready for your family..."))
        val clip = cutRange(ctx, m, d.startMs, d.endMs)
        val base = "${circleId(ctx)}/${Account.id(ctx)}/${m.id}_${System.currentTimeMillis()}"
        var video = ""
        var coverUrl = ""
        try {
            onProgress(L.t("שולחים למעגל המשפחה...", "Sending to your family circle..."))
            video = upload(ctx, "$base.mp4", clip, "video/mp4")
            coverUrl = coverAt(ctx, m, d)?.let { bmp -> uploadJpeg(ctx, "${base}_cover.jpg", bmp) } ?: ""
            val post = JSONObject()
                .put("circle_id", circleId(ctx)).put("author_id", Account.id(ctx)).put("author", me(ctx)).put("title", d.title.trim())
                .put("story", if (d.withStory) m.description else "").put("people", Fmt.names(m).joinToString(" · "))
                .put("place", Fmt.place(m)).put("kind", "video").put("taken_at", if (m.timeSource == "imported") JSONObject.NULL else isoOf(m.time))
                .put("video", video).put("cover", coverUrl)
                .put("caption", d.caption.trim()).put("style", d.style).put("memory_id", m.id)
            writePost(ctx, "POST", "posts", post)
            Settings.prefs(ctx).edit().putBoolean(sharedKey(ctx, m.id), true).apply()
        } catch (e: Exception) {
            removeFile(ctx, video); removeFile(ctx, coverUrl); throw e
        } finally {
            clip.delete()
        }
    }

    private fun shareImage(ctx: Context, m: Memory, d: Draft, onProgress: (String) -> Unit) {
        val source = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.fromFile(File(m.uri))
        val type = ctx.contentResolver.getType(source) ?: when (File(m.uri).extension.lowercase()) {
            "png" -> "image/png"; "webp" -> "image/webp"; "heic", "heif" -> "image/heic"; else -> "image/jpeg"
        }
        val tmp = File(ctx.cacheDir, "circle_photo_${System.currentTimeMillis()}")
        var uploaded = ""
        try {
            onProgress(L.t("רגע, אנחנו שומרים את הזיכרון הזה...", "Saving this memory..."))
            ctx.contentResolver.openInputStream(source)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                ?: throw IllegalStateException(L.t("התמונה אינה זמינה", "This photo isn't available"))
            require(tmp.length() <= 45L * 1024 * 1024) { L.t("התמונה גדולה מדי לשיתוף (עד 45MB)", "This photo is too large to share (max 45MB)") }
            val ext = when (type) { "image/png" -> "png"; "image/webp" -> "webp"; "image/heic" -> "heic"; else -> "jpg" }
            uploaded = upload(ctx, "${circleId(ctx)}/${Account.id(ctx)}/${m.id}_${System.currentTimeMillis()}.$ext", tmp, type)
            writePost(ctx, "POST", "posts", JSONObject().put("circle_id", circleId(ctx)).put("author_id", Account.id(ctx)).put("author", me(ctx))
                .put("title", d.title.trim()).put("story", if (d.withStory) m.description else "").put("people", Fmt.names(m).joinToString(" · "))
                .put("place", Fmt.place(m)).put("kind", "photo").put("taken_at", if (m.timeSource == "imported") JSONObject.NULL else isoOf(m.time)).put("video", uploaded).put("cover", uploaded)
                .put("caption", d.caption.trim()).put("style", d.style).put("memory_id", m.id))
            Settings.prefs(ctx).edit().putBoolean(sharedKey(ctx, m.id), true).apply()
        } catch (e: Exception) { if (uploaded.isNotEmpty()) removeFile(ctx, uploaded); throw e }
        finally { tmp.delete() }
    }

    /**
     * Edits a shared post: words, title, style, and (when [recut] and the moment is on this phone) a new part of the clip.
     * Background thread only.
     */
    fun updatePost(ctx: Context, post: Post, d: Draft, m: Memory?, recut: Boolean, onProgress: (String) -> Unit) {
        val change = JSONObject().put("title", d.title.trim()).put("caption", d.caption.trim()).put("style", d.style)
        if (m != null) change.put("story", if (d.withStory) m.description else "")
        var oldVideo = ""
        var oldCover = ""
        if (recut && m != null && m.isVideo) {
            onProgress(L.t("גוזרים את הקטע החדש...", "Trimming the new clip..."))
            val clip = cutRange(ctx, m, d.startMs, d.endMs)
            try {
                val base = "${circleId(ctx)}/${Account.id(ctx)}/${m.id}_${System.currentTimeMillis()}"
                onProgress(L.t("שולחים למעגל המשפחה...", "Sending to your family circle..."))
                change.put("video", upload(ctx, "$base.mp4", clip, "video/mp4"))
                coverAt(ctx, m, d)?.let { change.put("cover", uploadJpeg(ctx, "${base}_cover.jpg", it)) }
                oldVideo = post.video
                if (change.has("cover")) oldCover = post.cover
            } finally {
                clip.delete()
            }
        }
        onProgress(L.t("שומרים...", "Saving..."))
        writePost(ctx, "PATCH", "posts?id=eq.${post.id}", change)
        if (oldVideo.isNotEmpty()) removeFile(ctx, oldVideo)
        if (oldCover.isNotEmpty() && oldCover != oldVideo) removeFile(ctx, oldCover)
    }

    /** The cover: the frame in the middle of the chosen part (or the usual cover). */
    internal fun coverAt(ctx: Context, m: Memory, d: Draft): Bitmap? {
        if (d.startMs >= 0 && d.endMs > d.startMs) {
            val mmr = MediaMetadataRetriever()
            try {
                if (m.uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(m.uri)) else mmr.setDataSource(m.uri)
                mmr.getFrameAtTime((d.startMs + d.endMs) / 2 * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { return it }
            } catch (_: Exception) {
            } finally {
                try { mmr.release() } catch (_: Exception) {}
            }
        }
        return Covers.get(ctx, m)
    }

    private fun sharedKey(ctx: Context, memoryId: String) = "circle_shared_${Account.id(ctx)}_${circleId(ctx)}_$memoryId"
    fun wasShared(ctx: Context, m: Memory) = Settings.prefs(ctx).getBoolean(sharedKey(ctx, m.id), false)

    /** Shares a photo or video from the phone's gallery. Background thread only. */
    fun shareFromGallery(ctx: Context, uri: Uri, title: String, onProgress: (String) -> Unit) {
        secureReady(ctx)
        val type = ctx.contentResolver.getType(uri) ?: throw IllegalStateException(L.t("לא ניתן לזהות את סוג המדיה", "Couldn't recognize this media type"))
        require(type.startsWith("video/") || type.startsWith("image/")) { L.t("אפשר לשתף רק תמונות וסרטונים", "Only photos and videos can be shared") }
        val isVideo = type.startsWith("video/")
        val tmp = File(ctx.cacheDir, "circle_upload_${System.currentTimeMillis()}")
        try {
            onProgress(L.t("רגע, אנחנו שומרים את הזיכרון הזה...", "Saving this memory..."))
            ctx.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                ?: throw IllegalStateException(L.t("לא הצלחתי לקרוא את הקובץ", "Couldn't read the file"))
            if (tmp.length() > 45L * 1024 * 1024) throw IllegalStateException(L.t("הקובץ גדול מדי (עד 45MB). אפשר לקצר אותו קודם.", "This file is too large (max 45MB). Try trimming it first."))
            val ext = when (type) { "video/mp4" -> "mp4"; "video/quicktime" -> "mov"; "video/webm" -> "webm"; "image/png" -> "png"; "image/webp" -> "webp"; "image/heic", "image/heif" -> "heic"; else -> if (isVideo) "video" else "jpg" }
            val base = "${circleId(ctx)}/${Account.id(ctx)}/app_${System.currentTimeMillis()}"
            onProgress(L.t("שולחים למעגל המשפחה...", "Sending to your family circle..."))
            val fileUrl = upload(ctx, "$base.$ext", tmp, type)
            val coverUrl = if (isVideo) {
                val frame = try {
                    val mmr = MediaMetadataRetriever()
                    mmr.setDataSource(tmp.absolutePath)
                    val f = mmr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    mmr.release()
                    f
                } catch (_: Exception) {
                    null
                }
                frame?.let { uploadJpeg(ctx, "${base}_cover.jpg", it) } ?: ""
            } else fileUrl
            val post = JSONObject()
                .put("circle_id", circleId(ctx)).put("author_id", Account.id(ctx)).put("author", me(ctx)).put("title", title.trim())
                .put("kind", if (isVideo) "video" else "photo").put("taken_at", JSONObject.NULL)
                .put("video", fileUrl).put("cover", coverUrl)
            rest(ctx, "POST", "posts", post.toString())
        } finally {
            tmp.delete()
        }
    }

    private fun uploadJpeg(ctx: Context, path: String, bmp: Bitmap): String {
        val f = File(ctx.cacheDir, "cover_${System.currentTimeMillis()}.jpg")
        try {
            val w = 720
            val scaled = if (bmp.width > w) Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true) else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            f.writeBytes(out.toByteArray())
            return upload(ctx, path, f, "image/jpeg")
        } finally {
            f.delete()
        }
    }

    /**
     * Copies part of a clip into a small MP4, without re-encoding.
     * [startMs]/[endMs] < 0 = ~10 seconds around the moment itself (the highlight).
     */
    internal fun cutRange(ctx: Context, m: Memory, startMs: Long, endMs: Long): File {
        val seconds = SHARE_SECONDS
        val src = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.fromFile(File(m.uri))
        val ex = MediaExtractor()
        ex.setDataSource(ctx, src, null)
        val rotation = try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(ctx, src)
            val r = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            mmr.release()
            r
        } catch (_: Exception) {
            0
        }
        val out = File(ctx.cacheDir, "circle_${System.currentTimeMillis()}.mp4")
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        val map = HashMap<Int, Int>()
        var durUs = m.durationMs * 1000
        var videoTrack = -1
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                ex.selectTrack(i)
                map[i] = muxer.addTrack(f)
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    if (f.containsKey(MediaFormat.KEY_DURATION)) durUs = f.getLong(MediaFormat.KEY_DURATION)
                }
            }
        }
        if (videoTrack < 0) {
            ex.release()
            muxer.release()
            out.delete()
            throw IllegalStateException(L.t("לא מצאתי וידאו ברגע הזה", "No video found in this moment"))
        }
        muxer.start()
        val half = seconds * 500_000L
        val mid = (m.highlight * 1000).coerceIn(0, durUs) // the moment itself
        val chosen = startMs >= 0 && endMs > startMs
        val startUs = if (chosen) (startMs * 1000).coerceIn(0, durUs) else (mid - half).coerceAtLeast(0)
        val endUs = if (chosen) (endMs * 1000).coerceIn(startUs, durUs) else (mid + half).coerceAtMost(durUs)
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var base = -1L
        try {
            while (true) {
                val track = ex.sampleTrackIndex
                if (track < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                if (base < 0) {
                    if (track != videoTrack || (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) == 0) { ex.advance(); continue }
                    base = t
                }
                val o = map[track]
                if (o != null && t >= base) {
                    val sync = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                    info.set(0, size, t - base, if (sync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(o, buf, info)
                }
                ex.advance()
            }
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release()
            ex.release()
        }
        return out
    }

    // ---------- images from the web ----------

    private val imgCache = object : android.util.LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /** Downloads a cover (cached on disk and in memory). Background thread only. */
    fun image(ctx: Context, url: String): Bitmap? {
        if (url.isEmpty()) return null
        imgCache.get(url)?.let { return it }
        val f = File(File(ctx.cacheDir, "circle_img").apply { mkdirs() }, url.hashCode().toString() + ".img")
        if (!f.exists()) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                try {
                    if (conn.responseCode != 200) return null
                    conn.inputStream.use { input -> f.outputStream().use { input.copyTo(it) } }
                } finally {
                    conn.disconnect()
                }
            } catch (_: Exception) {
                f.delete()
                return null
            }
        }
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, opts)
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 720) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        imgCache.put(url, bmp)
        return bmp
    }
}
