package com.regaim.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * While a book is being made: an open book with the Moments mark on its left page, pages turning one after
 * another, and small sparkles rising from the spine. [pages] shows how many pages are already drawn (as filled
 * lines on the right page). Drawn by hand on a canvas, no images.
 */
class BookLoadingView(ctx: Context) : View(ctx) {
    var drawn = 0
        set(v) { field = v; invalidate() }
    var total = 0
        set(v) { field = v; invalidate() }

    private val brand = 0xFF5B4FE0.toInt()
    private val brandSoft = 0xFF8E84F2.toInt()
    private val paperC = 0xFFFBF7F0.toInt()
    private val paperShade = 0xFFEDE4D6.toInt()
    private val ink = 0xFF2C2A28.toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val logo = ContextCompat.getDrawable(ctx, R.drawable.ic_logo_mark)?.mutate()
    private var t = 0f // 0..1 within one page turn
    private var time = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { t = it.animatedValue as Float; time += 0.016f; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 0.62f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bookW = min(w * 0.86f, h * 1.55f)
        val pageW = bookW / 2f
        val pageH = pageW * 1.18f
        val cx = w / 2f
        val top = (h - pageH) / 2f + h * 0.04f
        val bottom = top + pageH

        // Cover behind the pages, and a soft shadow.
        fill.color = 0x22000000
        c.drawRoundRect(RectF(cx - pageW - 8f, bottom - 6f, cx + pageW + 8f, bottom + 14f), 20f, 20f, fill)
        fill.shader = LinearGradient(0f, top, 0f, bottom, brand, brandSoft, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(cx - pageW - 10f, top - 8f, cx + pageW + 10f, bottom + 8f), 18f, 18f, fill)
        fill.shader = null

        // Left page: the Moments mark.
        page(c, cx - pageW, top, cx, bottom, left = true)
        logo?.let { d ->
            val s = pageW * 0.42f
            val lx = cx - pageW / 2f
            val ly = top + pageH * 0.44f
            val pulse = 1f + 0.04f * sin(time * 3f)
            d.setBounds((lx - s / 2 * pulse).toInt(), (ly - s / 2 * pulse).toInt(), (lx + s / 2 * pulse).toInt(), (ly + s / 2 * pulse).toInt())
            d.draw(c)
        }
        fill.color = brand
        fill.textSize = pageW * 0.11f
        fill.textAlign = Paint.Align.CENTER
        fill.isFakeBoldText = true
        c.drawText("Moments", cx - pageW / 2f, top + pageH * 0.8f, fill)
        fill.isFakeBoldText = false

        // Right page: a line of "text" for every page already drawn.
        page(c, cx, top, cx + pageW, bottom, left = false)
        val lines = 8
        val done = if (total > 0) (lines * drawn / total) else 0
        for (i in 0 until lines) {
            val y = top + pageH * (0.2f + 0.08f * i)
            val len = pageW * (if (i % 3 == 2) 0.45f else 0.7f)
            stroke.strokeWidth = pageH * 0.022f
            stroke.color = if (i < done) ink else paperShade
            stroke.alpha = if (i < done) 140 else 255
            c.drawLine(cx + pageW * 0.15f, y, cx + pageW * 0.15f + len, y, stroke)
        }

        // The page turning: folds from the right page over to the left around the spine.
        val angle = Math.PI * t
        val x = cos(angle).toFloat() // 1 = flat on the right, -1 = flat on the left
        val lift = sin(angle).toFloat()
        val edge = cx + pageW * x
        val p = Path().apply {
            moveTo(cx, top)
            quadTo((cx + edge) / 2f, top - pageH * 0.06f * lift, edge, top - pageH * 0.03f * lift)
            lineTo(edge, bottom - pageH * 0.03f * lift)
            quadTo((cx + edge) / 2f, bottom - pageH * 0.02f * lift, cx, bottom)
            close()
        }
        fill.color = if (x >= 0) paperC else paperShade
        c.drawPath(p, fill)
        stroke.strokeWidth = 2f
        stroke.color = 0x33000000
        stroke.alpha = 60
        c.drawPath(p, stroke)

        // Spine.
        stroke.color = 0x40000000
        stroke.strokeWidth = 3f
        c.drawLine(cx, top + 4f, cx, bottom - 4f, stroke)

        // Sparkles rising from the spine.
        for (k in 0 until 5) {
            val phase = (time * 0.35f + k / 5f) % 1f
            val sx = cx + sin((k * 1.7f + time).toDouble()).toFloat() * pageW * 0.35f
            val sy = top - phase * h * 0.12f + pageH * 0.05f
            val r = (1f - abs(phase - 0.5f) * 2f) * pageW * 0.035f
            fill.color = if (k % 2 == 0) brandSoft else 0xFFF2B84B.toInt()
            fill.alpha = (255 * (1f - phase)).toInt()
            star(c, sx, sy, r)
        }
        fill.alpha = 255
    }

    private fun page(c: Canvas, l: Float, t: Float, r: Float, b: Float, left: Boolean) {
        fill.shader = LinearGradient(if (left) r else l, 0f, if (left) l else r, 0f, paperShade, paperC, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(l, t, r, b), 10f, 10f, fill)
        fill.shader = null
    }

    private fun star(c: Canvas, x: Float, y: Float, r: Float) {
        if (r <= 0f) return
        val p = Path().apply {
            moveTo(x, y - r); quadTo(x, y, x + r, y); quadTo(x, y, x, y + r); quadTo(x, y, x - r, y); quadTo(x, y, x, y - r); close()
        }
        c.drawPath(p, fill)
    }
}
