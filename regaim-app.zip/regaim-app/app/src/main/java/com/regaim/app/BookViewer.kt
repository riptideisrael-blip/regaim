package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * A finished book, read like a real picture book: full-page illustrations, the story printed on the page, swipe to
 * turn the page (right to left, like a Hebrew book) with a page-turn effect, a cover, a dedication and "the end".
 * Tap the page for the controls (close, page number, draw this page again).
 */
class BookViewerActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_ID = "book"
        fun open(ctx: Context, id: String) = ctx.startActivity(Intent(ctx, BookViewerActivity::class.java).putExtra(EXTRA_ID, id))
    }

    /** One spread of the book as the reader sees it. [page] is the index in Book.allPages (0 = cover), -1 for extra pages. */
    private class Sheet(val kind: Int, val page: Int)
    private val COVER = 0; private val DEDICATION = 1; private val STORY = 2; private val END = 3

    private lateinit var pager: ViewPager2
    private lateinit var bar: LinearLayout
    private lateinit var counter: TextView
    private lateinit var redrawBtn: TextView
    private var book: Book? = null
    private var sheets: List<Sheet> = emptyList()
    private var busy = false
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val paper = Color.parseColor("#F8F2E7")
    private val ink = Color.parseColor("#2A2420")

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#1C1917")) }
        pager = ViewPager2(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL // the next page comes from the left, like a Hebrew book
            offscreenPageLimit = 1
            setPageTransformer { page, position -> turn(page, position) }
        }
        root.addView(pager, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
            visibility = View.GONE
        }
        val close = barText("✕") { finish() }
        counter = barText("") {}
        redrawBtn = barText(L.t("לצייר את העמוד מחדש", "Redraw this page")) { redrawCurrent() }
        bar.addView(close)
        bar.addView(counter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(16) })
        bar.addView(redrawBtn)
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateBar()
        })
        load()
    }

    override fun onDestroy() { worker.shutdown(); super.onDestroy() }

    private fun barText(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 16f
        setPadding(dp(6), dp(6), dp(6), dp(6))
        setOnClickListener { onClick() }
    }

    private fun load(keepAt: Int = 0) {
        val b = BookStore.load(this, intent.getStringExtra(EXTRA_ID).orEmpty()) ?: run { finish(); return }
        book = b
        val list = ArrayList<Sheet>()
        list.add(Sheet(COVER, 0))
        if (b.dedication.isNotBlank()) list.add(Sheet(DEDICATION, -1))
        b.pages.indices.forEach { list.add(Sheet(STORY, it + 1)) }
        list.add(Sheet(END, -1))
        sheets = list
        pager.adapter = Adapter()
        pager.setCurrentItem(keepAt.coerceIn(0, list.size - 1), false)
        updateBar()
    }

    private fun updateBar() {
        val s = sheets.getOrNull(pager.currentItem) ?: return
        counter.text = when (s.kind) {
            COVER -> L.t("כריכה", "Cover")
            STORY -> L.t("עמוד ${s.page} מתוך ${book?.pages?.size ?: 0}", "Page ${s.page} of ${book?.pages?.size ?: 0}")
            else -> ""
        }
        redrawBtn.visibility = if (s.page >= 0) View.VISIBLE else View.GONE
        redrawBtn.text = if (busy) L.t("מציירים מחדש...", "Redrawing...") else L.t("לצייר את העמוד מחדש", "Redraw this page")
    }

    private fun toggleBar() { bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE; updateBar() }

    /** A gentle page turn: the page leaving folds away around the spine; the next one is revealed underneath. */
    private val rtl = true
    private val dir = if (rtl) -1 else 1

    private fun turn(page: View, position: Float) {
        page.cameraDistance = page.width * 14f
        when {
            position < -1f || position > 1f -> { page.alpha = 0f }
            position <= 0f -> {
                page.alpha = 1f
                page.translationX = 0f
                page.pivotY = page.height / 2f
                page.pivotX = if (rtl) page.width.toFloat() else 0f
                page.rotationY = -75f * position * dir
                page.translationZ = 1f
            }
            else -> {
                page.alpha = 1f
                page.rotationY = 0f
                page.translationZ = 0f
                // Stay in place under the turning page instead of sliding in.
                page.translationX = -page.width * position * dir
                val scale = 0.94f + 0.06f * (1f - abs(position))
                page.scaleX = scale; page.scaleY = scale
            }
        }
        if (position <= 0f) { page.scaleX = 1f; page.scaleY = 1f }
    }

    /** Decodes a page picture at about screen size (no out-of-memory on long books). */
    private fun picture(file: File): Bitmap? {
        if (!file.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, o)
        val target = max(resources.displayMetrics.widthPixels, 720)
        var sample = 1
        while (o.outWidth / (sample * 2) >= target) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private inner class Holder(val frame: FrameLayout) : RecyclerView.ViewHolder(frame)

    private inner class Adapter : RecyclerView.Adapter<Holder>() {
        override fun getItemCount() = sheets.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(FrameLayout(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        })
        override fun onBindViewHolder(h: Holder, position: Int) {
            val f = h.frame
            f.removeAllViews()
            f.setOnClickListener { toggleBar() }
            val b = book ?: return
            val s = sheets[position]
            when (s.kind) {
                COVER -> coverPage(f, b)
                DEDICATION -> textPage(f, b.dedication, small = L.t("הקדשה", "Dedication"))
                STORY -> storyPage(f, b, s.page)
                else -> endPage(f, b)
            }
        }
    }

    private fun image(f: FrameLayout, p: BookPage, b: Book): Boolean {
        val bmp = if (p.image.isNotEmpty()) picture(File(BookStore.dir(this, b.id), p.image)) else null
        if (bmp == null) {
            f.setBackgroundColor(paper)
            f.addView(TextView(this).apply {
                text = L.t("העמוד הזה עוד לא צויר.\nפתחו את התפריט ולחצו \"לצייר את העמוד מחדש\".", "This page isn't drawn yet.\nOpen the menu and tap \"Redraw this page\".")
                setTextColor(ink); textSize = 16f; gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return false
        }
        // Portrait pages fill the screen; older landscape pages are shown whole.
        val portrait = bmp.height >= bmp.width
        f.setBackgroundColor(if (portrait) Color.BLACK else paper)
        f.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = if (portrait) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_START
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return true
    }

    private fun coverPage(f: FrameLayout, b: Book) {
        image(f, b.cover, b)
        f.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x99000000.toInt(), 0x00000000, 0x00000000))
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(56), dp(24), 0)
        }
        box.addView(TextView(this).apply {
            text = b.title
            textSize = 34f
            typeface = Fonts.display
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(dp(6).toFloat(), 0f, dp(2).toFloat(), 0xAA000000.toInt())
        })
        box.addView(TextView(this).apply {
            text = L.t("ספר של ${b.child}", "A book about ${b.child}")
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(dp(4).toFloat(), 0f, dp(1).toFloat(), 0xAA000000.toInt())
            setPadding(0, dp(8), 0, 0)
        })
        f.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
    }

    private fun storyPage(f: FrameLayout, b: Book, index: Int) {
        val p = b.allPages.getOrNull(index) ?: return
        image(f, p, b)
        // The story printed on the page: a soft paper panel over the calm lower part of the picture.
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(22))
            background = GradientDrawable().apply {
                setColor((paper and 0x00FFFFFF) or (0xEB shl 24))
                cornerRadius = dp(22).toFloat()
            }
            elevation = dp(2).toFloat()
        }
        panel.addView(TextView(this).apply {
            text = p.text
            textSize = 20f
            setTextColor(ink)
            setLineSpacing(dp(5).toFloat(), 1f)
            gravity = Gravity.CENTER
            textDirection = if (b.lang == "he") View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
        })
        panel.addView(TextView(this).apply {
            text = "$index"
            textSize = 12f
            setTextColor(Color.parseColor("#8A7F74"))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        f.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(14), 0, dp(14), dp(22))
        })
    }

    private fun textPage(f: FrameLayout, text: String, small: String) {
        f.setBackgroundColor(paper)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(36), 0, dp(36), 0) }
        box.addView(TextView(this).apply { this.text = "♡"; textSize = 30f; setTextColor(Color.parseColor("#C07A5A")); gravity = Gravity.CENTER })
        box.addView(TextView(this).apply {
            this.text = text
            textSize = 24f
            typeface = Fonts.display
            setTextColor(ink)
            gravity = Gravity.CENTER
            setLineSpacing(dp(6).toFloat(), 1f)
            setPadding(0, dp(16), 0, dp(16))
        })
        box.addView(TextView(this).apply { this.text = small; textSize = 13f; setTextColor(Color.parseColor("#8A7F74")); gravity = Gravity.CENTER })
        f.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun endPage(f: FrameLayout, b: Book) {
        val drawn = image(f, b.cover, b)
        if (drawn) f.addView(View(this).apply { setBackgroundColor(0xB3000000.toInt()) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(TextView(this).apply {
            text = L.t("הסוף", "The End")
            textSize = 44f
            typeface = Fonts.display
            setTextColor(if (drawn) Color.WHITE else ink)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = L.t("נוצר באהבה ב-Moments", "Made with love in Moments")
            textSize = 14f
            setTextColor(if (drawn) Color.WHITE else Color.parseColor("#8A7F74"))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        })
        f.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun redrawCurrent(newCredit: Boolean = false) {
        val s = sheets.getOrNull(pager.currentItem) ?: return
        val b = book ?: return
        if (busy || s.page < 0) return
        busy = true
        updateBar()
        val at = pager.currentItem
        worker.execute {
            val err = try { BookMaker.Pages.redraw(applicationContext, b.id, s.page, newCredit); null } catch (e: BookMaker.NeedCredit) { "credit" } catch (e: Exception) { e.message ?: "" }
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                when (err) {
                    null -> load(at)
                    "credit" -> AlertDialog.Builder(this)
                        .setMessage(L.t("עברו יותר משלוש שעות מאז שהספר התחיל, אז ציור מחדש משתמש בקרדיט נוסף (שמאפשר עוד תיקונים בשלוש השעות הקרובות). להמשיך?", "It's been over three hours since the book started, so redrawing uses another credit (good for more fixes in the next three hours). Continue?"))
                        .setPositiveButton(L.t("כן", "Yes")) { _, _ -> redrawCurrent(true) }
                        .setNegativeButton(L.t("לא", "No"), null).show()
                    else -> { load(at); Toast.makeText(this, err, Toast.LENGTH_LONG).show() }
                }
            }
        }
    }
}
