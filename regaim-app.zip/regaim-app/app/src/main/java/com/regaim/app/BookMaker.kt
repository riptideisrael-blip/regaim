package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** Books on the phone: one folder per book (book.json, the face crops, the character, every page). */
object BookStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "books").apply { mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    @Synchronized
    fun save(ctx: Context, b: Book) {
        val d = dir(ctx, b.id)
        val tmp = File(d, "book.json.tmp")
        tmp.writeText(BookJson.toJson(b).toString())
        tmp.renameTo(File(d, "book.json"))
    }

    @Synchronized
    fun load(ctx: Context, id: String): Book? = try {
        BookJson.fromJson(JSONObject(File(root(ctx), "$id/book.json").readText()))
    } catch (_: Exception) { null }

    /** Finished books, newest first. */
    fun all(ctx: Context): List<Book> = (root(ctx).listFiles() ?: emptyArray()).mapNotNull { load(ctx, it.name) }.sortedByDescending { it.created }

    /** Read, change and save in one step (pages are drawn two at a time: no change is lost). Null if there's no such book. */
    @Synchronized
    fun update(ctx: Context, id: String, change: (Book) -> Book): Book? {
        val b = load(ctx, id) ?: return null
        return change(b).also { save(ctx, it) }
    }

    fun image(ctx: Context, b: Book, name: String): File = File(dir(ctx, b.id), name)

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }

    fun writeJpeg(f: File, bmp: Bitmap) = FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
}

/**
 * Makes a personal book, reusing the cartoon film's server path (credits, fal jobs, polling):
 *  photos (automatic) → story (Claude) → one credit → the child as a book character → the parent approves
 *  → cover and pages, each drawn from the approved character and one real face photo → done.
 * Every result is downloaded at once and fal is asked to delete the request ("forget").
 *
 * Built for phones on cellular data: every server call waits for the connection and tries again (Net); when the
 * connection is gone for minutes the book is paused, not failed, and can be continued from the step it reached
 * (also after the phone closed the app). The credit is tied to the book (its id), so asking again never takes a
 * second one, and a refund that couldn't be sent is kept and sent later (Refunds).
 * One book at a time; its state is saved to disk after every step. A foreground service (BookService) keeps the
 * work going when the parent leaves the app.
 */
object BookMaker {
    const val PAGES = 6
    const val CHARACTER_TRIES = 3

    enum class State { PHOTOS, NEED_PHOTO, CONFIRM_PHOTOS, WRITING, CHARACTER, APPROVE, PAGES, PAUSED, NEED_CREDIT, DONE, FAILED }

    /** The credit's 30-minute window is over (or used up): continuing needs one more credit, with the parent's OK. */
    class NeedCredit : Exception()

    @Volatile var current: Session? = null
        private set

    fun start(ctx: Context, child: FamilyMember, theme: BookTheme, details: String): Session {
        current?.cancel()
        Refunds.flushAsync(ctx.applicationContext)
        return Session(ctx.applicationContext, child.name, child, theme, details, null).also { current = it; it.go() }
    }

    /** A book that stopped in the middle (no connection, or the phone closed the app) and isn't being worked on now. */
    fun unfinished(ctx: Context): Book? = BookStore.all(ctx).firstOrNull { b ->
        b.state in setOf("character", "approve", "pages") && current?.bookId != b.id
    }

    /** Continues a saved book from the step it reached. */
    fun resume(ctx: Context, b: Book): Session {
        current?.let { if (it.bookId == b.id && it.isActive) return it; it.cancel() }
        val member = Profile.members(ctx).firstOrNull { it.name.trim() == b.child.trim() }
        return Session(ctx.applicationContext, b.child, member, BookThemes.of(b.theme), "", b).also { current = it; it.retry() }
    }

    /** Gives up on a saved unfinished book: returns its credit if the server still allows it. Background thread only. */
    fun abandon(ctx: Context, b: Book) {
        if (b.charged) Refunds.add(ctx, b.id)
        BookStore.update(ctx, b.id) { it.copy(state = "failed", error = L.t("בוטל", "Cancelled")) }
        Refunds.flush(ctx)
    }

    /** Forgets a finished (or failed) session so the screen starts fresh next time. */
    fun clear() { if (current?.isActive != true) current = null }

    class Session(
        private val ctx: Context, val childName: String, private val member: FamilyMember?,
        val theme: BookTheme, private val details: String, saved: Book?,
    ) {
        @Volatile var state = State.PHOTOS; private set
        @Volatile var message = ""; private set
        @Volatile var book: Book? = saved; private set
        @Volatile var progress = 0; private set
        /** Waiting for the internet to come back (shown on the screen and in the notification). */
        @Volatile var waiting = false; private set
        var listener: (() -> Unit)? = null
        val bookId: String = saved?.id ?: "book_${System.currentTimeMillis()}"
        private val main = Handler(Looper.getMainLooper())
        private val worker = Executors.newSingleThreadExecutor()
        private val cancelled = AtomicBoolean(false)
        private var faces: List<Bitmap> = emptyList()
        /** The photos found automatically, waiting for the parent to confirm they really are this child. */
        val candidates = java.util.concurrent.CopyOnWriteArrayList<BookPhotos.Chosen>()
        private var sources: List<String> = emptyList()
        private val link = Link(ctx, cancelled) { w -> if (waiting != w) { waiting = w; changed(); BookService.sync(ctx) } }

        val isActive: Boolean get() = state != State.DONE && state != State.FAILED
        val triesLeft: Int get() = CHARACTER_TRIES - (book?.characterTries ?: 0)

        private fun changed() = main.post { listener?.invoke() }
        private fun set(s: State, msg: String = message) {
            state = s; message = msg
            if (s !in setOf(State.PHOTOS, State.WRITING, State.CHARACTER, State.PAGES)) waiting = false
            changed()
            BookService.sync(ctx)
            // Finished: let the worker thread end (the current task still completes).
            if (s == State.DONE || s == State.FAILED) worker.shutdown()
        }

        private fun fail(msg: String) {
            val b = book
            if (b != null) {
                book = BookStore.update(ctx, b.id) { it.copy(state = "failed", error = msg) } ?: b
                if (b.charged) { Refunds.add(ctx, b.id); Refunds.flush(ctx) }
            }
            set(State.FAILED, msg)
        }

        /** No connection for minutes: keep everything as it is; the parent continues when back online. */
        private fun pause(msg: String) = set(State.PAUSED, msg)

        /** Runs one step on the worker; a step that throws ends in pause / need-credit / failure (never a crash). */
        private fun step(fallback: String, block: () -> Unit) = worker.execute {
            try { block() } catch (e: Exception) {
                if (cancelled.get()) return@execute
                when (e) {
                    is Net.Offline, is Net.Stuck -> pause(e.message ?: "")
                    is NeedCredit -> set(State.NEED_CREDIT, L.t(
                        "עברו יותר מ-30 דקות מאז שהספר התחיל, אז ההמשך ישתמש בקרדיט נוסף. להמשיך?",
                        "More than 30 minutes have passed since the book started, so continuing uses one more credit. Continue?",
                    ))
                    is CartoonFilm.FatalEdgeError -> fail(e.message ?: fallback)
                    else -> fail(CartoonFilm.friendly(e, fallback))
                }
            }
        }

        fun go() = step(L.t("לא הצלחנו לבחור תמונות", "Couldn't choose photos")) { photos() }

        /** Continues from where the book stopped (after a pause, or a book saved before the app was closed). */
        fun retry() = step(L.t("לא הצלחנו להמשיך את הספר", "Couldn't continue the book")) { continueSaved(again = false) }

        /** The parent agreed to use one more credit. */
        fun continueWithNewCredit() = step(L.t("לא הצלחנו להמשיך את הספר", "Couldn't continue the book")) { continueSaved(again = true) }

        private fun continueSaved(again: Boolean) {
            val b = book
            if (b == null) {
                // Stopped before the story was saved.
                if (faces.isNotEmpty()) write() else photos()
                return
            }
            when (b.state) {
                "character" -> { ensureCredit(again); character() }
                "approve" -> set(State.APPROVE, "")
                else -> { ensureCredit(again); drawPages() }
            }
        }

        private fun photos() {
            val child = member ?: throw IllegalStateException(L.t("הילד/ה לא נמצא/ה בפרופיל המשפחה", "The child isn't in the family profile"))
            set(State.PHOTOS, L.t("בוחרים את התמונות הכי טובות של $childName...", "Choosing the best photos of $childName..."))
            val r = BookPhotos.pick(ctx, child) { p -> progress = p; changed() }
            if (cancelled.get()) return
            if (r.photos.isEmpty()) { set(State.NEED_PHOTO, r.problem ?: ""); return }
            // Face recognition can mix up siblings: the parent confirms the photos before anything is sent or paid.
            candidates.clear()
            candidates.addAll(r.photos)
            set(State.CONFIRM_PHOTOS, "")
        }

        /** The parent says this photo isn't the child. */
        fun removeCandidate(c: BookPhotos.Chosen) {
            if (state != State.CONFIRM_PHOTOS) return
            candidates.remove(c)
            changed()
        }

        /** The parent confirmed: the book is drawn from the first three. */
        fun confirmPhotos() {
            if (state != State.CONFIRM_PHOTOS || candidates.isEmpty()) return
            val use = candidates.take(3)
            faces = use.map { it.crop }
            sources = use.map { it.memoryId }.filter { it != "parent" && it != "profile" }
            step(L.t("לא הצלחנו לכתוב את הסיפור", "Couldn't write the story")) { write() }
        }

        /** The parent's own photo, when we couldn't find a good one. */
        fun usePhoto(uri: Uri) = step(L.t("לא הצלחנו להשתמש בתמונה", "Couldn't use the photo")) {
            val c = BookPhotos.fromParentPhoto(ctx, uri)
            if (c == null) {
                set(State.NEED_PHOTO, L.t("לא מצאנו פנים ברורות בתמונה הזאת. נסו תמונה אחרת, קרובה ובאור טוב.", "No clear face in that photo. Try another one, closer and in good light."))
                return@step
            }
            if (state == State.CONFIRM_PHOTOS) {
                // Added to the photos being confirmed (first: the parent chose it).
                candidates.add(0, c)
                set(State.CONFIRM_PHOTOS, "")
                return@step
            }
            faces = listOf(c.crop)
            sources = emptyList()
            write()
        }

        private fun write() {
            set(State.WRITING, L.t("כותבים את הסיפור...", "Writing the story..."))
            val months = member?.let { Profile.ageMonths(it.birth) }
            val girl = when (member?.relation) { "ילדה" -> true; "ילד" -> false; else -> null }
            // Safe to repeat: a lost answer only means the story is written again.
            val story = link.net {
                Net.token(ctx)
                ClaudeClient.bookStory(ctx, childName, months, girl, theme, details, PAGES)
            } ?: throw IllegalStateException(L.t("לא הצלחנו לכתוב את הסיפור. נסו שוב.", "Couldn't write the story. Try again."))
            if (cancelled.get()) return
            val b = Book(
                bookId, childName, BookJson.ageDesc(months, girl), theme.key, if (L.isEn) "en" else "he", story.title, story.outfit,
                BookPage(story.title, story.coverScene), story.pages.map { BookPage(it.first, it.second) },
                state = "character", photoSources = sources,
            )
            // The face crops stay in the book's folder on the phone (to continue or fix a page later).
            faces.forEachIndexed { i, f -> BookStore.writeJpeg(BookStore.image(ctx, b, "face_$i.jpg"), f) }
            BookStore.save(ctx, b)
            book = b
            ensureCredit(again = false)
            character()
        }

        /** Makes sure this book holds a credit (taking one only the first time, or with the parent's OK). */
        private fun ensureCredit(again: Boolean) {
            val b = book ?: return
            link.reserve(b.id, again)
            if (!b.charged) book = BookStore.update(ctx, b.id) { it.copy(charged = true) } ?: b.copy(charged = true)
        }

        private fun character() {
            val b = book ?: return
            set(State.CHARACTER, L.t("מציירים את $childName כדמות בספר...", "Drawing $childName as the book's hero..."))
            val faces = (0 until 3).mapNotNull { i -> BookStore.image(ctx, b, "face_$i.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) } }
            if (faces.isEmpty()) throw IllegalStateException(L.t("התמונות של הילד/ה לא נמצאו. התחילו ספר חדש.", "The child's photos are missing. Start a new book."))
            val uris = faces.map { CartoonFilm.dataUri(it) }
            val (url, req) = link.job(mapOf("kind" to "book_character", "image" to uris.first(), "refs" to JSONArray(uris.drop(1)),
                "age" to b.ageDesc, "outfit" to b.outfit, "aspect" to "3:4"))
            val bmp = url?.let { link.download(it) }
            req?.let { link.forget(b.id, it) }
            if (bmp == null) throw IllegalStateException(Pages.refusal())
            if (cancelled.get()) return
            val name = "character_${b.characterTries}.jpg"
            BookStore.writeJpeg(BookStore.image(ctx, b, name), bmp)
            book = BookStore.update(ctx, b.id) { it.copy(character = name, characterTries = it.characterTries + 1, state = "approve") }
            set(State.APPROVE, "")
        }

        fun redrawCharacter() {
            if (state != State.APPROVE || triesLeft <= 0) return
            step(L.t("לא הצלחנו לצייר את הדמות", "Couldn't draw the character")) { ensureCredit(again = false); character() }
        }

        /** The parent approved the character: draw the cover and the pages (two at a time). */
        fun approve() {
            val b = book ?: return
            if (state != State.APPROVE) return
            book = BookStore.update(ctx, b.id) { it.copy(state = "pages") } ?: b
            set(State.PAGES, L.t("מציירים את הספר...", "Drawing the book..."))
            step(L.t("לא הצלחנו לצייר את הספר", "Couldn't draw the book")) { ensureCredit(again = false); drawPages() }
        }

        /** Draws every page that isn't drawn yet (all of them the first time; the missing ones after a pause). */
        private fun drawPages() {
            set(State.PAGES, L.t("מציירים את הספר...", "Drawing the book..."))
            val b = BookStore.load(ctx, bookId) ?: return
            val all = b.allPages
            val todo = all.indices.filter { all[it].status != "done" }
            val total = all.size
            val done = AtomicInteger(total - todo.size)
            progress = 100 * done.get() / total; changed()
            val needCredit = AtomicBoolean(false)
            val stop = AtomicReference<Exception?>(null)
            val tasks = todo.map { i ->
                Callable<Unit> {
                    try {
                        if (!cancelled.get() && !needCredit.get() && stop.get() == null) Pages.draw(ctx, link, bookId, i)
                    } catch (_: NeedCredit) {
                        needCredit.set(true)
                    } catch (e: Net.Offline) {
                        stop.compareAndSet(null, e)
                    } catch (e: Net.Stuck) {
                        stop.compareAndSet(null, e)
                    } catch (e: CartoonFilm.FatalEdgeError) {
                        stop.compareAndSet(null, e)
                    } catch (_: Exception) {
                        // this page is marked failed in the book; it can be redrawn from there
                    } finally {
                        progress = 100 * done.incrementAndGet() / total
                        changed()
                    }
                    Unit
                }
            }
            val pool = Executors.newFixedThreadPool(2)
            try { pool.invokeAll(tasks) } finally { pool.shutdown() }
            if (cancelled.get()) return
            if (needCredit.get()) throw NeedCredit()
            stop.get()?.let { throw it }
            val fin = BookStore.load(ctx, bookId) ?: return
            val ok = fin.allPages.count { it.status == "done" }
            if (ok == 0) throw IllegalStateException(L.t("לא הצלחנו לצייר את העמודים", "Couldn't draw the pages"))
            book = BookStore.update(ctx, bookId) { it.copy(state = "done", error = "") }
            set(State.DONE, if (ok < total) L.t("${total - ok} עמודים לא צוירו. אפשר לצייר אותם שוב מתוך הספר.", "${total - ok} pages weren't drawn. You can redraw them from the book.") else "")
        }

        /** The parent cancelled: the book is dropped; its credit is returned if the server still allows it. */
        fun cancel() {
            cancelled.set(true)
            if (current === this) current = null
            worker.shutdownNow()
            val b = book
            val app = ctx
            Thread {
                if (b != null) {
                    BookStore.update(app, b.id) { it.copy(state = "failed", error = L.t("בוטל", "Cancelled")) }
                    if (b.charged || BookStore.load(app, b.id)?.charged == true) Refunds.add(app, b.id)
                }
                Refunds.flush(app)
            }.start()
            BookService.sync(ctx)
        }
    }

    /**
     * The server calls of a book, each one waiting for the connection and trying again (Net).
     * Repeating is safe: reserve/refund carry the book's reference, polling and downloads only read,
     * forget is idempotent at fal. (A repeated submit may draw one extra picture: a few cents, never a credit.)
     */
    class Link(private val ctx: Context, private val cancelled: AtomicBoolean = AtomicBoolean(false), private val onWait: (Boolean) -> Unit = {}) {
        private val edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"

        fun <T> net(maxWaitMs: Long = Net.WAIT_MS, block: () -> T): T = Net.retry(ctx, cancelled, maxWaitMs, onWait, block)

        fun call(body: Map<String, Any>, maxWaitMs: Long = Net.WAIT_MS): JSONObject = net(maxWaitMs) { CartoonFilm.callEdge(edgeUrl, Net.token(ctx), body) }

        /** Takes the book's credit, or confirms it already has it. Throws [NeedCredit] when the window is over. */
        fun reserve(ref: String, again: Boolean) {
            val res = call(mapOf<String, Any>("action" to "reserve", "ref" to ref) + (if (again) mapOf<String, Any>("again" to true) else emptyMap()))
            if (res.optBoolean("ok", false)) return
            if (res.optBoolean("expired", false)) {
                // The window ran out while (almost) nothing was drawn: that credit comes back first, so continuing costs nothing extra.
                if (!again && refund(ref)) return reserve(ref, true)
                throw NeedCredit()
            }
            if (res.optInt("_code", 200) == 401) throw CartoonFilm.FatalEdgeError(res.optString("error").ifBlank { L.t("צריך להתחבר מחדש", "Please sign in again") })
            throw IllegalStateException(res.optString("error", "").ifBlank { L.t("אין קרדיט פנוי ליצירה.", "No credit available.") })
        }

        /** True only when the server confirmed giving the credit back. */
        fun refund(ref: String): Boolean = try {
            call(mapOf("action" to "refund", "ref" to ref), 60_000).optBoolean("refunded", false)
        } catch (e: CancellationException) { false } catch (_: Exception) { false }

        /** Submits one drawing and waits for it; returns (result url, fal request id). */
        fun job(body: Map<String, Any>): Pair<String?, String?> {
            val res = call(mapOf<String, Any>("action" to "submit") + body)
            if (res.optInt("_code", 200) == 402) throw NeedCredit()
            CartoonFilm.checkError(res)
            val url = poll(res.optString("status_url"), res.optString("response_url"))
            return url.ifEmpty { null } to res.optString("request_id").ifEmpty { null }
        }

        private fun poll(statusUrl: String, responseUrl: String): String {
            if (statusUrl.isEmpty() || responseUrl.isEmpty()) return ""
            CartoonFilm.lastJobDetail = ""
            repeat(120) { // up to 10 minutes of drawing (time without a connection isn't counted)
                if (cancelled.get()) throw CancellationException()
                Thread.sleep(5000)
                val res = call(mapOf("action" to "poll", "status_url" to statusUrl, "response_url" to responseUrl))
                when (res.optString("status", "PENDING")) {
                    "DONE" -> return res.optString("url", "")
                    "FAILED" -> { CartoonFilm.lastJobDetail = res.optString("detail", "").take(160); return "" }
                }
            }
            return ""
        }

        /** The drawing, or null if fal no longer has it (a lost connection is waited out). */
        fun download(url: String): Bitmap? = net {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            try {
                if (conn.responseCode !in 200..299) null
                else conn.inputStream.use { BitmapFactory.decodeStream(it) } ?: throw IOException("partial image")
            } finally { conn.disconnect() }
        }

        /** Asks fal to delete the request (inputs, outputs, files); records whether fal confirmed it. */
        fun forget(bookId: String, requestId: String) {
            val ok = try { call(mapOf("action" to "forget", "request_id" to requestId), 60_000).optBoolean("ok", false) } catch (_: Exception) { false }
            BookStore.update(ctx, bookId) { it.copy(forgotten = it.forgotten + (requestId to ok)) }
        }
    }

    /** Drawing one page (also used from the finished book, to fix a single page). */
    object Pages {
        fun refusal(): String {
            val d = CartoonFilm.lastJobDetail.lowercase()
            return if ("content_policy" in d || "safety" in d || "flagged" in d) L.t("שירות הציור סירב לתמונה הזאת. נסו שוב, או בחרו תמונה אחרת של הילד.", "The drawing service refused this picture. Try again, or pick another photo of the child.")
            else L.t("הציור לא הצליח הפעם. נסו שוב.", "The drawing didn't work this time. Try again.")
        }

        /**
         * Draws page [i] (0 = cover) and saves it into the book as done or failed. A lost connection is waited out
         * (and if it's gone for minutes, [Net.Offline] is thrown and the page is left as it was). Throws [NeedCredit]
         * when the credit's window is over.
         */
        fun draw(ctx: Context, link: Link, bookId: String, i: Int) {
            val b = BookStore.load(ctx, bookId) ?: return
            val page = b.allPages[i]
            val dir = BookStore.dir(ctx, b.id)
            val character = BitmapFactory.decodeFile(File(dir, b.character).absolutePath) ?: return
            val face = BitmapFactory.decodeFile(File(dir, "face_0.jpg").absolutePath)
            val scene = if (i == 0) "Book cover illustration: ${page.scene}" else page.scene
            val body = mapOf(
                "kind" to "book_page", "image" to CartoonFilm.dataUri(character),
                "refs" to JSONArray(listOfNotNull(face?.let { CartoonFilm.dataUri(it) })),
                "scene" to scene, "outfit" to b.outfit, "aspect" to "4:3",
            )
            val (url, req) = try { link.job(body) } catch (e: NeedCredit) { throw e } catch (e: CartoonFilm.FatalEdgeError) { throw e
            } catch (e: Net.Offline) { throw e } catch (e: Net.Stuck) { throw e } catch (e: CancellationException) { throw e } catch (_: Exception) { null to null }
            val bmp = url?.let { link.download(it) }
            req?.let { link.forget(bookId, it) }
            BookStore.update(ctx, bookId) { fresh ->
                val p = if (i == 0) fresh.cover else fresh.pages[i - 1]
                val updated = if (bmp != null) {
                    val name = if (i == 0) "cover_${p.tries}.jpg" else "page_${i}_${p.tries}.jpg"
                    BookStore.writeJpeg(File(dir, name), bmp)
                    p.copy(image = name, status = "done", tries = p.tries + 1)
                } else p.copy(status = if (p.image.isNotEmpty()) "done" else "failed", tries = p.tries + 1)
                if (i == 0) fresh.copy(cover = updated) else fresh.copy(pages = fresh.pages.mapIndexed { k, x -> if (k == i - 1) updated else x })
            }
            if (bmp == null) throw IllegalStateException(refusal())
        }

        /**
         * Fixes one page of a finished book. Inside the credit's 30-minute window it's free; after it, [newCredit]
         * must be true (the parent agreed to use one more credit). Background thread only.
         */
        fun redraw(ctx: Context, bookId: String, i: Int, newCredit: Boolean) {
            BookStore.load(ctx, bookId) ?: throw IllegalStateException("no book")
            val link = Link(ctx)
            // A fresh reference for this fix, fixed before any retry: a resent request can't take a second credit.
            if (newCredit) link.reserve("${bookId}_fix_${System.currentTimeMillis()}", again = false)
            draw(ctx, link, bookId, i)
        }
    }
}

/**
 * Refunds that couldn't reach the server (no connection) are kept here and sent again later
 * (when a book starts, when the book screen opens). The server refunds a book's credit at most once.
 */
object Refunds {
    private fun p(ctx: Context) = ctx.getSharedPreferences("book_refunds", Context.MODE_PRIVATE)

    @Synchronized fun add(ctx: Context, ref: String) {
        val now = p(ctx).getStringSet("refs", emptySet()).orEmpty()
        p(ctx).edit().putStringSet("refs", now + ref).apply()
    }

    @Synchronized private fun remove(ctx: Context, ref: String) {
        val now = p(ctx).getStringSet("refs", emptySet()).orEmpty()
        p(ctx).edit().putStringSet("refs", now - ref).apply()
    }

    /** Background thread only. */
    fun flush(ctx: Context) {
        if (!Account.signedIn(ctx)) return
        val refs = synchronized(this) { p(ctx).getStringSet("refs", emptySet()).orEmpty().toList() }
        if (refs.isEmpty()) return
        val edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"
        for (ref in refs) {
            try {
                val token = Account.token(ctx) ?: return
                val res = CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "refund", "ref" to ref))
                // The server answered (refunded, or the refund isn't allowed any more): nothing left to send.
                if (res.optInt("_code", 200) in 200..499) remove(ctx, ref)
            } catch (_: Exception) { return } // still offline: next time
        }
    }

    fun flushAsync(ctx: Context) { Thread { flush(ctx) }.start() }
}
