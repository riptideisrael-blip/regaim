package com.regaim.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Books on the phone: one folder per book (book.json, the face crops, the character, every page). */
object BookStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "books").apply { mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    @Synchronized
    fun save(ctx: Context, b: Book) {
        val d = dir(ctx, b.id)
        val tmp = File(d, "book.json.tmp")
        tmp.writeText(BookJson.toJson(b).toString())
        tmp.renameTo(File(d, "book.json"))
    }

    @Synchronized
    fun load(ctx: Context, id: String): Book? = try {
        BookJson.fromJson(JSONObject(File(root(ctx), "$id/book.json").readText()))
    } catch (_: Exception) { null }

    /** Finished books, newest first. */
    fun all(ctx: Context): List<Book> = (root(ctx).listFiles() ?: emptyArray()).mapNotNull { load(ctx, it.name) }.sortedByDescending { it.created }

    fun image(ctx: Context, b: Book, name: String): File = File(dir(ctx, b.id), name)

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }

    fun writeJpeg(f: File, bmp: Bitmap) = FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
}

/**
 * Makes a personal book, reusing the cartoon film's server path (credits, fal jobs, polling):
 *  photos (automatic) → story (Claude) → one credit → the child as a book character → the parent approves
 *  → cover and pages, each drawn from the approved character and one real face photo → done.
 * Every result is downloaded at once and fal is asked to delete the request ("forget").
 * One book at a time; its state is saved to disk after every step.
 */
object BookMaker {
    const val PAGES = 6
    const val CHARACTER_TRIES = 3

    enum class State { PHOTOS, NEED_PHOTO, WRITING, CHARACTER, APPROVE, PAGES, DONE, FAILED }

    @Volatile var current: Session? = null
        private set

    fun start(ctx: Context, child: FamilyMember, theme: BookTheme, details: String): Session {
        current?.cancel()
        return Session(ctx.applicationContext, child, theme, details).also { current = it; it.go() }
    }

    /** Forgets a finished (or failed) session so the screen starts fresh next time. */
    fun clear() { if (current?.isActive != true) current = null }

    class Session(private val ctx: Context, val child: FamilyMember, val theme: BookTheme, private val details: String) {
        @Volatile var state = State.PHOTOS; private set
        @Volatile var message = ""; private set
        @Volatile var book: Book? = null; private set
        @Volatile var progress = 0; private set
        var listener: (() -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())
        private val worker = Executors.newFixedThreadPool(2)
        private val cancelled = AtomicBoolean(false)
        private var faces: List<Bitmap> = emptyList()
        private var token = ""
        private var edgeUrl = ""
        private var reserved = false
        private val id = "book_${System.currentTimeMillis()}"

        val isActive: Boolean get() = state != State.DONE && state != State.FAILED

        private fun changed() = main.post { listener?.invoke() }
        private fun set(s: State, msg: String = message) {
            state = s; message = msg; changed()
            // Finished: let the two worker threads end (the current task still completes).
            if (s == State.DONE || s == State.FAILED) worker.shutdown()
        }
        private fun fail(msg: String) {
            book?.let { BookStore.save(ctx, it.copy(state = "failed", error = msg)) }
            refundQuietly()
            set(State.FAILED, msg)
        }

        fun go() = worker.execute { photos() }

        private fun photos() {
            try {
                set(State.PHOTOS, L.t("בוחרים את התמונות הכי טובות של ${child.name}...", "Choosing the best photos of ${child.name}..."))
                val r = BookPhotos.pick(ctx, child) { p -> progress = p; changed() }
                if (cancelled.get()) return
                if (r.photos.isEmpty()) { set(State.NEED_PHOTO, r.problem ?: ""); return }
                faces = r.photos.map { it.crop }
                write(r.photos.map { it.memoryId }.filter { it != "parent" && it != "profile" })
            } catch (e: Exception) {
                fail(CartoonFilm.friendly(e, L.t("לא הצלחנו לבחור תמונות", "Couldn't choose photos")))
            }
        }

        /** The parent's own photo, when we couldn't find a good one. */
        fun usePhoto(uri: Uri) = worker.execute {
            val c = BookPhotos.fromParentPhoto(ctx, uri)
            if (c == null) { set(State.NEED_PHOTO, L.t("לא מצאנו פנים ברורות בתמונה הזאת. נסו תמונה אחרת, קרובה ובאור טוב.", "No clear face in that photo. Try another one, closer and in good light.")); return@execute }
            faces = listOf(c.crop)
            write(emptyList())
        }

        private fun write(sources: List<String>) {
            try {
                set(State.WRITING, L.t("כותבים את הסיפור...", "Writing the story..."))
                val months = Profile.ageMonths(child.birth)
                val girl = when (child.relation) { "ילדה" -> true; "ילד" -> false; else -> null }
                val story = ClaudeClient.bookStory(ctx, child.name, months, girl, theme, details, PAGES)
                    ?: throw IllegalStateException(L.t("לא הצלחנו לכתוב את הסיפור. נסו שוב.", "Couldn't write the story. Try again."))
                if (cancelled.get()) return
                val b = Book(
                    id, child.name, BookJson.ageDesc(months, girl), theme.key, if (L.isEn) "en" else "he", story.title, story.outfit,
                    BookPage(story.title, story.coverScene), story.pages.map { BookPage(it.first, it.second) },
                    state = "character", photoSources = sources,
                )
                book = b
                // The face crops stay in the book's folder on the phone (for fixing a page later).
                faces.forEachIndexed { i, f -> BookStore.writeJpeg(BookStore.image(ctx, b, "face_$i.jpg"), f) }
                BookStore.save(ctx, b)
                // One credit for the whole book (the film's credits; refunded if almost nothing was drawn).
                if (!Account.signedIn(ctx)) throw IllegalStateException(L.t("צריך להתחבר כדי ליצור ספר", "Sign in to create a book"))
                token = Account.token(ctx) ?: throw IllegalStateException(L.t("בעיה בהתחברות. התחברו מחדש.", "Sign-in problem. Sign in again."))
                edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"
                val res = CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "reserve"))
                if (!res.optBoolean("ok", false)) throw IllegalStateException(res.optString("error", "").ifBlank { L.t("אין קרדיט פנוי ליצירה.", "No credit available.") })
                reserved = true
                character()
            } catch (e: Exception) {
                if (!cancelled.get()) fail(CartoonFilm.friendly(e, L.t("לא הצלחנו להתחיל את הספר", "Couldn't start the book")))
            }
        }

        private fun character() {
            val b = book ?: return
            set(State.CHARACTER, L.t("מציירים את ${child.name} כדמות בספר...", "Drawing ${child.name} as the book's hero..."))
            try {
                val uris = faces.map { CartoonFilm.dataUri(it) }
                val url = job(mapOf("kind" to "book_character", "image" to uris.first(), "refs" to org.json.JSONArray(uris.drop(1)),
                    "age" to b.ageDesc, "outfit" to b.outfit, "aspect" to "3:4"))
                val bmp = url.first?.let { CartoonFilm.downloadBitmap(it) } ?: throw IllegalStateException(refusal())
                url.second?.let { forget(it) }
                val name = "character_${b.characterTries}.jpg"
                BookStore.writeJpeg(BookStore.image(ctx, b, name), bmp)
                book = b.copy(character = name, characterTries = b.characterTries + 1, state = "approve")
                BookStore.save(ctx, book!!)
                set(State.APPROVE, "")
            } catch (e: CartoonFilm.FatalEdgeError) {
                fail(e.message ?: "")
            } catch (e: Exception) {
                if (!cancelled.get()) fail(CartoonFilm.friendly(e, L.t("לא הצלחנו לצייר את הדמות", "Couldn't draw the character")))
            }
        }

        val triesLeft: Int get() = CHARACTER_TRIES - (book?.characterTries ?: 0)

        fun redrawCharacter() { if (state == State.APPROVE && triesLeft > 0) worker.execute { character() } }

        /** The parent approved the character: draw the cover and the pages (two at a time). */
        fun approve() {
            val b = book ?: return
            if (state != State.APPROVE) return
            book = b.copy(state = "pages")
            BookStore.save(ctx, book!!)
            set(State.PAGES, L.t("מציירים את הספר...", "Drawing the book..."))
            worker.execute {
                try {
                    val total = b.pages.size + 1
                    val done = java.util.concurrent.atomic.AtomicInteger(0)
                    val tasks = (0 until total).map { i ->
                        java.util.concurrent.Callable {
                            // A page that fails is marked in the book (it can be redrawn from there); the others go on.
                            try { if (!cancelled.get()) drawPage(i) } catch (_: Exception) { } finally {
                                progress = 100 * done.incrementAndGet() / total
                                changed()
                            }
                        }
                    }
                    val pool = Executors.newFixedThreadPool(2)
                    try { pool.invokeAll(tasks) } finally { pool.shutdown() }
                    val fin = BookStore.load(ctx, b.id) ?: return@execute
                    val ok = fin.allPages.count { it.status == "done" }
                    if (ok == 0) { fail(L.t("לא הצלחנו לצייר את העמודים", "Couldn't draw the pages")); return@execute }
                    val out = fin.copy(state = "done")
                    BookStore.save(ctx, out)
                    book = out
                    reserved = false // the credit was used
                    set(State.DONE, if (ok < total) L.t("${total - ok} עמודים לא צוירו. אפשר לצייר אותם שוב מתוך הספר.", "${total - ok} pages weren't drawn. You can redraw them from the book.") else "")
                } catch (e: Exception) {
                    fail(CartoonFilm.friendly(e, L.t("לא הצלחנו לצייר את הספר", "Couldn't draw the book")))
                }
            }
        }

        /** Draws page [i] (0 = cover) and saves it into the book. */
        private fun drawPage(i: Int) {
            val b = BookStore.load(ctx, id) ?: return
            Pages.draw(ctx, b, i, token, edgeUrl, cancelled)
        }

        fun cancel() {
            cancelled.set(true)
            refundQuietly()
            if (current === this) current = null
            worker.shutdownNow()
        }

        private fun refundQuietly() {
            if (!reserved) return
            reserved = false
            // The server refunds only if almost nothing was drawn (a few calls at most), so this can't be abused.
            try { CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "refund")) } catch (_: Exception) { }
        }

        /** Submits one job and waits; returns (result url, fal request id). Fatal server errors are thrown. */
        private fun job(body: Map<String, Any>): Pair<String?, String?> {
            val res = CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "submit") + body)
            CartoonFilm.checkError(res)
            val url = CartoonFilm.pollEdge(edgeUrl, token, res.optString("status_url"), res.optString("response_url"), cancelled)
            return url.ifEmpty { null } to res.optString("request_id").ifEmpty { null }
        }

        private fun forget(requestId: String) = Pages.forget(ctx, id, requestId, edgeUrl, token)

        private fun refusal() = Pages.refusal()
    }

    /** Drawing one page (also used later from the book, to fix a single page). */
    object Pages {
        class NeedCredit : Exception()

        fun refusal(): String {
            val d = CartoonFilm.lastJobDetail.lowercase()
            return if ("content_policy" in d || "safety" in d || "flagged" in d) L.t("שירות הציור סירב לתמונה הזאת. נסו שוב, או בחרו תמונה אחרת של הילד.", "The drawing service refused this picture. Try again, or pick another photo of the child.")
            else L.t("הציור לא הצליח הפעם. נסו שוב.", "The drawing didn't work this time. Try again.")
        }

        /** Draws page [i] of [b] (0 = cover). Saves the page as done or failed. Throws NeedCredit when the credit's window is over. */
        fun draw(ctx: Context, b: Book, i: Int, token: String, edgeUrl: String, cancelled: AtomicBoolean) {
            val page = b.allPages[i]
            val dir = BookStore.dir(ctx, b.id)
            val character = BitmapFactory.decodeFile(File(dir, b.character).absolutePath) ?: return
            val face = BitmapFactory.decodeFile(File(dir, "face_0.jpg").absolutePath)
            val scene = if (i == 0) "Book cover illustration: ${page.scene}" else page.scene
            val body = mapOf(
                "action" to "submit", "kind" to "book_page", "image" to CartoonFilm.dataUri(character),
                "refs" to org.json.JSONArray(listOfNotNull(face?.let { CartoonFilm.dataUri(it) })),
                "scene" to scene, "outfit" to b.outfit, "aspect" to "4:3",
            )
            var result: Pair<String?, String?> = null to null
            try {
                val res = CartoonFilm.callEdge(edgeUrl, token, body)
                if (res.optInt("_code") == 402) throw NeedCredit()
                CartoonFilm.checkError(res)
                val url = CartoonFilm.pollEdge(edgeUrl, token, res.optString("status_url"), res.optString("response_url"), cancelled)
                result = url.ifEmpty { null } to res.optString("request_id").ifEmpty { null }
            } catch (e: NeedCredit) { throw e } catch (e: CartoonFilm.FatalEdgeError) { throw e } catch (_: Exception) { }
            val bmp = result.first?.let { CartoonFilm.downloadBitmap(it) }
            result.second?.let { forget(ctx, b.id, it, edgeUrl, token) }
            synchronized(this) {
                val fresh = BookStore.load(ctx, b.id) ?: return
                val name = if (i == 0) "cover_${page.tries}.jpg" else "page_${i}_${page.tries}.jpg"
                val updated = if (bmp != null) {
                    BookStore.writeJpeg(File(dir, name), bmp)
                    page.copy(image = name, status = "done", tries = page.tries + 1)
                } else page.copy(status = if (page.image.isNotEmpty()) "done" else "failed", tries = page.tries + 1)
                val out = if (i == 0) fresh.copy(cover = updated) else fresh.copy(pages = fresh.pages.mapIndexed { k, p -> if (k == i - 1) updated else p })
                BookStore.save(ctx, out)
            }
            if (bmp == null) throw IllegalStateException(refusal())
        }

        /** Asks fal to delete the request (inputs, outputs, files); records whether fal confirmed it. */
        fun forget(ctx: Context, bookId: String, requestId: String, edgeUrl: String, token: String) {
            val ok = try { CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "forget", "request_id" to requestId)).optBoolean("ok", false) } catch (_: Exception) { false }
            synchronized(this) {
                val b = BookStore.load(ctx, bookId) ?: return
                BookStore.save(ctx, b.copy(forgotten = b.forgotten + (requestId to ok)))
            }
        }

        /**
         * Fixes one page of a finished book. Inside the credit's 30-minute window it's free; after it, [newCredit]
         * must be true (the parent agreed to use one more credit). Background thread only.
         */
        fun redraw(ctx: Context, bookId: String, i: Int, newCredit: Boolean) {
            val b = BookStore.load(ctx, bookId) ?: throw IllegalStateException("no book")
            if (!Account.signedIn(ctx)) throw IllegalStateException(L.t("צריך להתחבר", "Please sign in"))
            val token = Account.token(ctx) ?: throw IllegalStateException(L.t("בעיה בהתחברות. התחברו מחדש.", "Sign-in problem. Sign in again."))
            val edgeUrl = Circle.url(ctx) + "/functions/v1/cartoon-film"
            if (newCredit) {
                val res = CartoonFilm.callEdge(edgeUrl, token, mapOf("action" to "reserve"))
                if (!res.optBoolean("ok", false)) throw IllegalStateException(res.optString("error", "").ifBlank { L.t("אין קרדיט פנוי.", "No credit available.") })
            }
            draw(ctx, b, i, token, edgeUrl, AtomicBoolean(false))
        }
    }
}
