package com.regaim.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import java.util.concurrent.Executors

/** Import from Google Photos: connect → choose in Google Photos (photos or whole albums) → we copy only what was chosen. */
class GooglePhotosActivity : AppCompatActivity() {
    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, GooglePhotosActivity::class.java))
    }

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var actions: LinearLayout
    private var token: String? = null
    private var session: GooglePhotos.Session? = null
    private var waiting = false
    @Volatile private var busy = false

    private val consent = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            onToken(Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(res.data))
        } catch (_: Exception) {
            say("לא קיבלנו הרשאה מ-Google. אפשר לנסות שוב.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen)
        findViewById<TextView>(R.id.screenTitle).text = "Google Photos"
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        val ui = Ui(this)
        val content = findViewById<LinearLayout>(R.id.screenContent)
        content.addView(ui.text("להביא רגעים מ-Google Photos", 19f, bold = true, top = 18))
        content.addView(ui.hint("תבחרו תמונות, סרטונים או אלבומים שלמים באפליקציית Google Photos. רק מה שתבחרו יועתק ל-Moments, והוא יישאר פרטי עד שתחליטו אחרת. עד ${GooglePhotos.MAX_ITEMS} פריטים בכל פעם.", top = 8))
        actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(ui.button("התחברו ובחרו מ-Google Photos", primary = true, top = 20) { if (!busy) connect() })
        content.addView(actions)
        status = ui.hint("", top = 16)
        content.addView(status)
    }

    override fun onResume() {
        super.onResume()
        if (waiting && !busy) fetchPicked()
    }

    private fun say(t: String) = runOnUiThread { if (!isFinishing) status.text = t }

    private fun connect() {
        say("מתחברים ל-Google...")
        val req = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(GooglePhotos.SCOPE))).build()
        Identity.getAuthorizationClient(this).authorize(req)
            .addOnSuccessListener { r ->
                if (r.hasResolution()) {
                    try { consent.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build()) }
                    catch (_: Exception) { say("לא הצלחנו לפתוח את חלון ההרשאה.") }
                } else onToken(r)
            }
            .addOnFailureListener { say("ההתחברות ל-Google נכשלה. בדקו שהגדרות Google Cloud הושלמו (ראו את ההוראות).") }
    }

    private fun onToken(r: AuthorizationResult) {
        val t = r.accessToken
        if (t == null) { say("לא התקבלה הרשאה מ-Google."); return }
        token = t
        busy = true
        say("פותחים את Google Photos...")
        worker.execute {
            try {
                val s = GooglePhotos.createSession(t)
                session = s
                waiting = true
                busy = false
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    status.text = "בחרו ב-Google Photos ואז חזרו לכאן."
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.pickerUri))) }
                    catch (_: Exception) { status.text = "לא הצלחנו לפתוח את Google Photos." }
                }
            } catch (e: Exception) {
                busy = false
                say(e.message ?: "משהו השתבש")
            }
        }
    }

    private fun fetchPicked() {
        val t = token ?: return
        val s = session ?: return
        busy = true
        say("בודקים מה בחרתם...")
        worker.execute {
            try {
                var ready = false
                repeat(8) { if (!ready) { ready = GooglePhotos.picked(t, s.id); if (!ready) Thread.sleep(2000) } }
                if (!ready) {
                    busy = false
                    say("עוד לא נבחר כלום. בחרו ב-Google Photos ולחצו על 'סיום', או נסו שוב.")
                    runOnUiThread { actions.addView(Ui(this).button("פתחו שוב את Google Photos", top = 8) { actions.removeViewAt(actions.childCount - 1); try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.pickerUri))) } catch (_: Exception) { } }) }
                    return@execute
                }
                waiting = false
                val items = GooglePhotos.items(t, s.id)
                var done = 0
                var last: String? = null
                items.forEach { it0 ->
                    say("מעתיקים ${done + 1} מתוך ${items.size}...")
                    try {
                        val uri = GooglePhotos.download(applicationContext, t, it0)
                        last = MediaImporter.add(applicationContext, uri).id
                        done++
                    } catch (_: Exception) { /* skip an item that cannot be copied */ }
                }
                GooglePhotos.deleteSession(t, s.id)
                busy = false
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    when {
                        done == 0 -> status.text = "לא הצלחנו להעתיק את הפריטים שנבחרו. נסו שוב."
                        done == 1 -> { MomentActivity.open(this, last!!); finish() }
                        else -> { android.widget.Toast.makeText(this, "נוספו $done רגעים ✓", android.widget.Toast.LENGTH_LONG).show(); startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)); finish() }
                    }
                }
            } catch (e: Exception) {
                busy = false
                say(e.message ?: "משהו השתבש")
            }
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
