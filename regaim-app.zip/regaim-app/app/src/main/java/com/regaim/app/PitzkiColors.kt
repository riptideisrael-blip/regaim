package com.regaim.app

import kotlin.math.max
import kotlin.math.min

/**
 * Finds how much of each lesson color a picture has (pure Kotlin, tested on the computer), so Pitzki can show
 * "and at home too!" with one of the family's own photos. Simple and honest: it counts pixels by hue, it doesn't
 * know what's in the photo. Skin tones are kept out of "brown" (they'd make every face brown).
 */
object PitzkiColors {
    /** A picture counts for a color when at least this share of its pixels has it. */
    const val ENOUGH = 0.18f

    /** Hue (0..360), saturation and value (0..1) of an ARGB pixel. */
    fun hsv(argb: Int): FloatArray {
        val r = (argb shr 16 and 0xFF) / 255f
        val g = (argb shr 8 and 0xFF) / 255f
        val b = (argb and 0xFF) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        val h = when {
            d == 0f -> 0f
            mx == r -> 60f * (((g - b) / d) % 6f)
            mx == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }.let { if (it < 0f) it + 360f else it }
        val s = if (mx == 0f) 0f else d / mx
        return floatArrayOf(h, s, mx)
    }

    /** Which lesson color one pixel is, or null (white, black, skin, blue, ...). */
    fun of(argb: Int): PColor? {
        val (h, s, v) = hsv(argb).let { Triple(it[0], it[1], it[2]) }
        return when {
            s < 0.12f && v in 0.35f..0.80f -> PColor.GRAY
            s < 0.30f -> null
            (h < 12f || h >= 345f) && s >= 0.50f && v >= 0.30f -> PColor.RED
            h in 45f..68f && s >= 0.45f && v >= 0.55f -> PColor.YELLOW
            h in 75f..165f && s >= 0.30f && v >= 0.20f -> PColor.GREEN
            // Brown: dark orange. Skin is lighter (v above ~0.55), so it isn't counted.
            h in 12f..45f && s >= 0.35f && v in 0.12f..0.50f -> PColor.BROWN
            else -> null
        }
    }

    /** The share (0..1) of [pixels] that has each color. */
    fun shares(pixels: IntArray): Map<PColor, Float> {
        if (pixels.isEmpty()) return emptyMap()
        val counts = IntArray(PColor.values().size)
        for (p in pixels) of(p)?.let { counts[it.ordinal]++ }
        return PColor.values().associateWith { counts[it.ordinal].toFloat() / pixels.size }
    }

    /**
     * One picture per color: the one with the most of it (at least [ENOUGH]), never the same picture for two colors.
     * [pictures]: id to that picture's pixels, best candidates first (for example, moments with the child in them).
     */
    fun pick(pictures: List<Pair<String, Map<PColor, Float>>>): Map<PColor, String> {
        val out = LinkedHashMap<PColor, String>()
        val used = HashSet<String>()
        // The rarest colors pick first, so a common one (gray) doesn't take the only red picture.
        val order = PColor.values().sortedBy { c -> pictures.count { (it.second[c] ?: 0f) >= ENOUGH } }
        for (c in order) {
            val best = pictures.filter { it.first !in used && (it.second[c] ?: 0f) >= ENOUGH }.maxByOrNull { it.second[c] ?: 0f } ?: continue
            out[c] = best.first
            used.add(best.first)
        }
        return out
    }
}
