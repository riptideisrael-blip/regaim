package com.regaim.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * One memory, opened like a story: the video, what happened, who was there, what it was,
 * where it happened, and a box to ask the memory anything.
 */
class MomentActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun open(ctx: Context, id: String) {
            ctx.startActivity(Intent(ctx, MomentActivity::class.java).putExtra(EXTRA_ID, id))
            if (ctx is Activity) {
                @Suppress("DEPRECATION")
                ctx.overridePendingTransition(R.anim.slide_up_in, R.anim.stay)
            }
        }
    }

    private lateinit var memory: Memory
    private lateinit var mv: MemoryViews
    private lateinit var video: VideoView
    private lateinit var poster: ImageView
    private lateinit var bigPlay: View
    private lateinit var playPause: ImageView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var muteBtn: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var player: MediaPlayer? = null
    private var muted = false
    private var loadedUri = ""
    private var triedAnalyze = false
    private var asking = false

    private val ticker = object : Runnable {
        override fun run() {
            if (video.isPlaying) {
                seek.progress = video.currentPosition
                timeText.text = Fmt.shortDuration(video.currentPosition.toLong())
            }
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_moment)
        val m = MemoryStore.get(this, intent.getStringExtra(EXTRA_ID) ?: "")
        if (m == null) {
            finish()
            return
        }
        memory = m
        mv = MemoryViews(this)
        video = findViewById(R.id.videoView)
        poster = findViewById(R.id.videoPoster)
        bigPlay = findViewById(R.id.btnBigPlay)
        playPause = findViewById(R.id.btnPlayPause)
        seek = findViewById(R.id.videoSeek)
        timeText = findViewById(R.id.videoTime)
        muteBtn = findViewById(R.id.btnMute)

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnFixMoment).setOnClickListener { fix() }
        bigPlay.setOnClickListener { play() }
        poster.setOnClickListener { play() }
        video.setOnClickListener { if (video.isPlaying) pause() else play() }
        playPause.setOnClickListener { if (video.isPlaying) pause() else play() }
        muteBtn.setOnClickListener {
            muted = !muted
            applyMute()
        }
        findViewById<View>(R.id.btnFullscreen).setOnClickListener { fullscreen() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    video.seekTo(p)
                    timeText.text = Fmt.shortDuration(p.toLong())
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        video.setOnPreparedListener { mp ->
            player = mp
            applyMute()
            seek.max = mp.duration.coerceAtLeast(1)
            timeText.text = Fmt.shortDuration(mp.duration.toLong())
        }
        video.setOnCompletionListener {
            playPause.setImageResource(R.drawable.ic_play)
            bigPlay.visibility = View.VISIBLE
            video.seekTo(0)
            seek.progress = 0
        }
        video.setOnErrorListener { _, _, _ ->
            bigPlay.visibility = View.GONE
            timeText.text = ""
            Toast.makeText(this, "לא מצאתי את הסרטון של הרגע הזה בגלריה", Toast.LENGTH_LONG).show()
            true
        }
        val askInput = findViewById<EditText>(R.id.askInput)
        findViewById<View>(R.id.btnMore).setOnClickListener { v -> moreMenu(v) }
        findViewById<View>(R.id.btnAsk).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = mv.dp(18).toFloat()
                setColor(ContextCompat.getColor(this@MomentActivity, R.color.accent))
            }
            setOnClickListener { ask(askInput.text.toString()) }
        }
        askInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { ask(askInput.text.toString()); true } else false
        }
        bind(first = true)
        mv.reveal(findViewById(R.id.momentBody))
        ui.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        // Back from trimming or fixing: reload.
        if (::memory.isInitialized) MemoryStore.get(this, memory.id)?.let { memory = it; bind(first = false) }
    }

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized && video.isPlaying) pause()
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.stay, R.anim.fade_out_down)
    }

    // ---------- video ----------

    private fun uri(): Uri =
        if (memory.uri.startsWith("content://")) Uri.parse(memory.uri) else Uri.parse("file://" + memory.uri)

    private fun loadVideo() {
        if (loadedUri == memory.uri) return
        loadedUri = memory.uri
        video.setVideoURI(uri())
        poster.visibility = View.VISIBLE
        bigPlay.visibility = View.VISIBLE
        timeText.text = Fmt.shortDuration(memory.durationMs)
        Covers.load(poster, memory) { bmp -> fitBox(bmp) }
    }

    /** The video frame takes the clip's shape (portrait clips get a tall frame), within the screen. */
    private fun fitBox(bmp: Bitmap) {
        val box = findViewById<FrameLayout>(R.id.videoBox)
        val w = resources.displayMetrics.widthPixels
        val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        val h = (w * bmp.height.toFloat() / bmp.width).toInt().coerceIn(mv.dp(200), maxH)
        box.layoutParams = box.layoutParams.apply { height = h }
    }

    private fun play() {
        if (poster.visibility == View.VISIBLE) poster.animate().alpha(0f).setDuration(180).withEndAction { poster.visibility = View.GONE; poster.alpha = 1f }.start()
        bigPlay.visibility = View.GONE
        playPause.setImageResource(R.drawable.ic_pause)
        video.start()
    }

    private fun pause() {
        video.pause()
        playPause.setImageResource(R.drawable.ic_play)
        bigPlay.visibility = View.VISIBLE
    }

    private fun applyMute() {
        try { player?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f) } catch (_: Exception) {}
        muteBtn.text = if (muted) "🔇" else "🔊"
    }

    private fun fullscreen() {
        if (video.isPlaying) pause()
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri(), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, "הקליפ נמצא בגלריה, תיקייה Moments", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- the story ----------

    private fun bind(first: Boolean) {
        val m = memory
        loadVideo()
        findViewById<TextView>(R.id.momentTitle).text = Fmt.title(m)
        findViewById<TextView>(R.id.momentMeta).text = listOf(Fmt.dayTime(m.time), Fmt.duration(m.durationMs)).joinToString(" · ")
        bindInfo()
        bindStory(first)
        bindPeople()
        bindTags()
        bindPlace()
        bindAsk()
        bindActions()
    }

    private fun bindStory(first: Boolean) {
        val m = memory
        val desc = findViewById<TextView>(R.id.momentDesc)
        mv.stopPulse(desc)
        desc.setOnClickListener(null)
        when {
            m.analyzed && m.description.isNotEmpty() -> {
                desc.text = m.description
                desc.setTextColor(ContextCompat.getColor(this, R.color.ink))
                if (!first) mv.reveal(desc)
            }
            ClaudeClient.hasKey(this) -> {
                desc.text = "אנחנו מבינים את הרגע... ✨"
                desc.setTextColor(ContextCompat.getColor(this, R.color.accent))
                mv.pulse(desc)
                if (!triedAnalyze) {
                    triedAnalyze = true
                    worker.execute {
                        try { MemoryStore.analyzePending(applicationContext) } catch (_: Exception) {}
                        runOnUiThread {
                            if (isFinishing) return@runOnUiThread
                            val fresh = MemoryStore.get(this, memory.id) ?: return@runOnUiThread
                            memory = fresh
                            if (fresh.analyzed) bind(first = false) else {
                                mv.stopPulse(desc)
                                desc.text = "לא הצלחנו להבין את הרגע הפעם. ננסה שוב בפעם הבאה שתפתחו את האפליקציה."
                                desc.setTextColor(ContextCompat.getColor(this, R.color.ink_soft))
                            }
                        }
                    }
                }
            }
            else -> {
                desc.text = "כדי שנספר לכם מה קרה כאן, חברו את ה-AI בפרופיל ›"
                desc.setTextColor(ContextCompat.getColor(this, R.color.ink_soft))
                desc.setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
            }
        }
        findViewById<TextView>(R.id.momentReason).apply {
            val lines = mutableListOf<String>()
            if (m.chosen) lines.add("♥ שמרתם את הרגע הזה בעצמכם")
            if (m.reason.isNotEmpty()) lines.add("למה זה רגע שלכם: ${m.reason}")
            if (m.noLearn) lines.add("Moments לא לומד מהרגע הזה")
            text = lines.joinToString("\n")
            visibility = if (lines.isEmpty()) View.GONE else View.VISIBLE
        }
        findViewById<View>(R.id.btnFixMoment).visibility = if (m.analyzed) View.VISIBLE else View.GONE
    }

    /** Three quick facts under the title: who, where, and favorite. */
    private fun bindInfo() {
        val m = memory
        val row = findViewById<LinearLayout>(R.id.infoRow)
        row.removeAllViews()
        fun chip(icon: Int, line1: String, line2: String, onClick: (() -> Unit)?, iconColor: Int = R.color.accent): View {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.card_white)
                elevation = mv.dp(2).toFloat()
                outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
                setPadding(mv.dp(10), mv.dp(10), mv.dp(10), mv.dp(10))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = mv.dp(4); marginEnd = mv.dp(4)
                }
                if (onClick != null) setOnClickListener { onClick() }
            }
            box.addView(mv.icon(icon, 22, iconColor))
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(mv.dp(8), 0, mv.dp(4), 0)
            }
            texts.addView(TextView(this).apply {
                text = line1
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@MomentActivity, R.color.ink))
            })
            if (line2.isNotEmpty()) texts.addView(TextView(this).apply {
                text = line2
                textSize = 12f
                maxLines = 1
                setTextColor(ContextCompat.getColor(this@MomentActivity, R.color.ink_soft))
            })
            box.addView(texts)
            return box
        }
        val who = Fmt.names(m).firstOrNull()
        val age = who?.let { n -> Profile.kids(this).firstOrNull { it.name == n }?.let { Profile.ageText(it.birth, m.time) } }.orEmpty()
        row.addView(chip(R.drawable.ic_face, who ?: "מי היה?", if (who != null) age.ifEmpty { if (Fmt.names(m).size > 1) "ועוד ${Fmt.names(m).size - 1}" else "" } else "", { editPeople() }))
        val place = Fmt.place(m)
        row.addView(chip(R.drawable.ic_pin_outline, place.ifEmpty { "ללא מיקום" }, if (place.isNotEmpty()) "" else Fmt.time(m.time), null))
        row.addView(chip(if (m.favorite) R.drawable.ic_star else R.drawable.ic_star_outline, if (m.favorite) "מועדף" else "למועדפים", "",
            { toggleFavorite() }, if (m.favorite) R.color.gold else R.color.ink_soft))
    }

    /** Choose who was in this moment: everyone the family knows, plus a new name. */
    private fun editPeople() {
        val current = Fmt.names(memory)
        val known = (Profile.kids(this).map { it.name } + PeopleStore.people(this).map { it.name } + current +
            MemoryStore.all(this).flatMap { Fmt.names(it) }).filter { it.isNotBlank() }.distinct()
        val ui = Ui(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(4), ui.dp(20), 0)
        }
        val checks = known.map { n ->
            android.widget.CheckBox(this).apply {
                text = n
                textSize = 16f
                isChecked = n in current
                box.addView(this)
            }
        }
        if (known.isEmpty()) box.addView(ui.hint("עוד אין שמות. כתבו שם חדש:", top = 4))
        val newName = ui.field("שם חדש (למשל: נתן)", "", top = 10)
        box.addView(newName)
        val rewrite = if (ClaudeClient.hasKey(this)) android.widget.CheckBox(this).apply {
            text = "לכתוב מחדש את התיאור עם השמות"
            isChecked = true
            setPadding(0, ui.dp(8), 0, 0)
            box.addView(this)
        } else null
        AlertDialog.Builder(this)
            .setTitle("מי היה ברגע הזה?")
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton("שמור") { _, _ ->
                val chosen = checks.filter { it.isChecked }.map { it.text.toString() }.toMutableList()
                newName.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { if (it !in chosen) chosen.add(it) }
                setPeople(chosen, rewrite = rewrite?.isChecked == true)
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    /** Saves who was in the moment: names not found by face recognition are "added", missing ones "removed". */
    private fun setPeople(names: List<String>, rewrite: Boolean) {
        val fresh = MemoryStore.get(this, memory.id) ?: memory
        val faces = fresh.people.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        memory = fresh.copy(
            extraPeople = names.filter { it !in faces }.joinToString(", "),
            hiddenPeople = faces.filter { it !in names }.joinToString(", "),
            analyzed = if (rewrite) false else fresh.analyzed,
        )
        MemoryStore.update(this, memory)
        triedAnalyze = false
        bind(first = false)
        Toast.makeText(this, if (names.isEmpty()) "עודכן" else "עודכן: ${names.joinToString(", ")}", Toast.LENGTH_SHORT).show()
    }

    private fun toggleFavorite() {
        val fresh = MemoryStore.get(this, memory.id) ?: memory
        memory = fresh.copy(favorite = !fresh.favorite)
        MemoryStore.update(this, memory)
        bindInfo()
        bindActions()
        if (memory.favorite) Toast.makeText(this, "נוסף למועדפים ⭐", Toast.LENGTH_SHORT).show()
    }

    private fun moreMenu(anchor: View) {
        val menu = android.widget.PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "✦ הפוך לקומיקס")
        menu.menu.add(0, 2, 1, if (memory.milestone.isEmpty()) "⭐ סמן כאבן דרך" else "⭐ ערוך אבן דרך")
        menu.menu.add(0, 3, 2, "✎ תקן את מה שנכתב")
        menu.menu.add(0, 4, 3, "↗ שתף את הקליפ המלא")
        menu.menu.add(0, 5, 4, "⛶ פתח בנגן של הטלפון")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> ComicActivity.forMoment(this, memory.id)
                2 -> editMilestone()
                3 -> fix()
                4 -> share()
                5 -> fullscreen()
            }
            true
        }
        menu.show()
    }

    private fun bindPeople() {
        val m = memory
        val row = findViewById<LinearLayout>(R.id.peopleRow)
        val hint = findViewById<TextView>(R.id.peopleHint)
        row.removeAllViews()
        hint.setOnClickListener(null)
        val names = Fmt.names(m)
        val kids = Profile.kids(this)
        for (n in names) {
            val age = kids.firstOrNull { it.name == n }?.let { Profile.ageText(it.birth, m.time) }.orEmpty()
            row.addView(mv.person(n, age.ifEmpty { "${PeopleStore.countFor(this, n)} רגעים" }) {
                startActivity(Intent(this, MemoriesActivity::class.java).putExtra(MemoriesActivity.EXTRA_PERSON, n)
                    .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            }.apply {
                setOnLongClickListener {
                    AlertDialog.Builder(this@MomentActivity).setTitle("להסיר את $n מהרגע הזה?")
                        .setPositiveButton("הסר") { _, _ -> setPeople(Fmt.names(memory) - n, rewrite = false) }
                        .setNegativeButton("ביטול", null).show()
                    true
                }
            })
        }
        hint.setTextColor(ContextCompat.getColor(this, R.color.ink_soft))
        hint.text = when {
            names.isNotEmpty() -> "לחיצה ארוכה על אדם מסירה אותו מהרגע"
            !PeopleStore.peopleEnabled(this) -> "זיהוי הפנים כבוי. אפשר להפעיל בפרופיל."
            !m.facesScanned -> "מחפשים מי היה כאן..."
            else -> "לא זוהה כאן אף אחד. הוסיפו בעצמכם עם ה-+, או תנו שמות לפנים ›"
        }
        run {
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(mv.dp(78), LinearLayout.LayoutParams.WRAP_CONTENT)
                addView(TextView(this@MomentActivity).apply {
                    text = "+"
                    textSize = 24f
                    gravity = android.view.Gravity.CENTER
                    setTextColor(ContextCompat.getColor(this@MomentActivity, R.color.accent))
                    setBackgroundResource(R.drawable.dashed_circle)
                    layoutParams = LinearLayout.LayoutParams(mv.dp(56), mv.dp(56))
                })
                addView(TextView(this@MomentActivity).apply {
                    text = "אנשים נוספים"
                    textSize = 12f
                    gravity = android.view.Gravity.CENTER
                    setTextColor(ContextCompat.getColor(this@MomentActivity, R.color.ink_soft))
                    setPadding(0, mv.dp(6), 0, 0)
                })
                setOnClickListener { editPeople() }
            })
        }
        if (names.isEmpty() && m.facesScanned && PeopleStore.peopleEnabled(this)) {
            hint.setTextColor(ContextCompat.getColor(this, R.color.accent))
            hint.setOnClickListener { PeopleActivity.open(this) }
        }
    }

    private fun bindTags() {
        val m = memory
        val row = findViewById<LinearLayout>(R.id.tagsRow)
        row.removeAllViews()
        val chips = mutableListOf<String>()
        if (m.category.isNotEmpty()) chips.add("${Fmt.CATEGORY_EMOJI[m.category] ?: "✨"} ${m.category}")
        if (m.milestone.isNotEmpty()) chips.add("⭐ ${m.milestone}")
        val names = Fmt.names(m).toSet()
        m.tags.split(",").map { it.trim() }
            .filter { it.length in 2..18 && it != m.category && it !in names }
            .distinct().take(7).forEach { chips.add(it) }
        chips.add(
            when {
                m.label == "manual" -> "♥ נשמר על ידיכם"
                m.label.startsWith("״") -> "🗣 ${m.label}"
                m.label in Labels.VISUAL -> "😊 ${Labels.he(m.label)}"
                else -> "🔊 ${Labels.he(m.label)}"
            }
        )
        chips.forEach { row.addView(mv.tag(it)) }
    }

    private fun bindPlace() {
        val m = memory
        val box = findViewById<View>(R.id.placeBox)
        if (m.place.isEmpty()) {
            box.visibility = View.GONE
            return
        }
        box.visibility = View.VISIBLE
        val t = findViewById<TextView>(R.id.placeText)
        val hasMap = m.lat != null && m.lon != null
        t.text = m.place + if (hasMap) "\nפתח במפה ›" else ""
        if (hasMap) findViewById<View>(R.id.placeCard).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${m.lat},${m.lon}?q=${m.lat},${m.lon}")))
            } catch (_: Exception) {
            }
        }
    }

    // ---------- ask the memory ----------

    private fun bindAsk() {
        val chips = findViewById<LinearLayout>(R.id.askChips)
        chips.removeAllViews()
        val input = findViewById<EditText>(R.id.askInput)
        val has = ClaudeClient.hasKey(this)
        input.isEnabled = has
        input.hint = if (has) "שאל משהו על הרגע הזה..." else "חברו את ה-AI בפרופיל כדי לשאול"
        findViewById<View>(R.id.btnAsk).isEnabled = has
        if (!has) return
        val kid = Fmt.names(memory).firstOrNull()
        val qs = listOf(
            if (kid != null) "מה הצחיק את $kid?" else "מה מצחיק כאן?",
            "מי היה שם?",
            "מה קרה רגע לפני?",
            "תמצא לי עוד רגעים כאלה",
        )
        for (q in qs) chips.addView(mv.tag(q).apply { setOnClickListener { input.setText(q); ask(q) } })
    }

    private fun ask(q: String) {
        val question = q.trim()
        if (question.isEmpty() || asking || !ClaudeClient.hasKey(this)) return
        asking = true
        val answer = findViewById<TextView>(R.id.askAnswer)
        val related = findViewById<LinearLayout>(R.id.askRelated)
        related.removeAllViews()
        answer.visibility = View.VISIBLE
        answer.text = "רגע, אני מסתכלת על הרגע... ✨"
        answer.setTextColor(ContextCompat.getColor(this, R.color.accent))
        mv.pulse(answer)
        val m = memory
        worker.execute {
            val all = MemoryStore.all(applicationContext)
            val result = try {
                Result.success(ClaudeClient.askMoment(applicationContext, m, question, all))
            } catch (e: Exception) {
                Result.failure(e)
            }
            runOnUiThread {
                asking = false
                if (isFinishing) return@runOnUiThread
                mv.stopPulse(answer)
                answer.setTextColor(ContextCompat.getColor(this, R.color.ink))
                result.onSuccess { a ->
                    answer.text = a.text
                    mv.reveal(answer)
                    val byId = all.associateBy { it.id }
                    for (id in a.ids) {
                        val o = byId[id] ?: continue
                        if (o.id == m.id) continue
                        related.addView(LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            addView(mv.mini(o, 96, 120) { MomentActivity.open(this@MomentActivity, o.id) })
                            addView(TextView(this@MomentActivity).apply {
                                text = Fmt.day(o.time)
                                textSize = 12f
                                setTextColor(ContextCompat.getColor(this@MomentActivity, R.color.ink_soft))
                                setPadding(0, mv.dp(4), 0, 0)
                            })
                        })
                    }
                }.onFailure { e ->
                    answer.text = "לא הצלחתי לענות עכשיו: ${e.message}"
                    answer.setTextColor(ContextCompat.getColor(this, R.color.ink_soft))
                }
            }
        }
    }

    // ---------- quiet actions ----------

    /** The bar at the bottom: favorite, share, family circle, trim, delete. */
    private fun bindActions() {
        val row = findViewById<LinearLayout>(R.id.actionsRow)
        row.removeAllViews()
        fun add(icon: Int, label: String, colorRes: Int = R.color.ink, action: () -> Unit) {
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                setBackgroundResource(android.R.drawable.list_selector_background)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                addView(mv.icon(icon, 22, colorRes).apply { (layoutParams as LinearLayout.LayoutParams).bottomMargin = mv.dp(3) })
                addView(TextView(this@MomentActivity).apply {
                    text = label
                    textSize = 11f
                    gravity = android.view.Gravity.CENTER
                    setTextColor(ContextCompat.getColor(this@MomentActivity, colorRes))
                })
                setOnClickListener {
                    scaleX = 0.9f; scaleY = 0.9f
                    animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                    action()
                }
            })
        }
        add(if (memory.favorite) R.drawable.ic_heart else R.drawable.ic_heart_outline, if (memory.favorite) "שמור ❤" else "שמור",
            if (memory.favorite) R.color.heart else R.color.ink) { toggleFavorite() }
        add(R.drawable.ic_share_outline, "שתף") { share() }
        add(R.drawable.ic_mail, if (Circle.wasShared(this, memory)) "במעגל ✓" else "למעגל", R.color.accent) { shareToCircle() }
        add(R.drawable.ic_cut, "קצר") { TrimActivity.open(this, memory.id) }
        add(R.drawable.ic_trash, "מחק", R.color.danger) { confirmDelete() }
    }

    /** Sends the heart of this moment (~10 seconds) to the family circle. */
    private fun shareToCircle() {
        if (!Circle.joined(this)) {
            CircleActivity.open(this)
            return
        }
        // Choose the part, write a few words and a style first.
        ShareActivity.share(this, memory.id)
    }

    @Suppress("unused")
    private fun shareToCircleNow() {
        val m = memory
        Toast.makeText(this, "רגע, אנחנו מכינים את הרגע למשפחה...", Toast.LENGTH_SHORT).show()
        worker.execute {
            val r = try {
                Circle.shareMoment(applicationContext, m) {}
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                r.onSuccess {
                    Toast.makeText(this, "שותף עם ${Circle.name(this)} ❤️", Toast.LENGTH_SHORT).show()
                    bindActions()
                }.onFailure { e -> Toast.makeText(this, "לא הצלחתי לשתף: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** Share the clip itself (e.g. to the family WhatsApp group). */
    private fun share() {
        try {
            val text = Fmt.title(memory) + if (memory.description.isNotEmpty()) "\n${memory.description}" else ""
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM, uri())
                .putExtra(Intent.EXTRA_TEXT, text)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "לשתף את הרגע עם..."))
        } catch (_: Exception) {
            Toast.makeText(this, "לא ניתן לשתף את הקליפ הזה", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editMilestone() {
        val field = EditText(this).apply {
            hint = "למשל: הצעדים הראשונים"
            setText(memory.milestone)
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, p / 2)
        }
        AlertDialog.Builder(this)
            .setTitle("אבן דרך")
            .setMessage("איזו פעם ראשונה זאת?")
            .setView(field)
            .setPositiveButton("שמור") { _, _ ->
                val ms = field.text.toString().trim()
                memory = memory.copy(
                    milestone = ms,
                    category = if (ms.isNotEmpty()) "אבן דרך" else if (memory.category == "אבן דרך") "אחר" else memory.category,
                )
                MemoryStore.update(this, memory)
                bind(first = false)
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("למחוק את הרגע?")
            .setMessage("הרגע והקליפ יימחקו מהגלריה.")
            .setPositiveButton("מחק") { _, _ ->
                try {
                    if (memory.uri.startsWith("content://")) contentResolver.delete(uri(), null, null)
                } catch (_: Exception) {
                }
                MemoryStore.remove(this, memory.id)
                finish()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    /** Correct the AI: title, description, category, why it matters, and whether to learn from it. */
    private fun fix() {
        val ui = Ui(this)
        val m = memory
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        box.addView(ui.text("כותרת", 13f, R.color.ink_soft))
        val title = ui.field("כותרת", m.title, top = 2)
        box.addView(title)
        box.addView(ui.text("מה קורה ברגע", 13f, R.color.ink_soft, top = 10))
        val desc = ui.field("תיאור", m.description, multiline = true, top = 2)
        box.addView(desc)
        box.addView(ui.text("למה זה רגע שלך", 13f, R.color.ink_soft, top = 10))
        val reason = ui.field("למשל: היא רצה אליי מהגן", m.reason, multiline = true, top = 2)
        box.addView(reason)
        box.addView(ui.text("קטגוריה", 13f, R.color.ink_soft, top = 10))
        var category = m.category
        box.addView(ui.chips(Categories.ALL, Categories.ALL.indexOf(m.category), top = 4) { category = Categories.ALL[it] })
        var noLearn = m.noLearn
        box.addView(ui.switch("לא ללמוד מהרגע הזה", noLearn, top = 12) { noLearn = it })
        box.addView(ui.hint("מי מופיע מתוקן במסך \"אנשים\" (משפחה ← מי זה?).", top = 8))
        val scroll = android.widget.ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle("תיקון הרגע")
            .setView(scroll)
            .setPositiveButton("שמור") { _, _ ->
                val fresh = MemoryStore.get(this, m.id) ?: m
                memory = fresh.copy(
                    title = title.text.toString().trim().take(40),
                    description = desc.text.toString().trim(),
                    reason = reason.text.toString().trim(),
                    category = if (fresh.milestone.isNotEmpty()) "אבן דרך" else category,
                    noLearn = noLearn,
                    analyzed = true,
                )
                MemoryStore.update(this, memory)
                bind(first = false)
                Toast.makeText(this, "נשמר. Moments ילמד מהתיקון בלמידה הבאה", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }
}
