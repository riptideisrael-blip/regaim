package com.regaim.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** One memory, up close: big bubble, story, and actions (play, favorite, share to family, milestone, delete). */
class MomentActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun open(ctx: Context, id: String) {
            ctx.startActivity(Intent(ctx, MomentActivity::class.java).putExtra(EXTRA_ID, id))
        }
    }

    private lateinit var memory: Memory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_moment)
        val m = MemoryStore.get(this, intent.getStringExtra(EXTRA_ID) ?: "")
        if (m == null) {
            finish()
            return
        }
        memory = m
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.momentImage).setOnClickListener { play() }
        findViewById<View>(R.id.actPlay).setOnClickListener { play() }
        findViewById<View>(R.id.actFav).setOnClickListener { toggleFavorite() }
        findViewById<View>(R.id.actShare).setOnClickListener { share() }
        findViewById<View>(R.id.actMilestone).setOnClickListener { editMilestone() }
        findViewById<View>(R.id.actComic).setOnClickListener { ComicActivity.forMoment(this, memory.id) }
        findViewById<View>(R.id.actDelete).setOnClickListener { confirmDelete() }
        bind()
    }

    private fun bind() {
        val m = memory
        val img = findViewById<ImageView>(R.id.momentImage)
        val bmp = if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb) else null
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.drawable.bubble_placeholder)

        findViewById<TextView>(R.id.momentTitle).text = m.displayTitle
        findViewById<TextView>(R.id.momentMeta).text =
            ClaudeClient.describeTime(m.time) + if (m.place.isNotEmpty()) "\n${m.place}" else ""
        findViewById<TextView>(R.id.momentDesc).apply {
            text = m.description.ifEmpty {
                if (ClaudeClient.hasKey(this@MomentActivity)) "ה-AI עוד לא תיאר את הרגע הזה."
                else "הוסף מפתח AI בלשונית \"שאל\" כדי לקבל תיאור לכל רגע."
            }
        }

        val catChip = findViewById<TextView>(R.id.momentCategory)
        val cat = m.category.ifEmpty { Labels.he(m.label) }
        catChip.text = cat
        catChip.background = pill(Categories.color(m.category))

        val msChip = findViewById<TextView>(R.id.momentMilestone)
        msChip.visibility = if (m.milestone.isEmpty()) View.GONE else View.VISIBLE
        msChip.text = "★ ${m.milestone}"
        msChip.background = pill(Categories.color("אבן דרך"))

        val fav = findViewById<ImageView>(R.id.actFavIcon)
        fav.setColorFilter(if (m.favorite) 0xFFD64532.toInt() else ContextCompat.getColor(this, R.color.ink_soft))
        findViewById<TextView>(R.id.actFavLabel).text = if (m.favorite) "במועדפים" else "מועדף"
        findViewById<TextView>(R.id.actMilestoneLabel).text = if (m.milestone.isEmpty()) "סמן כאבן דרך" else "ערוך אבן דרך"
    }

    private fun pill(color: Int) = GradientDrawable().apply {
        cornerRadius = 40f * resources.displayMetrics.density
        setColor(color)
    }

    private fun uri(): Uri =
        if (memory.uri.startsWith("content://")) Uri.parse(memory.uri) else Uri.parse("file://" + memory.uri)

    private fun play() {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri(), "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "הקליפ נמצא בגלריה, תיקייה Moments", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleFavorite() {
        memory = memory.copy(favorite = !memory.favorite)
        MemoryStore.update(this, memory)
        bind()
    }

    /** Share the clip itself (e.g. to the family WhatsApp group). */
    private fun share() {
        try {
            val text = memory.displayTitle + if (memory.description.isNotEmpty()) "\n${memory.description}" else ""
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM, uri())
                .putExtra(Intent.EXTRA_TEXT, text)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "לשתף את הרגע עם..."))
        } catch (_: Exception) {
            Toast.makeText(this, "לא ניתן לשתף את הקליפ הזה", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editMilestone() {
        val field = EditText(this).apply {
            hint = "למשל: הצעדים הראשונים"
            setText(memory.milestone)
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, p / 2)
        }
        AlertDialog.Builder(this)
            .setTitle("אבן דרך")
            .setMessage("איזו פעם ראשונה זאת?")
            .setView(field)
            .setPositiveButton("שמור") { _, _ ->
                val ms = field.text.toString().trim()
                memory = memory.copy(
                    milestone = ms,
                    category = if (ms.isNotEmpty()) "אבן דרך" else if (memory.category == "אבן דרך") "אחר" else memory.category,
                )
                MemoryStore.update(this, memory)
                bind()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("למחוק את הרגע?")
            .setMessage("הבועה והקליפ יימחקו מהגלריה.")
            .setPositiveButton("מחק") { _, _ ->
                try {
                    if (memory.uri.startsWith("content://")) contentResolver.delete(uri(), null, null)
                } catch (_: Exception) {
                }
                MemoryStore.remove(this, memory.id)
                finish()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }
}
