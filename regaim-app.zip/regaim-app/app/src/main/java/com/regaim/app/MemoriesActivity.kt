package com.regaim.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "My bubbles": every saved moment as a round memory bubble. Tap to play, long-press to delete. */
class MemoriesActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var count: TextView
    private val adapter = BubbleAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_memories)
        list = findViewById(R.id.bubbleList)
        empty = findViewById(R.id.emptyText)
        count = findViewById(R.id.countText)
        list.layoutManager = GridLayoutManager(this, 3)
        list.adapter = adapter
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnAsk).setOnClickListener { startActivity(Intent(this, ChatActivity::class.java)) }
    }

    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()

    override fun onResume() {
        super.onResume()
        reload()
        // Describe new moments with AI in the background, then refresh the captions.
        if (ClaudeClient.hasKey(this) && MemoryStore.all(this).any { !it.analyzed }) {
            worker.execute {
                if (MemoryStore.analyzePending(applicationContext) > 0) runOnUiThread { if (!isFinishing) reload() }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun reload() {
        val items = MemoryStore.all(this)
        adapter.items = items
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        count.text = if (items.isEmpty()) "" else "${items.size} בועות"
    }

    private fun play(m: Memory) {
        try {
            val uri = if (m.uri.startsWith("content://")) Uri.parse(m.uri) else Uri.parse("file://" + m.uri)
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "לא נמצא נגן וידאו", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "הקליפ נמצא בגלריה, תיקייה Regaim", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDelete(m: Memory) {
        AlertDialog.Builder(this)
            .setTitle("למחוק את הבועה?")
            .setMessage("גם הקליפ יימחק מהגלריה.")
            .setPositiveButton("מחק") { _, _ ->
                try {
                    if (m.uri.startsWith("content://")) contentResolver.delete(Uri.parse(m.uri), null, null)
                } catch (_: Exception) {
                }
                MemoryStore.remove(this, m.id)
                reload()
            }
            .setNegativeButton("ביטול", null)
            .show()
    }

    private fun caption(m: Memory): String {
        val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(m.time))
        val day = when {
            DateUtils.isToday(m.time) -> "היום"
            DateUtils.isToday(m.time + DateUtils.DAY_IN_MILLIS) -> "אתמול"
            else -> SimpleDateFormat("d.M", Locale.US).format(Date(m.time))
        }
        return "$day $time"
    }

    inner class BubbleAdapter : RecyclerView.Adapter<BubbleAdapter.VH>() {
        var items: List<Memory> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val image: ImageView = v.findViewById(R.id.bubbleImage)
            val title: TextView = v.findViewById(R.id.bubbleTitle)
            val sub: TextView = v.findViewById(R.id.bubbleSub)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_bubble, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val m = items[position]
            val bmp = if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb) else null
            if (bmp != null) h.image.setImageBitmap(bmp) else h.image.setImageResource(R.drawable.bubble_placeholder)
            h.title.text = caption(m)
            val meta = listOf(Labels.he(m.label), m.place).filter { it.isNotEmpty() }.joinToString(" · ")
            h.sub.text = if (m.description.isNotEmpty()) "$meta\n${m.description}" else meta
            h.itemView.setOnClickListener { play(m) }
            h.itemView.setOnLongClickListener {
                confirmDelete(m)
                true
            }
        }
    }
}
