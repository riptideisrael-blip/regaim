package com.regaim.app

import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** "זיכרונות": every moment as a bubble, grouped by day with the story of the day, filterable by category. */
class MemoriesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PERSON = "person"
    }

    private sealed class Row {
        class Header(val day: String, val title: String, val story: String, val count: Int) : Row()
        class Bubble(val m: Memory) : Row()
        class Custom(val view: View) : Row()
    }

    private lateinit var chipsScroll: View
    private lateinit var mv: MemoryViews

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var chips: LinearLayout
    private val adapter = RowAdapter()
    private val worker = Executors.newSingleThreadExecutor()
    private var filter = "הכל"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_memories)
        list = findViewById(R.id.bubbleList)
        empty = findViewById(R.id.emptyText)
        chips = findViewById(R.id.filterChips)

        val grid = GridLayoutManager(this, 3)
        grid.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) = if (adapter.rows[position] is Row.Bubble) 1 else 3
        }
        list.layoutManager = grid
        list.adapter = adapter
        Nav.setup(this, Nav.Tab.MEMORIES)
        mv = MemoryViews(this)
        // The filter chips move into the list, under the Stories / People / Albums section.
        chipsScroll = chips.parent as View
        (chipsScroll.parent as ViewGroup).removeView(chipsScroll)
        findViewById<View>(R.id.btnPeople).visibility = View.GONE
        findViewById<View>(R.id.btnMilestones).visibility = View.GONE
        findViewById<View>(R.id.btnPeople).setOnClickListener { PeopleActivity.open(this) }
        findViewById<View>(R.id.btnMilestones).setOnClickListener {
            startActivity(android.content.Intent(this, MilestonesActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        }
        intent.getStringExtra(EXTRA_PERSON)?.let { filter = "👤$it" }
    }

    override fun onResume() {
        super.onResume()
        reload()
        if (ClaudeClient.hasKey(this)) {
            worker.execute {
                val described = MemoryStore.analyzePending(applicationContext)
                val wrote = MemoryStore.refreshStories(applicationContext)
                if (described > 0 || wrote) runOnUiThread { if (!isFinishing) reload() }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun reload() {
        val all = MemoryStore.all(this)
        buildChips(all)
        val shown = when {
            filter.startsWith("📅") -> all.filter { Fmt.monthKey(it.time) == filter.removePrefix("📅") }
            else -> filterOf(all)
        }
        val rows = mutableListOf<Row>()
        if (all.isNotEmpty()) rows.add(Row.Custom(topSection(all)))
        rows.add(Row.Custom(chipsScroll))
        buildRows(rows, shown, all)
    }

    private fun filterOf(all: List<Memory>): List<Memory> = when (filter) {
            "הכל" -> all
            "מועדפים" -> all.filter { it.favorite }
            in personFilters(all) -> all.filter { m -> Fmt.names(m).contains(filter.removePrefix("👤")) }
            else -> all.filter { it.category == filter }
        }

    private fun buildRows(rows: MutableList<Row>, shown: List<Memory>, all: List<Memory>) {
        for ((day, items) in shown.groupBy { it.dayKey }) {
            rows.add(Row.Header(day, dayTitle(items.first().time), MemoryStore.story(this, day), items.size))
            items.forEach { rows.add(Row.Bubble(it)) }
        }
        adapter.rows = rows
        adapter.notifyDataSetChanged()
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (all.isEmpty()) getString(R.string.bubbles_empty) else "אין רגעים בקטגוריה הזאת עדיין"
    }

    private fun buildChips(all: List<Memory>) {
        chips.removeAllViews()
        val present = Categories.ALL.filter { c -> all.any { it.category == c } }
        val options = listOf("הכל", "מועדפים") + personFilters(all) + present +
            (if (filter.startsWith("📅")) listOf(filter) else emptyList())
        for (o in options) {
            val chip = layoutInflater.inflate(R.layout.item_chip, chips, false) as TextView
            chip.text = when {
                o == "מועדפים" -> "♥ מועדפים"
                o.startsWith("📅") -> "📅 " + Fmt.month(all.firstOrNull { Fmt.monthKey(it.time) == o.removePrefix("📅") }?.time ?: 0L)
                else -> o
            }
            val selected = o == filter
            val bg = GradientDrawable().apply {
                cornerRadius = 40f * resources.displayMetrics.density
                setColor(if (selected) ContextCompat.getColor(this@MemoriesActivity, R.color.accent) else 0xFFFFFFFF.toInt())
                if (!selected) setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), 0xFFE4E0D8.toInt())
            }
            chip.background = bg
            chip.setTextColor(if (selected) 0xFFFFFFFF.toInt() else ContextCompat.getColor(this, R.color.ink))
            chip.setOnClickListener {
                filter = o
                reload()
            }
            chips.addView(chip)
        }
    }

    // ---------- Stories · People · Albums ----------

    private fun cover(m: Memory, h: Int, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, weight: Float = 0f): View {
        val frame = android.widget.FrameLayout(this).apply {
            setBackgroundResource(R.drawable.rounded_media)
            clipToOutline = true
            layoutParams = if (weight > 0f) LinearLayout.LayoutParams(0, h, weight) else LinearLayout.LayoutParams(w, h)
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        frame.addView(iv)
        Covers.load(iv, m)
        return frame
    }

    private fun tileText(box: LinearLayout, title: String, sub: String) {
        box.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD))
            setTextColor(ContextCompat.getColor(this@MemoriesActivity, R.color.ink))
            setPadding(mv.dp(2), mv.dp(8), mv.dp(2), 0)
        })
        box.addView(TextView(this).apply {
            text = sub
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@MemoriesActivity, R.color.ink_soft))
            setPadding(mv.dp(2), 0, mv.dp(2), 0)
        })
    }

    private fun topSection(all: List<Memory>): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(mv.dp(8), mv.dp(4), mv.dp(8), mv.dp(8))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val best = ReelMaker.best(all)
        val tiles = mutableListOf<View>()

        // Stories: a collage of the best moments.
        val stories = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { StoriesActivity.open(this@MemoriesActivity) } }
        val collage = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(176)) }
        best.getOrNull(0)?.let { collage.addView(cover(it, mv.dp(176), weight = 1.4f)) }
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, mv.dp(176), 1f).apply { marginStart = mv.dp(4) }
        }
        best.getOrNull(1)?.let { side.addView(cover(it, mv.dp(86))) }
        best.getOrNull(2)?.let { side.addView(cover(it, mv.dp(86)).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = mv.dp(4) }) }
        if (side.childCount > 0) collage.addView(side)
        stories.addView(collage)
        tileText(stories, "סיפורים", "${Topics.all(this).size} נושאים")
        tiles.add(stories)

        // People: up to four faces.
        val names = (Profile.kids(this).map { it.name } + PeopleStore.people(this).map { it.name } + all.flatMap { Fmt.names(it) }).distinct()
        val people = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { startActivity(android.content.Intent(this@MemoriesActivity, FamilyActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) } }
        val faces = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.rounded_media)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(176))
        }
        if (names.isEmpty()) {
            faces.addView(mv.icon(R.drawable.ic_tab_family, 44, R.color.ink_soft))
        } else names.take(4).chunked(2).forEach { pair ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER }
            pair.forEach { n -> r.addView(mv.avatar(n, 70).apply { (layoutParams as LinearLayout.LayoutParams).setMargins(mv.dp(5), mv.dp(5), mv.dp(5), mv.dp(5)) }) }
            faces.addView(r)
        }
        people.addView(faces)
        tileText(people, "אנשים", if (names.isEmpty()) "תנו שמות לפנים" else "${names.size}")
        tiles.add(people)
        box.addView(mv.grid(tiles, 12))

        // Albums: one per month, plus milestones.
        box.addView(mv.sectionTitle("אלבומים", top = 26, icon = R.drawable.ic_photos))
        val albums = mutableListOf<View>()
        val milestones = all.filter { it.milestone.isNotEmpty() }
        if (milestones.isNotEmpty()) albums.add(album("⭐ אבני דרך", milestones) {
            startActivity(android.content.Intent(this, MilestonesActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        })
        for ((key, ms) in Topics.months(this).take(6)) {
            albums.add(album(Fmt.month(ms.first().time), ms) {
                filter = "📅$key"
                reload()
                list.smoothScrollToPosition(1)
            })
        }
        box.addView(mv.grid(albums, 12))
        box.addView(mv.sectionTitle("כל הרגעים", top = 26, icon = R.drawable.ic_clock))
        return box
    }

    private fun album(title: String, ms: List<Memory>, onClick: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { onClick() } }
        val top = ReelMaker.best(ms)
        top.getOrNull(0)?.let { box.addView(cover(it, mv.dp(110))) }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mv.dp(56)).apply { topMargin = mv.dp(4) }
        }
        top.drop(1).take(3).forEachIndexed { i, m ->
            row.addView(cover(m, mv.dp(56), weight = 1f).apply { if (i > 0) (layoutParams as LinearLayout.LayoutParams).marginStart = mv.dp(4) })
        }
        if (row.childCount > 0) box.addView(row)
        tileText(box, title, if (ms.size == 1) "רגע אחד" else "${ms.size} רגעים")
        return box
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_PERSON)?.let { filter = "👤$it"; reload() }
    }

    private fun personFilters(all: List<Memory>): List<String> =
        all.flatMap { m -> Fmt.names(m).filter { it.isNotBlank() } }.distinct().map { "👤$it" }

    private fun dayTitle(t: Long): String = when {
        DateUtils.isToday(t) -> "היום"
        DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "אתמול"
        else -> ClaudeClient.describeTime(t).substringBeforeLast(" ")
    }

    private inner class RowAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var rows: List<Row> = emptyList()

        inner class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
            val title: TextView = v.findViewById(R.id.dayTitle)
            val count: TextView = v.findViewById(R.id.dayCount)
            val story: TextView = v.findViewById(R.id.dayStory)
            val comic: TextView = v.findViewById(R.id.dayComic)
        }

        inner class BubbleVH(v: View) : RecyclerView.ViewHolder(v) {
            val image: ImageView = v.findViewById(R.id.bubbleImage)
            val title: TextView = v.findViewById(R.id.bubbleTitle)
            val sub: TextView = v.findViewById(R.id.bubbleSub)
        }

        inner class CustomVH(val box: android.widget.FrameLayout) : RecyclerView.ViewHolder(box)

        override fun getItemViewType(position: Int) = when (rows[position]) {
            is Row.Header -> 0
            is Row.Bubble -> 1
            is Row.Custom -> 2
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return when (viewType) {
                0 -> HeaderVH(inf.inflate(R.layout.item_day_header, parent, false))
                2 -> CustomVH(android.widget.FrameLayout(parent.context).apply {
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                })
                else -> BubbleVH(inf.inflate(R.layout.item_bubble, parent, false))
            }
        }

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            when (val r = rows[position]) {
                is Row.Custom -> {
                    h as CustomVH
                    h.box.removeAllViews()
                    (r.view.parent as? ViewGroup)?.removeView(r.view)
                    h.box.addView(r.view)
                }
                is Row.Header -> {
                    h as HeaderVH
                    h.title.text = r.title
                    h.count.text = if (r.count == 1) "רגע אחד" else "${r.count} רגעים"
                    h.story.text = r.story
                    h.story.visibility = if (r.story.isEmpty()) View.GONE else View.VISIBLE
                    h.comic.setOnClickListener { ComicActivity.forDay(this@MemoriesActivity, r.day) }
                }
                is Row.Bubble -> {
                    h as BubbleVH
                    val m = r.m
                    Motion.stop(h.image)
                    h.image.clipToOutline = true
                    h.image.scaleType = ImageView.ScaleType.CENTER_CROP
                    Covers.load(h.image, m)
                    Motion.attach(h.image, m, width = 240)
                    h.title.text = (if (m.favorite) "♥ " else "") + Fmt.title(m) +
                        if (m.allPeople.isNotEmpty()) "\n👤 ${m.allPeople}" else ""
                    h.sub.text = SimpleDateFormat("HH:mm", Locale.US).format(Date(m.time)) +
                        if (m.milestone.isNotEmpty()) " · ★ ${m.milestone}" else if (m.category.isNotEmpty()) " · ${m.category}" else ""
                    h.sub.setTextColor(if (m.milestone.isNotEmpty()) Categories.color("אבן דרך") else ContextCompat.getColor(this@MemoriesActivity, R.color.ink_soft))
                    h.itemView.setOnClickListener { MomentActivity.open(this@MemoriesActivity, m.id) }
                }
            }
        }
    }
}
