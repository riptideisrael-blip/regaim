package com.regaim.app

import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** "זיכרונות": every moment as a bubble, grouped by day with the story of the day, filterable by category. */
class MemoriesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PERSON = "person"
    }

    private sealed class Row {
        class Header(val day: String, val title: String, val story: String, val count: Int) : Row()
        class Bubble(val m: Memory) : Row()
    }

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var chips: LinearLayout
    private val adapter = RowAdapter()
    private val worker = Executors.newSingleThreadExecutor()
    private var filter = "הכל"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_memories)
        list = findViewById(R.id.bubbleList)
        empty = findViewById(R.id.emptyText)
        chips = findViewById(R.id.filterChips)

        val grid = GridLayoutManager(this, 3)
        grid.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) = if (adapter.rows[position] is Row.Header) 3 else 1
        }
        list.layoutManager = grid
        list.adapter = adapter
        Nav.setup(this, Nav.Tab.MEMORIES)
        findViewById<View>(R.id.btnPeople).setOnClickListener { PeopleActivity.open(this) }
        intent.getStringExtra(EXTRA_PERSON)?.let { filter = "👤$it" }
    }

    override fun onResume() {
        super.onResume()
        reload()
        if (ClaudeClient.hasKey(this)) {
            worker.execute {
                val described = MemoryStore.analyzePending(applicationContext)
                val wrote = MemoryStore.refreshStories(applicationContext)
                if (described > 0 || wrote) runOnUiThread { if (!isFinishing) reload() }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun reload() {
        val all = MemoryStore.all(this)
        buildChips(all)
        val shown = when (filter) {
            "הכל" -> all
            "מועדפים" -> all.filter { it.favorite }
            in personFilters(all) -> all.filter { m -> m.people.split(", ").contains(filter.removePrefix("👤")) }
            else -> all.filter { it.category == filter }
        }
        val rows = mutableListOf<Row>()
        for ((day, items) in shown.groupBy { it.dayKey }) {
            rows.add(Row.Header(day, dayTitle(items.first().time), MemoryStore.story(this, day), items.size))
            items.forEach { rows.add(Row.Bubble(it)) }
        }
        adapter.rows = rows
        adapter.notifyDataSetChanged()
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (all.isEmpty()) getString(R.string.bubbles_empty) else "אין רגעים בקטגוריה הזאת עדיין"
    }

    private fun buildChips(all: List<Memory>) {
        chips.removeAllViews()
        val present = Categories.ALL.filter { c -> all.any { it.category == c } }
        val options = listOf("הכל", "מועדפים") + personFilters(all) + present
        for (o in options) {
            val chip = layoutInflater.inflate(R.layout.item_chip, chips, false) as TextView
            chip.text = if (o == "מועדפים") "♥ מועדפים" else o
            val selected = o == filter
            val bg = GradientDrawable().apply {
                cornerRadius = 40f * resources.displayMetrics.density
                setColor(if (selected) ContextCompat.getColor(this@MemoriesActivity, R.color.ink) else 0xFFE9E7FB.toInt())
            }
            chip.background = bg
            chip.setTextColor(if (selected) 0xFFFFFFFF.toInt() else ContextCompat.getColor(this, R.color.accent_dark))
            chip.setOnClickListener {
                filter = o
                reload()
            }
            chips.addView(chip)
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_PERSON)?.let { filter = "👤$it"; reload() }
    }

    private fun personFilters(all: List<Memory>): List<String> =
        all.flatMap { m -> m.people.split(", ").filter { it.isNotBlank() } }.distinct().map { "👤$it" }

    private fun dayTitle(t: Long): String = when {
        DateUtils.isToday(t) -> "היום"
        DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "אתמול"
        else -> ClaudeClient.describeTime(t).substringBeforeLast(" ")
    }

    private inner class RowAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var rows: List<Row> = emptyList()

        inner class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
            val title: TextView = v.findViewById(R.id.dayTitle)
            val count: TextView = v.findViewById(R.id.dayCount)
            val story: TextView = v.findViewById(R.id.dayStory)
            val comic: TextView = v.findViewById(R.id.dayComic)
        }

        inner class BubbleVH(v: View) : RecyclerView.ViewHolder(v) {
            val image: ImageView = v.findViewById(R.id.bubbleImage)
            val title: TextView = v.findViewById(R.id.bubbleTitle)
            val sub: TextView = v.findViewById(R.id.bubbleSub)
        }

        override fun getItemViewType(position: Int) = if (rows[position] is Row.Header) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return if (viewType == 0) HeaderVH(inf.inflate(R.layout.item_day_header, parent, false))
            else BubbleVH(inf.inflate(R.layout.item_bubble, parent, false))
        }

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            when (val r = rows[position]) {
                is Row.Header -> {
                    h as HeaderVH
                    h.title.text = r.title
                    h.count.text = if (r.count == 1) "רגע אחד" else "${r.count} רגעים"
                    h.story.text = r.story
                    h.story.visibility = if (r.story.isEmpty()) View.GONE else View.VISIBLE
                    h.comic.setOnClickListener { ComicActivity.forDay(this@MemoriesActivity, r.day) }
                }
                is Row.Bubble -> {
                    h as BubbleVH
                    val m = r.m
                    val bmp = if (m.thumb.isNotEmpty()) BitmapFactory.decodeFile(m.thumb) else null
                    if (bmp != null) h.image.setImageBitmap(bmp) else h.image.setImageResource(R.drawable.bubble_placeholder)
                    h.title.text = (if (m.favorite) "♥ " else "") + m.displayTitle +
                        if (m.people.isNotEmpty()) "\n👤 ${m.people}" else ""
                    h.sub.text = SimpleDateFormat("HH:mm", Locale.US).format(Date(m.time)) +
                        if (m.milestone.isNotEmpty()) " · ★ ${m.milestone}" else if (m.category.isNotEmpty()) " · ${m.category}" else ""
                    h.sub.setTextColor(if (m.milestone.isNotEmpty()) Categories.color("אבן דרך") else ContextCompat.getColor(this@MemoriesActivity, R.color.ink_soft))
                    h.itemView.setOnClickListener { MomentActivity.open(this@MemoriesActivity, m.id) }
                }
            }
        }
    }
}
