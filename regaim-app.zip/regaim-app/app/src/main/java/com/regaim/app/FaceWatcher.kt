package com.regaim.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Looks at the camera about once a second, fully on the phone (Google ML Kit):
 *  - a big smile on a face in front of you  -> "smile" moment
 *  - a face growing fast in the frame (a child running to you) -> "approach" moment
 * No face is recognized or stored; it only measures smiles and sizes.
 */
class FaceWatcher(private val onMoment: (String) -> Unit) {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.12f)
            .build()
    )
    private val busy = AtomicBoolean(false)
    private var lastRunMs = 0L
    private val history = ArrayDeque<Pair<Long, Float>>() // time, biggest face area share

    /** Feed an upright bitmap; skips frames while busy or too soon. */
    fun feed(bmp: Bitmap) {
        val now = System.currentTimeMillis()
        if (now - lastRunMs < 800 || !busy.compareAndSet(false, true)) return
        lastRunMs = now
        detector.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { faces ->
                val frameArea = (bmp.width * bmp.height).toFloat()
                var smile = 0f
                var biggest = 0f
                for (f in faces) {
                    val area = f.boundingBox.width() * f.boundingBox.height() / frameArea
                    if (area > biggest) biggest = area
                    val s = f.smilingProbability ?: 0f
                    if (area > 0.02f && s > smile) smile = s
                }
                Status.faces = faces.size
                Status.smile = smile
                check(now, smile, biggest)
            }
            .addOnCompleteListener { busy.set(false) }
    }

    private fun check(now: Long, smile: Float, biggest: Float) {
        if (smile >= 0.88f) {
            onMoment("Smile")
            return
        }
        history.addLast(now to biggest)
        while (history.isNotEmpty() && now - history.first().first > 2500) history.removeFirst()
        val oldest = history.firstOrNull() ?: return
        // A face that tripled in size within ~2 seconds and is now close = someone running toward you.
        if (oldest.second in 0.004f..0.05f && biggest > 0.07f && biggest > oldest.second * 3f) {
            history.clear()
            onMoment("Approach")
        }
    }

    fun close() {
        try { detector.close() } catch (_: Exception) {}
    }
}
