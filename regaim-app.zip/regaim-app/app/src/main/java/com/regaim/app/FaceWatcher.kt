package com.regaim.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Looks at the camera about once a second, fully on the phone (Google ML Kit):
 *  - a big smile on a face in front of you  -> "smile" moment
 *  - a face growing fast in the frame (a child running to you) -> "approach" moment
 *  - a hug: a face comes very close and then the camera on your chest is covered for ~3 seconds,
 *    or two faces stay pressed together in front of you for 3+ seconds -> "hug" moment
 * No face is recognized or stored; it only measures smiles, sizes and how dark/covered the picture is.
 */
class FaceWatcher(private val onMoment: (String) -> Unit) {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.12f)
            .build()
    )
    private val busy = AtomicBoolean(false)
    private var lastRunMs = 0L
    private val history = ArrayDeque<Pair<Long, Float>>() // time, biggest face area share
    private var lastCloseFaceMs = 0L   // when a face was last very close to the camera
    private var coveredSinceMs = 0L    // camera covered (pressed against someone) since
    private var togetherSinceMs = 0L   // two faces pressed together since

    /** Feed an upright bitmap; skips frames while busy or too soon. */
    fun feed(bmp: Bitmap) {
        val now = System.currentTimeMillis()
        if (now - lastRunMs < 800 || !busy.compareAndSet(false, true)) return
        lastRunMs = now
        detector.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { faces ->
                val covered = isCovered(bmp)
                val frameArea = (bmp.width * bmp.height).toFloat()
                var smile = 0f
                var biggest = 0f
                for (f in faces) {
                    val area = f.boundingBox.width() * f.boundingBox.height() / frameArea
                    if (area > biggest) biggest = area
                    val s = f.smilingProbability ?: 0f
                    if (area > 0.02f && s > smile) smile = s
                }
                Status.faces = faces.size
                Status.smile = smile
                if (Status.hugOn && checkHug(now, faces, frameArea, biggest, covered)) return@addOnSuccessListener
                if (Status.facesOn) check(now, smile, biggest)
            }
            .addOnCompleteListener { busy.set(false) }
    }

    private fun check(now: Long, smile: Float, biggest: Float) {
        if (smile >= 0.88f) {
            onMoment("Smile")
            return
        }
        history.addLast(now to biggest)
        while (history.isNotEmpty() && now - history.first().first > 2500) history.removeFirst()
        val oldest = history.firstOrNull() ?: return
        // A face that tripled in size within ~2 seconds and is now close = someone running toward you.
        if (oldest.second in 0.004f..0.05f && biggest > 0.07f && biggest > oldest.second * 3f) {
            history.clear()
            onMoment("Approach")
        }
    }

    /** Mostly dark or flat picture = the camera is pressed against someone (or covered). */
    private fun isCovered(bmp: Bitmap): Boolean {
        val n = 12
        var sum = 0.0
        var sumSq = 0.0
        for (i in 0 until n) for (j in 0 until n) {
            val p = bmp.getPixel((bmp.width - 1) * i / (n - 1), (bmp.height - 1) * j / (n - 1))
            val y = 0.299 * ((p shr 16) and 0xff) + 0.587 * ((p shr 8) and 0xff) + 0.114 * (p and 0xff)
            sum += y
            sumSq += y * y
        }
        val count = n * n
        val mean = sum / count
        val std = kotlin.math.sqrt((sumSq / count - mean * mean).coerceAtLeast(0.0))
        return mean < 40 || std < 14
    }

    private fun checkHug(
        now: Long, faces: List<com.google.mlkit.vision.face.Face>, frameArea: Float, biggest: Float, covered: Boolean,
    ): Boolean {
        // 1) Someone hugs you: a face very close, then the chest camera covered for ~3 seconds.
        if (biggest > 0.12f) lastCloseFaceMs = now
        if (covered && faces.isEmpty()) {
            if (coveredSinceMs == 0L) coveredSinceMs = now
            if (now - lastCloseFaceMs < 5000 && now - coveredSinceMs >= 2500) {
                reset()
                onMoment("Hug")
                return true
            }
        } else coveredSinceMs = 0L

        // 2) Two people hugging in front of you: two faces pressed together for 3+ seconds.
        val big = faces.filter { it.boundingBox.width() * it.boundingBox.height() / frameArea > 0.015f }
            .sortedByDescending { it.boundingBox.width() * it.boundingBox.height() }
        var together = false
        if (big.size >= 2) {
            val a = big[0].boundingBox
            val b = big[1].boundingBox
            val dx = (a.centerX() - b.centerX()).toFloat()
            val dy = (a.centerY() - b.centerY()).toFloat()
            val dist = kotlin.math.sqrt(dx * dx + dy * dy)
            together = dist < 1.15f * (a.width() + b.width()) / 2f
        }
        if (together) {
            if (togetherSinceMs == 0L) togetherSinceMs = now
            if (now - togetherSinceMs >= 3000) {
                reset()
                onMoment("Hug")
                return true
            }
        } else togetherSinceMs = 0L
        return false
    }

    private fun reset() {
        coveredSinceMs = 0L
        togetherSinceMs = 0L
        lastCloseFaceMs = 0L
        history.clear()
    }

    fun close() {
        try { detector.close() } catch (_: Exception) {}
    }
}
