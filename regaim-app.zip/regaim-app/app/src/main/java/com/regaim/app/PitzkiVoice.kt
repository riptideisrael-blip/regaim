package com.regaim.app

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Pitzki's voice: Hebrew lines and English color words, from the phone's own voices (or a recorded line when one
 * was added to the app). Every line calls [done] exactly once — after it was said, or after a fair reading time when
 * there's no voice (muted, or no Hebrew voice on the phone), so the lesson never gets stuck.
 */
class PitzkiVoice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var he: TextToSpeech? = null
    private var en: TextToSpeech? = null
    @Volatile var heOk = false
        private set
    @Volatile var enOk = false
        private set
    var muted = false
    private var pending: Runnable? = null
    private var pendingId = ""
    private var player: MediaPlayer? = null
    private var seq = 0

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { main.post { finish(utteranceId.orEmpty()) } }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { main.post { finish(utteranceId.orEmpty()) } }
        override fun onError(utteranceId: String?, errorCode: Int) { main.post { finish(utteranceId.orEmpty()) } }
    }

    init {
        he = TextToSpeech(ctx.applicationContext) init@{ status ->
            val t = he ?: return@init
            if (status == TextToSpeech.SUCCESS) {
                val r = t.setLanguage(Locale("he", "IL"))
                heOk = r >= TextToSpeech.LANG_AVAILABLE
                bestVoice(t, "he", "iw")
                t.setSpeechRate(0.88f)
                t.setPitch(1.3f) // higher: a young, childlike voice for Pitzki
                t.setOnUtteranceProgressListener(listener)
            }
        }
        en = TextToSpeech(ctx.applicationContext) init@{ status ->
            val t = en ?: return@init
            if (status == TextToSpeech.SUCCESS) {
                val r = t.setLanguage(Locale.US)
                enOk = r >= TextToSpeech.LANG_AVAILABLE
                bestVoice(t, "en")
                t.setSpeechRate(0.72f)
                t.setPitch(1.25f)
                t.setOnUtteranceProgressListener(listener)
            }
        }
    }

    /**
     * The clearest voice the phone has for the language: the highest quality, and one that works without the internet
     * when it's as good.
     */
    private fun bestVoice(t: TextToSpeech, vararg langs: String) {
        try {
            val vs = t.voices.orEmpty().filter { v -> v.locale.language in langs && !v.features.orEmpty().contains("notInstalled") }
            val best = vs.maxWithOrNull(compareBy<android.speech.tts.Voice>({ it.quality }, { if (it.isNetworkConnectionRequired) 0 else 1 }))
            if (best != null) t.voice = best
        } catch (_: Exception) { /* the default voice stays */ }
    }

    private fun spoken(text: String) = spokenText(text)

    companion object {
        /**
         * The niqqud of every word Pitzki says, so his voice reads each one right (חוּם the color, not חַם hot).
         * Whole words only; the subtitles keep the plain text. New words: add them here.
         */
        private val NIQQUD: Map<String, String> = mapOf(
            "פיצקי" to "פִּיצְקִי",
            "שדון" to "שֵׁדוֹן",
            "אבן" to "אֶבֶן",
            "אדום" to "אָדוֹם",
            "אומרים" to "אוֹמְרִים",
            "אותם" to "אוֹתָם",
            "איזה" to "אֵיזֶה",
            "איפה" to "אֵיפֹה",
            "איתי" to "אִיתִּי",
            "אלוף" to "אַלּוּף",
            "אלופה" to "אַלּוּפָה",
            "אלופים" to "אַלּוּפִים",
            "אפור" to "אָפוֹר",
            "ארבעה" to "אַרְבָּעָה",
            "ארנב" to "אַרְנָב",
            "את" to "אַתְּ",
            "אתה" to "אַתָּה",
            "אתם" to "אַתֶּם",
            "באנגלית" to "בְּאַנְגְּלִית",
            "בהרפתקה" to "בַּהַרְפַּתְקָה",
            "בוא" to "בּוֹא",
            "בואי" to "בּוֹאִי",
            "בואו" to "בּוֹאוּ",
            "בין" to "בֵּין",
            "ביער" to "בַּיַּעַר",
            "בנחל" to "בַּנַּחַל",
            "בצורת" to "בְּצוּרַת",
            "בשביל" to "בַּשְּׁבִיל",
            "גדול" to "גָּדוֹל",
            "האבן" to "הָאֶבֶן",
            "האבנים" to "הָאֲבָנִים",
            "האגם" to "הָאֲגַם",
            "האדום" to "הָאָדוֹם",
            "האפור" to "הָאָפוֹר",
            "האפורה" to "הָאֲפוֹרָה",
            "הארנב" to "הָאַרְנָב",
            "הבאה" to "הַבָּאָה",
            "הגזע" to "הַגֶּזַע",
            "הגפן" to "הַגֶּפֶן",
            "הוורוד" to "הַוָּרוֹד",
            "הופ" to "הוֹפּ",
            "החום" to "הַחוּם",
            "החיפושית" to "הַחִיפּוּשִׁית",
            "היא" to "הִיא",
            "היום" to "הַיּוֹם",
            "הירוק" to "הַיָּרוֹק",
            "הכבוד" to "הַכָּבוֹד",
            "הכחול" to "הַכָּחוֹל",
            "הכחולה" to "הַכְּחוּלָּה",
            "הלבן" to "הַלָּבָן",
            "הנה" to "הִנֵּה",
            "הנכונה" to "הַנְּכוֹנָה",
            "הסגול" to "הַסָּגוֹל",
            "הסגולים" to "הַסְּגוֹלִים",
            "העלה" to "הֶעָלֶה",
            "הענבים" to "הָעֲנָבִים",
            "הענף" to "הָעָנָף",
            "העצים" to "הָעֵצִים",
            "הפלמינגו" to "הַפְלָמִינְגּוֹ",
            "הפרח" to "הַפֶּרַח",
            "הצהוב" to "הַצָּהוֹב",
            "הציפור" to "הַצִּיפּוֹר",
            "הרגליים" to "הָרַגְלַיִם",
            "השחור" to "הַשָּׁחוֹר",
            "השחורה" to "הַשְּׁחוֹרָה",
            "התפוח" to "הַתַּפּוּחַ",
            "התשובה" to "הַתְּשׁוּבָה",
            "ומבריקה" to "וּמַבְרִיקָה",
            "ונחפש" to "וּנְחַפֵּשׂ",
            "ונלמד" to "וְנִלְמַד",
            "ורוד" to "וָרוֹד",
            "ורך" to "וָרַךְ",
            "זה" to "זֶה",
            "זכרנו" to "זָכַרְנוּ",
            "חום" to "חוּם",
            "חיפושית" to "חִיפּוּשִׁית",
            "טוב" to "טוֹב",
            "טיול" to "טִיּוּל",
            "יד" to "יָד",
            "יופי" to "יוֹפִי",
            "יחד" to "יַחַד",
            "יער" to "יַעַר",
            "יפה" to "יָפֶה",
            "ירוק" to "יָרוֹק",
            "יש" to "יֵשׁ",
            "כבר" to "כְּבָר",
            "כחול" to "כָּחוֹל",
            "כיף" to "כֵּיף",
            "כל" to "כָּל",
            "כמעט" to "כִּמְעַט",
            "לא" to "לֹא",
            "לאבן" to "לָאֶבֶן",
            "לארנב" to "לָאַרְנָב",
            "לב" to "לֵב",
            "לבן" to "לָבָן",
            "לגזע" to "לַגֶּזַע",
            "לגלות" to "לְגַלּוֹת",
            "להגיד" to "לְהַגִּיד",
            "לחיפושית" to "לַחִיפּוּשִׁית",
            "לטיול" to "לְטִיּוּל",
            "לי" to "לִי",
            "ליד" to "לְיַד",
            "ליער" to "לַיַּעַר",
            "למדנו" to "לָמַדְנוּ",
            "לעלה" to "לֶעָלֶה",
            "לענבים" to "לָעֲנָבִים",
            "לפלמינגו" to "לַפְלָמִינְגּוֹ",
            "לפרח" to "לַפֶּרַח",
            "לציפור" to "לַצִּיפּוֹר",
            "לתפוח" to "לַתַּפּוּחַ",
            "מאוד" to "מְאוֹד",
            "מה" to "מָה",
            "מוכן" to "מוּכָן",
            "מוכנה" to "מוּכָנָה",
            "מוכנים" to "מוּכָנִים",
            "מצאנו" to "מָצָאנוּ",
            "נבדוק" to "נִבְדּוֹק",
            "נגיד" to "נַגִּיד",
            "נכון" to "נָכוֹן",
            "נמצא" to "נִמְצָא",
            "נמשיך" to "נַמְשִׁיךְ",
            "נסה" to "נַסֵּה",
            "נסי" to "נַסִּי",
            "נסו" to "נַסּוּ",
            "נפלא" to "נִפְלָא",
            "נצא" to "נֵצֵא",
            "נקפוץ" to "נִקְפּוֹץ",
            "נתראה" to "נִתְרָאֶה",
            "סגול" to "סָגוֹל",
            "עוד" to "עוֹד",
            "עומד" to "עוֹמֵד",
            "עכשיו" to "עַכְשָׁיו",
            "על" to "עַל",
            "עלה" to "עָלֶה",
            "ענבים" to "עֲנָבִים",
            "עץ" to "עֵץ",
            "עשרה" to "עֲשָׂרָה",
            "פלמינגו" to "פְלָמִינְגּוֹ",
            "פנימה" to "פְּנִימָה",
            "פרח" to "פֶּרַח",
            "צבע" to "צֶבַע",
            "צבעים" to "צְבָעִים",
            "צהוב" to "צָהוֹב",
            "ציפור" to "צִיפּוֹר",
            "קופץ" to "קוֹפֵץ",
            "קטן" to "קָטָן",
            "קטנה" to "קְטַנָּה",
            "רק" to "רַק",
            "שוב" to "שׁוּב",
            "שחור" to "שָׁחוֹר",
            "שישה" to "שִׁישָּׁה",
            "שלו" to "שֶׁלּוֹ",
            "שלום" to "שָׁלוֹם",
            "שלנו" to "שֶׁלָּנוּ",
            "שמעתי" to "שָׁמַעְתִּי",
            "שמש" to "שֶׁמֶשׁ",
            "שני" to "שְׁנֵי",
            "תגיד" to "תַּגִּיד",
            "תגידי" to "תַּגִּידִי",
            "תגידו" to "תַּגִּידוּ",
            "תלחץ" to "תִּלְחַץ",
            "תלחצי" to "תִּלְחֲצִי",
            "תלחצו" to "תִּלְחֲצוּ",
            "תן" to "תֵּן",
            "תני" to "תְּנִי",
            "תנו" to "תְּנוּ",
            "תפוח" to "תַּפּוּחַ",
            "תצביע" to "תַּצְבִּיעַ",
            "תצביעי" to "תַּצְבִּיעִי",
            "תצביעו" to "תַּצְבִּיעוּ",
            "תראה" to "תִּרְאֶה",
            "תראי" to "תִּרְאִי",
            "תראו" to "תִּרְאוּ",
            "חברים" to "חֲבֵרִים",
            "מצאתם" to "מְצָאתֶם",
            "שבאתם" to "שֶׁבָּאתֶם",
            "וואו" to "וָאוּ"
        )
        private val HEBREW_WORD = Regex("[\u05D0-\u05EA]+")

        /**
         * How this child's name is said (the parent wrote it with niqqud, e.g. אוֹרִי and not אוּרִי): the name as
         * written -> as said. Set by the screen for the chosen child.
         */
        @Volatile var sayName: Pair<String, String>? = null

        /** The line with niqqud for Pitzki's voice (and the child's name the way the family says it). */
        fun spokenText(text: String): String {
            val name = sayName
            return HEBREW_WORD.replace(text) { m ->
                val w = m.value
                if (name != null && w == name.first && name.second.isNotBlank()) name.second else NIQQUD[w] ?: w
            }
        }
    }

    private fun finish(id: String) {
        if (id != pendingId) return
        val p = pending ?: return
        pending = null
        pendingId = ""
        p.run()
    }

    /** About how long a line takes to read, when it isn't heard. */
    private fun readingMs(text: String) = (900L + text.length * 75L).coerceAtMost(6000L)

    /** Hebrew line. [recording]: the id of a recorded line to play instead, if the app has it. */
    fun say(text: String, recording: String = "", done: () -> Unit) = speak(he, heOk, text, recording, done)

    /** An English word, slow and clear. */
    fun word(text: String, done: () -> Unit) = speak(en, enOk, text, "", done)

    private fun speak(tts: TextToSpeech?, ok: Boolean, text: String, recording: String, done: () -> Unit) {
        stop()
        val id = "p${++seq}"
        pendingId = id
        pending = Runnable { done() }
        // A safety net: the line ends even if the phone never says it's done.
        main.postDelayed({ finish(id) }, readingMs(text) + 6000L)
        if (muted) { main.postDelayed({ finish(id) }, readingMs(text)); return }
        // Pitzki's own voice (made ahead, kept on the phone): the same for Hebrew lines and the English words.
        PitzkiStore.voiceFile(ctx, spokenText(text))?.let { f ->
            try {
                val mp = MediaPlayer()
                mp.setDataSource(f.absolutePath)
                mp.setOnCompletionListener { finish(id) }
                mp.setOnErrorListener { _, _, _ -> finish(id); true }
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (_: Exception) { /* the phone's voice */ }
        }
        if (recording.isNotEmpty() && PitzkiStore.hasRecording(ctx, recording)) {
            try {
                val fd = ctx.assets.openFd("pitzki/voice/$recording.mp3")
                val mp = MediaPlayer()
                mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                fd.close()
                mp.setOnCompletionListener { finish(id) }
                mp.setOnErrorListener { _, _, _ -> finish(id); true }
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (_: Exception) { /* fall back to the phone's voice */ }
        }
        if (tts == null || !ok) { main.postDelayed({ finish(id) }, readingMs(text)); return }
        val say = if (tts === he) spoken(text) else text
        if (tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) main.postDelayed({ finish(id) }, readingMs(text))
    }

    /** Stops what's being said; its [done] is NOT called (the lesson was paused or moved on). */
    fun stop() {
        pending = null
        pendingId = ""
        try { he?.stop() } catch (_: Exception) {}
        try { en?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    fun shutdown() {
        stop()
        try { he?.shutdown() } catch (_: Exception) {}
        try { en?.shutdown() } catch (_: Exception) {}
        he = null
        en = null
    }
}
