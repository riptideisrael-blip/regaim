package com.regaim.app

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Pitzki's voice: Hebrew lines and English color words, from the phone's own voices (or a recorded line when one
 * was added to the app). Every line calls [done] exactly once — after it was said, or after a fair reading time when
 * there's no voice (muted, or no Hebrew voice on the phone), so the lesson never gets stuck.
 */
class PitzkiVoice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var he: TextToSpeech? = null
    private var en: TextToSpeech? = null
    @Volatile var heOk = false
        private set
    @Volatile var enOk = false
        private set
    var muted = false
    private var pending: Runnable? = null
    private var pendingId = ""
    private var player: MediaPlayer? = null
    private var seq = 0

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { main.post { finish(utteranceId.orEmpty()) } }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { main.post { finish(utteranceId.orEmpty()) } }
        override fun onError(utteranceId: String?, errorCode: Int) { main.post { finish(utteranceId.orEmpty()) } }
    }

    init {
        he = TextToSpeech(ctx.applicationContext) init@{ status ->
            val t = he ?: return@init
            if (status == TextToSpeech.SUCCESS) {
                val r = t.setLanguage(Locale("he", "IL"))
                heOk = r >= TextToSpeech.LANG_AVAILABLE
                bestVoice(t, "he", "iw")
                t.setSpeechRate(0.88f)
                t.setPitch(1.3f) // higher: a young, childlike voice for Pitzki
                t.setOnUtteranceProgressListener(listener)
            }
        }
        en = TextToSpeech(ctx.applicationContext) init@{ status ->
            val t = en ?: return@init
            if (status == TextToSpeech.SUCCESS) {
                val r = t.setLanguage(Locale.US)
                enOk = r >= TextToSpeech.LANG_AVAILABLE
                bestVoice(t, "en")
                t.setSpeechRate(0.72f)
                t.setPitch(1.25f)
                t.setOnUtteranceProgressListener(listener)
            }
        }
    }

    /**
     * The clearest voice the phone has for the language: the highest quality, and one that works without the internet
     * when it's as good.
     */
    private fun bestVoice(t: TextToSpeech, vararg langs: String) {
        try {
            val vs = t.voices.orEmpty().filter { v -> v.locale.language in langs && !v.features.orEmpty().contains("notInstalled") }
            val best = vs.maxWithOrNull(compareBy<android.speech.tts.Voice>({ it.quality }, { if (it.isNetworkConnectionRequired) 0 else 1 }))
            if (best != null) t.voice = best
        } catch (_: Exception) { /* the default voice stays */ }
    }

    /** Small spelling help (niqqud) for words the phone's Hebrew voice says wrong. The subtitles keep the plain text. */
    private fun spoken(text: String): String {
        var t = text
        for ((plain, voweled) in NIQQUD) t = t.replace(plain, voweled)
        return t
    }

    private val NIQQUD = listOf(
        "פיצקי" to "פִּיצְקִי",
        "שדון" to "שֵׁדוֹן",
    )

    private fun finish(id: String) {
        if (id != pendingId) return
        val p = pending ?: return
        pending = null
        pendingId = ""
        p.run()
    }

    /** About how long a line takes to read, when it isn't heard. */
    private fun readingMs(text: String) = (900L + text.length * 75L).coerceAtMost(6000L)

    /** Hebrew line. [recording]: the id of a recorded line to play instead, if the app has it. */
    fun say(text: String, recording: String = "", done: () -> Unit) = speak(he, heOk, text, recording, done)

    /** An English word, slow and clear. */
    fun word(text: String, done: () -> Unit) = speak(en, enOk, text, "", done)

    private fun speak(tts: TextToSpeech?, ok: Boolean, text: String, recording: String, done: () -> Unit) {
        stop()
        val id = "p${++seq}"
        pendingId = id
        pending = Runnable { done() }
        // A safety net: the line ends even if the phone never says it's done.
        main.postDelayed({ finish(id) }, readingMs(text) + 6000L)
        if (muted) { main.postDelayed({ finish(id) }, readingMs(text)); return }
        if (recording.isNotEmpty() && PitzkiStore.hasRecording(ctx, recording)) {
            try {
                val fd = ctx.assets.openFd("pitzki/voice/$recording.mp3")
                val mp = MediaPlayer()
                mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                fd.close()
                mp.setOnCompletionListener { finish(id) }
                mp.setOnErrorListener { _, _, _ -> finish(id); true }
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (_: Exception) { /* fall back to the phone's voice */ }
        }
        if (tts == null || !ok) { main.postDelayed({ finish(id) }, readingMs(text)); return }
        val say = if (tts === he) spoken(text) else text
        if (tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) main.postDelayed({ finish(id) }, readingMs(text))
    }

    /** Stops what's being said; its [done] is NOT called (the lesson was paused or moved on). */
    fun stop() {
        pending = null
        pendingId = ""
        try { he?.stop() } catch (_: Exception) {}
        try { en?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    fun shutdown() {
        stop()
        try { he?.shutdown() } catch (_: Exception) {}
        try { en?.shutdown() } catch (_: Exception) {}
        he = null
        en = null
    }
}
