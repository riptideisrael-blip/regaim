package com.regaim.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("regaim", MODE_PRIVATE) }

    private lateinit var statusText: TextView
    private lateinit var timerText: TextView
    private lateinit var btnToggle: Button
    private lateinit var meter: ProgressBar
    private lateinit var meterLabel: TextView
    private lateinit var sensitivity: SeekBar
    private lateinit var sensitivityLabel: TextView
    private lateinit var clipsText: TextView
    private lateinit var btnSaveNow: Button
    private lateinit var btnGallery: Button
    private lateinit var errorText: TextView
    private lateinit var btnBubbles: Button

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCorePermissions()) startCapture()
            else toast("צריך הרשאת מצלמה ומיקרופון כדי לעבוד")
        }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        timerText = findViewById(R.id.timerText)
        btnToggle = findViewById(R.id.btnToggle)
        meter = findViewById(R.id.meter)
        meterLabel = findViewById(R.id.meterLabel)
        sensitivity = findViewById(R.id.sensitivity)
        sensitivityLabel = findViewById(R.id.sensitivityLabel)
        clipsText = findViewById(R.id.clipsText)
        btnSaveNow = findViewById(R.id.btnSaveNow)
        btnGallery = findViewById(R.id.btnGallery)
        errorText = findViewById(R.id.errorText)
        btnBubbles = findViewById(R.id.btnBubbles)
        btnBubbles.setOnClickListener { startActivity(Intent(this, MemoriesActivity::class.java)) }

        // Sensitivity slider: higher = saves on quieter / shorter laughs.
        Status.threshold = prefs.getFloat("threshold", 0.3f)
        sensitivity.max = 80
        sensitivity.progress = ((0.9f - Status.threshold) * 100).roundToInt().coerceIn(0, 80)
        updateSensitivityLabel()
        sensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                Status.threshold = 0.9f - progress / 100f
                prefs.edit().putFloat("threshold", Status.threshold).apply()
                updateSensitivityLabel()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnToggle.setOnClickListener {
            if (Status.running) sendToService(CaptureService.ACTION_STOP) else requestAndStart()
        }
        btnSaveNow.setOnClickListener { sendToService(CaptureService.ACTION_SAVE_NOW) }
        btnGallery.setOnClickListener { openGallery() }
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    // ---------- permissions & service ----------

    private fun neededPermissions(): List<String> {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        // Optional: lets each memory remember where it happened.
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT < 29) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return list
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasCorePermissions(): Boolean {
        val core = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT < 29) core.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return core.all { granted(it) }
    }

    private fun requestAndStart() {
        val missing = neededPermissions().filterNot { granted(it) }
        if (missing.isEmpty()) startCapture() else permLauncher.launch(missing.toTypedArray())
    }

    private fun startCapture() {
        Status.error = null
        val intent = Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun sendToService(action: String) {
        startService(Intent(this, CaptureService::class.java).setAction(action))
    }

    // ---------- UI ----------

    private fun updateSensitivityLabel() {
        val p = sensitivity.progress
        val word = when {
            p >= 65 -> "גבוהה מאוד"
            p >= 50 -> "גבוהה"
            p >= 30 -> "בינונית"
            else -> "נמוכה"
        }
        sensitivityLabel.text = "רגישות: $word (סף ${(Status.threshold * 100).roundToInt()}%)"
    }

    private fun refresh() {
        val s = Status
        btnToggle.text = if (s.running) "עצור" else "התחל לתפוס רגעים"
        statusText.text = when {
            !s.running -> "כבוי"
            s.pending -> "זוהה רגע! שומר גם את 15 השניות הבאות..."
            else -> "מאזין לרגעים..."
        }
        timerText.text = if (s.running && s.startedAt > 0) {
            "זמן פעילות: " + formatDuration(System.currentTimeMillis() - s.startedAt)
        } else ""

        val pct = (s.lastScore * 100).roundToInt().coerceIn(0, 100)
        meter.progress = if (s.running) pct else 0
        meterLabel.text = if (s.running) {
            val what = if (s.lastLabel.isEmpty()) "אין צחוק" else Labels.he(s.lastLabel)
            "$what · $pct%\nשומע עכשיו: ${Labels.he(s.topLabel)}"
        } else "מד הצחוק יתעורר כשתתחיל"

        val last = if (s.lastClipAt > 0) {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(s.lastClipAt))
            "\nאחרון: ${Labels.he(s.lastClipLabel)} ב-$t"
        } else ""
        clipsText.text = "רגעים שנשמרו בסשן הזה: ${s.clips}$last"

        val err = s.error
        errorText.text = err ?: ""
        errorText.visibility = if (err == null) View.GONE else View.VISIBLE
        btnSaveNow.isEnabled = s.running && !s.pending
    }

    private fun formatDuration(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val sec = total % 60
        return String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    }

    private fun openGallery() {
        val candidates = listOf(
            Intent(Intent.ACTION_VIEW).setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*"),
            Intent(Intent.ACTION_VIEW, MediaStore.Video.Media.EXTERNAL_CONTENT_URI),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
        )
        for (intent in candidates) {
            try {
                startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: ActivityNotFoundException) {
            } catch (_: SecurityException) {
            }
        }
        toast("הקליפים נמצאים בגלריה, בתיקייה Movies/Regaim")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
