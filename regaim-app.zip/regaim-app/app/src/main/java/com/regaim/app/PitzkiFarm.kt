package com.regaim.app

/**
 * The third world: Pitzki's farm, "who makes that sound?" (ages ~3). Seven animals: first only the animal's sound is
 * heard, Pitzki asks who it is (his talking video, the animal still hidden), the child answers (out loud or by tapping
 * a picture), and only then the animal comes out (its animation, from hidden to seen) and Pitzki says who it was.
 * Pitzki and the animals are the same for every family (made once); the child is drawn into four scenes of their
 * own (arriving, petting the dog, feeding the sheep, goodbye), and a short game of three sounds ends the walk.
 */
object FarmWorld {
    const val ID = "farm"
    const val INTRO = "farm_intro"

    /** An animal: its key, how it's called, how its sound is written, the picture, and the ask / reveal lines. */
    class Animal(
        val id: String, val he: String, val emoji: String, val sound: String,
        /** Pitzki's question in his video (the same for every child: no name, said to everyone). */
        val ask: String,
        /** What he says when it comes out. */
        val reveal: String,
        /** The animal hidden in the picture before it comes out (said to the drawing model). */
        val hidden: String,
        /** How it comes out (the animation from hidden to seen). */
        val comesOut: String,
        /** The sound effect asked from the voice service. */
        val sfx: String,
    ) {
        val key get() = "farm_$id"
        val open get() = "farm_${id}_open"
    }

    /** In the order of the walk: the coop, the barn, the dog house, the hay, the fence, the stable, the pasture. */
    val ANIMALS = listOf(
        Animal("rooster", "תרנגול", "🐓", "קוּקוּרִיקוּ!",
            "שמעתם? מי קורא ככה, קוּקוּרִיקוּ? מי עושה את הקול?",
            "זה התרנגול! הוא מעיר את כל החווה בבוקר. קוּקוּרִיקוּ!",
            "the rooster is hidden behind the closed coop door: only its shadow is seen through the slats, the perch is empty",
            "the colorful rooster hops out onto the wooden perch, spreads its wings a little and crows proudly; Pitzki claps",
            "a rooster crowing cock-a-doodle-doo once, clear, no background"),
        Animal("cow", "פרה", "🐮", "מוּוּוּ!",
            "איזה קול עמוק! מי עושה מוּוּוּ?",
            "זאת הפרה! היא נותנת לנו חלב. מוּוּוּ!",
            "the cow is hidden in the dark barn doorway: only a big soft shadow is seen inside",
            "the friendly black and white cow steps slowly out of the barn, its bell ringing, and moos with a big smile; Pitzki pats it gently",
            "a friendly cow mooing once, long and warm, no background"),
        Animal("dog", "כלב", "🐶", "הַב הַב!",
            "וואו! מי נובח ככה? מי עושה הַב הַב?",
            "זה הכלב! הוא מכשכש בזנב מרוב שמחה. הַב הַב!",
            "the dog is hidden inside the wooden dog house: only darkness in its round doorway, the bowl outside",
            "the happy puppy runs out of the dog house, wags its tail and barks joyfully; Pitzki laughs",
            "a happy small dog barking twice, clear, friendly, no background"),
        Animal("cat", "חתול", "🐱", "מְיָאוּ!",
            "שֶׁקֶט שֶׁקֶט... מי עושה מְיָאוּ?",
            "זה החתול! הוא התחבא בחבית. מְיָאוּ!",
            "the barrel is dark, the kitten is hidden deep inside the straw: only a small cat-shaped shadow",
            "the little orange and white kitten peeks out of the barrel, blinks curiously and meows; Pitzki giggles",
            "a cute small kitten meowing twice, soft, no background"),
        Animal("donkey", "חמור", "🫏", "אִי־אָה!",
            "איזה קול מצחיק! מי עושה אִי־אָה?",
            "זה החמור! יש לו אוזניים ארוכות ארוכות. אִי־אָה!",
            "the donkey is hidden behind the barn wall: only the tips of two long ears show above the fence",
            "the grey donkey comes up to the fence, wiggles its long ears one at a time and brays with its mouth open; Pitzki laughs gently",
            "a funny donkey braying hee-haw twice, no background"),
        Animal("horse", "סוס", "🐴", "הִי־הִי־הִי!",
            "מי צוהל שם, הִי־הִי־הִי? מי עושה את הקול?",
            "זה הסוס! הוא רץ מהר מהר. הִי־הִי־הִי!",
            "the stable is dark and the horse is hidden inside: only its shadow far behind the fence",
            "the brown horse with a white stripe on its face trots out of the stable to the fence, shakes its mane and neighs gently; Pitzki pats it",
            "a horse neighing once, cheerful, no background"),
        Animal("sheep", "כבשה", "🐑", "מֶהֶה!",
            "מי עושה מֶהֶה? מי מסתתר במרעה?",
            "זאת הכבשה! יש לה צמר רך ונעים. מֶהֶה!",
            "the sheep is hidden behind the big rocks and tall flowers of the pasture: nothing of it is seen",
            "the fluffy white sheep walks slowly out from behind the rocks, blinks and bleats softly; Pitzki smiles",
            "a gentle sheep bleating twice, soft, no background"),
    )

    fun animal(key: String) = ANIMALS.firstOrNull { key == it.key || key == it.open }

    /** Pitzki's talking videos in the farm: the hello at the gate, and a question for each animal (still hidden). */
    val TALKS: List<TrainWorld.Talk> = listOf(
        TrainWorld.Talk(INTRO,
            "שלום! איזה כיף שבאתם לחוות החברים! היום נגלה יחד מי משמיע כל קול. מקשיבים טוב טוב!",
            "", "Pitzki stands at the farm gate, waves hello happily, bounces a little and points toward the farm, talking excitedly to the camera."),
    ) + ANIMALS.map { a ->
        TrainWorld.Talk(a.key, a.ask, "",
            "Pitzki holds his hand by his ear, listening, then talks to the camera with a curious, excited face and a playful shrug. The hidden animal stays hidden.")
    }

    /** The scenes with the child (drawn and animated for each child): arriving, petting the dog, feeding the sheep, goodbye. */
    const val KID_INTRO = "farm_intro_kid"
    val CHILD_KEYS = listOf(KID_INTRO, "farm_dog_kid", "farm_sheep_kid", "farm_end_kid")

    val KEYS: List<String> get() = listOf("song", INTRO, KID_INTRO) +
        ANIMALS.flatMap { a -> listOf(a.key, a.open) + (if (a.id == "dog") listOf("farm_dog_kid") else if (a.id == "sheep") listOf("farm_sheep_kid") else emptyList()) } +
        listOf("farm_review", "farm_end_kid")

    /** Three pictures for an animal: it and two others (always the same, so the voice for them is made once). */
    private fun choices(i: Int): Pair<List<Choice>, Int> {
        val a = ANIMALS[i]
        val others = listOf(ANIMALS[(i + 2) % ANIMALS.size], ANIMALS[(i + 4) % ANIMALS.size])
        val list = others.map { Choice(it.emoji, it.he, 1.2f) }.toMutableList()
        val right = i % 3
        list.add(right, Choice(a.emoji, a.he, 1.2f))
        return list to right
    }

    fun lesson(kid: PitzkiKid): List<PitzkiScene> {
        val name = kid.name.trim()
        val nm = kid.named
        fun g(b: String, gi: String, all: String) = kid.g(b, gi, all)
        val p = nm
        val s = ArrayList<PitzkiScene>()
        fun add(key: String, title: String, vararg beats: Beat) { s.add(PitzkiScene(s.size + 1, key, title, null, beats.toList())) }
        fun talk(key: String) = Beat.Talk(key, TALKS.first { it.key == key }.text)

        add("song", "השיר של פיצקי", Beat.Song(0, 0, PitzkiScript.SONG.zip(PitzkiScript.SONG_AT).map { it.second to it.first }), Beat.Wait(500))
        add(INTRO, "חוות החברים", talk(INTRO), Beat.Wait(400))
        add(KID_INTRO, "מגיעים לחווה",
            Beat.Say("f_come", (if (nm) "$name, " else "") + g("בוא! תן לי יד!", "בואי! תני לי יד!", "בואו! תנו לי יד!"), personal = p),
            Beat.Say("f_ready_q", (if (nm) "$name, " else "") + g("מוכן?", "מוכנה?", "מוכנים?"), personal = p),
            Beat.Hear("f_ready", listOf("כן", "מוכן", "מוכנה", "בטח", "יאללה", "כן כן"), ok = "יאללה, מתחילים!", hint = "יאללה, מתחילים!"),
        )
        for ((i, a) in ANIMALS.withIndex()) {
            val (list, right) = choices(i)
            add(a.key, "מי עושה ${a.sound.trimEnd('!')}?",
                Beat.Sound(a.id, a.sound),
                talk(a.key),
                Beat.Pick("f_${a.id}_pick", list, right = right),
                Beat.Say("f_reveal_${a.id}", g("בוא נגלה מי זה!", "בואי נגלה מי זה!", "בואו נגלה מי זה!"), personal = p),
            )
            add(a.open, a.he,
                Beat.Say("f_${a.id}_is", a.reveal),
                Beat.Sound(a.id, a.sound),
                Beat.Wait(400),
            )
            if (a.id == "dog") add("farm_dog_kid", "ליטוף לכלב",
                Beat.Say("f_dog_pet", "הכלב רוצה ליטוף! " + g("תלטף אותו בעדינות.", "תלטפי אותו בעדינות.", "תלטפו אותו בעדינות."), personal = p),
                Beat.Say("f_dog_love", "איזה כלב חמוד! הוא אוהב " + g("אותך", "אותך", "אתכם") + "!", personal = p),
                Beat.Wait(800),
            )
            if (a.id == "sheep") add("farm_sheep_kid", "חציר לכבשה",
                Beat.Say("f_sheep_feed", "הכבשה רעבה. " + g("בוא ניתן לה קצת חציר.", "בואי ניתן לה קצת חציר.", "בואו ניתן לה קצת חציר."), personal = p),
                Beat.Say("f_sheep_eat", "ממממ! היא אוכלת בנחת. תודה!"),
                Beat.Wait(800),
            )
        }
        // A short game: three sounds again (no pictures yet), guess, then the animal is said.
        val review = listOf(1, 3, 0) // the cow, the cat, the rooster
        val beats = ArrayList<Beat>()
        beats.add(Beat.Say("f_game", (if (nm) "$name, " else "") + "איזה יופי! עכשיו משחק קצר!", personal = p))
        for (i in review) {
            val a = ANIMALS[i]
            val (list, right) = choices(i)
            beats.add(Beat.Sound(a.id, a.sound))
            beats.add(Beat.Say("f_game_q_${a.id}", "מי עושה את הקול?"))
            beats.add(Beat.Pick("f_game_${a.id}", list, right = right))
            beats.add(Beat.Say("f_game_is_${a.id}", if (a.he == "פרה" || a.he == "כבשה") "נכון, זאת ה${a.he}!" else "נכון, זה ה${a.he}!"))
        }
        add("farm_review", "משחק קולות", *beats.toTypedArray())
        add("farm_end_kid", "נתראה בהרפתקה הבאה",
            Beat.Celebrate,
            Beat.Say("f_bravo", (if (nm) "כל הכבוד, $name! " else "כל הכבוד! ") + "הכרנו את כל חברי החווה.", personal = p),
            Beat.Say("f_bye", "נתראה בהרפתקה הבאה!"),
        )
        return s
    }

    /** Where the child's scenes take place (said in every drawing). */
    const val SETTING = "a cozy, sunny storybook farm with a red barn, wooden fences, hay bales and a windmill, warm golden light"

    /** What happens in each of the child's scenes (the drawing). */
    fun childAction(key: String): String = when (key) {
        KID_INTRO -> "At the wooden gate of a sunny farm, the child stands next to Pitzki, both smiling at the camera, Pitzki waving hello; the farm path, the red barn and the windmill behind them."
        "farm_dog_kid" -> "Next to a wooden dog house, the child crouches beside a happy brown-and-white puppy and gently pets its head; the puppy wags its tail; Pitzki smiles beside them."
        "farm_sheep_kid" -> "In a green pasture by a wooden feeding trough, the child holds out a small handful of hay to a fluffy white sheep, which eats from it; Pitzki stands beside them smiling."
        else -> "Pitzki and the child stand together in the middle of a sunny farmyard, smiling at the camera; behind them, in a half circle and all clearly seen: a rooster, a black-and-white cow, a brown-and-white puppy, an orange-and-white kitten, a grey donkey, a brown horse with a white stripe, and a white sheep. No other animals."
    }

    /** How each of the child's scenes moves. */
    fun childMotion(key: String): String = when (key) {
        KID_INTRO -> "Pitzki waves to the camera; the child stands next to him and smiles; then both turn and walk a few steps together along the farm path toward the coop."
        "farm_dog_kid" -> "The child gently pets the puppy, which wags its tail happily, nuzzles the child's hand and stays by the child's side; Pitzki giggles."
        "farm_sheep_kid" -> "The child holds out the hay, the sheep steps closer, blinks and eats calmly from the child's hand; the child smiles happily; Pitzki claps softly."
        else -> "Pitzki and the child wave goodbye to the camera together; the animals behind them move gently and happily; the camera slowly pulls back to show the whole farm in warm sunlight."
    } + " The child does not talk: the child's mouth stays closed or in a natural smile."

    // ---------- the pictures (from the app's farm pictures) ----------

    /** The picture each scene starts from, in the app (assets/pitzki/farm): the gate, each animal seen, all of them. */
    fun asset(key: String): String? = when {
        key == INTRO -> "farm_gate"
        key == "farm_review" -> "farm_end"
        key.endsWith("_open") -> key
        else -> null
    }

    /** The question's picture: the same place as the animal's picture, the animal hidden (drawn from it). */
    fun hiddenPrompt(a: Animal): String =
        "Edit this picture: keep everything exactly the same (Pitzki the elf, his pose with his hand by his ear, the place, the light, " +
            "the style, the framing), but the ${a.id} is not visible: ${a.hidden}. Remove any white sound lines. " +
            "Exactly one Pitzki, no text, no letters."

    /** The gate's picture made clean: its sign without the (wrongly written) words. */
    const val GATE_PROMPT =
        "Edit this picture: keep everything exactly the same (Pitzki the elf, his pose, the farm gate, the barn, the animals, the light, " +
            "the style, the framing), but the wooden sign on the right is blank: no letters or words on it at all, only wood grain " +
            "and a small carved flower. Exactly one Pitzki, no text anywhere."

    /** The animal coming out: from the hidden picture to the seen one (5 seconds). */
    fun revealMotion(a: Animal) = "From hidden to seen: ${a.comesOut}. Pitzki stays the same elf, delighted. Smooth, gentle, slow camera. No text."
}

/** Pitzki's talking videos of every world (the train's and the farm's): shared, with their own sound. */
object PitzkiTalks {
    val ALL: List<TrainWorld.Talk> get() = TrainWorld.TALKS + FarmWorld.TALKS
    val KEYS: Set<String> get() = ALL.map { it.key }.toSet()
    fun get(key: String) = ALL.firstOrNull { it.key == key }
}
