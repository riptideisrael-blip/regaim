package com.regaim.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Answers from the stored record only. This does not inspect or infer what happened in a video. */
object MemoryFacts {
    /** Null means this question needs more than the record's explicit metadata. */
    fun answer(memory: Memory, question: String): String? {
        val q = question.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return null
        return when {
            listOf("באיזו שעה", "באיזה שעה", "מה השעה", "what time").any { it in q } ->
                if (memory.time <= 0) "לא נשמרה שעה לזיכרון הזה."
                else if (memory.timeSource == "imported") "הזיכרון נוסף בשעה ${format(memory.time, "HH:mm")}. שעת הצילום המקורית לא ידועה."
                else "לפי הזמן שנשמר, הזיכרון תועד בשעה ${format(memory.time, "HH:mm")}."

            listOf("באיזה יום", "באיזה תאריך", "מה התאריך", "מתי צולם", "מתי זה צולם", "מתי תועד", "מתי זה קרה", "when was", "what date").any { it in q } ->
                if (memory.time <= 0) "לא נשמר תאריך לזיכרון הזה."
                else if (memory.timeSource == "imported") "הזיכרון נוסף ב־${format(memory.time, "EEEE, d.M.yyyy")} בשעה ${format(memory.time, "HH:mm")}. תאריך הצילום המקורי לא ידוע."
                else "לפי הזמן שנשמר, הזיכרון תועד ב־${format(memory.time, "EEEE, d.M.yyyy")} בשעה ${format(memory.time, "HH:mm")}."

            listOf("איפה זה", "איפה צולם", "איפה היינו", "באיזה מקום", "מה המיקום", "איפה זה היה", "where was", "where were").any { it in q } ->
                if (memory.place.isNotBlank()) "המקום שנשמר לזיכרון הזה: ${memory.place}."
                else "לא נשמר מקום לזיכרון הזה, אז איני יודעת איפה הוא צולם."

            listOf("מי היה שם", "מי היה ברגע", "מי מופיע", "מי נמצא", "מי השתתף", "מי היו שם", "who was there", "who is in").any { it in q } -> {
                val identified = people(memory.people).filterNot { it in people(memory.hiddenPeople) }
                val added = people(memory.extraPeople).filterNot { it in people(memory.hiddenPeople) || it in identified }
                if (identified.isEmpty() && added.isEmpty()) {
                    "לא נשמרו שמות של משתתפים בזיכרון הזה. איני יכולה לדעת מי היה שם."
                } else buildString {
                    if (identified.isNotEmpty()) append("שמות מזיהוי הפנים: ${identified.joinToString(", ")}. הזיהוי עשוי לטעות.")
                    if (added.isNotEmpty()) {
                        if (isNotEmpty()) append("\n")
                        append("שמות שהוספת לזיכרון: ${added.joinToString(", ")}.")
                    }
                }
            }

            listOf("מה קרה ברגע", "מה קרה בזיכרון", "מה קרה כאן", "מה קרה פה", "what happened here").any { it in q } ->
                if (memory.description.isNotBlank()) "לפי התיאור שנשמר לזיכרון: ${memory.description}"
                else "עדיין אין תיאור לזיכרון הזה. מהפרטים שנשמרו איני יודעת לומר מה קרה בו."

            else -> null
        }
    }

    private fun people(value: String) = value.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    private fun format(time: Long, pattern: String) = SimpleDateFormat(pattern, Locale("he", "IL")).format(Date(time))
}
