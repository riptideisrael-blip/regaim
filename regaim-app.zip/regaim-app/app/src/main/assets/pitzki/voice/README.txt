Pitzki's recorded voice (optional). Put an mp3 here with the file name on the left, and the app plays it instead of the phone's voice.
Lines with the child's name (e.g. 'שלום אורי!') always use the phone's voice; the ones marked 'only when no child is chosen' are their no-name versions.

s1_hello.mp3	שלום חברים! אני פיצקי, שדון היער.	(only when no child is chosen)
s1_trip.mp3	היום נצא יחד לטיול ביער, ונלמד צבעים באנגלית.
s1_ready.mp3	מוכנים?	(only when no child is chosen)
s1_go.mp3	בואו!	(only when no child is chosen)
s2_pretty.mp3	איזה יער יפה! נסתכל מסביב ונמצא צבעים.
s2_point.mp3	אפשר להצביע יחד איתי.
s3_green_found.mp3	וואו, תראו! עלה בצורת לב!
s3_green_which.mp3	איזה צבע יש לעלה?
s3_green_he.mp3	ירוק!
s3_green_en.mp3	באנגלית אומרים
s3_green_together.mp3	תגידו איתי:	(only when no child is chosen)
s3_green_tap.mp3	תלחצו על העלה הירוק.	(only when no child is chosen)
s4_brown_found.mp3	וואו, תראו! עץ גדול! תראו את הגזע שלו.
s4_brown_which.mp3	איזה צבע יש לגזע?
s4_brown_he.mp3	חום!
s4_brown_en.mp3	באנגלית אומרים
s4_brown_together.mp3	תגידו איתי:	(only when no child is chosen)
s4_brown_tap.mp3	תלחצו על הגזע החום.	(only when no child is chosen)
s5_red_found.mp3	וואו, תראו! תפוח על הענף!
s5_red_which.mp3	איזה צבע יש לתפוח?
s5_red_he.mp3	אדום!
s5_red_en.mp3	באנגלית אומרים
s5_red_together.mp3	תגידו איתי:	(only when no child is chosen)
s5_red_tap.mp3	תלחצו על התפוח האדום.	(only when no child is chosen)
s6_yellow_found.mp3	וואו, תראו! פרח שמש קטן!
s6_yellow_which.mp3	איזה צבע יש לפרח?
s6_yellow_he.mp3	צהוב!
s6_yellow_en.mp3	באנגלית אומרים
s6_yellow_together.mp3	תגידו איתי:	(only when no child is chosen)
s6_yellow_tap.mp3	תלחצו על הפרח הצהוב.	(only when no child is chosen)
s7_gray_found.mp3	וואו, תראו! אבן ליד הרגליים שלנו!
s7_gray_which.mp3	איזה צבע יש לאבן?
s7_gray_he.mp3	אפור!
s7_gray_en.mp3	באנגלית אומרים
s7_gray_together.mp3	תגידו איתי:	(only when no child is chosen)
s7_gray_tap.mp3	תלחצו על האבן האפורה.	(only when no child is chosen)
s8_check.mp3	עכשיו בואו נבדוק מה זכרנו!	(only when no child is chosen)
s8_where_red.mp3	איפה האדום?
s8_where_green.mp3	איפה הירוק?
s8_where_yellow.mp3	איפה הצהוב?
s8_where_gray.mp3	איפה האפור?
s8_where_brown.mp3	איפה החום?
s8_wonderful.mp3	איזה טיול נפלא! היום למדנו:
s8_bye.mp3	נתראה בהרפתקה הבאה!	(only when no child is chosen)
