Put regular.ttf and bold.ttf here (for example Heebo or Assistant). Optional.
