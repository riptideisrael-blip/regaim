Put regular.ttf and bold.ttf here (for example Heebo or Assistant). Optional.

Big headings use a serif display font. For the look in the design reference, download "Frank Ruhl Libre" (Bold) from
Google Fonts (free, OFL license), rename the file to display.ttf and put it here in assets/fonts/. Without it, the
phone's own serif font is used.
