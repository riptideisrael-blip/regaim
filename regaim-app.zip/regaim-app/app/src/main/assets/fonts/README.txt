App font (SIL Open Font License, Google Fonts), downloaded automatically at build time (see app/build.gradle.kts):
- heebo.ttf: Heebo (variable), used for all text; headings use a heavier weight.
- heebo-OFL.txt: its license.
Older optional overrides still work: regular.ttf, bold.ttf, display.ttf.
