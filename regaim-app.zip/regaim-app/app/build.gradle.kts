plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.regaim.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.regaim.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 22
        versionName = "0.22"
    }

    // A fixed prototype key, so each new build installs over the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("regaim-debug.keystore")
            storePassword = "regaim123"
            keyAlias = "regaim"
            keyPassword = "regaim123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        // ContextWrapper is supplied by the Android mockable JAR. Profile
        // tests override preferences with a real in-memory implementation.
        unitTests.isReturnDefaultValues = true
    }

    androidResources {
        noCompress.add("tflite")
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.tensorflow:tensorflow-lite-task-audio:0.4.4")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
}
