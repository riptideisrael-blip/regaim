import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.regaim.app"
    // The GitHub build runs Gradle 8.9, whose newest Android plugin (8.7) builds against Android 15 (API 35).
    compileSdk = 35

    defaultConfig {
        applicationId = "com.regaim.app"
        minSdk = 26
        // Google Play requires Android 16 (API 36) for new apps and updates from 31.8.2026. The app behaves as an
        // Android 16 app (screen edges, back button) while being built against Android 15's tools.
        targetSdk = 36
        // Every GitHub build gets a higher number on its own, matching "גרסה N" on the Releases page.
        val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0
        versionCode = 100 + runNumber
        versionName = "0.42 · build $runNumber"
        // Modern phones only (64-bit ARM): leaves out the extra copies of the AI libraries, about half the download.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // A fixed prototype key, so each new build installs over the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("regaim-debug.keystore")
            storePassword = "regaim123"
            keyAlias = "regaim"
            keyPassword = "regaim123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        // ContextWrapper is supplied by the Android mockable JAR. Profile
        // tests override preferences with a real in-memory implementation.
        unitTests.isReturnDefaultValues = true
    }

    androidResources {
        noCompress.add("tflite")
    }

    // A newer build toolchain brings new lint checks: they're reported (in the build's reports), not a failed build.
    lint {
        abortOnError = false
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    // Lets Android finish finding faces in the background even after it closed the app (official, by Google).
    implementation("androidx.work:work-runtime:2.9.1")
    implementation("org.tensorflow:tensorflow-lite-task-audio:0.4.4")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("androidx.media3:media3-transformer:1.3.1")
    implementation("androidx.media3:media3-effect:1.3.1")
    implementation("androidx.media3:media3-common:1.3.1")
    // Paying for books through Google Play (off until the server turns payments on).
    implementation("com.android.billingclient:billing:8.0.0")
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
}

// The app's font (SIL Open Font License, from Google Fonts): Heebo, for all text and headings.
// Downloaded once at build time if they aren't in the project yet. If the download fails the build still works,
// and the app falls back to the phone's own fonts.
val fetchFonts by tasks.registering {
    val dir = file("src/main/assets/fonts")
    val files = mapOf(
        "heebo.ttf" to "https://github.com/google/fonts/raw/main/ofl/heebo/Heebo%5Bwght%5D.ttf",
        "heebo-OFL.txt" to "https://github.com/google/fonts/raw/main/ofl/heebo/OFL.txt",
        // Rubik (SIL Open Font License): rounded and soft, light headings like premium photo-book brands.
        "rubik.ttf" to "https://github.com/google/fonts/raw/main/ofl/rubik/Rubik%5Bwght%5D.ttf",
        "rubik-OFL.txt" to "https://github.com/google/fonts/raw/main/ofl/rubik/OFL.txt",
    )
    doLast {
        dir.mkdirs()
        for ((name, url) in files) {
            val out = File(dir, name)
            if (out.exists() && out.length() > 1000) continue
            try {
                (URL(url).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }).getInputStream().use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                if (out.length() < 1000) { out.delete(); logger.warn("Font file too small, skipped: $name") }
            } catch (e: Exception) {
                out.delete()
                logger.warn("Font download failed for $name: ${e.message}")
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchFonts) }
